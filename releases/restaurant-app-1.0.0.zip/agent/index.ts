// The local print agent. Run from the repo root with `npm run agent` (or
// `npx tsx -r dotenv/config agent/index.ts`). Stays running on a Windows machine at the
// restaurant, polls the cloud app for pending print jobs, and executes them against real
// printers — this is the piece that lets printing keep working once the app itself is
// hosted somewhere that can no longer reach a restaurant's USB port or LAN directly.
import { replayCommands, type TicketCommand, type PrinterConfig } from "../src/lib/ticketWriter";
import { createPrinter } from "./printerExecution";
import { listInstalledPrinters, discoverNetworkPrinters } from "./printerDiscovery";

const BASE_URL = (process.env.PUBLIC_BASE_URL ?? "http://localhost:3000").replace(/\/$/, "");
const AGENT_TOKEN = process.env.AGENT_TOKEN;
const POLL_INTERVAL_MS = 2500;

if (!AGENT_TOKEN) {
  console.error("AGENT_TOKEN is not set. Copy the agent token from Settings → Receipts into .env.");
  process.exit(1);
}

interface PrintJob {
  id: string;
  type: "RECEIPT" | "TICKET" | "SUMMARY" | "TEST" | "LIST_INSTALLED" | "DISCOVER_NETWORK";
  payload: { printerConfig?: PrinterConfig; commands?: TicketCommand[] };
}

async function pollForJob(): Promise<PrintJob | null> {
  const res = await fetch(`${BASE_URL}/api/agent/poll`, {
    method: "POST",
    headers: { Authorization: `Bearer ${AGENT_TOKEN}` },
  });
  if (!res.ok) {
    throw new Error(`Poll failed: ${res.status} ${await res.text().catch(() => "")}`);
  }
  const body = (await res.json()) as { job: PrintJob | null };
  return body.job;
}

async function completeJob(id: string, result: { status: "DONE"; result?: unknown } | { status: "FAILED"; error: string }) {
  await fetch(`${BASE_URL}/api/agent/jobs/${id}/complete`, {
    method: "POST",
    headers: { Authorization: `Bearer ${AGENT_TOKEN}`, "Content-Type": "application/json" },
    body: JSON.stringify(result),
  });
}

async function runJob(job: PrintJob): Promise<void> {
  switch (job.type) {
    case "LIST_INSTALLED": {
      const printers = await listInstalledPrinters();
      await completeJob(job.id, { status: "DONE", result: printers });
      return;
    }
    case "DISCOVER_NETWORK": {
      const printers = await discoverNetworkPrinters();
      await completeJob(job.id, { status: "DONE", result: printers });
      return;
    }
    case "RECEIPT":
    case "TICKET":
    case "SUMMARY":
    case "TEST": {
      const { printerConfig, commands } = job.payload;
      if (!printerConfig || !commands) {
        await completeJob(job.id, { status: "FAILED", error: "Malformed job payload." });
        return;
      }
      const { writer, finish } = createPrinter(printerConfig);
      await replayCommands(writer, commands);
      const result = await finish();
      await completeJob(job.id, { status: "DONE", result: result.recoveredIp ? result : undefined });
      return;
    }
  }
}

async function loop() {
  console.log(`Print agent started — polling ${BASE_URL}`);
  for (;;) {
    try {
      const job = await pollForJob();
      if (job) {
        console.log(`Running job ${job.id} (${job.type})`);
        try {
          await runJob(job);
          console.log(`Job ${job.id} done`);
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          console.error(`Job ${job.id} failed: ${message}`);
          await completeJob(job.id, { status: "FAILED", error: message }).catch(() => {});
        }
        continue; // check for another job immediately rather than waiting out the interval
      }
    } catch (err) {
      console.error("Poll error:", err instanceof Error ? err.message : err);
    }
    await new Promise((resolve) => setTimeout(resolve, POLL_INTERVAL_MS));
  }
}

loop();
