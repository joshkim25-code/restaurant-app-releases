import os from "os";
import net from "net";
import dns from "dns/promises";
import { execFile } from "child_process";
import { promisify } from "util";
import type { InstalledPrinter, DiscoveredNetworkPrinter } from "../src/lib/printerDiscovery";

const execFileAsync = promisify(execFile);

const FRIENDLY_STATUS: Record<string, string> = {
  Normal: "Ready",
  Offline: "Offline",
  Error: "Error",
  PaperOut: "Out of paper",
  PendingDeletion: "Removed",
};

function friendlyStatus(status: string): string {
  return FRIENDLY_STATUS[status] ?? status;
}

// Lists printers Windows already knows about (installed via any connection —
// USB, Bluetooth, etc.), so restaurant owners can pick one instead of typing a name.
export async function listInstalledPrinters(): Promise<InstalledPrinter[]> {
  try {
    const { stdout } = await execFileAsync("powershell.exe", [
      "-NoProfile",
      "-NonInteractive",
      "-Command",
      "Get-Printer | Select-Object Name,@{N='PrinterStatus';E={$_.PrinterStatus.ToString()}} | ConvertTo-Json",
    ]);
    const trimmed = stdout.trim();
    if (!trimmed) return [];
    const parsed: unknown = JSON.parse(trimmed);
    const rows = Array.isArray(parsed) ? parsed : [parsed];
    return rows
      .filter((row): row is { Name: string; PrinterStatus: string } =>
        Boolean(row && typeof row === "object" && "Name" in row && row.PrinterStatus !== "PendingDeletion")
      )
      .map((row) => ({ name: row.Name, status: friendlyStatus(String(row.PrinterStatus ?? "Unknown")) }));
  } catch {
    return [];
  }
}

const PRINTER_PORT = 9100;
const PROBE_TIMEOUT_MS = 400;
const SCAN_CONCURRENCY = 30;

function probePort(ip: string): Promise<boolean> {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let settled = false;
    const done = (result: boolean) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve(result);
    };
    socket.setTimeout(PROBE_TIMEOUT_MS);
    socket.once("connect", () => done(true));
    socket.once("timeout", () => done(false));
    socket.once("error", () => done(false));
    socket.connect(PRINTER_PORT, ip);
  });
}

function localIPv4Subnets(): string[] {
  const prefixes = new Set<string>();
  for (const addrs of Object.values(os.networkInterfaces())) {
    for (const addr of addrs ?? []) {
      if (addr.family === "IPv4" && !addr.internal) {
        const parts = addr.address.split(".");
        if (parts.length === 4) prefixes.add(parts.slice(0, 3).join("."));
      }
    }
  }
  return [...prefixes];
}

// Scans the local /24 subnet(s) for devices with the standard raw-printing port
// (9100) open, so restaurant owners can pick a network printer instead of typing an IP.
export async function discoverNetworkPrinters(): Promise<DiscoveredNetworkPrinter[]> {
  const subnets = localIPv4Subnets();
  const candidates: string[] = [];
  for (const prefix of subnets) {
    for (let host = 1; host <= 254; host++) {
      candidates.push(`${prefix}.${host}`);
    }
  }

  const found: string[] = [];
  for (let i = 0; i < candidates.length; i += SCAN_CONCURRENCY) {
    const batch = candidates.slice(i, i + SCAN_CONCURRENCY);
    const results = await Promise.all(batch.map(async (ip) => ((await probePort(ip)) ? ip : null)));
    for (const ip of results) {
      if (ip) found.push(ip);
    }
  }

  return Promise.all(
    found.map(async (ip) => {
      const hostname = await dns.reverse(ip).then(
        (names) => names[0] ?? null,
        () => null
      );
      return { ip, hostname };
    })
  );
}
