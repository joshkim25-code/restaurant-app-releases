// Everything hardware-facing lives here: this is the code that used to run inside the
// Next.js server (src/lib/thermalPrinter.ts) before printing moved to a local agent.
// Same three delivery mechanisms as before — raw TCP to network ESC/POS printers, the
// Windows print spooler for USB thermal printers, and a bundled SumatraPDF for "standard"
// printers — moved out of the cloud app verbatim, just now driven by a replayed command
// list (see ../src/lib/ticketWriter.ts) instead of being called directly in-process.
import fs from "fs/promises";
import { createWriteStream } from "fs";
import os from "os";
import path from "path";
import { execFile } from "child_process";
import { promisify } from "util";
import { ThermalPrinter, PrinterTypes, CharacterSet } from "node-thermal-printer";
import PDFDocument from "pdfkit";
import { print as printPdf } from "pdf-to-printer";
import type { PrinterConfig, TicketWriter } from "../src/lib/ticketWriter";
import {
  needsImageRendering,
  renderTextToPng,
  renderBitImageColumns,
  splitIntoRuns,
  BIT_IMAGE_MODE_24_DOT,
  BIT_IMAGE_SAFE_INLINE_WIDTH_DOTS,
} from "./unicodeText";
import { discoverNetworkPrinters } from "./printerDiscovery";

// What createPrinter()'s finish() reports back to the job queue once a print completes -
// recoveredIp is set only when the configured IP was unreachable but a same-network retry
// (see the network branch below) succeeded against a different address.
export interface PrintResult {
  recoveredIp?: string;
}

type PrinterConnection =
  | { type: "network"; ip: string; port: number }
  | { type: "usb"; printerName: string };

function resolveConnection(printer: PrinterConfig): PrinterConnection | null {
  if (printer.connectionType === "usb") {
    return printer.printerName ? { type: "usb", printerName: printer.printerName } : null;
  }
  return printer.ipAddress ? { type: "network", ip: printer.ipAddress, port: printer.port } : null;
}

const execFileAsync = promisify(execFile);
const printRawScriptPath = path.join(process.cwd(), "scripts", "print-raw.ps1");
// pdf-to-printer locates its bundled SumatraPDF binary via `__dirname`, which doesn't
// resolve correctly once run through tsx — point at the real on-disk path ourselves.
const sumatraPdfPath = path.join(
  process.cwd(),
  "node_modules",
  "pdf-to-printer",
  "dist",
  "SumatraPDF-3.4.6-32.exe"
);

// Sends bytes straight to a printer via the Windows print spooler (winspool.drv), through
// a bundled PowerShell script. No printer sharing or firewall access needed — this works
// for any printer Windows already knows about, USB or otherwise.
async function sendRawToPrinter(printerName: string, buffer: Buffer, dataType: "RAW" | "TEXT" = "RAW") {
  const tempPath = path.join(os.tmpdir(), `print-${Date.now()}-${Math.random().toString(36).slice(2)}.prn`);
  await fs.writeFile(tempPath, buffer);
  try {
    await execFileAsync("powershell.exe", [
      "-NoProfile",
      "-NonInteractive",
      "-ExecutionPolicy",
      "Bypass",
      "-File",
      printRawScriptPath,
      "-PrinterName",
      printerName,
      "-FilePath",
      tempPath,
      "-DataType",
      dataType,
    ]);
  } finally {
    await fs.unlink(tempPath).catch(() => {});
  }
}

const PLAIN_TEXT_WIDTH = 42;

// Renders ticket content for a normal (non-POS) printer as an actual PDF page, printed
// through the printer's real driver pipeline (via a bundled SumatraPDF binary).
const NORMAL_FONT_SIZE = 10;
const LARGE_FONT_SIZE = 14;

// Not a monospace font, so a line using it won't line up character-for-character with
// Courier's space-padding — an acceptable tradeoff, since this only affects a line that
// would otherwise be missing entirely, not the normal (Courier) case.
const UNICODE_FONT_PATH = "C:\\Windows\\Fonts\\malgun.ttf";
const UNICODE_FONT_NAME = "Malgun Gothic";

class StandardPrinterWriter implements TicketWriter {
  private lines: { text: string; fontSize: number; unicode: boolean }[] = [];
  private align: "left" | "center" = "left";
  private isBold = false;
  private fontSize = NORMAL_FONT_SIZE;

  alignCenter() {
    this.align = "center";
  }
  alignLeft() {
    this.align = "left";
  }
  bold(on: boolean) {
    this.isBold = on;
  }
  println(text: string) {
    const content = this.isBold ? text.toUpperCase() : text;
    const unicode = needsImageRendering(content);
    if (this.align === "center" && !unicode) {
      const pad = Math.max(0, Math.floor((PLAIN_TEXT_WIDTH - content.length) / 2));
      this.lines.push({ text: " ".repeat(pad) + content, fontSize: this.fontSize, unicode });
    } else {
      this.lines.push({ text: content, fontSize: this.fontSize, unicode });
    }
  }
  leftRight(left: string, right: string) {
    const unicode = needsImageRendering(left) || needsImageRendering(right);
    const gap = Math.max(1, PLAIN_TEXT_WIDTH - left.length - right.length);
    this.lines.push({ text: left + " ".repeat(gap) + right, fontSize: this.fontSize, unicode });
  }
  drawLine() {
    this.lines.push({ text: "-".repeat(PLAIN_TEXT_WIDTH), fontSize: this.fontSize, unicode: false });
  }
  textSize(size: "normal" | "large") {
    this.fontSize = size === "large" ? LARGE_FONT_SIZE : NORMAL_FONT_SIZE;
  }
  cut() {
    // No physical cut for a normal printer — nothing to add.
  }

  async printTo(printerName: string) {
    const tempPath = path.join(os.tmpdir(), `print-${Date.now()}-${Math.random().toString(36).slice(2)}.pdf`);
    await new Promise<void>((resolve, reject) => {
      const doc = new PDFDocument({ margin: 36 });
      const stream = doc.pipe(createWriteStream(tempPath));
      try {
        doc.registerFont(UNICODE_FONT_NAME, UNICODE_FONT_PATH);
      } catch {
        // Font not present on this machine - unicode lines fall back to Courier (tofu
        // boxes for unsupported glyphs) rather than crashing the whole print job.
      }
      for (const line of this.lines) {
        doc.font(line.unicode ? UNICODE_FONT_NAME : "Courier");
        doc.fontSize(line.fontSize).text(line.text);
      }
      doc.end();
      stream.on("finish", resolve);
      stream.on("error", reject);
    });
    try {
      await printPdf(tempPath, { printer: printerName, silent: true, sumatraPdfPath });
    } finally {
      await fs.unlink(tempPath).catch(() => {});
    }
  }
}

class EscPosWriter implements TicketWriter {
  private align: "left" | "center" = "left";
  private isBold = false;

  constructor(private printer: ThermalPrinter) {}

  alignCenter() {
    this.align = "center";
    this.printer.alignCenter();
  }
  alignLeft() {
    this.align = "left";
    this.printer.alignLeft();
  }
  bold(on: boolean) {
    this.isBold = on;
    this.printer.bold(on);
  }
  // The printer's own character table (WPC1252) can't represent everything - anything
  // outside it (Korean text, symbols like ▲▶, emoji) is rendered as a small image and
  // sent as a raster print instead, since ESC/POS text commands have no way to say it.
  // Only the unsupported characters themselves become an image - everything else in the
  // line stays real ESC/POS text, so a mostly-plain line doesn't turn entirely into a
  // (slower, blurrier) picture just because of one symbol in it.
  async println(text: string) {
    if (!needsImageRendering(text)) {
      this.printer.println(text);
      return;
    }
    await this.printMixedLine(text);
  }
  async leftRight(left: string, right: string) {
    if (!needsImageRendering(left) && !needsImageRendering(right)) {
      this.printer.leftRight(left, right);
      return;
    }
    const width = this.printer.getWidth();
    const gap = Math.max(1, width - left.length - right.length);
    await this.printMixedLine(left + " ".repeat(gap) + right);
  }
  // Builds the raw ESC * command for a run of text, or returns null when the rendered
  // image is too wide to safely print inline (see BIT_IMAGE_SAFE_INLINE_WIDTH_DOTS) - the
  // caller falls back to GS v 0 (its own line) in that case. Command layout per the spec:
  // 0x1B 0x2A m nL nH d1...dk, where m selects the mode and nL/nH are the width in dots
  // as a little-endian 16-bit value.
  private tryRenderInline(text: string): Buffer | null {
    const { widthDots, data } = renderBitImageColumns(text, { bold: this.isBold });
    if (widthDots > BIT_IMAGE_SAFE_INLINE_WIDTH_DOTS) return null;
    const header = Buffer.from([0x1b, 0x2a, BIT_IMAGE_MODE_24_DOT, widthDots & 0xff, (widthDots >> 8) & 0xff]);
    return Buffer.concat([header, data]);
  }

  // ESC & (define user-defined character) is confirmed unsupported on this printer -
  // it printed the raw command bytes as garbage text instead of ignoring it. ESC *
  // (bit-image mode) is confirmed to genuinely print inline (unlike GS v 0, which always
  // starts its own line here) - but there's no way to know how much of the current line
  // is already used by preceding text, so a wide inline image can overrun the page and
  // get cut off (also confirmed by a real test). Only attempted when the rendered image
  // is small enough to almost certainly still fit regardless of position; anything wider
  // falls back to GS v 0's own-line behavior, which has no such risk since it always
  // starts fresh at the left margin.
  private async printMixedLine(text: string) {
    for (const run of splitIntoRuns(text)) {
      if (!run.text) continue;
      if (!run.needsImage) {
        this.printer.print(run.text);
        continue;
      }
      const inline = this.tryRenderInline(run.text);
      if (inline) {
        this.printer.add(inline);
      } else {
        const png = renderTextToPng(run.text, { bold: this.isBold, align: "left" });
        await this.printer.printImageBuffer(png);
      }
    }
    this.printer.println(""); // the line's own trailing newline, after all its runs
  }
  drawLine() {
    this.printer.drawLine();
  }
  textSize(size: "normal" | "large") {
    if (size === "large") {
      this.printer.setTextSize(1, 1);
    } else {
      this.printer.setTextNormal();
    }
  }
  cut() {
    this.printer.cut();
  }
}

export function createPrinter(printer: PrinterConfig): { writer: TicketWriter; finish: () => Promise<PrintResult> } {
  if (printer.kind === "STANDARD") {
    if (!printer.printerName) {
      throw new Error(`"${printer.name}" isn't configured yet. Set it up in Settings → Receipts.`);
    }
    const writer = new StandardPrinterWriter();
    const finish = async (): Promise<PrintResult> => {
      try {
        await writer.printTo(printer.printerName as string);
        return {};
      } catch (err) {
        const reason = err instanceof Error ? err.message : String(err);
        throw new Error(
          `Could not print via "${printer.name}" — check it's powered on and connected. (${reason})`
        );
      }
    };
    return { writer, finish };
  }

  const connection = resolveConnection(printer);
  if (!connection) {
    throw new Error(`"${printer.name}" isn't configured yet. Set it up in Settings → Receipts.`);
  }

  if (connection.type === "usb") {
    const escposPrinter = new ThermalPrinter({
      type: PrinterTypes.EPSON,
      // Unused — the built buffer is sent directly to the printer via the spooler below.
      interface: "usb-buffer",
      characterSet: CharacterSet.WPC1252,
    });
    const finish = async (): Promise<PrintResult> => {
      try {
        await sendRawToPrinter(connection.printerName, escposPrinter.getBuffer(), "RAW");
        return {};
      } catch (err) {
        const reason = err instanceof Error ? err.message : String(err);
        throw new Error(
          `Could not print via "${printer.name}" — check it's powered on and connected. (${reason})`
        );
      }
    };
    return { writer: new EscPosWriter(escposPrinter), finish };
  }

  const escposPrinter = new ThermalPrinter({
    type: PrinterTypes.EPSON,
    interface: `tcp://${connection.ip}:${connection.port}`,
    characterSet: CharacterSet.WPC1252,
    options: { timeout: 5000 },
  });
  const finish = async (): Promise<PrintResult> => {
    try {
      await escposPrinter.execute();
      return {};
    } catch {
      // The configured IP might just be stale - printers on a restaurant's network are
      // usually DHCP-assigned and can get a new address on reconnect (confirmed to happen
      // here, unlike a stable home network). A failed execute() doesn't clear the printer's
      // buffer (see node_modules/node-thermal-printer/lib/core.js), so the exact same bytes
      // can be resent elsewhere without replaying the original print commands.
      let candidates: Awaited<ReturnType<typeof discoverNetworkPrinters>> = [];
      try {
        candidates = await discoverNetworkPrinters();
      } catch {
        // Best-effort - fall through to the error below if the scan itself fails.
      }
      const candidate =
        candidates.length === 1 && candidates[0].ip !== connection.ip ? candidates[0] : null;
      if (candidate) {
        try {
          const retryPrinter = new ThermalPrinter({
            type: PrinterTypes.EPSON,
            interface: `tcp://${candidate.ip}:${connection.port}`,
            characterSet: CharacterSet.WPC1252,
            options: { timeout: 5000 },
          });
          retryPrinter.setBuffer(escposPrinter.getBuffer());
          await retryPrinter.execute();
          return { recoveredIp: candidate.ip };
        } catch {
          // Recovery attempt failed too - fall through to the error below.
        }
      }
      throw new Error(
        `Could not reach "${printer.name}" at ${connection.ip}:${connection.port} — check it's powered on and connected to the network. If its IP address changed, use "Scan for network printers" in Settings → Receipts.`
      );
    }
  };
  return { writer: new EscPosWriter(escposPrinter), finish };
}
