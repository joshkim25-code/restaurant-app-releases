// Thermal receipt printers only understand a single-byte character table (WPC1252 here) -
// arrows, symbols, and non-Latin scripts like Korean have no representation in it at all.
// This renders just the offending line as a small bitmap image instead, using fonts that
// ship with Windows, so it can still be sent to the printer (as a raster image, not text).
import { createCanvas, GlobalFonts } from "@napi-rs/canvas";
import path from "path";

let fontsRegistered = false;
function ensureFontsRegistered() {
  if (fontsRegistered) return;
  fontsRegistered = true;
  const fontsDir = "C:\\Windows\\Fonts";
  // Malgun Gothic covers Latin + Korean; Segoe UI Symbol covers arrows/geometric symbols.
  // Best-effort - a missing font just means those specific glyphs render as a blank box
  // instead of the print job crashing.
  try {
    GlobalFonts.registerFromPath(path.join(fontsDir, "malgun.ttf"), "Malgun Gothic");
  } catch {
    // Font not present on this machine - fall through to whatever GlobalFonts already has.
  }
  try {
    GlobalFonts.registerFromPath(path.join(fontsDir, "seguisym.ttf"), "Segoe UI Symbol");
  } catch {
    // Same.
  }
}

// The sparse 0x80-0x9F range in WPC1252 isn't identical to raw Latin-1 - these specific
// characters are what's actually printable there (curly quotes, em dash, €, etc.).
const WPC1252_EXTRAS = new Set(
  "\u20AC\u201A\u0192\u201E\u2026\u2020\u2021\u02C6\u2030\u0160\u2039\u0152\u017D\u2018\u2019\u201C\u201D\u2022\u2013\u2014\u02DC\u2122\u0161\u203A\u0153\u017E\u0178",
);

function charNeedsImageRendering(ch: string): boolean {
  const code = ch.codePointAt(0) ?? 0;
  if (code < 0x80) return false; // ASCII
  if (code >= 0xa0 && code <= 0xff) return false; // Latin-1 supplement, matches WPC1252 here
  if (WPC1252_EXTRAS.has(ch)) return false;
  return true;
}

export function needsImageRendering(text: string): boolean {
  for (const ch of text) {
    if (charNeedsImageRendering(ch)) return true;
  }
  return false;
}

// Splits a line into consecutive runs of "printable as real text" vs "needs an image" -
// so only the actual unsupported characters become small inline images, and everything
// else stays fast, crisp ESC/POS text instead of turning the whole line into one image.
export interface TextRun {
  text: string;
  needsImage: boolean;
}

export function splitIntoRuns(text: string): TextRun[] {
  const runs: TextRun[] = [];
  let current = "";
  let currentNeedsImage = false;
  let started = false;

  for (const ch of text) {
    const chNeedsImage = charNeedsImageRendering(ch);
    if (started && chNeedsImage === currentNeedsImage) {
      current += ch;
      continue;
    }
    if (started) runs.push({ text: current, needsImage: currentNeedsImage });
    current = ch;
    currentNeedsImage = chNeedsImage;
    started = true;
  }
  if (started) runs.push({ text: current, needsImage: currentNeedsImage });
  return runs;
}

// Conservative - fits even the narrowest common (58mm) thermal printer's print head, since
// this agent has no way to know the real physical width of whichever printer is connected.
const MAX_WIDTH_PX = 384;
const FONT_STACK = '"Malgun Gothic", "Segoe UI Symbol", sans-serif';

function roundUpToMultipleOf8(n: number): number {
  return Math.ceil(n / 8) * 8;
}

// One line of text, rendered as a PNG - shrinks to fit MAX_WIDTH_PX rather than risking
// the image getting cropped by a printer narrower than expected.
export function renderTextToPng(text: string, opts: { bold?: boolean; align?: "left" | "center" } = {}): Buffer {
  ensureFontsRegistered();
  const bold = opts.bold ?? false;

  const measureCtx = createCanvas(10, 10).getContext("2d");
  let fontSize = 32;
  const fontFor = (size: number) => `${bold ? "bold " : ""}${size}px ${FONT_STACK}`;
  measureCtx.font = fontFor(fontSize);
  let textWidth = measureCtx.measureText(text).width;
  while (textWidth > MAX_WIDTH_PX && fontSize > 14) {
    fontSize -= 2;
    measureCtx.font = fontFor(fontSize);
    textWidth = measureCtx.measureText(text).width;
  }

  const height = Math.ceil(fontSize * 1.4);
  const canvasWidth = Math.min(MAX_WIDTH_PX, roundUpToMultipleOf8(Math.ceil(textWidth) + 4));
  const canvas = createCanvas(canvasWidth, height);
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "white";
  ctx.fillRect(0, 0, canvasWidth, height);
  ctx.fillStyle = "black";
  ctx.font = fontFor(fontSize);
  ctx.textBaseline = "top";
  const x = opts.align === "center" ? Math.max(0, (canvasWidth - textWidth) / 2) : 2;
  ctx.fillText(text, x, 2);

  return canvas.toBuffer("image/png");
}

// ESC * (Select bit-image mode) - an older, more widely-cloned ESC/POS command than the
// raster mode above, specifically meant for printing a small graphic inline with text: per
// the spec (and unlike GS v 0, confirmed on this printer to always start its own line), it
// advances the print position horizontally by the image width rather than acting as a full
// block. Mode 32 = 24-dot single-density, so height is fixed at 24 dots (3 bytes/column) -
// that's set by the command itself, not something this code can choose.
export const BIT_IMAGE_MODE_24_DOT = 32;
const BIT_IMAGE_HEIGHT_DOTS = 24;
const BIT_IMAGE_HEIGHT_BYTES = 3; // 24 / 8
const BIT_IMAGE_MAX_WIDTH_DOTS = 512; // ESC * width is a 16-bit field; stay well under any printer's real max
// Font size controls glyph HEIGHT here - this is the value that renders at a normal-looking
// height next to real printed text; do not shrink it to narrow the glyph (that shrinks height
// too, which looked "smaller" rather than "thinner" - see BIT_IMAGE_WIDTH_SCALE for narrowing).
const BIT_IMAGE_DEFAULT_FONT_SIZE = 18;
// Applied as a horizontal-only canvas scale, independent of font size, so an inline symbol
// gets narrower without getting shorter - keeps it closer to a normal ESC/POS Font A cell's
// width (~12 dots) while its height still matches surrounding text.
const BIT_IMAGE_WIDTH_SCALE = 0.72;

// A printed line has no reliable way to know how much horizontal space is already used by
// text before it, so an inline image can only safely be attempted when it's small enough
// to almost certainly fit regardless of position - confirmed necessary after a real test
// where "Thank you " + a 50-dot image overran the page width and got cut off. Anything
// wider than this falls back to starting a fresh line instead (see printerExecution.ts).
export const BIT_IMAGE_SAFE_INLINE_WIDTH_DOTS = 40;

// Renders text into the column-major format ESC * expects: for each column (left to
// right), 3 bytes top to bottom, MSB = topmost dot.
export function renderBitImageColumns(text: string, opts: { bold?: boolean } = {}): { widthDots: number; data: Buffer } {
  ensureFontsRegistered();
  const bold = opts.bold ?? false;
  const fontFor = (size: number) => `${bold ? "bold " : ""}${size}px ${FONT_STACK}`;

  const measureCtx = createCanvas(10, 10).getContext("2d");
  let fontSize = BIT_IMAGE_DEFAULT_FONT_SIZE;
  measureCtx.font = fontFor(fontSize);
  let scaledTextWidth = measureCtx.measureText(text).width * BIT_IMAGE_WIDTH_SCALE;
  while (scaledTextWidth > BIT_IMAGE_MAX_WIDTH_DOTS && fontSize > 6) {
    fontSize -= 1;
    measureCtx.font = fontFor(fontSize);
    scaledTextWidth = measureCtx.measureText(text).width * BIT_IMAGE_WIDTH_SCALE;
  }

  const widthDots = Math.max(1, Math.min(BIT_IMAGE_MAX_WIDTH_DOTS, Math.ceil(scaledTextWidth) + 2));
  const canvas = createCanvas(widthDots, BIT_IMAGE_HEIGHT_DOTS);
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "white";
  ctx.fillRect(0, 0, widthDots, BIT_IMAGE_HEIGHT_DOTS);
  ctx.fillStyle = "black";
  ctx.font = fontFor(fontSize);
  ctx.textBaseline = "top";
  const yOffset = Math.max(0, (BIT_IMAGE_HEIGHT_DOTS - fontSize) / 2);
  // Scale only the x axis so the glyph narrows without also getting shorter - a uniform
  // scale (or just a smaller font size) would shrink both dimensions together.
  ctx.save();
  ctx.scale(BIT_IMAGE_WIDTH_SCALE, 1);
  ctx.fillText(text, 1 / BIT_IMAGE_WIDTH_SCALE, yOffset);
  ctx.restore();

  const { data: pixels } = ctx.getImageData(0, 0, widthDots, BIT_IMAGE_HEIGHT_DOTS);
  const data = Buffer.alloc(widthDots * BIT_IMAGE_HEIGHT_BYTES);
  for (let x = 0; x < widthDots; x++) {
    for (let byteRow = 0; byteRow < BIT_IMAGE_HEIGHT_BYTES; byteRow++) {
      let byte = 0;
      for (let bit = 0; bit < 8; bit++) {
        const y = byteRow * 8 + bit;
        if (y >= BIT_IMAGE_HEIGHT_DOTS) continue;
        const idx = (y * widthDots + x) * 4;
        if (pixels[idx + 3] <= 126) continue; // transparent
        const gray = 0.2126 * pixels[idx] + 0.7152 * pixels[idx + 1] + 0.0722 * pixels[idx + 2];
        if (gray < 128) byte |= 1 << (7 - bit);
      }
      data[x * BIT_IMAGE_HEIGHT_BYTES + byteRow] = byte;
    }
  }
  return { widthDots, data };
}
