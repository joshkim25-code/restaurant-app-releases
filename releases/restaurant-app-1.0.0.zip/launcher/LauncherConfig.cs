using System.Text.Json;
using System.Text.Json.Serialization;

namespace RestaurantLauncher;

/// <summary>
/// Small local config file (launcher.config.json, next to the exe) so the manifest URL and
/// install directory can be pointed at a throwaway test release/location without rebuilding
/// the launcher - useful for Phase 1's "prove this on a second machine first" verification
/// step (see launcher/README.md). Falls back to sensible defaults if the file is missing.
/// </summary>
public sealed class LauncherConfig
{
    [JsonPropertyName("manifestUrl")]
    public string ManifestUrl { get; set; } =
        // Placeholder until the dedicated (public, source-free) releases repo is created -
        // see launcher/README.md's "Release hosting" section. Update this default, or point
        // a launcher.config.json at the real one, once that repo exists.
        "https://raw.githubusercontent.com/joshkim25-code/restaurant-app-releases/main/latest.json";

    [JsonPropertyName("installDir")]
    public string InstallDir { get; set; } = @"C:\ProgramData\RestaurantApp\app";

    [JsonPropertyName("appUrl")]
    public string AppUrl { get; set; } = "http://localhost:3000";

    public static LauncherConfig Load(string exeDirectory)
    {
        var path = Path.Combine(exeDirectory, "launcher.config.json");
        if (!File.Exists(path)) return new LauncherConfig();

        try
        {
            var json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<LauncherConfig>(json) ?? new LauncherConfig();
        }
        catch
        {
            // A malformed config shouldn't block the launcher from starting at all -
            // fall back to defaults rather than crashing on launch.
            return new LauncherConfig();
        }
    }
}
