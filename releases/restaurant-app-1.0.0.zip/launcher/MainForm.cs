using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace RestaurantLauncher;

/// <summary>
/// The launcher's one window. Startup sequence: make sure the core services are running,
/// check for and (if found) apply an update, then open a WebView2 view pointed at the app -
/// the existing magic-link login (src/app/login, src/proxy.ts) is the login gate; this
/// window doesn't implement any auth of its own, it just hosts the already-gated app.
/// See launcher/README.md for the full design and current phase status.
/// </summary>
public sealed class MainForm : Form
{
    private readonly Label _statusLabel;
    private readonly WebView2 _webView;
    private readonly LauncherConfig _config;
    private readonly string _exeDirectory;
    private readonly Panel _debugBar;
    private readonly TextBox _debugUrlBox;

    public MainForm()
    {
        Text = "Restaurant App";
        Width = 1280;
        Height = 800;
        StartPosition = FormStartPosition.CenterScreen;

        _exeDirectory = AppContext.BaseDirectory;
        _config = LauncherConfig.Load(_exeDirectory);

        _statusLabel = new Label
        {
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font(Font.FontFamily, 14),
            Text = "Starting...",
        };

        _webView = new WebView2
        {
            Dock = DockStyle.Fill,
            Visible = false,
        };

        // Temporary testing aid, not permanent UI: the real product needs a proper way to
        // route a magic-link email (opened in the OS's default browser) back into this
        // window's own isolated WebView2 cookie profile - most likely a custom URL protocol
        // handler (restaurantapp://) registered at install time, which is Phase 2+ work.
        // Until that exists, this lets a pasted link be opened directly inside the window,
        // which is what actually lets a session persist here across launcher restarts.
        _debugUrlBox = new TextBox { Dock = DockStyle.Fill };
        var goButton = new Button { Text = "Open in launcher (debug)", AutoSize = true, Dock = DockStyle.Right };
        goButton.Click += (_, _) => NavigateToDebugUrl();
        _debugUrlBox.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                NavigateToDebugUrl();
            }
        };
        _debugBar = new Panel { Dock = DockStyle.Top, Height = 30, Visible = false };
        _debugBar.Controls.Add(_debugUrlBox);
        _debugBar.Controls.Add(goButton);

        Controls.Add(_webView);
        Controls.Add(_debugBar);
        Controls.Add(_statusLabel);

        Load += async (_, _) => await StartupAsync();
    }

    private void NavigateToDebugUrl()
    {
        var url = _debugUrlBox.Text.Trim();
        if (string.IsNullOrEmpty(url) || _webView.CoreWebView2 is null) return;
        _webView.CoreWebView2.Navigate(url);
    }

    private async Task StartupAsync()
    {
        SetStatus("Starting services...");
        var missing = await Task.Run(ServiceSupervisor.EnsureRunning);
        if (missing.Count > 0)
        {
            SetStatus(
                "This machine isn't set up yet.\n\n" +
                $"Missing service(s): {string.Join(", ", missing)}\n\n" +
                "Run scripts\\install-services.ps1 (as Administrator) first, then reopen this launcher."
            );
            return;
        }

        SetStatus("Checking for updates...");
        var checker = new UpdateChecker(_config.ManifestUrl);
        var installedVersion = UpdateChecker.GetInstalledVersion(_config.InstallDir);
        var manifest = await checker.FetchLatestAsync();

        if (manifest is not null && UpdateChecker.IsNewer(manifest, installedVersion))
        {
            SetStatus($"Updating to version {manifest.Version}...\n\nA Windows security prompt may appear - this is expected, the update needs it to restart services.");
            bool succeeded;
            try
            {
                succeeded = await UpdateApplier.ApplyAsync(_config, manifest, _exeDirectory);
            }
            catch (Exception ex)
            {
                succeeded = false;
                SetStatus($"Update failed to start: {ex.Message}\n\nContinuing with the current version.");
                await Task.Delay(3000);
            }

            if (!succeeded)
            {
                // apply-update.ps1 already restores/restarts the previous version on
                // failure - the launcher just needs to carry on and open whatever is
                // actually running now, not treat this as fatal to opening the app at all.
                SetStatus("Update didn't complete - continuing with the current version. See update-logs for details.");
                await Task.Delay(3000);
            }
        }

        SetStatus("Starting app...");
        var healthy = await ServiceSupervisor.WaitUntilHealthyAsync(_config.AppUrl, TimeSpan.FromSeconds(30));
        if (!healthy)
        {
            SetStatus(
                "The app didn't respond in time.\n\n" +
                "Check the services by hand (Get-Service Restaurant*) and try reopening this launcher."
            );
            return;
        }

        await OpenAppAsync();
    }

    private async Task OpenAppAsync()
    {
        var userDataFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "RestaurantApp", "WebView2"
        );
        Directory.CreateDirectory(userDataFolder);

        var environment = await CoreWebView2Environment.CreateAsync(userDataFolder: userDataFolder);
        await _webView.EnsureCoreWebView2Async(environment);

        _webView.CoreWebView2.Navigate(_config.AppUrl);
        _webView.Visible = true;
        _statusLabel.Visible = false;
        _debugBar.Visible = true;
    }

    private void SetStatus(string text)
    {
        if (InvokeRequired)
        {
            Invoke(() => _statusLabel.Text = text);
        }
        else
        {
            _statusLabel.Text = text;
        }
    }
}
