# Restaurant App Launcher

A small Windows desktop launcher, modeled on how the Riot Client works for League of Legends:
it makes sure the app's services are running, checks for and applies updates automatically,
then opens the app behind its existing login. This is **Phase 1** of turning the restaurant
app into a distributable product other restaurants can run independently — see the full
phased roadmap this came out of for what's deliberately deferred to later phases (Postgres
auto-provisioning for a brand-new machine, licensing, code signing, etc.).

## What this is (and isn't)

- **Is**: a thin WebView2 window around the app that's already running as Windows Services
  on this machine, plus an update-check-and-apply flow.
- **Isn't**: its own auth system. The app's existing magic-link login
  (`src/app/login/`, `src/proxy.ts`) already gates the entire app server-side — the launcher
  just opens a browser view at it. There's nothing to keep in sync between "the launcher's
  login" and "the app's login" because they're the same login.
- **Isn't**: a first-time-setup tool. It assumes Postgres and the NSSM services
  (`RestaurantApp`, `RestaurantPrintAgent`, `RestaurantSync`) are already installed on this
  machine, the same way they are today (`scripts/install-services.ps1`, run once by hand).
  Automating *that* part is Phase 2.

## Why WebView2, not Electron

Windows 11 ships the WebView2 runtime as an evergreen component (already confirmed present
on this machine), so a self-contained `dotnet publish` gives a real Chromium-grade renderer —
the app looks and behaves exactly as it does in a browser today — without bundling a second
copy of Chromium the way Electron would. It also avoids adding a whole second packaging
pipeline (`electron-builder`, its own signing/notarization) to a repo that has none today.

**Measured, not estimated** (built and published on 2026-09-23): the self-contained
single-file exe is **~155MB**. That's the full .NET runtime bundled in so the target machine
needs nothing pre-installed beyond WebView2 (which Windows 11 already has) — not a browser
engine, unlike Electron's bundle, which is the actual architectural difference this section's
size comparison is about, not raw byte count (Electron apps commonly land in a similar or
larger range once Chromium + Node are included). If install size becomes worth optimizing
later, two independent levers exist without changing the approach: framework-dependent
deployment (`SelfContained=false`, a few MB, but then the target machine needs the .NET 8
runtime installed too) or trimming (`PublishTrimmed`) — not attempted here since WinForms
trimming support is limited/risky and not worth the complexity for Phase 1. Neither is needed
for this phase; noted for Phase 5 (distribution polish) if it matters by then.
Electron's auto-updater ecosystem (`electron-updater`/Squirrel) isn't actually the right fit
here anyway: updating *this* app means stopping 3 Windows Services, replacing a Next.js
build, and running Prisma migrations against a live local Postgres — that orchestration is
bespoke regardless of launcher technology (see `scripts/apply-update.ps1`).

## Layout

```
launcher/
  RestaurantLauncher.csproj   Project file (net8.0-windows, self-contained win-x64)
  Program.cs                  Entry point
  MainForm.cs                 The one window: startup sequence + WebView2 host
  ServiceSupervisor.cs        Starts core services if stopped; app health-check polling
  UpdateChecker.cs            Fetches the release manifest, compares versions
  UpdateManifest.cs           version.json shape
  UpdateApplier.cs            Runs apply-update.ps1 elevated (only step that needs admin)
  LauncherConfig.cs           Optional launcher.config.json override (manifest URL, etc.)
  SemVer.cs                   Minimal MAJOR.MINOR.PATCH comparison
  scripts/apply-update.ps1    The actual stop -> backup -> replace -> migrate -> restart flow
  release-manifest.example.json
```

## Building

Requires the .NET 8 SDK (not installed in the environment this was scaffolded in — install
with `winget install Microsoft.DotNet.SDK.8` if `dotnet --version` doesn't work yet).

```
cd launcher
dotnet restore
dotnet build
```

To produce the actual distributable single-file exe:

```
dotnet publish -c Release -r win-x64 --self-contained
```

**Status (2026-09-23):**
- Builds and publishes cleanly: `dotnet restore`/`build`/`publish -c Release -r win-x64
  --self-contained` all succeed with 0 errors (.NET 8 SDK 8.0.425; one benign `MSB3277`
  warning - the WebView2 package ships both WinForms and WPF assembly variants, only
  WinForms is actually used at runtime). Published exe is ~155MB (self-contained .NET
  runtime, not a bundled browser - see "Why WebView2, not Electron" above).
- **Run and verified, end-to-end, against this restaurant's real machine** (no second
  machine was available, so this became the de facto test target for the *non-destructive*
  parts only - see caveat below): launches cleanly, starts core services (were already
  running), opens a real WebView2 window at the app, shows the existing login page, and a
  real magic-link login completed through the window. Verified headlessly (no screen access
  in that session) by reading the actual `restaurant_session` cookie out of WebView2's own
  SQLite cookie store (`%LOCALAPPDATA%\RestaurantApp\WebView2\EBWebView\Default\Network\
  Cookies`) - confirmed a real 60-day expiry once the app was rebuilt with the `maxAge` fix
  (it initially showed iron-session's 14-day *default*, because the running production
  build hadn't been rebuilt yet - not a flaw in the fix itself, see `src/lib/
  session-options.ts`). Then closed and relaunched the actual desktop shortcut: landed
  straight on the dashboard, no re-login needed - the core "stays logged in" promise works.
- **The update-apply path is now proven too** (`scripts/apply-update.ps1`, the piece that
  stops services, replaces the install directory, and runs migrations - previously the
  highest-risk untested part). No second machine was available, so instead of pointing it at
  the live install, a reusable harness (`scripts/test-update-flow.ps1` /
  `test-update-flow.bat`) sets up one fully isolated, disposable install on this same
  machine - own directory (`C:\ProgramData\RestaurantApp-test\app`), own Postgres database
  (`restaurant_test`), own temporary Windows Services (`RestaurantAppTest`/etc.), own port
  (3100) - and runs the real, unmodified script against *that*. Both paths genuinely pass:
  - **Happy path**: stop -> backup -> replace -> `npm ci` -> `prisma generate` -> build ->
    `prisma migrate deploy` -> restart -> health check -> cleanup, end to end.
  - **Failure/rollback path**: a release with one deliberately broken migration correctly
    rolls back to the previous version, restarts it successfully, and leaves a clear log -
    exactly what the design promises.

  Getting a *clean* pass took a few real rounds of debugging against real failures (all now
  fixed, kept for the record since they're the kind of thing worth knowing about):
  - `psql` returning zero rows came back as PowerShell `$null`, and `$null.Trim()` threw -
    masked what was actually a normal "database doesn't exist yet" case as a crash.
  - **A genuine bug in `apply-update.ps1` itself**, not just the test harness:
    `src/generated/prisma` (the Prisma Client `src/lib/db.ts` imports) is gitignored, so it's
    never in a release archive. `prisma migrate deploy` deliberately does not generate it
    (only `migrate dev` does), and nothing else in the script did either - every *real* future
    update would have hit `Module not found: '@/generated/prisma/client'` at the build step.
    Fixed by adding an explicit `prisma generate` before the build.
  - The test harness's own service setup used a `-p <port>` CLI flag to keep the test app off
    the real app's port 3000 - but `apply-update.ps1` deliberately resets `AppParameters` to
    plain `run start` on every successful update (correct for the *real* service), which
    silently wiped that flag and made the test service try to rebind onto port 3000. Fixed by
    driving the port through a `PORT` environment variable instead (NSSM
    `AppEnvironmentExtra`), which survives that reset.
  - A real bug in the test harness's own pass/fail check: the nested `apply-update.ps1`
    process's console output wasn't suppressed, so it became extra elements in the array
    PowerShell's `return $LASTEXITCODE` actually produced - comparing that array with
    `-eq 0`/`-ne 0` checks *array membership*, not the exit code, silently wrong either way
    regardless of the real result. (This is why an early run reported "PASS" - a coincidence
    of which comparison operator was used, not a real check.) Fixed by piping the nested
    process's output to `Out-Host` instead of leaving it to leak into the function's return
    value.

  None of this touched the real `RestaurantApp`/`RestaurantPrintAgent`/`RestaurantSync`
  services or the real `restaurant` database at any point.

## Release hosting

The main app repo (`restaurant-reservation-app`) is **private** (confirmed via the GitHub
API - an anonymous request to it 404s). Publishing release artifacts as public GitHub
Releases on that repo would expose the entire source tree, which defeats the point of
building this as a product. Decision: **a separate, dedicated releases repo**
(`restaurant-app-releases` by convention — update `LauncherConfig`'s default `ManifestUrl` if
you name it differently) that holds **only** built release zips + `version.json` manifests,
never source. This also means the launcher never needs an embedded GitHub token just to check
for updates — it's a plain anonymous `raw.githubusercontent.com` fetch of a public
`latest.json`.

**Not yet done**: actually creating that repo. Until it exists, `UpdateChecker.FetchLatestAsync`
will just fail to fetch (handled gracefully — the launcher opens whatever version is already
installed, no update applied) or you can point a `launcher.config.json` next to the exe at a
throwaway test repo/URL first.

### Cutting a release (once the releases repo exists)

1. Bump `package.json`'s `version`, add a `CHANGELOG.md` entry.
2. Build the app for production and zip up exactly what an install needs (source +
   `package.json`/`package-lock.json`/`prisma/` — **not** `node_modules`, `.env`, or the
   rotated `*.log` files sitting in the repo root today; `npm ci && npm run build` happens
   on the restaurant's machine during the update, per `apply-update.ps1`).
3. Compute the zip's SHA256 (`Get-FileHash -Algorithm SHA256`), publish the zip as a GitHub
   Release on the releases repo, and commit a `latest.json` (shape: see
   `release-manifest.example.json`) to the releases repo pointing at it.

## Verification (per the approved plan)

1. ✅ `dotnet build` cleanly.
2. ✅ `maxAge` fix: cookie carries a real 60-day expiry, survives closing/reopening WebView2.
3. ✅ Launches, starts services, shows the login gate, reaches the dashboard, stays logged in
   across a launcher restart. (No second machine was available, so this ran against this
   restaurant's real machine — but only the read-only/non-destructive parts: starting
   already-configured services, opening a browser view, completing a login. See the Status
   section above for exactly why the update-apply path specifically was *not* tested this
   way.)
4. ✅ Full update path (detect → stop → replace → migrate → restart → healthy), proven via
   `scripts/test-update-flow.ps1`'s disposable, fully isolated test install rather than the
   real one — deliberately safer than "a second machine" for this specific step, since it
   avoids ever needing physical access to a second machine at all while still using real
   Windows Services, a real Postgres database, and the actual unmodified script.
5. ✅ Failure/rollback path (a deliberately broken migration), proven the same way.
6. **Still outstanding**: an actual second machine (or at least a fresh clone) test — today's
   testing proves the *mechanism* works correctly, but every run so far has been on this one
   machine's already-configured environment (existing Node/NSSM/Postgres installs, etc.).
   Worth doing before this is trusted for a real restaurant that isn't this one.

## What's deliberately NOT in this phase

Postgres/Node/NSSM auto-provisioning for a brand-new machine, licensing/accounts/billing, a
multi-restaurant switcher UI (the `User`↔`Restaurant` `Membership` schema already supports
it, just no UI yet), voice/ngrok automation (already moved to cloud, nothing local to
automate), code signing (this will trigger a Windows SmartScreen warning for now — an
accepted trade-off until there's a stable artifact worth paying to sign), and generalizing
the hardcoded `nssm.exe`/`npm.cmd` discovery in `apply-update.ps1` beyond what
`scripts/install-services.ps1` already does — all of that is later-phase work.
