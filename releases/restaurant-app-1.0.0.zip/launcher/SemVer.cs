namespace RestaurantLauncher;

/// <summary>
/// Minimal MAJOR.MINOR.PATCH comparison - just enough to compare this app's own versioning
/// scheme (see the repo's CHANGELOG.md and package.json). Not a full semver spec parser
/// (no pre-release/build-metadata handling) since releases here don't use those.
/// </summary>
public readonly record struct SemVer(int Major, int Minor, int Patch) : IComparable<SemVer>
{
    public static bool TryParse(string text, out SemVer version)
    {
        version = default;
        var parts = text.Trim().TrimStart('v', 'V').Split('.');
        if (parts.Length != 3) return false;
        if (!int.TryParse(parts[0], out var major)) return false;
        if (!int.TryParse(parts[1], out var minor)) return false;
        if (!int.TryParse(parts[2], out var patch)) return false;
        version = new SemVer(major, minor, patch);
        return true;
    }

    public int CompareTo(SemVer other)
    {
        var majorCompare = Major.CompareTo(other.Major);
        if (majorCompare != 0) return majorCompare;
        var minorCompare = Minor.CompareTo(other.Minor);
        if (minorCompare != 0) return minorCompare;
        return Patch.CompareTo(other.Patch);
    }

    public override string ToString() => $"{Major}.{Minor}.{Patch}";
}
