using System.ServiceProcess;

namespace RestaurantLauncher;

/// <summary>
/// Makes sure the app's core Windows Services are running before the launcher opens a
/// WebView2 window pointed at them. Doesn't install or configure services (that's still
/// scripts/install-services.ps1, run once when a machine is first set up) - this only starts
/// ones that already exist but happen to be stopped (e.g. after a reboot, if a service
/// hasn't been set to auto-start, or right after this same machine's update flow finishes).
/// </summary>
public static class ServiceSupervisor
{
    private static readonly string[] CoreServices =
    {
        "RestaurantApp",
        "RestaurantPrintAgent",
        "RestaurantSync",
    };
    // RestaurantVoice / RestaurantVoiceTunnel intentionally excluded - voice now runs in the
    // cloud, so these are typically stopped/manual on a restaurant's machine already.

    /// <summary>
    /// Starts any core service that exists but isn't running. Returns a list of services that
    /// don't exist at all (meaning this machine was never set up via install-services.ps1) so
    /// the caller can show a clear "this machine isn't set up yet" message instead of a
    /// confusing blank window.
    /// </summary>
    public static List<string> EnsureRunning()
    {
        var missing = new List<string>();

        foreach (var name in CoreServices)
        {
            using var sc = new ServiceController(name);
            try
            {
                sc.Refresh();
                if (sc.Status != ServiceControllerStatus.Running)
                {
                    sc.Start();
                    sc.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(30));
                }
            }
            catch (InvalidOperationException)
            {
                // Service doesn't exist on this machine.
                missing.Add(name);
            }
        }

        return missing;
    }

    public static async Task<bool> WaitUntilHealthyAsync(string appUrl, TimeSpan timeout)
    {
        using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(5) };
        var deadline = DateTime.UtcNow + timeout;

        while (DateTime.UtcNow < deadline)
        {
            try
            {
                var response = await http.GetAsync($"{appUrl}/login");
                if (response.IsSuccessStatusCode) return true;
            }
            catch
            {
                // Not up yet - keep polling.
            }
            await Task.Delay(1000);
        }

        return false;
    }
}
