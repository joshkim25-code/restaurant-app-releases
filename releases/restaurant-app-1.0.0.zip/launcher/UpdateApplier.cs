using System.Diagnostics;

namespace RestaurantLauncher;

/// <summary>
/// Runs scripts/apply-update.ps1 elevated. Elevation (a UAC prompt) is only requested for
/// this step, not for normal day-to-day launching - opening the app just needs its already-
/// running services and a WebView2 window, neither of which needs admin rights.
/// </summary>
public static class UpdateApplier
{
    public static async Task<bool> ApplyAsync(LauncherConfig config, UpdateManifest manifest, string exeDirectory)
    {
        var scriptPath = Path.Combine(exeDirectory, "scripts", "apply-update.ps1");
        if (!File.Exists(scriptPath))
        {
            throw new FileNotFoundException($"Update script not found at {scriptPath} - reinstall the launcher.");
        }

        var arguments = string.Join(' ', new[]
        {
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", Quote(scriptPath),
            "-InstallDir", Quote(config.InstallDir),
            "-DownloadUrl", Quote(manifest.DownloadUrl),
            "-ExpectedSha256", Quote(manifest.Sha256),
            "-Version", Quote(manifest.Version),
        });

        var psi = new ProcessStartInfo
        {
            FileName = "powershell.exe",
            Arguments = arguments,
            // UseShellExecute + Verb "runas" is what triggers the UAC elevation prompt -
            // it also means stdout can't be captured here (a ShellExecute limitation), so
            // apply-update.ps1 writes its own transcript log instead (see its $logFile).
            UseShellExecute = true,
            Verb = "runas",
        };

        return await Task.Run(() =>
        {
            using var process = Process.Start(psi);
            if (process is null) return false;
            process.WaitForExit();
            return process.ExitCode == 0;
        });
    }

    private static string Quote(string value) => $"\"{value}\"";
}
