using System.Text.Json;

namespace RestaurantLauncher;

public sealed class UpdateChecker
{
    private readonly HttpClient _http;
    private readonly string _manifestUrl;

    public UpdateChecker(string manifestUrl)
    {
        _manifestUrl = manifestUrl;
        _http = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };
    }

    /// <summary>
    /// Reads the version this install is actually running, straight from its own
    /// package.json - always accurate (can't drift from what's really deployed the way a
    /// separately-tracked marker file could).
    /// </summary>
    public static string GetInstalledVersion(string installDir)
    {
        var packageJsonPath = Path.Combine(installDir, "package.json");
        if (!File.Exists(packageJsonPath)) return "0.0.0";

        using var doc = JsonDocument.Parse(File.ReadAllText(packageJsonPath));
        return doc.RootElement.TryGetProperty("version", out var v) ? v.GetString() ?? "0.0.0" : "0.0.0";
    }

    /// <summary>
    /// Fetches the latest release manifest. Returns null (not a thrown exception) on any
    /// network/parse failure - a failed update check should never block opening the app on
    /// whatever version is already installed; it should just quietly skip the update.
    /// </summary>
    public async Task<UpdateManifest?> FetchLatestAsync()
    {
        try
        {
            var json = await _http.GetStringAsync(_manifestUrl);
            return JsonSerializer.Deserialize<UpdateManifest>(json);
        }
        catch
        {
            return null;
        }
    }

    public static bool IsNewer(UpdateManifest manifest, string installedVersion)
    {
        if (!SemVer.TryParse(manifest.Version, out var remote)) return false;
        if (!SemVer.TryParse(installedVersion, out var local)) return true; // unknown local version - treat as needing an update
        return remote.CompareTo(local) > 0;
    }
}
