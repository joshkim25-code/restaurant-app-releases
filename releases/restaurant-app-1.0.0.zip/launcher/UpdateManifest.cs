using System.Text.Json.Serialization;

namespace RestaurantLauncher;

/// <summary>
/// Mirrors the version.json manifest published alongside each release in the (separate,
/// source-free) releases repo - see launcher/README.md for why release hosting is split
/// from the private source repo. One manifest per release; the launcher fetches whichever
/// one a well-known "latest.json" points at.
/// </summary>
public sealed class UpdateManifest
{
    [JsonPropertyName("version")]
    public string Version { get; set; } = "";

    [JsonPropertyName("releasedAt")]
    public string ReleasedAt { get; set; } = "";

    [JsonPropertyName("notes")]
    public string Notes { get; set; } = "";

    [JsonPropertyName("downloadUrl")]
    public string DownloadUrl { get; set; } = "";

    [JsonPropertyName("sha256")]
    public string Sha256 { get; set; } = "";

    [JsonPropertyName("minLauncherVersion")]
    public string MinLauncherVersion { get; set; } = "1.0.0";
}
