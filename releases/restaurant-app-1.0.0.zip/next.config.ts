import type { NextConfig } from "next";

// Dev mode keeps using ".next" (an NTFS junction pointing outside OneDrive's sync scope,
// see the project_onedrive_next_junction memory note) to avoid crashes from OneDrive's
// cloud-file filter racing with Turbopack's rapid hot-reload cache writes. A production
// build/start doesn't do sustained rapid writes the same way, and the junction setup
// breaks module resolution for some build-time worker processes - so production uses a
// separate, plain (non-junctioned) output directory instead.
const nextConfig: NextConfig = {
  distDir: process.env.NODE_ENV === "production" ? ".next-prod" : ".next",
};

export default nextConfig;
