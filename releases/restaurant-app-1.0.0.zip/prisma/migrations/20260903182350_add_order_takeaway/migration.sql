-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "isTakeaway" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "takeawayNote" TEXT;
