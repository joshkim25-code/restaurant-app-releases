-- AlterTable
ALTER TABLE "MenuCategory" ADD COLUMN     "station" TEXT;

-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "bookingWindowDays" INTEGER NOT NULL DEFAULT 30,
ADD COLUMN     "cancellationPolicy" TEXT,
ADD COLUMN     "contactPhone" TEXT,
ADD COLUMN     "currency" TEXT NOT NULL DEFAULT 'USD',
ADD COLUMN     "defaultTipPercentages" TEXT NOT NULL DEFAULT '15,18,20',
ADD COLUMN     "logoUrl" TEXT,
ADD COLUMN     "maxPartySize" INTEGER NOT NULL DEFAULT 12,
ADD COLUMN     "minPartySize" INTEGER NOT NULL DEFAULT 1,
ADD COLUMN     "notifyNewReservationEmail" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "notifyNewReservationInApp" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "notifyNewReservationSms" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "notifyOrderReadyEmail" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "notifyOrderReadyInApp" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "notifyOrderReadySms" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "serviceChargePercent" DOUBLE PRECISION NOT NULL DEFAULT 0,
ADD COLUMN     "tableAutoReset" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "taxRatePercent" DOUBLE PRECISION NOT NULL DEFAULT 0;
