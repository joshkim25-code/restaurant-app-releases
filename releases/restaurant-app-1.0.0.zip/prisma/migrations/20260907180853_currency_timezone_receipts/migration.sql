-- AlterTable
ALTER TABLE "Payment" ADD COLUMN     "serviceChargeCents" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "subtotalCents" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "taxCents" INTEGER NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "receiptFooterText" TEXT,
ADD COLUMN     "receiptHeaderText" TEXT,
ADD COLUMN     "receiptShowAddress" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "receiptShowLogo" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "receiptShowPhone" BOOLEAN NOT NULL DEFAULT true,
ALTER COLUMN "currency" SET DEFAULT 'GBP';
