-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "notificationDurationSeconds" INTEGER NOT NULL DEFAULT 8;
