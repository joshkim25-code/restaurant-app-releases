-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "printerIpAddress" TEXT,
ADD COLUMN     "printerPort" INTEGER NOT NULL DEFAULT 9100;
