-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "kitchenPrinterIpAddress" TEXT,
ADD COLUMN     "kitchenPrinterPort" INTEGER NOT NULL DEFAULT 9100;
