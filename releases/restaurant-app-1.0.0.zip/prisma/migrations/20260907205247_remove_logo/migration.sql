-- AlterTable
ALTER TABLE "Restaurant" DROP COLUMN "logoUrl",
DROP COLUMN "receiptShowLogo";
