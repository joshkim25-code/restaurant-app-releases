-- AlterTable
ALTER TABLE "MenuItem" ADD COLUMN     "sendToKitchen" BOOLEAN NOT NULL DEFAULT true;
