-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "kitchenPrinterConnectionType" TEXT NOT NULL DEFAULT 'network',
ADD COLUMN     "kitchenPrinterShareName" TEXT,
ADD COLUMN     "printerConnectionType" TEXT NOT NULL DEFAULT 'network',
ADD COLUMN     "printerShareName" TEXT;
