-- Rename printer share-name columns to printer-name columns now that USB printing
-- goes directly through the Windows print spooler by printer name, not a network share.
ALTER TABLE "Restaurant" RENAME COLUMN "printerShareName" TO "printerName";
ALTER TABLE "Restaurant" RENAME COLUMN "kitchenPrinterShareName" TO "kitchenPrinterName";
