-- CreateEnum
CREATE TYPE "PrinterRole" AS ENUM ('RECEIPT', 'TICKET');

-- CreateTable
CREATE TABLE "Printer" (
    "id" TEXT NOT NULL,
    "restaurantId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "role" "PrinterRole" NOT NULL DEFAULT 'TICKET',
    "connectionType" TEXT NOT NULL DEFAULT 'network',
    "ipAddress" TEXT,
    "port" INTEGER NOT NULL DEFAULT 9100,
    "printerName" TEXT,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "Printer_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Printer_restaurantId_idx" ON "Printer"("restaurantId");

-- AddForeignKey
ALTER TABLE "Printer" ADD CONSTRAINT "Printer_restaurantId_fkey" FOREIGN KEY ("restaurantId") REFERENCES "Restaurant"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- DataMigration: one RECEIPT printer per restaurant, always created, seeded from the old receipt-printer columns
INSERT INTO "Printer" ("id", "restaurantId", "name", "role", "connectionType", "ipAddress", "port", "printerName", "sortOrder")
SELECT gen_random_uuid()::text, "id", 'Receipt Printer', 'RECEIPT', "printerConnectionType", "printerIpAddress", "printerPort", "printerName", 0
FROM "Restaurant";

-- DataMigration: one TICKET printer per restaurant, only where a kitchen printer was actually configured
INSERT INTO "Printer" ("id", "restaurantId", "name", "role", "connectionType", "ipAddress", "port", "printerName", "sortOrder")
SELECT gen_random_uuid()::text, "id", 'Kitchen Printer', 'TICKET', "kitchenPrinterConnectionType", "kitchenPrinterIpAddress", "kitchenPrinterPort", "kitchenPrinterName", 0
FROM "Restaurant"
WHERE "kitchenPrinterIpAddress" IS NOT NULL OR "kitchenPrinterName" IS NOT NULL;

-- AlterTable: MenuItem gains printerId, replacing sendToKitchen
ALTER TABLE "MenuItem" ADD COLUMN "printerId" TEXT;

-- DataMigration: items that were sent to the kitchen now point at that restaurant's new Kitchen Printer row
UPDATE "MenuItem" mi
SET "printerId" = p."id"
FROM "Printer" p
WHERE p."restaurantId" = mi."restaurantId"
  AND p."role" = 'TICKET'
  AND p."name" = 'Kitchen Printer'
  AND mi."sendToKitchen" = true;

ALTER TABLE "MenuItem" DROP COLUMN "sendToKitchen";

-- CreateIndex
CREATE INDEX "MenuItem_printerId_idx" ON "MenuItem"("printerId");

-- AddForeignKey
ALTER TABLE "MenuItem" ADD CONSTRAINT "MenuItem_printerId_fkey" FOREIGN KEY ("printerId") REFERENCES "Printer"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AlterTable: drop the old hardcoded printer columns from Restaurant, now replaced by the Printer table
ALTER TABLE "Restaurant"
  DROP COLUMN "printerIpAddress",
  DROP COLUMN "printerPort",
  DROP COLUMN "printerConnectionType",
  DROP COLUMN "printerName",
  DROP COLUMN "kitchenPrinterIpAddress",
  DROP COLUMN "kitchenPrinterPort",
  DROP COLUMN "kitchenPrinterConnectionType",
  DROP COLUMN "kitchenPrinterName";
