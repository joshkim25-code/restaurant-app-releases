-- CreateEnum
CREATE TYPE "PrinterKind" AS ENUM ('POS', 'STANDARD');

-- AlterTable
ALTER TABLE "Printer" ADD COLUMN     "isSummaryPrinter" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "kind" "PrinterKind" NOT NULL DEFAULT 'POS';

-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "summaryShowAverageBill" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "summaryShowBillCount" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "summaryShowCancelled" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "summaryShowPaymentMethods" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "summaryShowRevenue" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "summaryShowTopItems" BOOLEAN NOT NULL DEFAULT false;
