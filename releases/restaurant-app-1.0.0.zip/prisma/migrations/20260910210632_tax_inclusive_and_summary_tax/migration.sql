-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "pricesIncludeTax" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "summaryShowServiceCharge" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "summaryShowTax" BOOLEAN NOT NULL DEFAULT true;
