-- AlterTable
ALTER TABLE "Payment" ADD COLUMN     "pricesIncludeTax" BOOLEAN NOT NULL DEFAULT false;
