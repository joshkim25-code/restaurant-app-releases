-- AlterTable
ALTER TABLE "Bill" ADD COLUMN     "cancelledValueCents" INTEGER;

-- AlterTable
ALTER TABLE "Payment" ADD COLUMN     "discountCents" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "tipCents" INTEGER NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "summaryShowCancelledRevenue" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "summaryShowFulfillmentSplit" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "summaryShowRevenueByCategory" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "summaryShowRevenueBySource" BOOLEAN NOT NULL DEFAULT false;
