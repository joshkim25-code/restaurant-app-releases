-- CreateEnum
CREATE TYPE "PrintJobType" AS ENUM ('RECEIPT', 'TICKET', 'SUMMARY', 'TEST', 'LIST_INSTALLED', 'DISCOVER_NETWORK');

-- CreateEnum
CREATE TYPE "PrintJobStatus" AS ENUM ('PENDING', 'CLAIMED', 'DONE', 'FAILED');

-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "agentToken" TEXT;

-- CreateTable
CREATE TABLE "PrintJob" (
    "id" TEXT NOT NULL,
    "restaurantId" TEXT NOT NULL,
    "type" "PrintJobType" NOT NULL,
    "payload" JSONB NOT NULL,
    "status" "PrintJobStatus" NOT NULL DEFAULT 'PENDING',
    "result" JSONB,
    "error" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "claimedAt" TIMESTAMP(3),
    "completedAt" TIMESTAMP(3),

    CONSTRAINT "PrintJob_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "PrintJob_restaurantId_status_idx" ON "PrintJob"("restaurantId", "status");

-- CreateIndex
CREATE UNIQUE INDEX "Restaurant_agentToken_key" ON "Restaurant"("agentToken");

-- AddForeignKey
ALTER TABLE "PrintJob" ADD CONSTRAINT "PrintJob_restaurantId_fkey" FOREIGN KEY ("restaurantId") REFERENCES "Restaurant"("id") ON DELETE CASCADE ON UPDATE CASCADE;
