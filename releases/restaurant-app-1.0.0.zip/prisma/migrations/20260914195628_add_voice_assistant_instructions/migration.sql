-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "voiceAssistantInstructions" TEXT;
