-- AlterEnum
ALTER TYPE "CallStatus" ADD VALUE 'ABANDONED';
