-- CreateEnum
CREATE TYPE "VoicePreset" AS ENUM ('DEFAULT', 'AMERICAN', 'BRITISH', 'AUSTRALIAN', 'INDIAN', 'IRISH', 'SOUTH_AFRICAN', 'NEW_ZEALAND');

-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "voicePreset" "VoicePreset" NOT NULL DEFAULT 'DEFAULT';
