-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "notifyNewPhoneOrderInApp" BOOLEAN NOT NULL DEFAULT true;
