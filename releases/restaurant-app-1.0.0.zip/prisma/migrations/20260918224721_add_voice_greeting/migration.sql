-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "voiceGreeting" TEXT;
