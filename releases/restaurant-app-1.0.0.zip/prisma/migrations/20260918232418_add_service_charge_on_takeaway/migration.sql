-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "serviceChargeOnTakeaway" BOOLEAN NOT NULL DEFAULT true;
