-- CreateEnum
CREATE TYPE "InterruptSensitivity" AS ENUM ('LOW', 'MEDIUM', 'HIGH');

-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "voiceInterruptSensitivity" "InterruptSensitivity" NOT NULL DEFAULT 'LOW';
