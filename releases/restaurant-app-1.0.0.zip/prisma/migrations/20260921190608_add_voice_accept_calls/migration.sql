-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "voiceAcceptCalls" BOOLEAN NOT NULL DEFAULT true;
