-- CreateEnum
CREATE TYPE "ReceiptFontSize" AS ENUM ('NORMAL', 'LARGE');

-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "receiptFontSize" "ReceiptFontSize" NOT NULL DEFAULT 'NORMAL';
