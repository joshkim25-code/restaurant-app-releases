-- AlterEnum
ALTER TYPE "ReceiptFontSize" RENAME TO "PrinterFontSize";

-- AlterTable
ALTER TABLE "Restaurant" DROP COLUMN "receiptFontSize";

-- AlterTable
ALTER TABLE "Printer" ADD COLUMN     "fontSize" "PrinterFontSize" NOT NULL DEFAULT 'NORMAL';
