-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN     "summaryShowTipsByMethod" BOOLEAN NOT NULL DEFAULT true;
