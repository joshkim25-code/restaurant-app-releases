-- AlterTable
ALTER TABLE "Payment" ADD COLUMN     "tipMethod" "PaymentMethod";

-- Old payments never recorded a separate tip method; the closest honest default is
-- "the tip was paid the same way as the order."
UPDATE "Payment" SET "tipMethod" = "method" WHERE "tipMethod" IS NULL;
