-- AlterTable
ALTER TABLE "Bill" ADD COLUMN     "customerNameAtBooking" TEXT;

-- AlterTable
ALTER TABLE "Reservation" ADD COLUMN     "customerNameAtBooking" TEXT;
