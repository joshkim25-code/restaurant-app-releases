import "dotenv/config";
import { db } from "@/lib/db";

const DAYS_AGO = [0, 1, 4, 4, 10, 25, 45];
const METHODS = ["CASH", "CARD", "CARD", "CASH"] as const;

function atTime(daysAgo: number, hour: number, minute: number): Date {
  const date = new Date();
  date.setDate(date.getDate() - daysAgo);
  date.setHours(hour, minute, 0, 0);
  return date;
}

async function main() {
  const restaurant = await db.restaurant.findFirst();
  if (!restaurant) throw new Error("No restaurant found — run `npm run db:seed` first.");

  const menuItems = await db.menuItem.findMany({ where: { restaurantId: restaurant.id } });
  if (menuItems.length === 0) throw new Error("No menu items found — run `npm run db:seed` first.");

  const table = await db.table.findFirst({ where: { restaurantId: restaurant.id } });

  let created = 0;
  for (let i = 0; i < DAYS_AGO.length; i++) {
    const daysAgo = DAYS_AGO[i];
    const openedAt = atTime(daysAgo, 18, 0 + i);
    const closedAt = atTime(daysAgo, 19, 15 + i);

    const pickCount = 1 + (i % 3);
    const picks = Array.from({ length: pickCount }, (_, j) => menuItems[(i + j) % menuItems.length]);
    const orderItems = picks.map((item) => ({
      menuItemId: item.id,
      quantity: 1 + (i % 2),
      unitPriceCentsAtOrder: item.priceCents,
    }));
    const amountCents = orderItems.reduce((sum, item) => sum + item.quantity * item.unitPriceCentsAtOrder, 0);

    await db.bill.create({
      data: {
        restaurantId: restaurant.id,
        tableId: table?.id,
        status: "CLOSED",
        source: "WAITER",
        openedAt,
        closedAt,
        orders: {
          create: [
            {
              status: "SERVED",
              submittedAt: openedAt,
              items: { create: orderItems },
            },
          ],
        },
        payment: {
          create: {
            amountCents,
            method: METHODS[i % METHODS.length],
            paidAt: closedAt,
          },
        },
      },
    });
    created++;
  }

  console.log(`Seeded ${created} demo bills for ${restaurant.name}, spread across ${DAYS_AGO.join(", ")} days ago.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
