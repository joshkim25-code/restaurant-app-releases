import "dotenv/config";
import { db } from "@/lib/db";

async function main() {
  const restaurant = await db.restaurant.upsert({
    where: { twilioPhoneNumber: "+15555550100" },
    update: {},
    create: {
      name: "The Test Kitchen",
      timezone: "America/New_York",
      twilioPhoneNumber: "+15555550100",
      tables: {
        create: [
          { label: "T1", seats: 2 },
          { label: "T2", seats: 2 },
          { label: "T3", seats: 4 },
          { label: "T4", seats: 4 },
          { label: "T5", seats: 6 },
          { label: "T6", seats: 8 },
        ].map((table, i) => ({
          ...table,
          posX: 40 + (i % 4) * 160,
          posY: 40 + Math.floor(i / 4) * 140,
        })),
      },
      businessHours: {
        create: [1, 2, 3, 4, 5, 6, 0].map((dayOfWeek) => ({
          dayOfWeek,
          openTime: "17:00",
          closeTime: "22:00",
          isClosed: dayOfWeek === 1, // closed Mondays
        })),
      },
    },
  });

  console.log(`Seeded restaurant: ${restaurant.name} (${restaurant.id})`);

  const existingMenuItems = await db.menuItem.count({
    where: { restaurantId: restaurant.id },
  });

  if (existingMenuItems === 0) {
    const menu: Record<string, { name: string; priceCents: number; description?: string }[]> = {
      Appetizers: [
        { name: "Garlic Bread", priceCents: 600, description: "Toasted baguette, garlic butter" },
        { name: "Caesar Salad", priceCents: 900 },
      ],
      Mains: [
        { name: "Cheeseburger", priceCents: 1500, description: "With fries" },
        { name: "Margherita Pizza", priceCents: 1400 },
        { name: "Grilled Salmon", priceCents: 2200 },
      ],
      Drinks: [
        { name: "Soda", priceCents: 350 },
        { name: "Iced Tea", priceCents: 350 },
        { name: "House Red Wine", priceCents: 1000 },
      ],
    };

    let sortOrder = 0;
    for (const [categoryName, items] of Object.entries(menu)) {
      const category = await db.menuCategory.create({
        data: { restaurantId: restaurant.id, name: categoryName, sortOrder: sortOrder++ },
      });
      await db.menuItem.createMany({
        data: items.map((item) => ({ ...item, restaurantId: restaurant.id, categoryId: category.id })),
      });
    }

    console.log(`Seeded menu for ${restaurant.name}`);
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
