import "dotenv/config";
import { db } from "@/lib/db";
import type { PaymentMethod } from "@/generated/prisma/client";

const SERVICE_START_HOUR = 17;
const SERVICE_LENGTH_MIN = 5 * 60; // 17:00–22:00
const METHODS: PaymentMethod[] = ["CASH", "CARD"];

function randInt(min: number, max: number): number {
  return min + Math.floor(Math.random() * (max - min + 1));
}

function windowStart(): Date {
  const date = new Date();
  date.setHours(SERVICE_START_HOUR, 0, 0, 0);
  return date;
}

function addMinutes(date: Date, minutes: number): Date {
  return new Date(date.getTime() + minutes * 60 * 1000);
}

interface Seating {
  tableId: string;
  tableLabel: string;
  openedAt: Date;
  closedAt: Date;
}

function scheduleSeatings(tableId: string, tableLabel: string): Seating[] {
  const seatings: Seating[] = [];
  let cursor = 0;
  const numSeatings = randInt(2, 3);
  for (let i = 0; i < numSeatings; i++) {
    const duration = randInt(30, 75);
    if (cursor + duration > SERVICE_LENGTH_MIN) break;
    const openedAt = addMinutes(windowStart(), cursor);
    const closedAt = addMinutes(openedAt, duration);
    seatings.push({ tableId, tableLabel, openedAt, closedAt });
    cursor += duration + randInt(10, 20);
  }
  return seatings;
}

async function main() {
  const restaurant = await db.restaurant.findFirst();
  if (!restaurant) throw new Error("No restaurant found — run `npm run db:seed` first.");

  const tables = await db.table.findMany({ where: { restaurantId: restaurant.id }, orderBy: { label: "asc" } });
  if (tables.length === 0) throw new Error("No tables found — run `npm run db:seed` first.");

  const menuItems = await db.menuItem.findMany({ where: { restaurantId: restaurant.id } });
  if (menuItems.length === 0) throw new Error("No menu items found — run `npm run db:seed` first.");

  const seatings = tables.flatMap((table) => scheduleSeatings(table.id, table.label));

  let paidCount = 0;
  let cancelledCount = 0;
  let revenueCents = 0;
  const perTable = new Map<string, number>();

  for (const seating of seatings) {
    const itemCount = randInt(1, 4);
    const orderItems = Array.from({ length: itemCount }, () => {
      const menuItem = menuItems[randInt(0, menuItems.length - 1)];
      return {
        menuItemId: menuItem.id,
        quantity: randInt(1, 2),
        unitPriceCentsAtOrder: menuItem.priceCents,
      };
    });
    const amountCents = orderItems.reduce((sum, item) => sum + item.quantity * item.unitPriceCentsAtOrder, 0);
    const cancelled = Math.random() < 0.15;

    await db.bill.create({
      data: {
        restaurantId: restaurant.id,
        tableId: seating.tableId,
        status: "CLOSED",
        source: "WAITER",
        openedAt: seating.openedAt,
        closedAt: seating.closedAt,
        orders: {
          create: [
            {
              status: cancelled ? "CANCELLED" : "SERVED",
              submittedAt: seating.openedAt,
              items: { create: orderItems },
            },
          ],
        },
        ...(cancelled
          ? {}
          : {
              payment: {
                create: {
                  amountCents,
                  method: METHODS[randInt(0, METHODS.length - 1)],
                  paidAt: seating.closedAt,
                },
              },
            }),
      },
    });

    if (cancelled) {
      cancelledCount++;
    } else {
      paidCount++;
      revenueCents += amountCents;
      perTable.set(seating.tableLabel, (perTable.get(seating.tableLabel) ?? 0) + amountCents);
    }
  }

  console.log(
    `Simulated ${seatings.length} seatings across ${tables.length} tables for ${restaurant.name} ` +
      `(${SERVICE_START_HOUR}:00–${SERVICE_START_HOUR + 5}:00 today): ${paidCount} paid, ${cancelledCount} cancelled, ` +
      `£${(revenueCents / 100).toFixed(2)} revenue.`,
  );
  for (const [label, cents] of [...perTable.entries()].sort()) {
    console.log(`  ${label}: £${(cents / 100).toFixed(2)}`);
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
