# Builds a release artifact for the launcher's update mechanism (see launcher/README.md).
# Zips exactly the git-tracked source tree via `git archive` - deliberately not a hand-
# maintained include/exclude list, so it can never drift from .gitignore (no node_modules,
# no .env, no rotated *.log files, no /backups, no /src/generated/prisma ending up in a
# release by accident). The restaurant's machine runs `npm ci && npm run build` and
# `prisma migrate deploy` itself during the update (see launcher/scripts/apply-update.ps1) -
# this script only needs to produce the source.
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File scripts\build-release.ps1
#
# Reads the version from package.json, builds <repoRoot>\releases\restaurant-app-<version>.zip,
# and prints a version.json snippet ready to paste into the releases repo.

$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
Set-Location $repoRoot

$packageJson = Get-Content -Raw (Join-Path $repoRoot "package.json") | ConvertFrom-Json
$version = $packageJson.version
if (-not $version) { throw "Could not read version from package.json." }

$gitStatus = git status --porcelain
if ($gitStatus) {
  # Fail rather than warn: `git archive HEAD` below only ever packages committed content, so
  # building with uncommitted changes present would silently ship a version.json that
  # doesn't match what's actually in the zip (the version above is read from the working
  # tree's package.json, not HEAD's).
  throw "Working tree has uncommitted changes - commit (and ideally tag v$version) before building a release, so the archived content matches the reported version."
}

$outDir = Join-Path $repoRoot "releases"
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$outZip = Join-Path $outDir "restaurant-app-$version.zip"

Write-Output "Building release $version from the current commit's tracked files..."
git archive --format=zip --output $outZip HEAD

$sha256 = (Get-FileHash -Path $outZip -Algorithm SHA256).Hash

Write-Output ""
Write-Output "Built: $outZip"
Write-Output "SHA256: $sha256"
Write-Output ""
Write-Output "version.json for the releases repo (fill in downloadUrl once uploaded, and notes):"
Write-Output "----------------------------------------------------------------------------------"
$manifest = [ordered]@{
  version           = $version
  releasedAt        = (Get-Date -Format "yyyy-MM-dd")
  notes             = "TODO: what changed in this release"
  downloadUrl       = "TODO: the GitHub Release download URL for restaurant-app-$version.zip"
  sha256            = $sha256
  minLauncherVersion = "1.0.0"
}
$manifest | ConvertTo-Json
Write-Output "----------------------------------------------------------------------------------"
Write-Output ""
Write-Output "Next: upload $outZip as a GitHub Release asset on the releases repo, fill in the"
Write-Output "downloadUrl/notes above, and commit the result as latest.json there."
