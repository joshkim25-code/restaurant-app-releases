// Clears transactional test data (bills, reservations, calls, customers) before going live,
// keeping the menu, tables, hours, printers, users and settings. Writes a JSON backup first.
//   npx tsx -r dotenv/config scripts/clear-test-data.ts --yes            (local database)
//   npx tsx -r dotenv/config scripts/clear-test-data.ts --cloud --yes    (Neon copy)
import fs from "node:fs";
import path from "node:path";
import { localDb, cloudDb } from "../sync/db";

const useCloud = process.argv.includes("--cloud");
const confirmed = process.argv.includes("--yes");
const db = useCloud ? cloudDb : localDb;
const label = useCloud ? "CLOUD (Neon)" : "LOCAL";

async function counts(restaurantId: string) {
  const where = { restaurantId };
  return {
    bills: await db.bill.count({ where }),
    reservations: await db.reservation.count({ where }),
    calls: await db.call.count({ where }),
    customers: await db.customer.count({ where }),
  };
}

async function main() {
  const restaurants = await db.restaurant.findMany({ select: { id: true, name: true } });
  if (restaurants.length !== 1) {
    throw new Error(`Expected exactly one restaurant in the ${label} database, found ${restaurants.length}.`);
  }
  const { id: restaurantId, name } = restaurants[0];

  console.log(`${label} database, restaurant "${name}"`);
  console.log("before:", await counts(restaurantId));

  if (!confirmed) {
    console.log("\nDry run only. Re-run with --yes to back up and delete.");
    return;
  }

  const backup = {
    takenAt: new Date().toISOString(),
    database: label,
    restaurantId,
    bills: await db.bill.findMany({
      where: { restaurantId },
      include: { payment: true, orders: { include: { items: { include: { optionChoices: true } } } } },
    }),
    reservations: await db.reservation.findMany({ where: { restaurantId } }),
    calls: await db.call.findMany({ where: { restaurantId }, include: { messages: true } }),
    customers: await db.customer.findMany({ where: { restaurantId } }),
  };
  const dir = path.join(__dirname, "..", "backups");
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `pre-launch-${useCloud ? "cloud" : "local"}-${Date.now()}.json`);
  fs.writeFileSync(file, JSON.stringify(backup, null, 2));
  console.log(`backup written: ${file}`);

  // Bills cascade to orders/items/payments, calls cascade to messages. Reservations go
  // before customers, which they reference.
  await db.$transaction([
    db.bill.deleteMany({ where: { restaurantId } }),
    db.reservation.deleteMany({ where: { restaurantId } }),
    db.call.deleteMany({ where: { restaurantId } }),
    db.customer.deleteMany({ where: { restaurantId } }),
  ]);

  console.log("after: ", await counts(restaurantId));
}

main().then(
  () => process.exit(0),
  (err) => {
    console.error(err instanceof Error ? err.message : err);
    process.exit(1);
  },
);
