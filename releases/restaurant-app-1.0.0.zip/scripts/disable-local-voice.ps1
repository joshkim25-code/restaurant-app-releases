# Run this once the cloud voice service has taken over the Twilio number's webhook.
# Stops the local voice server + ngrok tunnel and sets them to Manual so they don't come
# back on boot. Does not delete them - to roll back, point the Twilio webhook back at the
# tunnel URL and run: Set-Service RestaurantVoice -StartupType Automatic (and the same for
# RestaurantVoiceTunnel), then Start-Service both.

$ErrorActionPreference = "Stop"

foreach ($name in @("RestaurantVoice", "RestaurantVoiceTunnel")) {
  Stop-Service $name -ErrorAction SilentlyContinue
  Set-Service $name -StartupType Manual
}

Write-Output ""
Write-Output "Status:"
Get-Service RestaurantVoice, RestaurantVoiceTunnel | Format-Table Name, Status, StartType

Write-Output ""
Write-Output "Press Enter to close this window..."
Read-Host | Out-Null
