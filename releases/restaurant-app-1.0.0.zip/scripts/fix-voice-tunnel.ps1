# One-off fix: repoints the RestaurantVoiceTunnel service at the real ngrok.exe
# (not the Windows Store alias stub, which fails silently under a service account),
# and points it at the logged-in user's ngrok config explicitly - the service runs as
# LocalSystem, whose %LOCALAPPDATA% isn't the same folder as the interactive user's,
# so it can't find the saved authtoken unless told exactly where to look.
# See install-voice-service.ps1 for the full install this patches.

$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
$nssm = (Get-ChildItem -Path "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Filter "nssm.exe" -Recurse |
  Where-Object { $_.FullName -like "*win64*" } | Select-Object -First 1 -ExpandProperty FullName)
$ngrokCmd = (Get-ChildItem -Path "$env:ProgramFiles\WindowsApps" -Filter "ngrok.exe" -Recurse -ErrorAction SilentlyContinue |
  Select-Object -First 1 -ExpandProperty FullName)
# Elevating here may run as a different Windows account than the one you're logged in
# as (a separate admin account, not just joshu's own token) - so its AppData isn't
# necessarily C:\Users\joshu\... Check each account's known config locations directly
# rather than recursing into C:\Users, which can crash on broken reparse points
# (e.g. OneDrive junctions) partway through.
# ngrok is installed as a Windows Store (MSIX) package, so it actually writes its
# config into the package's virtualized storage, not the plain path `ngrok config
# check` displays - check both.
$ngrokConfig = $null
foreach ($userDir in (Get-ChildItem -Path "C:\Users" -Directory -Force -ErrorAction SilentlyContinue)) {
  $plain = Join-Path $userDir.FullName "AppData\Local\ngrok\ngrok.yml"
  if (Test-Path -LiteralPath $plain -ErrorAction SilentlyContinue) {
    $ngrokConfig = $plain
    break
  }
  $packaged = Get-ChildItem -Path (Join-Path $userDir.FullName "AppData\Local\Packages\ngrok.ngrok_*\LocalCache\Local\ngrok\ngrok.yml") -ErrorAction SilentlyContinue |
    Select-Object -First 1 -ExpandProperty FullName
  if ($packaged) {
    $ngrokConfig = $packaged
    break
  }
}

if (-not $nssm) { throw "nssm.exe not found." }
if (-not $ngrokCmd) { throw "ngrok.exe not found under Program Files\WindowsApps." }
if (-not $ngrokConfig) {
  Write-Output "No ngrok.yml found under C:\Users\*. Running as: $env:USERNAME"
  throw "ngrok config not found anywhere under C:\Users."
}
Write-Output "Running as: $env:USERNAME. Found ngrok config at: $ngrokConfig"

# The discovered file may sit inside a Windows Store app's sandboxed storage, whose
# ACLs don't grant LocalSystem read access even with the right path. Copy it
# somewhere plain and universally-readable instead of referencing it in place.
$stableConfigDir = "C:\ProgramData\ngrok"
$stableConfig = Join-Path $stableConfigDir "ngrok.yml"
New-Item -ItemType Directory -Path $stableConfigDir -Force | Out-Null
Copy-Item -LiteralPath $ngrokConfig -Destination $stableConfig -Force
$ngrokConfig = $stableConfig
Write-Output "Copied to stable location: $ngrokConfig"

$envLine = Get-Content (Join-Path $repoRoot ".env") | Where-Object { $_ -match '^VOICE_PUBLIC_URL=' }
$publicUrl = ($envLine -split '=', 2)[1].Trim('"', "'", ' ')
$domain = ($publicUrl -replace '^https?://', '') -replace '/$', ''
$voicePort = (Get-Content (Join-Path $repoRoot ".env") | Where-Object { $_ -match '^VOICE_PORT=' } |
  ForEach-Object { ($_ -split '=', 2)[1].Trim('"', "'", ' ') })
if (-not $voicePort) { $voicePort = "3100" }

& $nssm set RestaurantVoiceTunnel Application $ngrokCmd
& $nssm set RestaurantVoiceTunnel AppParameters "http --config=`"$ngrokConfig`" --domain=$domain $voicePort"
Start-Service RestaurantVoiceTunnel
Start-Sleep -Seconds 2

Write-Output ""
Write-Output "Status:"
Get-Service RestaurantVoice, RestaurantVoiceTunnel | Format-Table Name, Status

Write-Output ""
Write-Output "Press Enter to close this window..."
Read-Host | Out-Null
