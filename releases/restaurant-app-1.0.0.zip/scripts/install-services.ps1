# Registers the app, print agent, and sync process as Windows Services via NSSM, so they
# survive closing any terminal and auto-start on reboot, with auto-restart on crash.
#
# Must be run from an elevated (Administrator) PowerShell - service registration requires
# admin rights. Right-click Start -> "Terminal (Admin)" / "Windows PowerShell (Admin)",
# or search "PowerShell", then Ctrl+Shift+Enter.
#
# Usage:  powershell -ExecutionPolicy Bypass -File scripts\install-services.ps1

$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
Start-Transcript -Path (Join-Path $repoRoot "install-services-output.log") -Force | Out-Null

$nssm = (Get-ChildItem -Path "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Filter "nssm.exe" -Recurse |
  Where-Object { $_.FullName -like "*win64*" } | Select-Object -First 1 -ExpandProperty FullName)
$npmCmd = "C:\Program Files\nodejs\npm.cmd"

if (-not $nssm) { throw "nssm.exe not found - install it first: winget install --id NSSM.NSSM -e" }
if (-not (Test-Path $npmCmd)) { throw "npm.cmd not found at $npmCmd - adjust the path in this script." }

function Install-AppService {
  param(
    [string]$Name,
    [string]$NpmArgs,
    [string]$LogFile
  )

  $existing = Get-Service -Name $Name -ErrorAction SilentlyContinue
  if ($existing) {
    Write-Output "Service '$Name' already exists - stopping and removing it first."
    & $nssm stop $Name
    & $nssm remove $Name confirm
  }

  & $nssm install $Name $npmCmd $NpmArgs
  & $nssm set $Name AppDirectory $repoRoot
  & $nssm set $Name AppStdout (Join-Path $repoRoot $LogFile)
  & $nssm set $Name AppStderr (Join-Path $repoRoot $LogFile)
  & $nssm set $Name AppRotateFiles 1
  & $nssm set $Name AppRotateBytes 5242880
  & $nssm set $Name Start SERVICE_AUTO_START
  & $nssm set $Name AppExit Default Restart
  & $nssm set $Name AppRestartDelay 3000
  & $nssm start $Name

  Write-Output "Installed and started '$Name'."
}

Install-AppService -Name "RestaurantApp" -NpmArgs "run dev" -LogFile "dev-server.log"
Install-AppService -Name "RestaurantPrintAgent" -NpmArgs "run agent" -LogFile "agent.log"
Install-AppService -Name "RestaurantSync" -NpmArgs "run sync" -LogFile "sync.log"
Install-AppService -Name "RestaurantVoice" -NpmArgs "run voice" -LogFile "voice.log"

Write-Output ""
Write-Output "Done. Check status any time with: Get-Service Restaurant*"
Stop-Transcript | Out-Null
