# Registers the AI phone-reservation voice server (and its ngrok tunnel) as Windows
# Services via NSSM, so they survive closing any terminal and auto-start on reboot,
# with auto-restart on crash. Doesn't touch RestaurantApp/PrintAgent/Sync - those are
# already installed; see install-services.ps1 if those ever need reinstalling.
#
# Must be run from an elevated (Administrator) PowerShell - service registration requires
# admin rights. Right-click Start -> "Terminal (Admin)" / "Windows PowerShell (Admin)",
# or search "PowerShell", then Ctrl+Shift+Enter.
#
# Usage:  powershell -ExecutionPolicy Bypass -File scripts\install-voice-service.ps1

$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
Start-Transcript -Path (Join-Path $repoRoot "install-voice-service-output.log") -Force | Out-Null

$nssm = (Get-ChildItem -Path "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Filter "nssm.exe" -Recurse |
  Where-Object { $_.FullName -like "*win64*" } | Select-Object -First 1 -ExpandProperty FullName)
$npmCmd = "C:\Program Files\nodejs\npm.cmd"
# `Get-Command ngrok` resolves to the Windows Store app-execution-alias stub, which
# fails silently when launched by a service/SYSTEM account (no interactive session for
# it to resolve through) - find the real packaged exe instead.
$ngrokCmd = (Get-ChildItem -Path "$env:ProgramFiles\WindowsApps" -Filter "ngrok.exe" -Recurse -ErrorAction SilentlyContinue |
  Select-Object -First 1 -ExpandProperty FullName)

if (-not $nssm) { throw "nssm.exe not found - install it first: winget install --id NSSM.NSSM -e" }
if (-not (Test-Path $npmCmd)) { throw "npm.cmd not found at $npmCmd - adjust the path in this script." }
if (-not $ngrokCmd) { throw "ngrok.exe not found under Program Files\WindowsApps." }

# Read VOICE_PUBLIC_URL out of .env so the tunnel's --domain always matches what
# Twilio is configured to call - this only ever changes if you change that value.
$envLine = Get-Content (Join-Path $repoRoot ".env") | Where-Object { $_ -match '^VOICE_PUBLIC_URL=' }
if (-not $envLine) { throw "VOICE_PUBLIC_URL not found in .env" }
$publicUrl = ($envLine -split '=', 2)[1].Trim('"', "'", ' ')
$domain = ($publicUrl -replace '^https?://', '') -replace '/$', ''
$voicePort = (Get-Content (Join-Path $repoRoot ".env") | Where-Object { $_ -match '^VOICE_PORT=' } |
  ForEach-Object { ($_ -split '=', 2)[1].Trim('"', "'", ' ') })
if (-not $voicePort) { $voicePort = "3100" }

function Install-AppService {
  param(
    [string]$Name,
    [string]$Command,
    [string]$Arguments,
    [string]$LogFile
  )

  $existing = Get-Service -Name $Name -ErrorAction SilentlyContinue
  if ($existing) {
    Write-Output "Service '$Name' already exists - stopping and removing it first."
    & $nssm stop $Name
    & $nssm remove $Name confirm
  }

  & $nssm install $Name $Command $Arguments
  & $nssm set $Name AppDirectory $repoRoot
  & $nssm set $Name AppStdout (Join-Path $repoRoot $LogFile)
  & $nssm set $Name AppStderr (Join-Path $repoRoot $LogFile)
  & $nssm set $Name AppRotateFiles 1
  & $nssm set $Name AppRotateBytes 5242880
  & $nssm set $Name Start SERVICE_AUTO_START
  & $nssm set $Name AppExit Default Restart
  & $nssm set $Name AppRestartDelay 3000
  & $nssm start $Name

  Write-Output "Installed and started '$Name'."
}

# The service runs as LocalSystem, whose %LOCALAPPDATA% isn't the interactive user's
# profile, so ngrok can't find the saved authtoken unless pointed at it explicitly.
# Elevating to run this script may also be a different Windows account than your own,
# so check each account's known config locations directly rather than recursing into
# C:\Users, which can crash on broken reparse points (e.g. OneDrive junctions).
# ngrok is installed as a Windows Store (MSIX) package, so it actually writes its
# config into the package's virtualized storage, not the plain path `ngrok config
# check` displays - check both.
$ngrokConfig = $null
foreach ($userDir in (Get-ChildItem -Path "C:\Users" -Directory -Force -ErrorAction SilentlyContinue)) {
  $plain = Join-Path $userDir.FullName "AppData\Local\ngrok\ngrok.yml"
  if (Test-Path -LiteralPath $plain -ErrorAction SilentlyContinue) {
    $ngrokConfig = $plain
    break
  }
  $packaged = Get-ChildItem -Path (Join-Path $userDir.FullName "AppData\Local\Packages\ngrok.ngrok_*\LocalCache\Local\ngrok\ngrok.yml") -ErrorAction SilentlyContinue |
    Select-Object -First 1 -ExpandProperty FullName
  if ($packaged) {
    $ngrokConfig = $packaged
    break
  }
}
if (-not $ngrokConfig) { throw "ngrok config (ngrok.yml) not found under C:\Users\*. Run 'ngrok config add-authtoken <token>' first." }

# The discovered file may sit inside a Windows Store app's sandboxed storage, whose
# ACLs don't grant LocalSystem read access even with the right path. Copy it
# somewhere plain and universally-readable instead of referencing it in place.
$stableConfigDir = "C:\ProgramData\ngrok"
$stableConfig = Join-Path $stableConfigDir "ngrok.yml"
New-Item -ItemType Directory -Path $stableConfigDir -Force | Out-Null
Copy-Item -LiteralPath $ngrokConfig -Destination $stableConfig -Force
$ngrokConfig = $stableConfig

Install-AppService -Name "RestaurantVoice" -Command $npmCmd -Arguments "run voice" -LogFile "voice.log"
Install-AppService -Name "RestaurantVoiceTunnel" -Command $ngrokCmd -Arguments "http --config=`"$ngrokConfig`" --domain=$domain $voicePort" -LogFile "voice-tunnel.log"

Write-Output ""
Write-Output "Done. Check status any time with: Get-Service Restaurant*"
Stop-Transcript | Out-Null
