# Stops RestaurantApp, runs `npm run build`, then starts it again - all in one step.
# Needed (not just a plain restart) because the running production server holds a file
# lock on .next-prod, so `npm run build` fails with EPERM while the service is up.

$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
$nssm = (Get-ChildItem -Path "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Filter "nssm.exe" -Recurse |
  Where-Object { $_.FullName -like "*win64*" } | Select-Object -First 1 -ExpandProperty FullName)
$npmCmd = "C:\Program Files\nodejs\npm.cmd"

if (-not $nssm) { throw "nssm.exe not found." }
if (-not (Test-Path $npmCmd)) { throw "npm.cmd not found at $npmCmd." }

Set-Location $repoRoot

Write-Output "Stopping RestaurantApp..."
& $nssm stop RestaurantApp
Start-Sleep -Seconds 1

# Next.js deletes the previous build's files itself at the start of a build, and on this
# OneDrive-synced folder that fails with EPERM while OneDrive is still touching them.
# Clearing the folder here first (with retries) avoids it.
$nextProd = Join-Path $repoRoot ".next-prod"
Write-Output "Clearing old build output..."
for ($attempt = 1; $attempt -le 5 -and (Test-Path $nextProd); $attempt++) {
  Remove-Item -Recurse -Force $nextProd -ErrorAction SilentlyContinue
  if (Test-Path $nextProd) { Start-Sleep -Seconds 2 }
}
if (Test-Path $nextProd) {
  throw "Could not clear .next-prod - close anything using it and try again."
}

Write-Output "Building..."
& $npmCmd run build
$buildExitCode = $LASTEXITCODE

# On a OneDrive-synced folder, npm can report success before the build's last files
# (notably .next-prod\BUILD_ID) are actually flushed to disk - starting the service
# immediately then finds an incomplete build and crash-loops. Wait for it to appear.
$buildId = Join-Path $repoRoot ".next-prod\BUILD_ID"
$waited = 0
while (-not (Test-Path $buildId) -and $waited -lt 30) {
  Start-Sleep -Seconds 1
  $waited++
}
if (-not (Test-Path $buildId)) {
  Write-Output "WARNING: BUILD_ID never appeared after ${waited}s - build likely failed. Not starting the service on a broken build."
  Write-Output "Press Enter to close this window..."
  Read-Host | Out-Null
  exit 1
}

Write-Output "Starting RestaurantApp..."
& $nssm start RestaurantApp
Start-Sleep -Seconds 2

Write-Output ""
Write-Output "Status:"
Get-Service RestaurantApp | Format-Table Name, Status

if ($buildExitCode -ne 0) {
  Write-Output ""
  Write-Output "WARNING: build exited with code $buildExitCode - the service was restarted on whatever build output already existed."
}

Write-Output ""
Write-Output "Press Enter to close this window..."
Read-Host | Out-Null
