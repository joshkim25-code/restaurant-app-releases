# Restarts all five app services. For a RestaurantApp code change, prefer
# rebuild-app.bat instead (it rebuilds first) - this script only restarts,
# it doesn't rebuild.

$ErrorActionPreference = "Stop"

$nssm = (Get-ChildItem -Path "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Filter "nssm.exe" -Recurse |
  Where-Object { $_.FullName -like "*win64*" } | Select-Object -First 1 -ExpandProperty FullName)
if (-not $nssm) { throw "nssm.exe not found." }

# Only services set to Automatic - disable-local-voice.bat sets the local voice/tunnel to
# Manual once the cloud voice service has taken over, so they stay stopped here.
$services = @("RestaurantApp", "RestaurantPrintAgent", "RestaurantSync", "RestaurantVoice", "RestaurantVoiceTunnel") |
  Where-Object { (Get-Service $_).StartType -eq "Automatic" }
foreach ($name in $services) {
  & $nssm restart $name
}
Start-Sleep -Seconds 2

Write-Output ""
Write-Output "Status:"
Get-Service $services | Format-Table Name, Status

Write-Output ""
Write-Output "Press Enter to close this window..."
Read-Host | Out-Null
