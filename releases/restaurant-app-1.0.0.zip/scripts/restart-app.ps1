# Restarts the RestaurantApp service so it picks up a fresh `npm run build`.
# Needed after every code change, since the service runs the compiled production
# build (`npm run start`), not `next dev` - see project_windows_services memory.

$ErrorActionPreference = "Stop"

$nssm = (Get-ChildItem -Path "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Filter "nssm.exe" -Recurse |
  Where-Object { $_.FullName -like "*win64*" } | Select-Object -First 1 -ExpandProperty FullName)
if (-not $nssm) { throw "nssm.exe not found." }

& $nssm restart RestaurantApp
Start-Sleep -Seconds 2

Write-Output ""
Write-Output "Status:"
Get-Service RestaurantApp | Format-Table Name, Status

Write-Output ""
Write-Output "Press Enter to close this window..."
Read-Host | Out-Null
