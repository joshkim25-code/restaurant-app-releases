# Restarts the RestaurantVoice service so it picks up a code change in voice/.
# No build step needed - it runs voice/index.ts directly via tsx.

$ErrorActionPreference = "Stop"

$nssm = (Get-ChildItem -Path "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Filter "nssm.exe" -Recurse |
  Where-Object { $_.FullName -like "*win64*" } | Select-Object -First 1 -ExpandProperty FullName)
if (-not $nssm) { throw "nssm.exe not found." }

& $nssm restart RestaurantVoice
Start-Sleep -Seconds 2

Write-Output ""
Write-Output "Status:"
Get-Service RestaurantVoice | Format-Table Name, Status

Write-Output ""
Write-Output "Press Enter to close this window..."
Read-Host | Out-Null
