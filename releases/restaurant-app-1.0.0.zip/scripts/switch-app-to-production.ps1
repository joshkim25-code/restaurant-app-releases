# Switches the RestaurantApp service from `npm run dev` to `npm run start` (a real
# production build, already built via `npm run build`). Must be run from an elevated
# (Administrator) PowerShell, same as install-services.ps1.
#
# Usage:  powershell -ExecutionPolicy Bypass -File scripts\switch-app-to-production.ps1

$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
Start-Transcript -Path (Join-Path $repoRoot "switch-to-production-output.log") -Force | Out-Null

$nssm = (Get-ChildItem -Path "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Filter "nssm.exe" -Recurse |
  Where-Object { $_.FullName -like "*win64*" } | Select-Object -First 1 -ExpandProperty FullName)

if (-not $nssm) { throw "nssm.exe not found." }

& $nssm stop RestaurantApp
& $nssm set RestaurantApp AppParameters "run start"
& $nssm start RestaurantApp

Write-Output "RestaurantApp now runs 'npm run start' (production) instead of 'npm run dev'."
Stop-Transcript | Out-Null
