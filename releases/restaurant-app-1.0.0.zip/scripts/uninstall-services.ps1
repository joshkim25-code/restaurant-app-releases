# Removes the three services created by install-services.ps1. Must be run from an
# elevated (Administrator) PowerShell, same as the install script.
#
# Usage:  powershell -ExecutionPolicy Bypass -File scripts\uninstall-services.ps1

$nssm = (Get-ChildItem -Path "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Filter "nssm.exe" -Recurse |
  Where-Object { $_.FullName -like "*win64*" } | Select-Object -First 1 -ExpandProperty FullName)

if (-not $nssm) { throw "nssm.exe not found." }

foreach ($name in @("RestaurantApp", "RestaurantPrintAgent", "RestaurantSync", "RestaurantVoice")) {
  $existing = Get-Service -Name $name -ErrorAction SilentlyContinue
  if ($existing) {
    & $nssm stop $name
    & $nssm remove $name confirm
    Write-Output "Removed '$name'."
  } else {
    Write-Output "'$name' isn't installed - skipping."
  }
}
