import Link from "next/link";
import { notFound } from "next/navigation";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { getCallDetail } from "@/lib/calls";
import { formatDateTime, formatClockTime } from "@/lib/time";

export default async function CallDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const restaurant = await getCurrentRestaurant();
  const call = await getCallDetail(restaurant.id, id);

  if (!call) notFound();

  return (
    <div className="space-y-6">
      <div>
        <Link href="/calls" className="text-sm text-neutral-500 underline hover:text-neutral-900">
          ← Back to Calls
        </Link>
        <h1 className="mt-2 text-xl font-semibold">Call from {call.fromPhoneNumber}</h1>
        <p className="text-sm text-neutral-500">
          {formatDateTime(call.startedAt, restaurant.timezone)}
          {call.endedAt ? ` – ${formatClockTime(call.endedAt, restaurant.timezone)}` : ""}
        </p>
        {call.reservation && (
          <p className="mt-1 text-sm text-green-700">
            Booked: party of {call.reservation.partySize} at{" "}
            {formatClockTime(call.reservation.startTime, restaurant.timezone)}
          </p>
        )}
      </div>

      <div className="space-y-3 rounded-lg border border-neutral-200 bg-white p-4">
        {call.messages.length === 0 && (
          <p className="text-sm text-neutral-400">No transcript recorded for this call.</p>
        )}
        {call.messages.map((message) => {
          if (message.role === "TOOL") {
            return (
              <div key={message.id} className="rounded bg-neutral-50 px-3 py-2 text-xs text-neutral-500">
                <span className="font-mono">{message.content}</span>
                {message.toolInput != null && (
                  <pre className="mt-1 overflow-x-auto whitespace-pre-wrap font-mono">
                    in: {JSON.stringify(message.toolInput)}
                  </pre>
                )}
                {message.toolResult != null && (
                  <pre className="mt-1 overflow-x-auto whitespace-pre-wrap font-mono">
                    out: {JSON.stringify(message.toolResult)}
                  </pre>
                )}
              </div>
            );
          }

          const isCaller = message.role === "USER";
          return (
            <div key={message.id} className={`flex ${isCaller ? "justify-start" : "justify-end"}`}>
              <div
                className={`max-w-[75%] rounded-lg px-3 py-2 text-sm ${
                  isCaller ? "bg-neutral-100 text-neutral-900" : "bg-neutral-900 text-white"
                }`}
              >
                <div className="mb-0.5 text-xs opacity-60">{isCaller ? "Caller" : "Assistant"}</div>
                {message.content}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
