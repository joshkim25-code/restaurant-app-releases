import Link from "next/link";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { getCallHistory } from "@/lib/calls";
import { formatDateTime, formatClockTime } from "@/lib/time";
import { Pagination } from "@/components/Pagination";
import type { CallStatus } from "@/generated/prisma/client";

const STATUS_LABEL: Record<CallStatus, string> = {
  IN_PROGRESS: "In progress",
  COMPLETED: "Completed",
  ABANDONED: "Abandoned",
  FAILED: "Failed",
  TRANSFERRED: "Transferred",
};

const STATUS_CLASS: Record<CallStatus, string> = {
  IN_PROGRESS: "text-amber-600",
  COMPLETED: "text-green-700",
  ABANDONED: "text-neutral-500",
  FAILED: "text-red-600",
  TRANSFERRED: "text-neutral-500",
};

function durationLabel(startedAt: Date, endedAt: Date | null): string {
  if (!endedAt) return "—";
  const seconds = Math.max(0, Math.round((endedAt.getTime() - startedAt.getTime()) / 1000));
  const minutes = Math.floor(seconds / 60);
  const remainder = seconds % 60;
  return `${minutes}:${String(remainder).padStart(2, "0")}`;
}

export default async function CallsPage({
  searchParams,
}: {
  searchParams: Promise<{ page?: string }>;
}) {
  const params = await searchParams;
  const page = Math.max(1, Number(params.page) || 1);

  const restaurant = await getCurrentRestaurant();
  const { calls, hasNext, hasPrev } = await getCallHistory(restaurant.id, { page });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Calls</h1>
        <p className="text-sm text-neutral-500">
          Every phone call handled by the AI reservation assistant for {restaurant.name}.
        </p>
      </div>

      <table className="w-full border-collapse overflow-hidden rounded-lg border border-neutral-200 bg-white text-sm">
        <thead className="bg-neutral-100 text-left text-neutral-600">
          <tr>
            <th className="px-4 py-2 font-medium">Started</th>
            <th className="px-4 py-2 font-medium">From</th>
            <th className="px-4 py-2 font-medium">Duration</th>
            <th className="px-4 py-2 font-medium">Status</th>
            <th className="px-4 py-2 font-medium">Reservation</th>
            <th className="px-4 py-2" />
          </tr>
        </thead>
        <tbody>
          {calls.map((call) => (
            <tr key={call.id} className="border-t border-neutral-200 align-top">
              <td className="px-4 py-2">{formatDateTime(call.startedAt, restaurant.timezone)}</td>
              <td className="px-4 py-2">{call.fromPhoneNumber}</td>
              <td className="px-4 py-2">{durationLabel(call.startedAt, call.endedAt)}</td>
              <td className="px-4 py-2">
                <span className={STATUS_CLASS[call.status]}>{STATUS_LABEL[call.status]}</span>
              </td>
              <td className="px-4 py-2">
                {call.reservation ? (
                  <>
                    Party of {call.reservation.partySize} at{" "}
                    {formatClockTime(call.reservation.startTime, restaurant.timezone)}
                  </>
                ) : (
                  <span className="text-neutral-400">—</span>
                )}
              </td>
              <td className="px-4 py-2 text-right">
                <Link href={`/calls/${call.id}`} className="underline hover:text-neutral-900">
                  Transcript
                </Link>
              </td>
            </tr>
          ))}
          {calls.length === 0 && (
            <tr>
              <td colSpan={6} className="px-4 py-6 text-center text-neutral-400">
                No calls yet.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <Pagination basePath="/calls" page={page} hasPrev={hasPrev} hasNext={hasNext} />
    </div>
  );
}
