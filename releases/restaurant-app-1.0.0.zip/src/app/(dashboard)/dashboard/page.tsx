import Link from "next/link";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { getTablesWithStatus } from "@/lib/tables";
import { updateTableLayout } from "@/lib/floorPlanActions";
import { FloorPlan } from "@/components/floor-plan/FloorPlan";
import { createTable, deleteTable } from "../tables/actions";

export default async function DashboardPage() {
  const restaurant = await getCurrentRestaurant();
  const tables = await getTablesWithStatus(restaurant.id);

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold">Dashboard</h1>
          <p className="text-sm text-neutral-500">
            {restaurant.name}&rsquo;s floor plan. Toggle edit mode to drag, resize, or
            reshape tables, or add/remove tables directly on the canvas.
          </p>
        </div>
        <Link
          href="/waiter"
          className="shrink-0 rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700"
        >
          Waiter view
        </Link>
      </div>
      <FloorPlan
        role="owner"
        tables={tables}
        timezone={restaurant.timezone}
        updateTableLayout={updateTableLayout}
        createTable={createTable}
        deleteTable={deleteTable}
      />
    </div>
  );
}
