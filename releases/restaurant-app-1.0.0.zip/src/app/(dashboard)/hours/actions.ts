"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";

export async function updateBusinessHours(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  for (let dayOfWeek = 0; dayOfWeek < 7; dayOfWeek++) {
    const isClosed = formData.get(`closed-${dayOfWeek}`) === "on";
    const openTime = String(formData.get(`open-${dayOfWeek}`) ?? "17:00");
    const closeTime = String(formData.get(`close-${dayOfWeek}`) ?? "22:00");

    await db.businessHours.upsert({
      where: {
        restaurantId_dayOfWeek: {
          restaurantId: restaurant.id,
          dayOfWeek,
        },
      },
      update: { isClosed, openTime, closeTime },
      create: {
        restaurantId: restaurant.id,
        dayOfWeek,
        isClosed,
        openTime,
        closeTime,
      },
    });
  }

  revalidatePath("/hours");
}
