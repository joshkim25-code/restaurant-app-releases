import Link from "next/link";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { getPendingReservationCount } from "@/lib/reservations";
import { NotificationBadge } from "@/components/NotificationBadge";
import { ReservationNotifier } from "@/components/ReservationNotifier";
import { OrderNotifier } from "@/components/OrderNotifier";
import { LogoutButton } from "@/components/LogoutButton";
import { PhoneCallsToggle } from "@/components/PhoneCallsToggle";

const navItems = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/tables", label: "Tables" },
  { href: "/menu", label: "Menu" },
  { href: "/hours", label: "Hours" },
  { href: "/reports", label: "Reports" },
  { href: "/reservations", label: "Reservations" },
  { href: "/calls", label: "Calls" },
  { href: "/settings", label: "Settings" },
];

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const restaurant = await getCurrentRestaurant();
  const pendingReservationCount = await getPendingReservationCount(restaurant.id);

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900">
      <header className="border-b border-neutral-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center gap-6 px-6 py-4">
          <span className="font-semibold">Restaurant Dashboard</span>
          <nav className="flex gap-4 text-sm">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`text-neutral-600 hover:text-neutral-900 ${
                  item.href === "/reservations" ? "relative" : ""
                }`}
              >
                {item.label}
                {item.href === "/reservations" && (
                  <NotificationBadge count={pendingReservationCount} />
                )}
              </Link>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-3">
            <PhoneCallsToggle accepting={restaurant.voiceAcceptCalls} />
            <LogoutButton />
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-6 py-8">{children}</main>
      <ReservationNotifier
        enabled={restaurant.notifyNewReservationInApp}
        timezone={restaurant.timezone}
        durationSeconds={restaurant.notificationDurationSeconds}
      />
      <OrderNotifier
        enabled={restaurant.notifyNewPhoneOrderInApp}
        currency={restaurant.currency}
        durationSeconds={restaurant.notificationDurationSeconds}
      />
    </div>
  );
}
