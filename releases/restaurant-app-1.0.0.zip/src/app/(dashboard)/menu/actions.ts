"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import type { OptionGroupSelectionType } from "@/generated/prisma/client";

export async function createCategory(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  const name = String(formData.get("name") ?? "").trim();
  if (!name) {
    throw new Error("A category name is required.");
  }

  const count = await db.menuCategory.count({
    where: { restaurantId: restaurant.id },
  });

  await db.menuCategory.create({
    data: { restaurantId: restaurant.id, name, sortOrder: count },
  });

  revalidatePath("/menu");
}

export async function deleteCategory(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = String(formData.get("id"));

  const category = await db.menuCategory.findFirst({
    where: { id, restaurantId: restaurant.id },
    // Only active items should block deletion - an archived item (one with real order
    // history - see deleteMenuItem) is already hidden everywhere and doesn't need this
    // category to keep existing; MenuItem.categoryId is nullable with onDelete: SetNull
    // specifically so deleting the category just clears it from any archived items left.
    include: { _count: { select: { items: { where: { archivedAt: null } } } } },
  });
  if (!category) {
    throw new Error("Category not found.");
  }

  // Production Next.js hides thrown server-action messages, so this redirects back with
  // an error code the page can render instead of a generic crash.
  if (category._count.items > 0) {
    redirect(
      `/menu?error=category-has-items&category=${encodeURIComponent(category.name)}&count=${category._count.items}`,
    );
  }

  await db.menuCategory.delete({ where: { id, restaurantId: restaurant.id } });

  revalidatePath("/menu");
}

export async function createMenuItem(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  const categoryId = String(formData.get("categoryId") ?? "");
  const name = String(formData.get("name") ?? "").trim();
  const description = String(formData.get("description") ?? "").trim();
  const priceDollars = Number(formData.get("price"));

  if (!categoryId || !name || !Number.isFinite(priceDollars) || priceDollars < 0) {
    throw new Error("A category, name, and non-negative price are required.");
  }

  const category = await db.menuCategory.findUnique({
    where: { id: categoryId, restaurantId: restaurant.id },
  });
  if (!category) {
    throw new Error("Category not found.");
  }

  const count = await db.menuItem.count({ where: { categoryId } });

  await db.menuItem.create({
    data: {
      restaurantId: restaurant.id,
      categoryId,
      name,
      description: description || null,
      priceCents: Math.round(priceDollars * 100),
      sortOrder: count,
    },
  });

  revalidatePath("/menu");
}

export async function updateMenuItemDetails(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = String(formData.get("id"));
  const name = String(formData.get("name") ?? "").trim();
  const description = String(formData.get("description") ?? "").trim();

  if (!name) {
    throw new Error("A name is required.");
  }

  await db.menuItem.update({
    where: { id, restaurantId: restaurant.id },
    data: { name, description: description || null },
  });

  revalidatePath("/menu");
}

// Swaps this item's sortOrder with its neighbor in the same category (the item one
// position up or down in the already-sorted list) — a no-op if it's already at that end.
export async function moveMenuItem(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = String(formData.get("id"));
  const direction = String(formData.get("direction"));

  if (direction !== "up" && direction !== "down") {
    throw new Error("Invalid direction.");
  }

  const item = await db.menuItem.findUnique({
    where: { id, restaurantId: restaurant.id },
  });
  if (!item) {
    throw new Error("Item not found.");
  }

  const neighbor = await db.menuItem.findFirst({
    where: {
      categoryId: item.categoryId,
      sortOrder: direction === "up" ? { lt: item.sortOrder } : { gt: item.sortOrder },
    },
    orderBy: { sortOrder: direction === "up" ? "desc" : "asc" },
  });
  if (!neighbor) {
    return;
  }

  await db.$transaction([
    db.menuItem.update({ where: { id: item.id }, data: { sortOrder: neighbor.sortOrder } }),
    db.menuItem.update({ where: { id: neighbor.id }, data: { sortOrder: item.sortOrder } }),
  ]);

  revalidatePath("/menu");
}

// Called directly from a client component's drop handler (not a <form action> - a drag
// event isn't a form submission), so it takes plain arguments rather than FormData.
// Persists a full drag-and-drop reorder in one go, rather than one adjacent swap at a time.
export async function reorderCategories(orderedIds: string[]): Promise<void> {
  const restaurant = await getCurrentRestaurant();

  const categories = await db.menuCategory.findMany({
    where: { restaurantId: restaurant.id, id: { in: orderedIds } },
    select: { id: true },
  });
  const validIds = new Set(categories.map((c) => c.id));
  if (validIds.size !== orderedIds.length) {
    throw new Error("One or more categories were not found.");
  }

  await db.$transaction(
    orderedIds.map((id, index) => db.menuCategory.update({ where: { id }, data: { sortOrder: index } })),
  );

  revalidatePath("/menu");
}

export async function reorderMenuItems(categoryId: string, orderedIds: string[]): Promise<void> {
  const restaurant = await getCurrentRestaurant();

  const category = await db.menuCategory.findFirst({
    where: { id: categoryId, restaurantId: restaurant.id },
  });
  if (!category) {
    throw new Error("Category not found.");
  }

  const items = await db.menuItem.findMany({
    where: { categoryId, id: { in: orderedIds } },
    select: { id: true },
  });
  const validIds = new Set(items.map((i) => i.id));
  if (validIds.size !== orderedIds.length) {
    throw new Error("One or more items were not found in this category.");
  }

  await db.$transaction(
    orderedIds.map((id, index) => db.menuItem.update({ where: { id }, data: { sortOrder: index } })),
  );

  revalidatePath("/menu");
}

export async function updateMenuItemPrice(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = String(formData.get("id"));
  const priceDollars = Number(formData.get("price"));

  if (!Number.isFinite(priceDollars) || priceDollars < 0) {
    throw new Error("A non-negative price is required.");
  }

  await db.menuItem.update({
    where: { id, restaurantId: restaurant.id },
    data: { priceCents: Math.round(priceDollars * 100) },
  });

  revalidatePath("/menu");
}

export async function toggleItemAvailable(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = String(formData.get("id"));
  const isAvailable = formData.get("isAvailable") === "true";

  await db.menuItem.update({
    where: { id, restaurantId: restaurant.id },
    data: { isAvailable: !isAvailable },
  });

  revalidatePath("/menu");
}

export async function assignMenuItemPrinter(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = String(formData.get("id"));
  const printerId = String(formData.get("printerId") ?? "").trim();

  let verifiedPrinterId: string | null = null;
  if (printerId.length > 0) {
    const printer = await db.printer.findUnique({
      where: { id: printerId, restaurantId: restaurant.id },
    });
    if (!printer) {
      throw new Error("Printer not found.");
    }
    verifiedPrinterId = printer.id;
  }

  await db.menuItem.update({
    where: { id, restaurantId: restaurant.id },
    data: { printerId: verifiedPrinterId },
  });

  revalidatePath("/menu");
}

export async function deleteMenuItem(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = String(formData.get("id"));

  const item = await db.menuItem.findFirst({
    where: { id, restaurantId: restaurant.id },
    include: { _count: { select: { orderItems: true } } },
  });
  if (!item) {
    throw new Error("Item not found.");
  }

  // OrderItem.menuItem has no cascade rule, and shouldn't get one — a past receipt or
  // kitchen ticket still needs this item's name. An item that's been ordered before can't
  // be truly deleted, so it's archived instead: hidden everywhere it'd normally be listed
  // (Menu page, ordering, the phone menu), but the row stays so history keeps working.
  if (item._count.orderItems > 0) {
    await db.menuItem.update({
      where: { id, restaurantId: restaurant.id },
      data: { archivedAt: new Date(), isAvailable: false },
    });
  } else {
    await db.menuItem.delete({ where: { id, restaurantId: restaurant.id } });
  }

  revalidatePath("/menu");
}

// Copies an item's fields plus every option group and choice into a new item in the same
// category — fast starting point for a similar dish instead of rebuilding its options
// from scratch. The copies are independent rows; editing one never touches the other.
export async function duplicateMenuItem(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = String(formData.get("id"));

  const item = await db.menuItem.findFirst({
    where: { id, restaurantId: restaurant.id },
    include: { optionGroups: { include: { choices: true } } },
  });
  if (!item) {
    throw new Error("Item not found.");
  }

  const count = await db.menuItem.count({ where: { categoryId: item.categoryId } });

  await db.menuItem.create({
    data: {
      restaurantId: restaurant.id,
      categoryId: item.categoryId,
      printerId: item.printerId,
      name: `${item.name} copy`,
      description: item.description,
      priceCents: item.priceCents,
      isAvailable: true,
      sortOrder: count,
      optionGroups: {
        create: item.optionGroups.map((group) => ({
          restaurantId: restaurant.id,
          name: group.name,
          selectionType: group.selectionType,
          isRequired: group.isRequired,
          minSelect: group.minSelect,
          maxSelect: group.maxSelect,
          sortOrder: group.sortOrder,
          choices: {
            create: group.choices.map((choice) => ({
              restaurantId: restaurant.id,
              name: choice.name,
              priceAdjustmentCents: choice.priceAdjustmentCents,
              sortOrder: choice.sortOrder,
            })),
          },
        })),
      },
    },
  });

  revalidatePath("/menu");
}

function parseGroupSelection(formData: FormData) {
  const rawSelectionType = String(formData.get("selectionType") ?? "SINGLE");
  const isRequired = formData.get("isRequired") === "on";

  if (rawSelectionType !== "SINGLE" && rawSelectionType !== "MULTI") {
    throw new Error("Invalid selection type.");
  }
  const selectionType = rawSelectionType as OptionGroupSelectionType;

  let minSelect: number | null = null;
  let maxSelect: number | null = null;

  if (selectionType === "MULTI") {
    minSelect = Number(formData.get("minSelect"));
    maxSelect = Number(formData.get("maxSelect"));

    if (!Number.isFinite(minSelect) || minSelect < 0) {
      throw new Error("Minimum selections must be 0 or more.");
    }
    if (!Number.isFinite(maxSelect) || maxSelect < 1 || maxSelect < minSelect) {
      throw new Error("Maximum selections must be at least 1 and at least the minimum.");
    }
    if (isRequired && minSelect < 1) {
      throw new Error("A required group must allow at least 1 selection.");
    }
  }

  return { selectionType, isRequired, minSelect, maxSelect };
}

export async function createOptionGroup(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  const menuItemId = String(formData.get("menuItemId") ?? "");
  const name = String(formData.get("name") ?? "").trim();

  if (!menuItemId || !name) {
    throw new Error("A group name is required.");
  }

  const menuItem = await db.menuItem.findUnique({
    where: { id: menuItemId, restaurantId: restaurant.id },
  });
  if (!menuItem) {
    throw new Error("Menu item not found.");
  }

  const { selectionType, isRequired, minSelect, maxSelect } = parseGroupSelection(formData);

  const count = await db.menuItemOptionGroup.count({ where: { menuItemId } });

  await db.menuItemOptionGroup.create({
    data: {
      restaurantId: restaurant.id,
      menuItemId,
      name,
      selectionType,
      isRequired,
      minSelect,
      maxSelect,
      sortOrder: count,
    },
  });

  revalidatePath("/menu");
}

export async function updateOptionGroup(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = String(formData.get("id"));
  const name = String(formData.get("name") ?? "").trim();

  if (!name) {
    throw new Error("A group name is required.");
  }

  const { selectionType, isRequired, minSelect, maxSelect } = parseGroupSelection(formData);

  await db.menuItemOptionGroup.update({
    where: { id, restaurantId: restaurant.id },
    data: { name, selectionType, isRequired, minSelect, maxSelect },
  });

  revalidatePath("/menu");
}

export async function deleteOptionGroup(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = String(formData.get("id"));

  await db.menuItemOptionGroup.delete({ where: { id, restaurantId: restaurant.id } });

  revalidatePath("/menu");
}

export async function createOptionChoice(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  const optionGroupId = String(formData.get("optionGroupId") ?? "");
  const name = String(formData.get("name") ?? "").trim();
  const priceAdjustmentPounds = Number(formData.get("priceAdjustment"));

  if (!optionGroupId || !name || !Number.isFinite(priceAdjustmentPounds)) {
    throw new Error("A choice name and price adjustment are required.");
  }

  const optionGroup = await db.menuItemOptionGroup.findUnique({
    where: { id: optionGroupId, restaurantId: restaurant.id },
  });
  if (!optionGroup) {
    throw new Error("Option group not found.");
  }

  const count = await db.menuItemOptionChoice.count({ where: { optionGroupId } });

  await db.menuItemOptionChoice.create({
    data: {
      restaurantId: restaurant.id,
      optionGroupId,
      name,
      priceAdjustmentCents: Math.round(priceAdjustmentPounds * 100),
      sortOrder: count,
    },
  });

  revalidatePath("/menu");
}

export async function updateOptionChoice(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = String(formData.get("id"));
  const name = String(formData.get("name") ?? "").trim();
  const priceAdjustmentPounds = Number(formData.get("priceAdjustment"));

  if (!name || !Number.isFinite(priceAdjustmentPounds)) {
    throw new Error("A choice name and price adjustment are required.");
  }

  await db.menuItemOptionChoice.update({
    where: { id, restaurantId: restaurant.id },
    data: { name, priceAdjustmentCents: Math.round(priceAdjustmentPounds * 100) },
  });

  revalidatePath("/menu");
}

export async function deleteOptionChoice(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = String(formData.get("id"));

  await db.menuItemOptionChoice.delete({ where: { id, restaurantId: restaurant.id } });

  revalidatePath("/menu");
}
