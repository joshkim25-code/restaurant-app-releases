import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { DraggableCategoryList } from "@/components/menu/DraggableCategoryList";
import {
  createCategory,
  createMenuItem,
  deleteCategory,
  deleteMenuItem,
  duplicateMenuItem,
  toggleItemAvailable,
  assignMenuItemPrinter,
  updateMenuItemPrice,
  updateMenuItemDetails,
  moveMenuItem,
  reorderCategories,
  reorderMenuItems,
  createOptionGroup,
  updateOptionGroup,
  deleteOptionGroup,
  createOptionChoice,
  updateOptionChoice,
  deleteOptionChoice,
} from "./actions";

export default async function MenuPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; category?: string; count?: string }>;
}) {
  const params = await searchParams;
  const restaurant = await getCurrentRestaurant();
  const [categories, printers] = await Promise.all([
    db.menuCategory.findMany({
      where: { restaurantId: restaurant.id },
      orderBy: { sortOrder: "asc" },
      include: {
        items: {
          where: { archivedAt: null },
          orderBy: { sortOrder: "asc" },
          include: {
            optionGroups: {
              orderBy: { sortOrder: "asc" },
              include: { choices: { orderBy: { sortOrder: "asc" } } },
            },
          },
        },
      },
    }),
    db.printer.findMany({
      where: { restaurantId: restaurant.id, role: "TICKET" },
      orderBy: { sortOrder: "asc" },
    }),
  ]);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-xl font-semibold">Menu</h1>
        <p className="text-sm text-neutral-500">
          Manage {restaurant.name}&rsquo;s menu. Waiters and the phone system
          only offer items marked available.
        </p>
      </div>

      {params.error === "category-has-items" && (
        <p className="rounded border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          Couldn&rsquo;t delete &ldquo;{params.category}&rdquo; — it still has {params.count}{" "}
          item{params.count === "1" ? "" : "s"} in it. Delete or move those items first.
        </p>
      )}
      <DraggableCategoryList
        categories={categories}
        printers={printers}
        currency={restaurant.currency}
        reorderCategories={reorderCategories}
        reorderMenuItems={reorderMenuItems}
        createMenuItem={createMenuItem}
        deleteCategory={deleteCategory}
        moveMenuItem={moveMenuItem}
        updateMenuItemPrice={updateMenuItemPrice}
        toggleItemAvailable={toggleItemAvailable}
        assignMenuItemPrinter={assignMenuItemPrinter}
        updateMenuItemDetails={updateMenuItemDetails}
        createOptionGroup={createOptionGroup}
        updateOptionGroup={updateOptionGroup}
        deleteOptionGroup={deleteOptionGroup}
        createOptionChoice={createOptionChoice}
        updateOptionChoice={updateOptionChoice}
        deleteOptionChoice={deleteOptionChoice}
        duplicateMenuItem={duplicateMenuItem}
        deleteMenuItem={deleteMenuItem}
      />
      <form
        action={createCategory}
        className="flex flex-wrap items-end gap-4 rounded-lg border border-neutral-200 bg-white p-4"
      >
        <div className="flex flex-col gap-1">
          <label className="text-xs text-neutral-500" htmlFor="category-name">
            New category
          </label>
          <input
            id="category-name"
            name="name"
            required
            placeholder="Desserts"
            className="rounded border border-neutral-300 px-2 py-1"
          />
        </div>
        <button
          type="submit"
          className="rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700"
        >
          Add category
        </button>
      </form>
    </div>
  );
}
