"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { getSalesReport, parseISODate, reportRangeLabel, type ReportRange } from "@/lib/reports";
import { buildSummaryCommands } from "@/lib/ticketContent";
import { enqueuePrintJob, awaitJobResult } from "@/lib/printJobs";

function bool(formData: FormData, key: string): boolean {
  return formData.get(key) === "on";
}

export async function updateSummarySettings(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  await db.restaurant.update({
    where: { id: restaurant.id },
    data: {
      summaryShowRevenue: bool(formData, "summaryShowRevenue"),
      summaryShowBillCount: bool(formData, "summaryShowBillCount"),
      summaryShowCancelled: bool(formData, "summaryShowCancelled"),
      summaryShowAverageBill: bool(formData, "summaryShowAverageBill"),
      summaryShowPaymentMethods: bool(formData, "summaryShowPaymentMethods"),
      summaryShowTipsByMethod: bool(formData, "summaryShowTipsByMethod"),
      summaryShowTopItems: bool(formData, "summaryShowTopItems"),
      summaryShowTax: bool(formData, "summaryShowTax"),
      summaryShowServiceCharge: bool(formData, "summaryShowServiceCharge"),
      summaryShowCancelledRevenue: bool(formData, "summaryShowCancelledRevenue"),
      summaryShowRevenueByCategory: bool(formData, "summaryShowRevenueByCategory"),
      summaryShowFulfillmentSplit: bool(formData, "summaryShowFulfillmentSplit"),
      summaryShowRevenueBySource: bool(formData, "summaryShowRevenueBySource"),
    },
  });

  revalidatePath("/reports");
}

export async function printSummaryAction(range: ReportRange, from?: string, to?: string) {
  const restaurant = await getCurrentRestaurant();

  const printer = await db.printer.findFirst({
    where: { restaurantId: restaurant.id, isSummaryPrinter: true },
  });
  if (!printer) {
    throw new Error("No printer is set up for the summary yet. Pick one in Settings → Receipts.");
  }

  const fromDate = parseISODate(from);
  const toDate = parseISODate(to);
  const custom = range === "custom" && fromDate && toDate ? { from: fromDate, to: toDate } : undefined;

  const report = await getSalesReport(restaurant.id, range, custom);
  const periodLabel = reportRangeLabel(range, custom, restaurant.timezone);

  const commands = buildSummaryCommands(restaurant, periodLabel, report, printer);
  const job = await enqueuePrintJob(restaurant.id, "SUMMARY", printer, commands);
  await awaitJobResult(job.id);
}
