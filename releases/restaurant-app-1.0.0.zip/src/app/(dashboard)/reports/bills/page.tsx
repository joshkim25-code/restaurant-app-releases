import Link from "next/link";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { REPORT_RANGES, type ReportRange } from "@/lib/reports";
import { getBillHistory, getRestaurantTables } from "@/lib/billHistory";
import { formatMoney } from "@/lib/money";
import { formatDateTime } from "@/lib/time";
import { RangeFilter } from "@/components/reports/RangeFilter";
import { TableFilter } from "@/components/TableFilter";
import { Pagination } from "@/components/Pagination";

function isPresetRange(value: string | undefined): value is Exclude<ReportRange, "custom"> {
  return REPORT_RANGES.some((r) => r.key === value);
}

function parseISODate(value: string | undefined): Date | undefined {
  if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return undefined;
  const [y, m, d] = value.split("-").map(Number);
  const date = new Date(y, m - 1, d);
  return Number.isNaN(date.getTime()) ? undefined : date;
}

export default async function BillHistoryPage({
  searchParams,
}: {
  searchParams: Promise<{ range?: string; from?: string; to?: string; table?: string; page?: string }>;
}) {
  const params = await searchParams;
  const from = parseISODate(params.from);
  const to = parseISODate(params.to);
  const range: ReportRange =
    params.range === "custom" && from && to ? "custom" : isPresetRange(params.range) ? params.range : "all";
  const custom = range === "custom" && from && to ? { from, to } : undefined;
  const page = Math.max(1, Number(params.page) || 1);

  const restaurant = await getCurrentRestaurant();
  const [{ bills, hasNext, hasPrev }, tables] = await Promise.all([
    getBillHistory(restaurant.id, { range, custom, tableId: params.table, page }),
    getRestaurantTables(restaurant.id),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <Link href="/reports" className="text-sm text-neutral-500 underline hover:text-neutral-900">
          ← Back to Reports
        </Link>
        <h1 className="mt-2 text-xl font-semibold">Bill history</h1>
        <p className="text-sm text-neutral-500">Every closed bill for {restaurant.name}, paid or cancelled.</p>
      </div>

      <RangeFilter
        basePath="/reports/bills"
        range={range}
        from={params.from}
        to={params.to}
        extraParams={{ table: params.table }}
      />
      <TableFilter
        basePath="/reports/bills"
        tables={tables}
        selectedTableId={params.table}
        extraParams={{ range: params.range, from: params.from, to: params.to }}
      />

      <div className="rounded-lg border border-neutral-200 bg-white p-4">
        {bills.length === 0 ? (
          <p className="text-sm text-neutral-400">No bills in this range.</p>
        ) : (
          <table className="w-full text-sm">
            <thead className="text-left text-neutral-500">
              <tr>
                <th className="pb-2 font-medium">Closed</th>
                <th className="pb-2 font-medium">Table</th>
                <th className="pb-2 font-medium">Status</th>
                <th className="pb-2 font-medium">Method</th>
                <th className="pb-2 font-medium text-right">Total</th>
                <th className="pb-2 font-medium text-right">Receipt</th>
              </tr>
            </thead>
            <tbody>
              {bills.map((bill) => (
                <tr key={bill.id} className="border-t border-neutral-100">
                  <td className="py-1.5">{formatDateTime(bill.closedAt, restaurant.timezone)}</td>
                  <td className="py-1.5">{bill.tableLabel}</td>
                  <td className="py-1.5">
                    <span className={bill.status === "PAID" ? "text-green-700" : "text-red-600"}>
                      {bill.status === "PAID" ? "Paid" : "Cancelled"}
                    </span>
                  </td>
                  <td className="py-1.5 capitalize">{bill.method?.toLowerCase() ?? "—"}</td>
                  <td className="py-1.5 text-right">
                    {formatMoney(bill.totalCents, restaurant.currency)}
                  </td>
                  <td className="py-1.5 text-right">
                    <Link
                      href={`/waiter/receipts/${bill.id}`}
                      className="underline hover:text-neutral-900"
                    >
                      View
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Pagination
        basePath="/reports/bills"
        page={page}
        hasPrev={hasPrev}
        hasNext={hasNext}
        searchParams={{ range: params.range, from: params.from, to: params.to, table: params.table }}
      />
    </div>
  );
}
