import Link from "next/link";
import { getCurrentRestaurant } from "@/lib/restaurant";
import {
  getSalesReport,
  isPresetRange,
  parseISODate,
  reportRangeLabel,
  type ReportRange,
} from "@/lib/reports";
import { formatMoney } from "@/lib/money";
import { RangeFilter } from "@/components/reports/RangeFilter";
import { PrinterFieldRow } from "@/components/settings/PrinterFieldRow";
import { TestPrintButton } from "@/components/settings/TestPrintButton";
import { CollapsibleCard } from "@/components/CollapsibleCard";
import { updateSummarySettings, printSummaryAction } from "./actions";

export default async function ReportsPage({
  searchParams,
}: {
  searchParams: Promise<{ range?: string; from?: string; to?: string }>;
}) {
  const params = await searchParams;
  const from = parseISODate(params.from);
  const to = parseISODate(params.to);
  const range: ReportRange =
    params.range === "custom" && from && to ? "custom" : isPresetRange(params.range) ? params.range : "7d";
  const custom = range === "custom" && from && to ? { from, to } : undefined;

  const restaurant = await getCurrentRestaurant();
  const report = await getSalesReport(restaurant.id, range, custom);
  const rangeLabel = reportRangeLabel(range, custom, restaurant.timezone);

  const maxDayRevenue = Math.max(1, ...report.revenueByDay.map(([, cents]) => cents));

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-xl font-semibold">Reports</h1>
        <p className="text-sm text-neutral-500">
          Sales performance for {restaurant.name}, based on closed and paid bills.{" "}
          <Link href="/reports/bills" className="underline hover:text-neutral-900">
            View bill history →
          </Link>
        </p>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-4">
        <RangeFilter basePath="/reports" range={range} from={params.from} to={params.to} />
        <TestPrintButton
          sendTestPrintAction={printSummaryAction.bind(null, range, params.from, params.to)}
          label={`Print ${rangeLabel} summary`}
          doneLabel="Printed"
        />
      </div>

      <CollapsibleCard
        summary={
          <div>
            <span className="font-medium text-neutral-900">Summary content</span>
            <p className="text-xs text-neutral-500">
              Which sections print on the summary, for whichever period is selected above.
            </p>
          </div>
        }
      >
        <form action={updateSummarySettings} className="divide-y divide-neutral-100 border-t border-neutral-100">
          <PrinterFieldRow label="Revenue">
            <input
              type="checkbox"
              name="summaryShowRevenue"
              key={String(restaurant.summaryShowRevenue)}
              defaultChecked={restaurant.summaryShowRevenue}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Bills paid">
            <input
              type="checkbox"
              name="summaryShowBillCount"
              key={String(restaurant.summaryShowBillCount)}
              defaultChecked={restaurant.summaryShowBillCount}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Bills cancelled">
            <input
              type="checkbox"
              name="summaryShowCancelled"
              key={String(restaurant.summaryShowCancelled)}
              defaultChecked={restaurant.summaryShowCancelled}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Average bill">
            <input
              type="checkbox"
              name="summaryShowAverageBill"
              key={String(restaurant.summaryShowAverageBill)}
              defaultChecked={restaurant.summaryShowAverageBill}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Tax">
            <input
              type="checkbox"
              name="summaryShowTax"
              key={String(restaurant.summaryShowTax)}
              defaultChecked={restaurant.summaryShowTax}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Service charge">
            <input
              type="checkbox"
              name="summaryShowServiceCharge"
              key={String(restaurant.summaryShowServiceCharge)}
              defaultChecked={restaurant.summaryShowServiceCharge}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Revenue by payment method">
            <input
              type="checkbox"
              name="summaryShowPaymentMethods"
              key={String(restaurant.summaryShowPaymentMethods)}
              defaultChecked={restaurant.summaryShowPaymentMethods}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Tips by payment method">
            <input
              type="checkbox"
              name="summaryShowTipsByMethod"
              key={String(restaurant.summaryShowTipsByMethod)}
              defaultChecked={restaurant.summaryShowTipsByMethod}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Top items">
            <input
              type="checkbox"
              name="summaryShowTopItems"
              key={String(restaurant.summaryShowTopItems)}
              defaultChecked={restaurant.summaryShowTopItems}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Lost revenue (cancelled bills)">
            <input
              type="checkbox"
              name="summaryShowCancelledRevenue"
              key={String(restaurant.summaryShowCancelledRevenue)}
              defaultChecked={restaurant.summaryShowCancelledRevenue}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Revenue by category">
            <input
              type="checkbox"
              name="summaryShowRevenueByCategory"
              key={String(restaurant.summaryShowRevenueByCategory)}
              defaultChecked={restaurant.summaryShowRevenueByCategory}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Dine-in vs takeaway">
            <input
              type="checkbox"
              name="summaryShowFulfillmentSplit"
              key={String(restaurant.summaryShowFulfillmentSplit)}
              defaultChecked={restaurant.summaryShowFulfillmentSplit}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Revenue by order source">
            <input
              type="checkbox"
              name="summaryShowRevenueBySource"
              key={String(restaurant.summaryShowRevenueBySource)}
              defaultChecked={restaurant.summaryShowRevenueBySource}
            />
          </PrinterFieldRow>
          <div className="pt-4">
            <button
              type="submit"
              className="rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700"
            >
              Save
            </button>
          </div>
        </form>
      </CollapsibleCard>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Revenue</div>
          <div className="mt-1 text-2xl font-semibold">
            {formatMoney(report.revenueCents, restaurant.currency)}
          </div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Bills paid</div>
          <div className="mt-1 text-2xl font-semibold">{report.billCount}</div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Average bill</div>
          <div className="mt-1 text-2xl font-semibold">
            {formatMoney(report.averageBillCents, restaurant.currency)}
          </div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Tax</div>
          <div className="mt-1 text-2xl font-semibold">
            {formatMoney(report.taxCents, restaurant.currency)}
          </div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Service charge</div>
          <div className="mt-1 text-2xl font-semibold">
            {formatMoney(report.serviceChargeCents, restaurant.currency)}
          </div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Bills cancelled</div>
          <div className="mt-1 text-2xl font-semibold">{report.cancelledCount}</div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Tips</div>
          <div className="mt-1 text-2xl font-semibold">
            {formatMoney(report.tipsCents, restaurant.currency)}
          </div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Lost revenue</div>
          <div className="mt-1 text-2xl font-semibold">
            {formatMoney(report.cancelledValueCents, restaurant.currency)}
          </div>
        </div>
      </div>

      <div className="rounded-lg border border-neutral-200 bg-white p-4">
        <h2 className="text-sm font-medium">Revenue by day</h2>
        {report.revenueByDay.length === 0 ? (
          <p className="mt-3 text-sm text-neutral-400">No paid bills in this range.</p>
        ) : (
          <div className="mt-4 space-y-2">
            {report.revenueByDay.map(([day, cents]) => (
              <div key={day} className="flex items-center gap-3 text-sm">
                <span className="w-24 shrink-0 text-neutral-500">{day}</span>
                <div className="h-4 flex-1 rounded bg-neutral-100">
                  <div
                    className="h-4 rounded bg-neutral-900"
                    style={{ width: `${(cents / maxDayRevenue) * 100}%` }}
                  />
                </div>
                <span className="w-20 shrink-0 text-right">
                  {formatMoney(cents, restaurant.currency)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h2 className="text-sm font-medium">Top menu items</h2>
          {report.topItems.length === 0 ? (
            <p className="mt-3 text-sm text-neutral-400">No items sold in this range.</p>
          ) : (
            <table className="mt-3 w-full text-sm">
              <thead className="text-left text-neutral-500">
                <tr>
                  <th className="pb-2 font-medium">Item</th>
                  <th className="pb-2 font-medium text-right">Qty</th>
                  <th className="pb-2 font-medium text-right">Revenue</th>
                </tr>
              </thead>
              <tbody>
                {report.topItems.map((item) => (
                  <tr key={item.menuItemId} className="border-t border-neutral-100">
                    <td className="py-1.5">{item.name}</td>
                    <td className="py-1.5 text-right">{item.quantity}</td>
                    <td className="py-1.5 text-right">
                      {formatMoney(item.revenueCents, restaurant.currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h2 className="text-sm font-medium">Revenue by payment method</h2>
          {report.revenueByMethod.length === 0 ? (
            <p className="mt-3 text-sm text-neutral-400">No paid bills in this range.</p>
          ) : (
            <table className="mt-3 w-full text-sm">
              <thead className="text-left text-neutral-500">
                <tr>
                  <th className="pb-2 font-medium">Method</th>
                  <th className="pb-2 font-medium text-right">Count</th>
                  <th className="pb-2 font-medium text-right">Revenue</th>
                </tr>
              </thead>
              <tbody>
                {report.revenueByMethod.map(([method, stats]) => (
                  <tr key={method} className="border-t border-neutral-100">
                    <td className="py-1.5 capitalize">{method.toLowerCase()}</td>
                    <td className="py-1.5 text-right">{stats.count}</td>
                    <td className="py-1.5 text-right">
                      {formatMoney(stats.revenueCents, restaurant.currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h2 className="text-sm font-medium">Tips by payment method</h2>
          {report.tipsByMethod.length === 0 ? (
            <p className="mt-3 text-sm text-neutral-400">No tips in this range.</p>
          ) : (
            <table className="mt-3 w-full text-sm">
              <thead className="text-left text-neutral-500">
                <tr>
                  <th className="pb-2 font-medium">Method</th>
                  <th className="pb-2 font-medium text-right">Tips</th>
                </tr>
              </thead>
              <tbody>
                {report.tipsByMethod.map(([method, cents]) => (
                  <tr key={method} className="border-t border-neutral-100">
                    <td className="py-1.5 capitalize">{method.toLowerCase()}</td>
                    <td className="py-1.5 text-right">{formatMoney(cents, restaurant.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h2 className="text-sm font-medium">Revenue by category</h2>
          {report.revenueByCategory.length === 0 ? (
            <p className="mt-3 text-sm text-neutral-400">No items sold in this range.</p>
          ) : (
            <table className="mt-3 w-full text-sm">
              <thead className="text-left text-neutral-500">
                <tr>
                  <th className="pb-2 font-medium">Category</th>
                  <th className="pb-2 font-medium text-right">Revenue</th>
                </tr>
              </thead>
              <tbody>
                {report.revenueByCategory.map((cat) => (
                  <tr key={cat.categoryId} className="border-t border-neutral-100">
                    <td className="py-1.5">{cat.name}</td>
                    <td className="py-1.5 text-right">
                      {formatMoney(cat.revenueCents, restaurant.currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h2 className="text-sm font-medium">Dine-in vs takeaway</h2>
          <div className="mt-3 flex justify-between text-sm">
            <span>Dine-in</span>
            <span>{formatMoney(report.revenueByFulfillment.dineInCents, restaurant.currency)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>Takeaway</span>
            <span>{formatMoney(report.revenueByFulfillment.takeawayCents, restaurant.currency)}</span>
          </div>
        </div>

        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h2 className="text-sm font-medium">Revenue by order source</h2>
          {report.revenueByBillSource.length === 0 ? (
            <p className="mt-3 text-sm text-neutral-400">No paid bills in this range.</p>
          ) : (
            <table className="mt-3 w-full text-sm">
              <thead className="text-left text-neutral-500">
                <tr>
                  <th className="pb-2 font-medium">Source</th>
                  <th className="pb-2 font-medium text-right">Revenue</th>
                </tr>
              </thead>
              <tbody>
                {report.revenueByBillSource.map(([source, cents]) => (
                  <tr key={source} className="border-t border-neutral-100">
                    <td className="py-1.5 capitalize">{source.toLowerCase()}</td>
                    <td className="py-1.5 text-right">{formatMoney(cents, restaurant.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
