"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { findAvailableTable, isTableAvailable, reservationWindowMinutes } from "@/lib/reservations";
import { sendReservationConfirmationSms } from "@/lib/sms";
import { zonedDateTimeToUtc, zonedMidnight } from "@/lib/time";
import type { ReservationStatus } from "@/generated/prisma/client";

const VALID_STATUSES: ReservationStatus[] = [
  "PENDING",
  "CONFIRMED",
  "CANCELLED",
  "COMPLETED",
  "NO_SHOW",
];

function revalidateReservationViews() {
  revalidatePath("/dashboard", "layout");
  revalidatePath("/waiter", "layout");
}

export async function createReservation(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  const name = String(formData.get("name") ?? "").trim();
  const phone = String(formData.get("phone") ?? "").trim();
  const partySize = Number(formData.get("partySize"));
  const date = String(formData.get("date") ?? "");
  const time = String(formData.get("time") ?? "");
  const tableId = String(formData.get("tableId") ?? "auto");
  const specialRequests = String(formData.get("specialRequests") ?? "").trim();

  if (!name || !phone) {
    throw new Error("A customer name and phone number are required.");
  }
  if (!Number.isInteger(partySize) || partySize <= 0) {
    throw new Error("Party size must be a positive whole number.");
  }
  if (!date || !time) {
    throw new Error("A date and time are required.");
  }

  const startTime = zonedDateTimeToUtc(`${date}T${time}`, restaurant.timezone);
  if (Number.isNaN(startTime.getTime())) {
    throw new Error("Invalid date or time.");
  }
  const dayStart = zonedMidnight(startTime, restaurant.timezone);

  const windowMinutes = reservationWindowMinutes(restaurant);

  let resolvedTableId: string;
  if (tableId === "auto") {
    const table = await findAvailableTable(restaurant.id, partySize, startTime, windowMinutes);
    if (!table) {
      throw new Error(
        "No table is free for that party size and time — pick one manually or adjust the time.",
      );
    }
    resolvedTableId = table.id;
  } else {
    const available = await isTableAvailable(tableId, startTime, windowMinutes);
    if (!available) {
      throw new Error("That table is already booked around that time.");
    }
    resolvedTableId = tableId;
  }

  const customer = await db.customer.upsert({
    where: { restaurantId_phone: { restaurantId: restaurant.id, phone } },
    update: { name },
    create: { restaurantId: restaurant.id, name, phone },
  });

  await db.reservation.create({
    data: {
      restaurantId: restaurant.id,
      tableId: resolvedTableId,
      customerId: customer.id,
      partySize,
      date: dayStart,
      startTime,
      status: "PENDING",
      specialRequests: specialRequests || null,
      source: "MANUAL",
      customerNameAtBooking: name,
    },
  });

  revalidateReservationViews();
}

export async function updateReservationStatus(formData: FormData) {
  const id = String(formData.get("id") ?? "");
  const status = String(formData.get("status") ?? "") as ReservationStatus;

  if (!id || !VALID_STATUSES.includes(status)) {
    throw new Error("A valid reservation and status are required.");
  }

  await db.reservation.update({ where: { id }, data: { status } });

  if (status === "CONFIRMED") {
    await notifyReservationConfirmed(id);
  }

  revalidateReservationViews();
}

// Same reasoning as the Tables page: production Next.js hides thrown server-action messages,
// so an expected failure (table already booked) redirects back with an error code instead.
export async function changeReservationTable(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  const id = String(formData.get("id") ?? "");
  const tableId = String(formData.get("tableId") ?? "");
  const rawReturnTo = String(formData.get("returnTo") ?? "");
  const returnTo = rawReturnTo.startsWith("/reservations") ? rawReturnTo : "/reservations";

  const reservation = await db.reservation.findFirst({
    where: { id, restaurantId: restaurant.id },
  });
  if (!reservation) {
    throw new Error("Reservation not found.");
  }
  if (reservation.status !== "PENDING" && reservation.status !== "CONFIRMED") {
    redirect(returnTo);
  }
  if (reservation.tableId === tableId) {
    redirect(returnTo);
  }

  const table = await db.table.findFirst({
    where: { id: tableId, restaurantId: restaurant.id, isActive: true },
  });
  if (!table) {
    throw new Error("Table not found.");
  }

  const available = await isTableAvailable(
    table.id,
    reservation.startTime,
    reservationWindowMinutes(restaurant),
    reservation.id,
  );
  if (!available) {
    const url = new URL(returnTo, "http://localhost");
    url.searchParams.set("error", "table-unavailable");
    redirect(url.pathname + url.search);
  }

  await db.reservation.update({ where: { id }, data: { tableId: table.id } });

  revalidateReservationViews();
  redirect(returnTo);
}

async function notifyReservationConfirmed(reservationId: string) {
  try {
    const restaurant = await getCurrentRestaurant();
    const reservation = await db.reservation.findUnique({
      where: { id: reservationId },
      include: { customer: true },
    });
    if (!reservation || !restaurant.twilioPhoneNumber || !reservation.customer.phone) return;

    await sendReservationConfirmationSms({
      to: reservation.customer.phone,
      from: restaurant.twilioPhoneNumber,
      customerName: reservation.customerNameAtBooking ?? reservation.customer.name,
      partySize: reservation.partySize,
      startTime: reservation.startTime,
      timezone: restaurant.timezone,
      restaurantName: restaurant.name,
    });
  } catch (err) {
    // A failed confirmation text must never block staff from confirming a
    // reservation in the app - this is a side effect, not the primary action.
    console.error(`Could not send confirmation SMS for reservation ${reservationId}:`, err);
  }
}
