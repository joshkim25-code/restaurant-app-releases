import Link from "next/link";
import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { getReservations, getPendingReservations, type ReservationListEntry } from "@/lib/reservations";
import { getRestaurantTables } from "@/lib/billHistory";
import { TableFilter } from "@/components/TableFilter";
import { Pagination } from "@/components/Pagination";
import { AutoRefresh } from "@/components/AutoRefresh";
import { changeReservationTable, createReservation, updateReservationStatus } from "./actions";
import { formatClockTime, formatDateTime } from "@/lib/time";
import type { ReservationStatus } from "@/generated/prisma/client";

const STATUS_OPTIONS: { value: ReservationStatus; label: string }[] = [
  { value: "PENDING", label: "Pending" },
  { value: "CONFIRMED", label: "Confirmed" },
  { value: "CANCELLED", label: "Cancelled" },
  { value: "COMPLETED", label: "Completed" },
  { value: "NO_SHOW", label: "No-show" },
];

const NEXT_STATUS: Partial<Record<ReservationStatus, { value: ReservationStatus; label: string }[]>> = {
  PENDING: [
    { value: "CONFIRMED", label: "Confirm" },
    { value: "CANCELLED", label: "Cancel" },
  ],
  CONFIRMED: [
    { value: "COMPLETED", label: "Complete" },
    { value: "NO_SHOW", label: "No-show" },
    { value: "CANCELLED", label: "Cancel" },
    { value: "PENDING", label: "Unconfirm" },
  ],
  COMPLETED: [{ value: "CONFIRMED", label: "Undo" }],
  NO_SHOW: [{ value: "CONFIRMED", label: "Undo" }],
  CANCELLED: [{ value: "PENDING", label: "Uncancel" }],
};

function TableCell({
  r,
  activeTables,
  returnTo,
}: {
  r: ReservationListEntry;
  activeTables: { id: string; label: string; seats: number }[];
  returnTo: string;
}) {
  const canChange = r.status === "PENDING" || r.status === "CONFIRMED";

  return (
    <td className="px-4 py-2">
      <div>{r.tableLabel ?? "—"}</div>
      {canChange && (
        <details className="mt-1">
          <summary className="cursor-pointer text-xs text-neutral-500 underline hover:text-neutral-900">
            Change
          </summary>
          <form action={changeReservationTable} className="mt-1 flex items-center gap-2">
            <input type="hidden" name="id" value={r.id} />
            <input type="hidden" name="returnTo" value={returnTo} />
            <select
              name="tableId"
              defaultValue={r.tableId ?? undefined}
              aria-label="Table"
              className="rounded border border-neutral-300 px-2 py-1 text-sm"
            >
              {activeTables.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.label} ({t.seats} seats{t.seats < r.partySize ? ", fewer than the party" : ""})
                </option>
              ))}
            </select>
            <button
              type="submit"
              className="rounded bg-neutral-900 px-2 py-1 text-xs text-white hover:bg-neutral-700"
            >
              Save
            </button>
          </form>
        </details>
      )}
    </td>
  );
}

function toISODate(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function parseISODate(value: string | undefined): Date {
  if (value) {
    const [y, m, d] = value.split("-").map(Number);
    if (y && m && d) return new Date(y, m - 1, d);
  }
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate());
}

function addDays(date: Date, days: number) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days);
}

function formatDateHeading(date: Date) {
  return date.toLocaleDateString(undefined, {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export default async function ReservationsPage({
  searchParams,
}: {
  searchParams: Promise<{
    date?: string;
    table?: string;
    status?: string;
    page?: string;
    error?: string;
  }>;
}) {
  const params = await searchParams;
  const restaurant = await getCurrentRestaurant();

  const date = parseISODate(params.date);
  const isoDate = toISODate(date);
  const status = STATUS_OPTIONS.some((s) => s.value === params.status)
    ? (params.status as ReservationStatus)
    : undefined;
  const page = Math.max(1, Number(params.page) || 1);

  const [tables, activeTables, { reservations, hasNext, hasPrev }, pendingReservations] = await Promise.all([
    getRestaurantTables(restaurant.id),
    db.table.findMany({
      where: { restaurantId: restaurant.id, isActive: true },
      orderBy: { seats: "asc" },
      select: { id: true, label: true, seats: true },
    }),
    getReservations(restaurant.id, { date, tableId: params.table, status, page }),
    getPendingReservations(restaurant.id),
  ]);

  function dateHref(target: Date) {
    const p = new URLSearchParams();
    p.set("date", toISODate(target));
    if (params.table) p.set("table", params.table);
    if (status) p.set("status", status);
    return `/reservations?${p.toString()}`;
  }

  function statusHref(target?: ReservationStatus) {
    const p = new URLSearchParams();
    p.set("date", isoDate);
    if (params.table) p.set("table", params.table);
    if (target) p.set("status", target);
    return `/reservations?${p.toString()}`;
  }

  const returnParams = new URLSearchParams({ date: isoDate });
  if (params.table) returnParams.set("table", params.table);
  if (status) returnParams.set("status", status);
  if (params.page) returnParams.set("page", params.page);
  const returnTo = `/reservations?${returnParams.toString()}`;

  const pillClass = (active: boolean) =>
    `rounded-full px-3 py-1 text-sm ${
      active
        ? "bg-neutral-900 text-white"
        : "border border-neutral-300 text-neutral-600 hover:bg-neutral-100"
    }`;

  return (
    <div className="space-y-8">
      <AutoRefresh />
      <div>
        <h1 className="text-xl font-semibold">Reservations</h1>
        <p className="text-sm text-neutral-500">
          Manually book a table for a phone or walk-up reservation at {restaurant.name}.
        </p>
      </div>

      {params.error === "table-unavailable" && (
        <p className="rounded border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          That table is already booked around that time. Pick another one.
        </p>
      )}

      {pendingReservations.length > 0 && (
        <div className="space-y-2">
          <h2 className="text-sm font-semibold text-neutral-700">
            Pending reservations ({pendingReservations.length})
          </h2>
          <table className="w-full border-collapse overflow-hidden rounded-lg border border-amber-200 bg-amber-50 text-sm">
            <thead className="bg-amber-100 text-left text-neutral-600">
              <tr>
                <th className="px-4 py-2 font-medium">Date &amp; time</th>
                <th className="px-4 py-2 font-medium">Party</th>
                <th className="px-4 py-2 font-medium">Customer</th>
                <th className="px-4 py-2 font-medium">Table</th>
                <th className="px-4 py-2 font-medium">Special requests</th>
                <th className="px-4 py-2" />
              </tr>
            </thead>
            <tbody>
              {pendingReservations.map((r) => (
                <tr key={r.id} className="border-t border-amber-200 align-top">
                  <td className="px-4 py-2">{formatDateTime(r.startTime, restaurant.timezone)}</td>
                  <td className="px-4 py-2">{r.partySize}</td>
                  <td className="px-4 py-2">
                    <div>{r.customerName}</div>
                    <div className="text-neutral-400">{r.customerPhone}</div>
                  </td>
                  <TableCell r={r} activeTables={activeTables} returnTo={returnTo} />
                  <td className="px-4 py-2 text-neutral-500">{r.specialRequests ?? "—"}</td>
                  <td className="px-4 py-2 text-right">
                    <div className="flex justify-end gap-3">
                      {(NEXT_STATUS.PENDING ?? []).map((transition) => (
                        <form key={transition.value} action={updateReservationStatus}>
                          <input type="hidden" name="id" value={r.id} />
                          <input type="hidden" name="status" value={transition.value} />
                          <button
                            type="submit"
                            className={
                              transition.value === "CANCELLED"
                                ? "text-red-600 underline hover:text-red-800"
                                : "text-neutral-600 underline hover:text-neutral-900"
                            }
                          >
                            {transition.label}
                          </button>
                        </form>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-sm">
          <Link
            href={dateHref(addDays(date, -1))}
            className="rounded border border-neutral-300 px-3 py-1.5 hover:bg-neutral-100"
          >
            ← Prev day
          </Link>
          <span className="font-medium">{formatDateHeading(date)}</span>
          <Link
            href={dateHref(addDays(date, 1))}
            className="rounded border border-neutral-300 px-3 py-1.5 hover:bg-neutral-100"
          >
            Next day →
          </Link>
          <Link href={dateHref(new Date())} className="text-neutral-500 underline hover:text-neutral-900">
            Today
          </Link>
        </div>
        <form action="/reservations" className="flex items-center gap-2 text-sm">
          {params.table && <input type="hidden" name="table" value={params.table} />}
          {status && <input type="hidden" name="status" value={status} />}
          <input
            id="jumpDate"
            type="date"
            name="date"
            defaultValue={isoDate}
            className="rounded border border-neutral-300 px-2 py-1"
          />
          <button type="submit" className="rounded border border-neutral-300 px-3 py-1.5 hover:bg-neutral-100">
            Go
          </button>
        </form>
      </div>

      <TableFilter
        basePath="/reservations"
        tables={tables}
        selectedTableId={params.table}
        extraParams={{ date: isoDate, status }}
      />

      <div className="flex flex-wrap gap-2 text-sm">
        <Link href={statusHref(undefined)} className={pillClass(!status)}>
          All statuses
        </Link>
        {STATUS_OPTIONS.map((s) => (
          <Link key={s.value} href={statusHref(s.value)} className={pillClass(status === s.value)}>
            {s.label}
          </Link>
        ))}
      </div>

      <table className="w-full border-collapse overflow-hidden rounded-lg border border-neutral-200 bg-white text-sm">
        <thead className="bg-neutral-100 text-left text-neutral-600">
          <tr>
            <th className="px-4 py-2 font-medium">Time</th>
            <th className="px-4 py-2 font-medium">Party</th>
            <th className="px-4 py-2 font-medium">Customer</th>
            <th className="px-4 py-2 font-medium">Table</th>
            <th className="px-4 py-2 font-medium">Special requests</th>
            <th className="px-4 py-2 font-medium">Status</th>
            <th className="px-4 py-2" />
          </tr>
        </thead>
        <tbody>
          {reservations.map((r) => (
            <tr key={r.id} className="border-t border-neutral-200 align-top">
              <td className="px-4 py-2">{formatClockTime(r.startTime, restaurant.timezone)}</td>
              <td className="px-4 py-2">{r.partySize}</td>
              <td className="px-4 py-2">
                <div>{r.customerName}</div>
                <div className="text-neutral-400">{r.customerPhone}</div>
              </td>
              <TableCell r={r} activeTables={activeTables} returnTo={returnTo} />
              <td className="px-4 py-2 text-neutral-500">{r.specialRequests ?? "—"}</td>
              <td className="px-4 py-2">
                {STATUS_OPTIONS.find((s) => s.value === r.status)?.label ?? r.status}
              </td>
              <td className="px-4 py-2 text-right">
                <div className="flex justify-end gap-3">
                  {(NEXT_STATUS[r.status] ?? []).map((transition) => (
                    <form key={transition.value} action={updateReservationStatus}>
                      <input type="hidden" name="id" value={r.id} />
                      <input type="hidden" name="status" value={transition.value} />
                      <button
                        type="submit"
                        className={
                          transition.value === "CANCELLED"
                            ? "text-red-600 underline hover:text-red-800"
                            : "text-neutral-600 underline hover:text-neutral-900"
                        }
                      >
                        {transition.label}
                      </button>
                    </form>
                  ))}
                </div>
              </td>
            </tr>
          ))}
          {reservations.length === 0 && (
            <tr>
              <td colSpan={7} className="px-4 py-6 text-center text-neutral-400">
                No reservations for this day.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <Pagination
        basePath="/reservations"
        page={page}
        hasPrev={hasPrev}
        hasNext={hasNext}
        searchParams={{ date: isoDate, table: params.table, status }}
      />

      <form
        action={createReservation}
        className="flex flex-wrap items-end gap-4 rounded-lg border border-neutral-200 bg-white p-4"
      >
        <div className="flex flex-col gap-1">
          <label className="text-xs text-neutral-500" htmlFor="name">
            Name
          </label>
          <input
            id="name"
            name="name"
            required
            placeholder="Jane Doe"
            className="rounded border border-neutral-300 px-2 py-1"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs text-neutral-500" htmlFor="phone">
            Phone
          </label>
          <input
            id="phone"
            name="phone"
            required
            placeholder="555-0100"
            className="rounded border border-neutral-300 px-2 py-1"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs text-neutral-500" htmlFor="partySize">
            Party size
          </label>
          <input
            id="partySize"
            name="partySize"
            type="number"
            min={1}
            required
            className="w-20 rounded border border-neutral-300 px-2 py-1"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs text-neutral-500" htmlFor="date">
            Date
          </label>
          <input
            id="date"
            name="date"
            type="date"
            defaultValue={isoDate}
            required
            className="rounded border border-neutral-300 px-2 py-1"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs text-neutral-500" htmlFor="time">
            Time
          </label>
          <input
            id="time"
            name="time"
            type="time"
            required
            className="rounded border border-neutral-300 px-2 py-1"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs text-neutral-500" htmlFor="tableId">
            Table
          </label>
          <select
            id="tableId"
            name="tableId"
            defaultValue="auto"
            className="rounded border border-neutral-300 px-2 py-1"
          >
            <option value="auto">Auto-assign</option>
            {activeTables.map((t) => (
              <option key={t.id} value={t.id}>
                {t.label} ({t.seats})
              </option>
            ))}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs text-neutral-500" htmlFor="specialRequests">
            Special requests (optional)
          </label>
          <input
            id="specialRequests"
            name="specialRequests"
            placeholder="High chair"
            className="rounded border border-neutral-300 px-2 py-1"
          />
        </div>
        <button type="submit" className="rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700">
          Add reservation
        </button>
      </form>
    </div>
  );
}
