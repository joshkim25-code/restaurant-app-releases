"use server";

import { revalidatePath } from "next/cache";
import crypto from "node:crypto";
import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { buildTestPrintCommands } from "@/lib/ticketContent";
import { enqueuePrintJob, enqueueDiscoveryJob, awaitJobResult } from "@/lib/printJobs";
import type {
  InterruptSensitivity,
  PrinterFontSize,
  PrinterKind,
  VoicePreset,
} from "@/generated/prisma/client";
import { INTERRUPT_SENSITIVITY_LABELS, VOICE_PRESET_LABELS } from "@/lib/voicePresets";
import type { InstalledPrinter, DiscoveredNetworkPrinter } from "@/lib/printerDiscovery";

const VALID_VOICE_PRESETS = Object.keys(VOICE_PRESET_LABELS) as VoicePreset[];
const VALID_INTERRUPT_SENSITIVITIES = Object.keys(INTERRUPT_SENSITIVITY_LABELS) as InterruptSensitivity[];

// Discovery scans a whole subnet, which can take longer than a normal print job's
// timeout — it's a manual, occasional setup action, so a longer wait is fine.
const DISCOVERY_TIMEOUT_MS = 45000;

function str(formData: FormData, key: string): string {
  return String(formData.get(key) ?? "").trim();
}

function optionalStr(formData: FormData, key: string): string | null {
  const value = str(formData, key);
  return value.length > 0 ? value : null;
}

function int(formData: FormData, key: string, fallback: number): number {
  const value = Number(formData.get(key));
  return Number.isFinite(value) ? Math.trunc(value) : fallback;
}

function float(formData: FormData, key: string, fallback: number): number {
  const value = Number(formData.get(key));
  return Number.isFinite(value) ? value : fallback;
}

function bool(formData: FormData, key: string): boolean {
  return formData.get(key) === "on";
}

export async function updateProfile(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  await db.restaurant.update({
    where: { id: restaurant.id },
    data: {
      name: str(formData, "name") || restaurant.name,
      address: optionalStr(formData, "address"),
      contactPhone: optionalStr(formData, "contactPhone"),
      currency: str(formData, "currency") || restaurant.currency,
      timezone: str(formData, "timezone") || restaurant.timezone,
    },
  });

  revalidatePath("/settings/profile");
}

export async function updateOperational(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  await db.restaurant.update({
    where: { id: restaurant.id },
    data: {
      reservationDurationMinutes: int(
        formData,
        "reservationDurationMinutes",
        restaurant.reservationDurationMinutes
      ),
      turnoverBufferMinutes: int(
        formData,
        "turnoverBufferMinutes",
        restaurant.turnoverBufferMinutes
      ),
      bookingWindowDays: int(formData, "bookingWindowDays", restaurant.bookingWindowDays),
      minPartySize: int(formData, "minPartySize", restaurant.minPartySize),
      maxPartySize: int(formData, "maxPartySize", restaurant.maxPartySize),
      cancellationPolicy: optionalStr(formData, "cancellationPolicy"),
      tableAutoReset: bool(formData, "tableAutoReset"),
    },
  });

  const categoryIds = formData.getAll("categoryIds").map(String);
  await Promise.all(
    categoryIds.map((id) =>
      db.menuCategory.update({
        where: { id },
        data: { station: optionalStr(formData, `station-${id}`) },
      })
    )
  );

  revalidatePath("/settings/operational");
}

export async function updatePhoneSettings(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  const voicePreset = str(formData, "voicePreset") as VoicePreset;
  const interruptSensitivity = str(formData, "voiceInterruptSensitivity") as InterruptSensitivity;

  await db.restaurant.update({
    where: { id: restaurant.id },
    data: {
      voiceAssistantInstructions: optionalStr(formData, "voiceAssistantInstructions"),
      voiceGreeting: optionalStr(formData, "voiceGreeting"),
      fallbackPhoneNumber: optionalStr(formData, "fallbackPhoneNumber"),
      voicePreset: VALID_VOICE_PRESETS.includes(voicePreset) ? voicePreset : restaurant.voicePreset,
      voiceInterruptSensitivity: VALID_INTERRUPT_SENSITIVITIES.includes(interruptSensitivity)
        ? interruptSensitivity
        : restaurant.voiceInterruptSensitivity,
    },
  });

  revalidatePath("/settings/phone");
}

export async function togglePhoneCalls() {
  const restaurant = await getCurrentRestaurant();

  await db.restaurant.update({
    where: { id: restaurant.id },
    data: { voiceAcceptCalls: !restaurant.voiceAcceptCalls },
  });

  revalidatePath("/dashboard", "layout");
  revalidatePath("/settings/phone");
}

export async function updatePayments(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  await db.restaurant.update({
    where: { id: restaurant.id },
    data: {
      defaultTipPercentages:
        str(formData, "defaultTipPercentages") || restaurant.defaultTipPercentages,
    },
  });

  revalidatePath("/settings/payments");
}

// Tax rate/service charge/pricing mode live in Settings → Receipts (not Payments) since
// they're what determines what actually prints on the receipt.
export async function updateTaxSettings(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  await db.restaurant.update({
    where: { id: restaurant.id },
    data: {
      taxRatePercent: float(formData, "taxRatePercent", restaurant.taxRatePercent),
      serviceChargePercent: float(
        formData,
        "serviceChargePercent",
        restaurant.serviceChargePercent
      ),
      serviceChargeOnTakeaway: bool(formData, "serviceChargeOnTakeaway"),
      pricesIncludeTax: bool(formData, "pricesIncludeTax"),
    },
  });

  revalidatePath("/settings/receipts");
}

export async function updateNotifications(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  await db.restaurant.update({
    where: { id: restaurant.id },
    data: {
      notifyNewReservationInApp: bool(formData, "notifyNewReservationInApp"),
      notifyNewReservationSms: bool(formData, "notifyNewReservationSms"),
      notifyNewReservationEmail: bool(formData, "notifyNewReservationEmail"),
      notifyNewPhoneOrderInApp: bool(formData, "notifyNewPhoneOrderInApp"),
      notifyOrderReadyInApp: bool(formData, "notifyOrderReadyInApp"),
      notifyOrderReadySms: bool(formData, "notifyOrderReadySms"),
      notifyOrderReadyEmail: bool(formData, "notifyOrderReadyEmail"),
      notificationDurationSeconds: int(
        formData,
        "notificationDurationSeconds",
        restaurant.notificationDurationSeconds
      ),
    },
  });

  revalidatePath("/settings/notifications");
  revalidatePath("/dashboard", "layout");
  revalidatePath("/waiter", "layout");
}

export async function updateReceiptSettings(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  await db.restaurant.update({
    where: { id: restaurant.id },
    data: {
      receiptHeaderText: optionalStr(formData, "receiptHeaderText"),
      receiptFooterText: optionalStr(formData, "receiptFooterText"),
      receiptShowAddress: bool(formData, "receiptShowAddress"),
      receiptShowPhone: bool(formData, "receiptShowPhone"),
    },
  });

  revalidatePath("/settings/receipts");
}

// The RECEIPT-role printer is a singleton — created automatically the first time
// Settings loads if it's somehow missing (should only ever happen once, at migration).
export async function ensureReceiptPrinter(restaurantId: string) {
  const existing = await db.printer.findFirst({ where: { restaurantId, role: "RECEIPT" } });
  if (existing) return existing;
  return db.printer.create({
    data: { restaurantId, name: "Receipt Printer", role: "RECEIPT" },
  });
}

function printerConnectionData(formData: FormData, existing?: {
  kind: string;
  connectionType: string;
  ipAddress: string | null;
  port: number;
  printerName: string | null;
  fontSize: string;
}) {
  const fontSize = str(formData, "fontSize");
  return {
    kind: (str(formData, "kind") || existing?.kind || "POS") as PrinterKind,
    connectionType: formData.has("connectionType")
      ? str(formData, "connectionType") || "network"
      : existing?.connectionType ?? "network",
    ipAddress: formData.has("ipAddress") ? optionalStr(formData, "ipAddress") : existing?.ipAddress ?? null,
    port: formData.has("port") ? int(formData, "port", existing?.port ?? 9100) : existing?.port ?? 9100,
    printerName: formData.has("printerName")
      ? optionalStr(formData, "printerName")
      : existing?.printerName ?? null,
    fontSize: (
      fontSize === "NORMAL" || fontSize === "LARGE" ? fontSize : existing?.fontSize ?? "NORMAL"
    ) as PrinterFontSize,
  };
}

export async function createPrinter(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const name = str(formData, "name") || "New printer";

  await db.printer.create({
    data: { restaurantId: restaurant.id, name, role: "TICKET" },
  });

  revalidatePath("/settings/receipts");
}

export async function updatePrinter(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = str(formData, "id");
  const existing = await db.printer.findUniqueOrThrow({ where: { id, restaurantId: restaurant.id } });

  await db.printer.update({
    where: { id, restaurantId: restaurant.id },
    data: {
      name: str(formData, "name") || existing.name,
      ...printerConnectionData(formData, existing),
    },
  });

  revalidatePath("/settings/receipts");
}

export async function deletePrinter(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = str(formData, "id");
  const printer = await db.printer.findUniqueOrThrow({ where: { id, restaurantId: restaurant.id } });
  if (printer.role === "RECEIPT") {
    throw new Error("The receipt printer can't be removed.");
  }

  await db.printer.delete({ where: { id, restaurantId: restaurant.id } });

  revalidatePath("/settings/receipts");
  revalidatePath("/menu");
}

// Only one printer can be the daily-summary printer at a time — independent of role/kind.
export async function setSummaryPrinter(formData: FormData) {
  const restaurant = await getCurrentRestaurant();
  const id = str(formData, "id");
  await db.printer.findUniqueOrThrow({ where: { id, restaurantId: restaurant.id } });

  await db.$transaction([
    db.printer.updateMany({
      where: { restaurantId: restaurant.id },
      data: { isSummaryPrinter: false },
    }),
    db.printer.update({ where: { id }, data: { isSummaryPrinter: true } }),
  ]);

  revalidatePath("/settings/receipts");
  revalidatePath("/reports");
}

export async function sendTestPrintAction(printerId: string): Promise<{ recoveredIp?: string }> {
  const restaurant = await getCurrentRestaurant();
  const printer = await db.printer.findUniqueOrThrow({
    where: { id: printerId, restaurantId: restaurant.id },
  });

  const commands = buildTestPrintCommands(printer, restaurant);
  const job = await enqueuePrintJob(restaurant.id, "TEST", printer, commands);
  const result = await awaitJobResult<{ recoveredIp?: string } | null>(job.id);
  if (result?.recoveredIp) {
    // The saved IP was stale and the agent recovered by rediscovering the printer - the DB
    // is already updated (see the job-completion route), this just refreshes the page so the
    // printer card's IP field shows the corrected address instead of the old one.
    revalidatePath("/settings/receipts");
  }
  return result ?? {};
}

// timeoutMs defaults to the full discovery timeout for the explicit "Refresh list" button
// (which shows its own pending state, so a longer wait is fine); callers that need this
// on initial page load should pass a short timeout + catch, so the page doesn't hang for
// tens of seconds whenever the local agent isn't currently running.
export async function listInstalledPrinters(timeoutMs = DISCOVERY_TIMEOUT_MS): Promise<InstalledPrinter[]> {
  const restaurant = await getCurrentRestaurant();
  const job = await enqueueDiscoveryJob(restaurant.id, "LIST_INSTALLED");
  return awaitJobResult<InstalledPrinter[]>(job.id, timeoutMs);
}

// The page's own initial load, unlike the "Refresh list" button, shouldn't make the owner
// wait out a live round trip to the print agent every single time it's opened - reuses
// whichever LIST_INSTALLED job last completed instead (from a previous page load or an
// explicit refresh), so the page renders instantly with the last known list.
export async function getLastKnownInstalledPrinters(): Promise<{
  printers: InstalledPrinter[];
  asOf: Date | null;
}> {
  const restaurant = await getCurrentRestaurant();
  const job = await db.printJob.findFirst({
    where: { restaurantId: restaurant.id, type: "LIST_INSTALLED", status: "DONE" },
    orderBy: { completedAt: "desc" },
  });
  return { printers: (job?.result as InstalledPrinter[] | undefined) ?? [], asOf: job?.completedAt ?? null };
}

export async function discoverNetworkPrinters(): Promise<DiscoveredNetworkPrinter[]> {
  const restaurant = await getCurrentRestaurant();
  const job = await enqueueDiscoveryJob(restaurant.id, "DISCOVER_NETWORK");
  return awaitJobResult<DiscoveredNetworkPrinter[]>(job.id, DISCOVERY_TIMEOUT_MS);
}

// Generates (or rotates) the secret the local print agent authenticates with. Shown once
// in Settings — same UX convention as an API key.
export async function generateAgentToken() {
  const restaurant = await getCurrentRestaurant();
  const token = crypto.randomBytes(24).toString("hex");

  await db.restaurant.update({ where: { id: restaurant.id }, data: { agentToken: token } });

  revalidatePath("/settings/receipts");
  return token;
}
