import { getCurrentRestaurant } from "@/lib/restaurant";
import { SettingsRow } from "@/components/settings/SettingsRow";
import { updateNotifications } from "../actions";

const checkboxLabelClass = "flex items-center gap-1.5 text-sm text-neutral-700";

export default async function NotificationsSettingsPage() {
  const restaurant = await getCurrentRestaurant();

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Notifications</h1>
        <p className="text-sm text-neutral-500">
          Choose what triggers an alert and how it&rsquo;s delivered.
        </p>
      </div>

      <form
        action={updateNotifications}
        className="rounded-lg border border-neutral-200 bg-white p-6"
      >
        <SettingsRow label="New reservation">
          <div className="flex items-center gap-4">
            <label className={checkboxLabelClass}>
              <input
                type="checkbox"
                name="notifyNewReservationInApp"
                key={String(restaurant.notifyNewReservationInApp)}
                defaultChecked={restaurant.notifyNewReservationInApp}
              />
              In-app
            </label>
            <label className={checkboxLabelClass}>
              <input
                type="checkbox"
                name="notifyNewReservationSms"
                key={String(restaurant.notifyNewReservationSms)}
                defaultChecked={restaurant.notifyNewReservationSms}
              />
              SMS
            </label>
            <label className={checkboxLabelClass}>
              <input
                type="checkbox"
                name="notifyNewReservationEmail"
                key={String(restaurant.notifyNewReservationEmail)}
                defaultChecked={restaurant.notifyNewReservationEmail}
              />
              Email
            </label>
          </div>
        </SettingsRow>
        <SettingsRow label="New phone order">
          <label className={checkboxLabelClass}>
            <input
              type="checkbox"
              name="notifyNewPhoneOrderInApp"
              key={String(restaurant.notifyNewPhoneOrderInApp)}
              defaultChecked={restaurant.notifyNewPhoneOrderInApp}
            />
            In-app
          </label>
        </SettingsRow>
        <SettingsRow label="Order ready">
          <div className="flex items-center gap-4">
            <label className={checkboxLabelClass}>
              <input
                type="checkbox"
                name="notifyOrderReadyInApp"
                key={String(restaurant.notifyOrderReadyInApp)}
                defaultChecked={restaurant.notifyOrderReadyInApp}
              />
              In-app
            </label>
            <label className={checkboxLabelClass}>
              <input
                type="checkbox"
                name="notifyOrderReadySms"
                key={String(restaurant.notifyOrderReadySms)}
                defaultChecked={restaurant.notifyOrderReadySms}
              />
              SMS
            </label>
            <label className={checkboxLabelClass}>
              <input
                type="checkbox"
                name="notifyOrderReadyEmail"
                key={String(restaurant.notifyOrderReadyEmail)}
                defaultChecked={restaurant.notifyOrderReadyEmail}
              />
              Email
            </label>
          </div>
        </SettingsRow>
        <SettingsRow
          label="Toast duration"
          description="How long the new-reservation notification stays on screen, in seconds"
        >
          <input
            type="number"
            name="notificationDurationSeconds"
            key={restaurant.notificationDurationSeconds}
            defaultValue={restaurant.notificationDurationSeconds}
            min={1}
            className="w-24 rounded border border-neutral-300 px-2 py-1.5 text-sm"
          />
        </SettingsRow>

        <p className="mt-4 text-xs text-neutral-400">
          Only new-reservation and new-phone-order in-app alerts are wired up today. The rest are
          saved for later — SMS/email delivery and order-ready alerts aren&rsquo;t built yet.
        </p>

        <div className="mt-6">
          <button
            type="submit"
            className="rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700"
          >
            Save notifications
          </button>
        </div>
      </form>
    </div>
  );
}
