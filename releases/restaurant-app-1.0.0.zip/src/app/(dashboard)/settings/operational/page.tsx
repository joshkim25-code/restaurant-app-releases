import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { SettingsRow } from "@/components/settings/SettingsRow";
import { updateOperational } from "../actions";

const inputClass = "w-24 rounded border border-neutral-300 px-2 py-1.5 text-sm";

export default async function OperationalSettingsPage() {
  const restaurant = await getCurrentRestaurant();
  const categories = await db.menuCategory.findMany({
    where: { restaurantId: restaurant.id },
    orderBy: { sortOrder: "asc" },
  });

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Operational settings</h1>
        <p className="text-sm text-neutral-500">
          Reservation rules and floor/kitchen defaults for {restaurant.name}.
        </p>
      </div>

      <form
        action={updateOperational}
        className="rounded-lg border border-neutral-200 bg-white p-6"
      >
        <SettingsRow
          label="Reservation duration"
          description="How long a table is held per reservation, in minutes"
        >
          <input
            type="number"
            name="reservationDurationMinutes"
            key={restaurant.reservationDurationMinutes}
            defaultValue={restaurant.reservationDurationMinutes}
            min={1}
            className={inputClass}
          />
        </SettingsRow>
        <SettingsRow
          label="Turnover buffer"
          description="Minutes kept free between reservations at the same table"
        >
          <input
            type="number"
            name="turnoverBufferMinutes"
            key={restaurant.turnoverBufferMinutes}
            defaultValue={restaurant.turnoverBufferMinutes}
            min={0}
            className={inputClass}
          />
        </SettingsRow>
        <SettingsRow label="Booking window" description="How far ahead reservations can be made, in days">
          <input
            type="number"
            name="bookingWindowDays"
            key={restaurant.bookingWindowDays}
            defaultValue={restaurant.bookingWindowDays}
            min={1}
            className={inputClass}
          />
        </SettingsRow>
        <SettingsRow label="Party size">
          <div className="flex items-center gap-3">
            <input
              type="number"
              name="minPartySize"
              key={restaurant.minPartySize}
              defaultValue={restaurant.minPartySize}
              min={1}
              className={inputClass}
              aria-label="Min party size"
            />
            <span className="text-sm text-neutral-400">to</span>
            <input
              type="number"
              name="maxPartySize"
              key={restaurant.maxPartySize}
              defaultValue={restaurant.maxPartySize}
              min={1}
              className={inputClass}
              aria-label="Max party size"
            />
          </div>
        </SettingsRow>
        <SettingsRow label="Cancellation policy">
          <textarea
            name="cancellationPolicy"
            key={restaurant.cancellationPolicy}
            defaultValue={restaurant.cancellationPolicy ?? ""}
            rows={2}
            className="w-72 rounded border border-neutral-300 px-2 py-1.5 text-sm"
          />
        </SettingsRow>
        <SettingsRow label="Table auto-reset" description="Free up a table automatically after payment">
          <input
            type="checkbox"
            name="tableAutoReset"
            key={String(restaurant.tableAutoReset)}
            defaultChecked={restaurant.tableAutoReset}
          />
        </SettingsRow>
        <SettingsRow
          label="Kitchen routing"
          description="Assign each menu category to a station/printer (not used yet)"
        >
          {categories.length === 0 ? (
            <p className="text-sm text-neutral-400">No menu categories yet.</p>
          ) : (
            <div className="space-y-2">
              {categories.map((category) => (
                <div key={category.id} className="flex items-center gap-3">
                  <input type="hidden" name="categoryIds" value={category.id} />
                  <span className="w-28 text-sm text-neutral-700">{category.name}</span>
                  <input
                    name={`station-${category.id}`}
                    key={`${category.id}-${category.station}`}
                    defaultValue={category.station ?? ""}
                    placeholder="e.g. Grill"
                    className="w-40 rounded border border-neutral-300 px-2 py-1.5 text-sm"
                  />
                </div>
              ))}
            </div>
          )}
        </SettingsRow>

        <div className="mt-6">
          <button
            type="submit"
            className="rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700"
          >
            Save operational settings
          </button>
        </div>
      </form>
    </div>
  );
}
