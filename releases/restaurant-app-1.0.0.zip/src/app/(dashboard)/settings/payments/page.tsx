import { getCurrentRestaurant } from "@/lib/restaurant";
import { SettingsRow } from "@/components/settings/SettingsRow";
import { updatePayments } from "../actions";

export default async function PaymentsSettingsPage() {
  const restaurant = await getCurrentRestaurant();

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Payments &amp; subscription</h1>
        <p className="text-sm text-neutral-500">
          Tax and tipping defaults, plus billing status for {restaurant.name}.
        </p>
      </div>

      <form action={updatePayments} className="rounded-lg border border-neutral-200 bg-white p-6">
        <SettingsRow label="Default tip options" description="Comma-separated percentages">
          <input
            name="defaultTipPercentages"
            key={restaurant.defaultTipPercentages}
            defaultValue={restaurant.defaultTipPercentages}
            placeholder="15,18,20"
            className="w-40 rounded border border-neutral-300 px-2 py-1.5 text-sm"
          />
        </SettingsRow>
        <SettingsRow label="Payment processor">
          <span className="text-sm text-neutral-500">Not connected — coming soon</span>
        </SettingsRow>
        <SettingsRow label="Subscription">
          <span className="text-sm text-neutral-500">Free (Beta) — billing isn&rsquo;t set up yet</span>
        </SettingsRow>

        <div className="mt-6">
          <button
            type="submit"
            className="rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700"
          >
            Save payments
          </button>
        </div>
      </form>
    </div>
  );
}
