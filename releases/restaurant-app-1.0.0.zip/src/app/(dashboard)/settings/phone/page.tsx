import { getCurrentRestaurant } from "@/lib/restaurant";
import { SettingsRow } from "@/components/settings/SettingsRow";
import { INTERRUPT_SENSITIVITY_LABELS, VOICE_PRESET_LABELS } from "@/lib/voicePresets";
import { PhoneCallsToggle } from "@/components/PhoneCallsToggle";
import { updatePhoneSettings } from "../actions";

export default async function PhoneSettingsPage() {
  const restaurant = await getCurrentRestaurant();

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Phone reservations</h1>
        <p className="text-sm text-neutral-500">
          Controls how the AI phone assistant talks to callers for {restaurant.name}.
        </p>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-4 rounded-lg border border-neutral-200 bg-white p-6">
        <div className="max-w-xl text-sm">
          <p className="font-medium text-neutral-900">Answer calls with the AI</p>
          <p className="mt-1 text-neutral-500">
            {restaurant.voiceAcceptCalls
              ? "The AI answers every call. Switch it off if you don't want to accept calls."
              : restaurant.fallbackPhoneNumber
                ? "The AI is off. Callers are put through to your staff phone number, or hear a short message if nobody answers."
                : "The AI is off. Callers hear a short message and the call ends (add a staff phone number below to put callers through instead)."}{" "}
            A change takes up to 30 seconds to reach callers, and needs this computer to be on and online.
          </p>
        </div>
        <PhoneCallsToggle accepting={restaurant.voiceAcceptCalls} />
      </div>

      <form
        action={updatePhoneSettings}
        className="rounded-lg border border-neutral-200 bg-white p-6"
      >
        <SettingsRow
          label="Voice & accent"
          description="The voice the AI uses when answering calls."
        >
          <select
            name="voicePreset"
            key={restaurant.voicePreset}
            defaultValue={restaurant.voicePreset}
            className="rounded border border-neutral-300 px-2 py-1.5 text-sm"
          >
            {Object.entries(VOICE_PRESET_LABELS).map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
        </SettingsRow>

        <SettingsRow
          label="Interruption sensitivity"
          description="How easily background noise or the caller's voice cuts the AI off mid-sentence. Use Low if callers are often outside or somewhere loud; High lets callers interrupt more easily in a quiet place."
        >
          <select
            name="voiceInterruptSensitivity"
            key={restaurant.voiceInterruptSensitivity}
            defaultValue={restaurant.voiceInterruptSensitivity}
            className="rounded border border-neutral-300 px-2 py-1.5 text-sm"
          >
            {Object.entries(INTERRUPT_SENSITIVITY_LABELS).map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
        </SettingsRow>

        <SettingsRow
          label="Greeting"
          description="The first thing callers hear, word for word. Leave blank to use the default."
        >
          <input
            type="text"
            name="voiceGreeting"
            key={restaurant.voiceGreeting}
            defaultValue={restaurant.voiceGreeting ?? ""}
            placeholder={`Thanks for calling ${restaurant.name}, how can I help you?`}
            className="w-full max-w-xl rounded border border-neutral-300 px-2 py-1.5 text-sm"
          />
        </SettingsRow>

        <SettingsRow
          label="Assistant instructions"
          description="Extra tone/wording guidance for the AI when it answers calls — e.g. how to end calls, phrases to avoid, or things to mention (specials, parking, dress code). This is added on top of the standard booking flow, which always collects name, phone, party size, and date/time."
        >
          <textarea
            name="voiceAssistantInstructions"
            key={restaurant.voiceAssistantInstructions}
            defaultValue={restaurant.voiceAssistantInstructions ?? ""}
            rows={6}
            placeholder={`e.g. End calls by saying "Thanks for calling, see you soon!" Mention we validate parking if asked. Keep a warm, casual tone.`}
            className="w-full max-w-xl rounded border border-neutral-300 px-2 py-1.5 text-sm"
          />
        </SettingsRow>

        <SettingsRow
          label="Staff phone number"
          description="A real number the AI can transfer callers to if they ask for a person, or have something outside reservations, and where callers are put through when the AI is switched off. Use international format, e.g. +447700900123. Leave blank to disable transfers — the AI will apologize and keep helping directly instead."
        >
          <input
            type="tel"
            name="fallbackPhoneNumber"
            key={restaurant.fallbackPhoneNumber}
            defaultValue={restaurant.fallbackPhoneNumber ?? ""}
            placeholder="+15555550100"
            className="w-full max-w-xs rounded border border-neutral-300 px-2 py-1.5 text-sm"
          />
        </SettingsRow>

        <p className="mt-2 text-xs text-neutral-400">
          Business hours, party size limits, booking window, and cancellation policy are set on the{" "}
          <a href="/settings/operational" className="underline">
            Operational Settings
          </a>{" "}
          page and are always included automatically.
        </p>

        <div className="mt-6">
          <button
            type="submit"
            className="rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700"
          >
            Save phone settings
          </button>
        </div>
      </form>
    </div>
  );
}
