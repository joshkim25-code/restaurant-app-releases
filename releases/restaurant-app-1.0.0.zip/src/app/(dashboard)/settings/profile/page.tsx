import Link from "next/link";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { SettingsRow } from "@/components/settings/SettingsRow";
import { updateProfile } from "../actions";

const CURRENCIES = ["USD", "EUR", "GBP", "KRW", "JPY", "CAD", "AUD"];

const TIMEZONES = [
  { value: "Europe/London", label: "London (GMT/BST)" },
  { value: "Europe/Dublin", label: "Dublin (GMT/IST)" },
  { value: "Europe/Paris", label: "Paris (CET/CEST)" },
  { value: "Europe/Berlin", label: "Berlin (CET/CEST)" },
  { value: "Europe/Madrid", label: "Madrid (CET/CEST)" },
  { value: "America/New_York", label: "New York (ET)" },
  { value: "America/Chicago", label: "Chicago (CT)" },
  { value: "America/Denver", label: "Denver (MT)" },
  { value: "America/Los_Angeles", label: "Los Angeles (PT)" },
  { value: "America/Toronto", label: "Toronto (ET)" },
  { value: "Asia/Dubai", label: "Dubai (GST)" },
  { value: "Asia/Kolkata", label: "Mumbai/Delhi (IST)" },
  { value: "Asia/Singapore", label: "Singapore (SGT)" },
  { value: "Asia/Hong_Kong", label: "Hong Kong (HKT)" },
  { value: "Asia/Shanghai", label: "Shanghai (CST)" },
  { value: "Asia/Tokyo", label: "Tokyo (JST)" },
  { value: "Asia/Seoul", label: "Seoul (KST)" },
  { value: "Australia/Sydney", label: "Sydney (AEST/AEDT)" },
  { value: "Pacific/Auckland", label: "Auckland (NZST/NZDT)" },
];

const inputClass = "w-56 rounded border border-neutral-300 px-2 py-1.5 text-sm";

export default async function ProfileSettingsPage() {
  const restaurant = await getCurrentRestaurant();

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Restaurant profile</h1>
        <p className="text-sm text-neutral-500">
          Basic information about {restaurant.name}, shown across the app.
        </p>
      </div>

      <form action={updateProfile} className="rounded-lg border border-neutral-200 bg-white p-6">
        <SettingsRow label="Restaurant name">
          <input
            name="name"
            key={restaurant.name}
            defaultValue={restaurant.name}
            required
            className={inputClass}
          />
        </SettingsRow>
        <SettingsRow label="Address">
          <input
            name="address"
            key={restaurant.address}
            defaultValue={restaurant.address ?? ""}
            className={inputClass}
          />
        </SettingsRow>
        <SettingsRow label="Phone number">
          <input
            name="contactPhone"
            key={restaurant.contactPhone}
            defaultValue={restaurant.contactPhone ?? ""}
            placeholder="07911 123456"
            className={inputClass}
          />
        </SettingsRow>
        <SettingsRow label="Currency">
          <select
            name="currency"
            key={restaurant.currency}
            defaultValue={restaurant.currency}
            className={inputClass}
          >
            {CURRENCIES.map((code) => (
              <option key={code} value={code}>
                {code}
              </option>
            ))}
          </select>
        </SettingsRow>
        <SettingsRow label="Timezone">
          <select
            name="timezone"
            key={restaurant.timezone}
            defaultValue={restaurant.timezone}
            className={inputClass}
          >
            {TIMEZONES.map((tz) => (
              <option key={tz.value} value={tz.value}>
                {tz.label}
              </option>
            ))}
          </select>
        </SettingsRow>
        <SettingsRow label="Business hours" description="Weekly open/close schedule">
          <Link href="/hours" className="text-sm text-blue-600 underline hover:text-blue-800">
            Manage business hours →
          </Link>
        </SettingsRow>

        <div className="mt-6">
          <button
            type="submit"
            className="rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700"
          >
            Save profile
          </button>
        </div>
      </form>
    </div>
  );
}
