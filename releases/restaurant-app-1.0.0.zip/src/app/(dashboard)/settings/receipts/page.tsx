import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { PrinterFieldRow } from "@/components/settings/PrinterFieldRow";
import { PrinterCard } from "@/components/settings/PrinterCard";
import { CollapsibleCard } from "@/components/CollapsibleCard";
import {
  updateReceiptSettings,
  updateTaxSettings,
  ensureReceiptPrinter,
  createPrinter,
  updatePrinter,
  deletePrinter,
  setSummaryPrinter,
  sendTestPrintAction,
  listInstalledPrinters,
  getLastKnownInstalledPrinters,
  discoverNetworkPrinters,
  generateAgentToken,
} from "../actions";
import { GenerateAgentTokenButton } from "@/components/settings/GenerateAgentTokenButton";
import { formatDateTime } from "@/lib/time";

export default async function ReceiptsSettingsPage() {
  const restaurant = await getCurrentRestaurant();
  const [receiptPrinter, ticketPrinters, { printers: installedPrinters, asOf: installedPrintersAsOf }] =
    await Promise.all([
      ensureReceiptPrinter(restaurant.id),
      db.printer.findMany({
        where: { restaurantId: restaurant.id, role: "TICKET" },
        orderBy: { sortOrder: "asc" },
      }),
      getLastKnownInstalledPrinters(),
    ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Receipts</h1>
        <p className="text-sm text-neutral-500">
          Customize what appears on printed receipts for {restaurant.name}, and manage every
          printer this restaurant uses.
        </p>
      </div>

      <CollapsibleCard
        summary={
          <div>
            <span className="font-medium text-neutral-900">Receipt content</span>
            <p className="text-xs text-neutral-500">Header, footer, and what appears on the receipt</p>
          </div>
        }
      >
        <form action={updateReceiptSettings} className="divide-y divide-neutral-100">
          <PrinterFieldRow label="Header text" description="Shown below the restaurant name — press Enter for a new line">
            <textarea
              name="receiptHeaderText"
              key={restaurant.receiptHeaderText}
              defaultValue={restaurant.receiptHeaderText ?? ""}
              placeholder="e.g. Fresh, local, every day"
              rows={2}
              className="w-72 rounded border border-neutral-300 px-2 py-1.5 text-sm"
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Footer text" description="Shown at the bottom of the receipt — press Enter for a new line">
            <textarea
              name="receiptFooterText"
              key={restaurant.receiptFooterText}
              defaultValue={restaurant.receiptFooterText ?? ""}
              placeholder="e.g. Thank you for dining with us!"
              rows={2}
              className="w-72 rounded border border-neutral-300 px-2 py-1.5 text-sm"
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Show address">
            <input
              type="checkbox"
              name="receiptShowAddress"
              key={String(restaurant.receiptShowAddress)}
              defaultChecked={restaurant.receiptShowAddress}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Show phone number">
            <input
              type="checkbox"
              name="receiptShowPhone"
              key={String(restaurant.receiptShowPhone)}
              defaultChecked={restaurant.receiptShowPhone}
            />
          </PrinterFieldRow>
          <div className="pt-4">
            <button
              type="submit"
              className="rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700"
            >
              Save
            </button>
          </div>
        </form>
      </CollapsibleCard>

      <CollapsibleCard
        summary={
          <div>
            <span className="font-medium text-neutral-900">Tax &amp; pricing</span>
            <p className="text-xs text-neutral-500">Tax rate, service charge, and how tax appears on receipts</p>
          </div>
        }
      >
        <form action={updateTaxSettings} className="divide-y divide-neutral-100">
          <PrinterFieldRow label="Tax rate">
            <div className="flex items-center gap-1">
              <input
                type="number"
                name="taxRatePercent"
                key={restaurant.taxRatePercent}
                defaultValue={restaurant.taxRatePercent}
                min={0}
                step={0.01}
                className="w-24 rounded border border-neutral-300 px-2 py-1.5 text-sm"
              />
              <span className="text-sm text-neutral-500">%</span>
            </div>
          </PrinterFieldRow>
          <PrinterFieldRow
            label="Prices include tax"
            description="A £10 item still costs the customer £10 either way — this only changes how tax is broken out on the receipt (e.g. £8.33 food + £1.67 tax, instead of £10 food + £2 tax added on top)"
          >
            <input
              type="checkbox"
              name="pricesIncludeTax"
              key={String(restaurant.pricesIncludeTax)}
              defaultChecked={restaurant.pricesIncludeTax}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Service charge">
            <div className="flex items-center gap-1">
              <input
                type="number"
                name="serviceChargePercent"
                key={restaurant.serviceChargePercent}
                defaultValue={restaurant.serviceChargePercent}
                min={0}
                step={0.01}
                className="w-24 rounded border border-neutral-300 px-2 py-1.5 text-sm"
              />
              <span className="text-sm text-neutral-500">%</span>
            </div>
          </PrinterFieldRow>
          <PrinterFieldRow
            label="Service charge on takeaway"
            description="Untick if takeaway orders (including AI phone orders) shouldn't include the service charge. Dine-in bills are unaffected."
          >
            <input
              type="checkbox"
              name="serviceChargeOnTakeaway"
              key={String(restaurant.serviceChargeOnTakeaway)}
              defaultChecked={restaurant.serviceChargeOnTakeaway}
            />
          </PrinterFieldRow>
          <div className="pt-4">
            <button
              type="submit"
              className="rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700"
            >
              Save
            </button>
          </div>
        </form>
      </CollapsibleCard>

      <CollapsibleCard
        summary={
          <div>
            <span className="font-medium text-neutral-900">Print agent</span>
            <p className="text-xs text-neutral-500">
              Connects this restaurant&rsquo;s printers to the app once it&rsquo;s hosted elsewhere
            </p>
          </div>
        }
      >
        <div className="space-y-2 text-sm text-neutral-600">
          <p>
            Run <code>npm run agent</code> on a Windows machine at this restaurant, with the token
            below in its <code>.env</code> file as <code>AGENT_TOKEN</code>. It stays connected and
            handles every print job for this restaurant.
          </p>
          <p>
            Status: {restaurant.agentToken ? "A token has been generated." : "No token generated yet."}
          </p>
          <GenerateAgentTokenButton generateAgentToken={generateAgentToken} />
        </div>
      </CollapsibleCard>

      <p className="text-xs text-neutral-400">
        {installedPrintersAsOf
          ? `Installed printers as of ${formatDateTime(installedPrintersAsOf, restaurant.timezone)} — use "Refresh list" below to check again.`
          : 'No printer list yet — use "Refresh list" below once the print agent is running.'}
      </p>

      <div>
        <h2 className="mb-2 text-sm font-semibold text-neutral-700">Receipt printer</h2>
        <PrinterCard
          key={receiptPrinter.id}
          printer={receiptPrinter}
          removable={false}
          installedPrinters={installedPrinters}
          listInstalledPrinters={listInstalledPrinters}
          discoverNetworkPrinters={discoverNetworkPrinters}
          updatePrinter={updatePrinter}
          deletePrinter={deletePrinter}
          setSummaryPrinter={setSummaryPrinter}
          sendTestPrintAction={sendTestPrintAction}
        />
      </div>

      <div>
        <h2 className="mb-2 text-sm font-semibold text-neutral-700">Ticket printers</h2>
        <p className="mb-3 text-xs text-neutral-500">
          Kitchen, bar, expo — any printer that should only get the items assigned to it on the
          Menu page. Items not assigned to any ticket printer still appear on the receipt
          printer&rsquo;s order ticket.
        </p>
        <div className="space-y-4">
          {ticketPrinters.map((printer) => (
            <PrinterCard
              key={printer.id}
              printer={printer}
              removable
              installedPrinters={installedPrinters}
              listInstalledPrinters={listInstalledPrinters}
              discoverNetworkPrinters={discoverNetworkPrinters}
              updatePrinter={updatePrinter}
              deletePrinter={deletePrinter}
              setSummaryPrinter={setSummaryPrinter}
              sendTestPrintAction={sendTestPrintAction}
            />
          ))}
        </div>

        <form
          action={createPrinter}
          className="mt-4 flex flex-wrap items-end gap-4 rounded-lg border border-dashed border-neutral-300 p-4"
        >
          <div className="flex flex-col gap-1">
            <label className="text-xs text-neutral-500" htmlFor="new-printer-name">
              New printer name
            </label>
            <input
              id="new-printer-name"
              name="name"
              required
              placeholder="Bar printer"
              className="rounded border border-neutral-300 px-2 py-1.5 text-sm"
            />
          </div>
          <button
            type="submit"
            className="rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700"
          >
            Add another printer
          </button>
        </form>
      </div>
    </div>
  );
}
