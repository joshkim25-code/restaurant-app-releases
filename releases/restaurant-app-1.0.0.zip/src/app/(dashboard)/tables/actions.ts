"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import type { TableShape } from "@/generated/prisma/client";

const SPAWN_COLS = 5;
const SPAWN_CELL_WIDTH = 160;
const SPAWN_CELL_HEIGHT = 140;
const SPAWN_MARGIN = 40;

function revalidateTableViews() {
  revalidatePath("/tables");
  revalidatePath("/dashboard");
  revalidatePath("/waiter");
}

export async function createTable(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  const label = String(formData.get("label") ?? "").trim();
  const seats = Number(formData.get("seats"));
  const section = String(formData.get("section") ?? "").trim();
  const shapeInput = String(formData.get("shape") ?? "RECTANGLE").toUpperCase();
  const shape: TableShape = shapeInput === "CIRCLE" ? "CIRCLE" : "RECTANGLE";

  if (!label || !Number.isFinite(seats) || seats <= 0) {
    throw new Error("A table label and a positive seat count are required.");
  }

  const count = await db.table.count({ where: { restaurantId: restaurant.id } });
  const col = count % SPAWN_COLS;
  const row = Math.floor(count / SPAWN_COLS);
  const posX = SPAWN_MARGIN + col * SPAWN_CELL_WIDTH;
  const posY = SPAWN_MARGIN + row * SPAWN_CELL_HEIGHT;
  const size = shape === "CIRCLE" ? 90 : undefined;

  await db.table.create({
    data: {
      restaurantId: restaurant.id,
      label,
      seats,
      section: section || null,
      shape,
      posX,
      posY,
      width: size ?? 120,
      height: size ?? 80,
    },
  });

  revalidateTableViews();
}

const SORT_KEYS = ["label", "seats", "section", "status"];

// Production Next.js hides the text of thrown server-action errors behind a generic
// "server error" page, so expected validation failures redirect back to the page with an
// error code it can render instead.
function tablesUrl(formData: FormData, extra: Record<string, string> = {}): string {
  const sort = String(formData.get("sort") ?? "");
  const dir = String(formData.get("dir") ?? "");
  const query = new URLSearchParams();
  if (SORT_KEYS.includes(sort)) query.set("sort", sort);
  if (dir === "asc" || dir === "desc") query.set("dir", dir);
  for (const [key, value] of Object.entries(extra)) query.set(key, value);
  const qs = query.toString();
  return qs ? `/tables?${qs}` : "/tables";
}

export async function updateTable(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  const id = String(formData.get("id") ?? "");
  const label = String(formData.get("label") ?? "").trim();
  const seats = Number(formData.get("seats"));
  const section = String(formData.get("section") ?? "").trim();

  if (!label || !Number.isInteger(seats) || seats <= 0) {
    redirect(tablesUrl(formData, { edit: id, error: "invalid" }));
  }

  const table = await db.table.findFirst({ where: { id, restaurantId: restaurant.id } });
  if (!table) {
    throw new Error("Table not found.");
  }

  const tooBig = await db.reservation.count({
    where: {
      tableId: id,
      status: { in: ["PENDING", "CONFIRMED"] },
      startTime: { gte: new Date() },
      partySize: { gt: seats },
    },
  });
  if (tooBig > 0) {
    redirect(tablesUrl(formData, { edit: id, error: "reserved", seats: String(seats) }));
  }

  await db.table.update({
    where: { id },
    data: { label, seats, section: section || null },
  });

  revalidateTableViews();
  redirect(tablesUrl(formData));
}

export async function toggleTableActive(formData: FormData) {
  const id = String(formData.get("id"));
  const isActive = formData.get("isActive") === "true";

  await db.table.update({
    where: { id },
    data: { isActive: !isActive },
  });

  revalidateTableViews();
}

export async function deleteTable(formData: FormData) {
  const id = String(formData.get("id"));

  await db.table.delete({ where: { id } });

  revalidateTableViews();
}
