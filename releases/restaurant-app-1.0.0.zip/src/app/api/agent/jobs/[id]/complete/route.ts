import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

async function resolveRestaurantId(request: NextRequest): Promise<string | null> {
  const auth = request.headers.get("authorization") ?? "";
  const token = auth.startsWith("Bearer ") ? auth.slice("Bearer ".length) : null;
  if (!token) return null;

  const restaurant = await db.restaurant.findUnique({ where: { agentToken: token } });
  return restaurant?.id ?? null;
}

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const restaurantId = await resolveRestaurantId(request);
  if (!restaurantId) {
    return NextResponse.json({ error: "Invalid agent token." }, { status: 401 });
  }

  const { id } = await params;
  const body = await request.json();
  const status = body.status === "DONE" ? "DONE" : body.status === "FAILED" ? "FAILED" : null;
  if (!status) {
    return NextResponse.json({ error: "status must be DONE or FAILED." }, { status: 400 });
  }

  const { count } = await db.printJob.updateMany({
    where: { id, restaurantId },
    data: {
      status,
      result: status === "DONE" ? (body.result ?? null) : undefined,
      error: status === "FAILED" ? String(body.error ?? "Unknown error") : null,
      completedAt: new Date(),
    },
  });

  if (count === 0) {
    return NextResponse.json({ error: "Job not found." }, { status: 404 });
  }

  // The printer's configured IP can drift (DHCP reassigning it a new address) - when the
  // agent recovers from that by rediscovering and retrying against the printer's current IP,
  // it reports the corrected address back here so future jobs use it directly instead of
  // needing another rediscovery-and-retry (or a manual "Scan for network printers") every time.
  const recoveredIp = status === "DONE" && typeof body.result?.recoveredIp === "string" ? body.result.recoveredIp : null;
  if (recoveredIp) {
    const job = await db.printJob.findUnique({ where: { id, restaurantId } });
    const printerId = (job?.payload as { printerConfig?: { id?: string } } | null)?.printerConfig?.id;
    if (printerId) {
      await db.printer.updateMany({
        where: { id: printerId, restaurantId },
        data: { ipAddress: recoveredIp },
      });
    }
  }

  return NextResponse.json({ ok: true });
}
