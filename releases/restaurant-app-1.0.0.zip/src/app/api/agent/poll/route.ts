import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

async function resolveRestaurantId(request: NextRequest): Promise<string | null> {
  const auth = request.headers.get("authorization") ?? "";
  const token = auth.startsWith("Bearer ") ? auth.slice("Bearer ".length) : null;
  if (!token) return null;

  const restaurant = await db.restaurant.findUnique({ where: { agentToken: token } });
  return restaurant?.id ?? null;
}

export async function POST(request: NextRequest) {
  const restaurantId = await resolveRestaurantId(request);
  if (!restaurantId) {
    return NextResponse.json({ error: "Invalid agent token." }, { status: 401 });
  }

  const job = await db.printJob.findFirst({
    where: { restaurantId, status: "PENDING" },
    orderBy: { createdAt: "asc" },
  });

  if (!job) {
    return NextResponse.json({ job: null });
  }

  const claimed = await db.printJob.update({
    where: { id: job.id },
    data: { status: "CLAIMED", claimedAt: new Date() },
  });

  return NextResponse.json({
    job: { id: claimed.id, type: claimed.type, payload: claimed.payload },
  });
}
