import { NextRequest, NextResponse } from "next/server";
import { consumeLoginToken, findOrCreateUser } from "@/lib/auth";
import { getSession } from "@/lib/session";
import { db } from "@/lib/db";

export async function GET(request: NextRequest) {
  const token = request.nextUrl.searchParams.get("token");
  const email = token ? await consumeLoginToken(token) : null;

  if (!email) {
    return NextResponse.redirect(new URL("/login?error=invalid", request.url));
  }

  const user = await findOrCreateUser(email);

  const session = await getSession();
  session.userId = user.id;
  await session.save();

  const membership = await db.membership.findFirst({ where: { userId: user.id } });
  return NextResponse.redirect(new URL(membership ? "/dashboard" : "/onboarding", request.url));
}
