import { NextRequest, NextResponse } from "next/server";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { getPhoneOrdersCreatedAfter } from "@/lib/orders";

export async function GET(request: NextRequest) {
  const sinceParam = request.nextUrl.searchParams.get("since");
  const since = sinceParam ? new Date(sinceParam) : new Date(0);

  const restaurant = await getCurrentRestaurant();
  const orders = await getPhoneOrdersCreatedAfter(restaurant.id, since);

  return NextResponse.json({ orders });
}
