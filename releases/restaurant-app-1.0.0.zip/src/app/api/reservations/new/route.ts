import { NextRequest, NextResponse } from "next/server";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { getReservationsCreatedAfter } from "@/lib/reservations";

export async function GET(request: NextRequest) {
  const sinceParam = request.nextUrl.searchParams.get("since");
  const since = sinceParam ? new Date(sinceParam) : new Date(0);

  const restaurant = await getCurrentRestaurant();
  const reservations = await getReservationsCreatedAfter(restaurant.id, since);

  return NextResponse.json({ reservations });
}
