"use server";

import { redirect } from "next/navigation";
import { createLoginToken } from "@/lib/auth";
import { sendLoginEmail } from "@/lib/mail";

export async function requestLoginLink(formData: FormData) {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  if (!email || !email.includes("@")) {
    throw new Error("A valid email is required.");
  }

  const token = await createLoginToken(email);

  try {
    await sendLoginEmail(email, token);
  } catch {
    redirect(`/login?error=send-failed&email=${encodeURIComponent(email)}`);
  }

  redirect("/login?sent=1");
}
