import { requestLoginLink } from "./actions";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ sent?: string; error?: string; email?: string }>;
}) {
  const { sent, error, email: failedEmail } = await searchParams;

  return (
    <div className="mx-auto mt-24 max-w-sm space-y-4 px-4">
      <div>
        <h1 className="text-xl font-semibold">Log in</h1>
        <p className="text-sm text-neutral-500">
          Enter your email and we&rsquo;ll send you a link to log in.
        </p>
      </div>

      {sent ? (
        <div className="rounded-lg border border-neutral-200 bg-white p-6 text-sm">
          Check your email for a login link. It expires in 15 minutes.
        </div>
      ) : (
        <form action={requestLoginLink} className="rounded-lg border border-neutral-200 bg-white p-6">
          {error === "invalid" && (
            <p className="mb-3 text-sm text-red-600">
              That link is invalid or has expired. Request a new one below.
            </p>
          )}
          {error === "send-failed" && (
            <p className="mb-3 text-sm text-red-600">
              Couldn&rsquo;t send a login email to {failedEmail ?? "that address"}. Ask the
              restaurant owner to check the email setup.
            </p>
          )}
          <label className="mb-1 block text-xs text-neutral-500">Email</label>
          <input
            type="email"
            name="email"
            required
            placeholder="you@restaurant.com"
            className="mb-3 w-full rounded border border-neutral-300 px-2 py-1.5 text-sm"
          />
          <button
            type="submit"
            className="w-full rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700"
          >
            Send login link
          </button>
        </form>
      )}
    </div>
  );
}
