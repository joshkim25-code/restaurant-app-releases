"use server";

import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { requireUserId } from "@/lib/session";

export async function createRestaurant(formData: FormData) {
  const userId = await requireUserId();

  const existing = await db.membership.findFirst({ where: { userId } });
  if (existing) {
    redirect("/dashboard");
  }

  const name = String(formData.get("name") ?? "").trim();
  const timezone = String(formData.get("timezone") ?? "").trim();
  const currency = String(formData.get("currency") ?? "GBP").trim();

  if (!name || !timezone) {
    throw new Error("A restaurant name and timezone are required.");
  }

  await db.$transaction(async (tx) => {
    const restaurant = await tx.restaurant.create({ data: { name, timezone, currency } });
    await tx.membership.create({ data: { userId, restaurantId: restaurant.id, role: "OWNER" } });
  });

  redirect("/dashboard");
}
