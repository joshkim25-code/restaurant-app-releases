"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { computeBillTotalCents, computeBillTotals } from "@/lib/billing";
import { submitOrderCore } from "@/lib/orders";
import type { CartItemInput } from "@/lib/orderTypes";
import type { PaymentMethod } from "@/generated/prisma/client";

export async function openBill(formData: FormData) {
  const restaurant = await getCurrentRestaurant();

  const tableId = String(formData.get("tableId") ?? "");
  if (!tableId) {
    throw new Error("A table is required.");
  }

  const table = await db.table.findUnique({
    where: { id: tableId, restaurantId: restaurant.id },
  });
  if (!table) {
    throw new Error("Table not found.");
  }

  const existing = await db.bill.findFirst({
    where: { tableId, restaurantId: restaurant.id, status: "OPEN" },
  });
  if (existing) {
    throw new Error("This table already has an open bill.");
  }

  await db.bill.create({
    data: {
      restaurantId: restaurant.id,
      tableId,
      status: "OPEN",
      source: "WAITER",
    },
  });

  revalidatePath(`/waiter/${tableId}`);
  revalidatePath("/waiter");
}

export async function submitOrder(
  billId: string,
  items: CartItemInput[],
  isTakeaway = false,
  takeawayNote?: string,
) {
  const restaurant = await getCurrentRestaurant();
  const order = await submitOrderCore(restaurant, billId, items, isTakeaway, takeawayNote);

  if (order.tableId) {
    revalidatePath(`/waiter/${order.tableId}`);
  }

  return { id: order.id };
}

function computeTipCents(formData: FormData, totalCents: number): number {
  const tipMode = String(formData.get("tipMode") ?? "none");
  if (tipMode === "custom") {
    const raw = Number(formData.get("tipCustomAmount"));
    return Number.isFinite(raw) && raw > 0 ? Math.round(raw * 100) : 0;
  }
  const pct = Number(tipMode);
  return Number.isFinite(pct) && pct > 0 ? Math.round((totalCents * pct) / 100) : 0;
}

const VALID_PAYMENT_METHODS: PaymentMethod[] = ["CASH", "CARD", "OTHER"];

export async function closeBill(formData: FormData) {
  const billId = String(formData.get("billId") ?? "");
  const tableId = String(formData.get("tableId") ?? "");
  const method = String(formData.get("method") ?? "") as PaymentMethod;
  const tipMethodRaw = String(formData.get("tipMethod") ?? "") as PaymentMethod;

  if (!billId || !VALID_PAYMENT_METHODS.includes(method)) {
    throw new Error("A valid payment method is required.");
  }
  // A tip paid a different way than the order (e.g. order on card, tip in cash) - falls
  // back to the order's method if not given or not one of the valid options.
  const tipMethod = VALID_PAYMENT_METHODS.includes(tipMethodRaw) ? tipMethodRaw : method;

  const restaurant = await getCurrentRestaurant();

  const bill = await db.bill.findUnique({
    where: { id: billId, restaurantId: restaurant.id },
    include: { orders: { include: { items: { include: { optionChoices: true } } } } },
  });
  if (!bill || bill.status !== "OPEN") {
    throw new Error("This bill is not open.");
  }

  const discountPercentRaw = Number(formData.get("discountPercent"));
  const discountPercent = Number.isFinite(discountPercentRaw)
    ? Math.min(100, Math.max(0, discountPercentRaw))
    : 0;

  const { subtotalCents, taxCents, serviceChargeCents, discountCents, totalCents } =
    computeBillTotals(bill.orders, restaurant, discountPercent, bill.tableId === null);

  const tipCents = computeTipCents(formData, totalCents);

  await db.$transaction([
    db.payment.create({
      data: {
        billId,
        amountCents: totalCents,
        subtotalCents,
        taxCents,
        serviceChargeCents,
        discountCents,
        tipCents,
        pricesIncludeTax: restaurant.pricesIncludeTax,
        method,
        tipMethod,
      },
    }),
    db.bill.update({ where: { id: billId }, data: { status: "CLOSED", closedAt: new Date() } }),
  ]);

  if (tableId) {
    revalidatePath(`/waiter/${tableId}`);
  }
  revalidatePath("/waiter");
  revalidatePath("/waiter/takeaway");
  revalidatePath("/dashboard");

  redirect(`/waiter/receipts/${billId}?autoprint=1`);
}

export async function cancelBill(formData: FormData) {
  const billId = String(formData.get("billId") ?? "");
  const tableId = String(formData.get("tableId") ?? "");

  if (!billId) {
    throw new Error("A bill is required.");
  }

  const restaurant = await getCurrentRestaurant();

  const bill = await db.bill.findUnique({
    where: { id: billId, restaurantId: restaurant.id },
    include: { orders: { include: { items: { include: { optionChoices: true } } } } },
  });
  if (!bill || bill.status !== "OPEN") {
    throw new Error("This bill is not open.");
  }

  // Must be computed before the orders below are marked CANCELLED — computeBillTotalCents
  // filters out CANCELLED orders, so computing this after would always yield 0.
  const cancelledValueCents = computeBillTotalCents(bill.orders);

  await db.$transaction([
    db.order.updateMany({
      where: { billId, status: { not: "CANCELLED" } },
      data: { status: "CANCELLED" },
    }),
    db.bill.update({
      where: { id: billId },
      data: { status: "CLOSED", closedAt: new Date(), cancelledValueCents },
    }),
  ]);

  if (tableId) {
    revalidatePath(`/waiter/${tableId}`);
  }
  revalidatePath("/waiter");
  revalidatePath("/waiter/takeaway");
  revalidatePath("/dashboard");
}
