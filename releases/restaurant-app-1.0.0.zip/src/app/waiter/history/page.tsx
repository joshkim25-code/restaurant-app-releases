import Link from "next/link";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { getBillHistory, getRestaurantTables } from "@/lib/billHistory";
import { formatMoney } from "@/lib/money";
import { formatDateTime } from "@/lib/time";
import { TableFilter } from "@/components/TableFilter";
import { Pagination } from "@/components/Pagination";

export default async function WaiterHistoryPage({
  searchParams,
}: {
  searchParams: Promise<{ table?: string; page?: string }>;
}) {
  const params = await searchParams;
  const page = Math.max(1, Number(params.page) || 1);

  const restaurant = await getCurrentRestaurant();
  const [{ bills, hasNext, hasPrev }, tables] = await Promise.all([
    getBillHistory(restaurant.id, { tableId: params.table, page }),
    getRestaurantTables(restaurant.id),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <Link href="/waiter" className="text-sm text-neutral-500 underline hover:text-neutral-900">
          ← Back to tables
        </Link>
        <h1 className="mt-2 text-lg font-semibold">Bill history</h1>
      </div>

      <TableFilter basePath="/waiter/history" tables={tables} selectedTableId={params.table} />

      <div className="rounded-lg border border-neutral-200 bg-white p-4">
        {bills.length === 0 ? (
          <p className="text-sm text-neutral-400">No past bills yet.</p>
        ) : (
          <ul className="divide-y divide-neutral-100">
            {bills.map((bill) => (
              <li key={bill.id} className="flex items-center justify-between py-2 text-sm">
                <div>
                  <div>{bill.tableLabel}</div>
                  <div className="text-neutral-500">
                    {formatDateTime(bill.closedAt, restaurant.timezone)}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={bill.status === "PAID" ? "text-green-700" : "text-red-600"}>
                    {bill.status === "PAID" ? "Paid" : "Cancelled"}
                  </span>
                  <span>{formatMoney(bill.totalCents, restaurant.currency)}</span>
                  <Link
                    href={`/waiter/receipts/${bill.id}`}
                    className="underline hover:text-neutral-900"
                  >
                    View
                  </Link>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <Pagination
        basePath="/waiter/history"
        page={page}
        hasPrev={hasPrev}
        hasNext={hasNext}
        searchParams={{ table: params.table }}
      />
    </div>
  );
}
