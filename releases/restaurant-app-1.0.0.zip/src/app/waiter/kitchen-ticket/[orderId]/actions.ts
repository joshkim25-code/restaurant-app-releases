"use server";

import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { buildTicketForPrinterCommands, buildOrderTicketCommands } from "@/lib/ticketContent";
import { enqueuePrintJob, awaitJobResult } from "@/lib/printJobs";

async function findOrderForTicket(orderId: string, restaurantId: string) {
  const order = await db.order.findFirst({
    where: { id: orderId, bill: { restaurantId } },
    include: {
      bill: { include: { table: true } },
      items: { include: { menuItem: true, optionChoices: true } },
    },
  });
  if (!order) {
    throw new Error("Order not found.");
  }
  return order;
}

// Prints the receipt printer's complete order ticket, then every ticket printer
// (Kitchen, Bar, Expo, ...) that has at least one item assigned to it in this round.
// Each printer's failure is independent — one printer being down doesn't block the rest.
export async function printOrderTickets(orderId: string): Promise<{ printer: string; error: string }[]> {
  const restaurant = await getCurrentRestaurant();
  const order = await findOrderForTicket(orderId, restaurant.id);
  const printers = await db.printer.findMany({ where: { restaurantId: restaurant.id } });

  const failures: { printer: string; error: string }[] = [];

  const receiptPrinter = printers.find((p) => p.role === "RECEIPT");
  if (receiptPrinter) {
    try {
      const commands = buildOrderTicketCommands(restaurant, order, receiptPrinter);
      const job = await enqueuePrintJob(restaurant.id, "TICKET", receiptPrinter, commands);
      await awaitJobResult(job.id);
    } catch (err) {
      failures.push({ printer: receiptPrinter.name, error: err instanceof Error ? err.message : "unknown error" });
    }
  }

  for (const printer of printers.filter((p) => p.role === "TICKET")) {
    const commands = buildTicketForPrinterCommands(printer, restaurant, order);
    if (!commands) continue; // no items in this round assigned to this printer

    try {
      const job = await enqueuePrintJob(restaurant.id, "TICKET", printer, commands);
      await awaitJobResult(job.id);
    } catch (err) {
      failures.push({ printer: printer.name, error: err instanceof Error ? err.message : "unknown error" });
    }
  }

  return failures;
}

// Same as printOrderTickets, but for the manual "reprint" button — throws if anything
// failed, matching ThermalPrintButton's expected (id) => Promise<void> contract.
export async function reprintOrderTickets(orderId: string): Promise<void> {
  const failures = await printOrderTickets(orderId);
  if (failures.length > 0) {
    throw new Error(failures.map((f) => `${f.printer}: ${f.error}`).join("; "));
  }
}
