import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { ThermalPrintButton } from "@/components/ThermalPrintButton";
import { formatDateTime } from "@/lib/time";
import { reprintOrderTickets } from "./actions";

export default async function KitchenTicketPage({
  params,
}: {
  params: Promise<{ orderId: string }>;
}) {
  const { orderId } = await params;
  const restaurant = await getCurrentRestaurant();

  const order = await db.order.findFirst({
    where: { id: orderId, bill: { restaurantId: restaurant.id } },
    include: {
      bill: { include: { table: true } },
      items: { include: { menuItem: true, optionChoices: true } },
    },
  });
  if (!order) {
    notFound();
  }

  const printers = await db.printer.findMany({
    where: { restaurantId: restaurant.id, role: "TICKET" },
    orderBy: { sortOrder: "asc" },
  });
  const groups = printers
    .map((printer) => ({
      printer,
      items: order.items.filter((item) => item.menuItem.printerId === printer.id),
    }))
    .filter((group) => group.items.length > 0);
  const unassignedItems = order.items.filter((item) => item.menuItem.printerId === null);

  return (
    <div className="space-y-6">
      <div className="print:hidden flex items-center justify-end">
        <ThermalPrintButton id={order.id} printAction={reprintOrderTickets} label="Print tickets" />
      </div>

      <div className="rounded-lg border border-neutral-200 bg-white p-6 print:border-0">
        <div className="text-center">
          <h1 className="text-lg font-semibold">Order tickets</h1>
          <p className="text-sm text-neutral-500">
            {order.bill.table ? order.bill.table.label : "Takeaway"}
          </p>
          {order.isTakeaway && (
            <div className="mt-1 flex items-center justify-center gap-2 text-xs font-medium text-amber-700">
              <span className="rounded-full bg-amber-100 px-2 py-0.5">Takeaway</span>
              {order.takeawayNote && <span className="text-neutral-500">{order.takeawayNote}</span>}
            </div>
          )}
          <p className="text-xs text-neutral-400">
            {formatDateTime(order.submittedAt, restaurant.timezone)}
          </p>
        </div>

        {groups.length === 0 && unassignedItems.length === order.items.length ? (
          <p className="mt-4 border-t border-neutral-200 pt-4 text-center text-sm text-neutral-400">
            Nothing on this order is assigned to a ticket printer.
          </p>
        ) : (
          groups.map(({ printer, items }) => (
            <div key={printer.id} className="mt-4 space-y-3 border-t border-neutral-200 pt-4">
              <h2 className="text-sm font-semibold text-neutral-700">{printer.name}</h2>
              {items.map((item) => (
                <div key={item.id} className="text-sm">
                  <div className="font-medium">
                    {item.quantity}× {item.menuItem.name}
                  </div>
                  {item.optionChoices.length > 0 && (
                    <div className="text-neutral-500">
                      {item.optionChoices.map((c) => c.choiceNameAtOrder).join(", ")}
                    </div>
                  )}
                  {item.notes && <div className="text-neutral-400">Note: {item.notes}</div>}
                </div>
              ))}
            </div>
          ))
        )}

        {unassignedItems.length > 0 && (
          <div className="mt-4 space-y-3 border-t border-neutral-200 pt-4">
            <h2 className="text-sm font-semibold text-neutral-700">
              Not sent to a ticket printer (receipt only)
            </h2>
            {unassignedItems.map((item) => (
              <div key={item.id} className="text-sm">
                <div className="font-medium">
                  {item.quantity}× {item.menuItem.name}
                </div>
                {item.optionChoices.length > 0 && (
                  <div className="text-neutral-500">
                    {item.optionChoices.map((c) => c.choiceNameAtOrder).join(", ")}
                  </div>
                )}
                {item.notes && <div className="text-neutral-400">Note: {item.notes}</div>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
