import Link from "next/link";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { getPendingReservationCount } from "@/lib/reservations";
import { NotificationBadge } from "@/components/NotificationBadge";
import { ReservationNotifier } from "@/components/ReservationNotifier";
import { OrderNotifier } from "@/components/OrderNotifier";
import { LogoutButton } from "@/components/LogoutButton";

export default async function WaiterLayout({ children }: { children: React.ReactNode }) {
  const restaurant = await getCurrentRestaurant();
  const pendingReservationCount = await getPendingReservationCount(restaurant.id);

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900">
      <header className="print:hidden flex items-center justify-between border-b border-neutral-200 bg-white px-6 py-4">
        <span className="font-semibold">Waiter</span>
        <div className="flex items-center gap-4">
          <Link
            href="/dashboard"
            className="text-sm text-neutral-500 underline hover:text-neutral-900"
          >
            Dashboard
          </Link>
          <Link
            href="/waiter/takeaway"
            className="text-sm text-neutral-500 underline hover:text-neutral-900"
          >
            Takeaway
          </Link>
          <Link
            href="/waiter/history"
            className="text-sm text-neutral-500 underline hover:text-neutral-900"
          >
            History
          </Link>
          <Link
            href="/waiter/reservations"
            className="relative text-sm text-neutral-500 underline hover:text-neutral-900"
          >
            Reservations
            <NotificationBadge count={pendingReservationCount} />
          </Link>
          <LogoutButton />
        </div>
      </header>
      <main className="mx-auto max-w-2xl px-6 py-8">{children}</main>
      <ReservationNotifier
        enabled={restaurant.notifyNewReservationInApp}
        timezone={restaurant.timezone}
        durationSeconds={restaurant.notificationDurationSeconds}
      />
      <OrderNotifier
        enabled={restaurant.notifyNewPhoneOrderInApp}
        currency={restaurant.currency}
        durationSeconds={restaurant.notificationDurationSeconds}
      />
    </div>
  );
}
