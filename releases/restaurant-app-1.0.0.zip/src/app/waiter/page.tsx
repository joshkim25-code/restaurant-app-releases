import { getCurrentRestaurant } from "@/lib/restaurant";
import { getTablesWithStatus } from "@/lib/tables";
import { updateTableLayout } from "@/lib/floorPlanActions";
import { FloorPlan } from "@/components/floor-plan/FloorPlan";

export default async function WaiterTablePickerPage() {
  const restaurant = await getCurrentRestaurant();
  const tables = await getTablesWithStatus(restaurant.id);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Tables</h1>
        <p className="text-sm text-neutral-500">
          Tap a table to start or continue an order.
        </p>
      </div>
      <FloorPlan
        role="waiter"
        tables={tables}
        timezone={restaurant.timezone}
        updateTableLayout={updateTableLayout}
      />
    </div>
  );
}
