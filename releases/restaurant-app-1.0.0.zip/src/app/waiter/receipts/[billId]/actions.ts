"use server";

import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { resolveBillTotals } from "@/lib/billing";
import { buildReceiptCommands } from "@/lib/ticketContent";
import { enqueuePrintJob, awaitJobResult } from "@/lib/printJobs";

export async function printReceiptToThermal(billId: string) {
  const restaurant = await getCurrentRestaurant();

  const bill = await db.bill.findFirst({
    where: { id: billId, restaurantId: restaurant.id },
    include: {
      table: true,
      payment: true,
      orders: {
        orderBy: { submittedAt: "asc" },
        include: { items: { include: { menuItem: true, optionChoices: true } } },
      },
    },
  });
  if (!bill) {
    throw new Error("Bill not found.");
  }

  const totals = resolveBillTotals(bill, restaurant);

  const receiptPrinter = await db.printer.findFirst({
    where: { restaurantId: restaurant.id, role: "RECEIPT" },
  });
  if (!receiptPrinter) {
    throw new Error("No receipt printer is configured. Add one in Settings → Receipts.");
  }

  const commands = buildReceiptCommands(restaurant, bill, totals, receiptPrinter);
  const job = await enqueuePrintJob(restaurant.id, "RECEIPT", receiptPrinter, commands);
  await awaitJobResult(job.id);
}
