import { notFound } from "next/navigation";
import Link from "next/link";
import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { lineTotalCents, resolveBillTotals } from "@/lib/billing";
import { formatMoney } from "@/lib/money";
import { ThermalPrintButton } from "@/components/ThermalPrintButton";
import { formatDateTime } from "@/lib/time";
import { printReceiptToThermal } from "./actions";

export default async function ReceiptPage({
  params,
  searchParams,
}: {
  params: Promise<{ billId: string }>;
  searchParams: Promise<{ autoprint?: string }>;
}) {
  const { billId } = await params;
  const { autoprint } = await searchParams;
  const restaurant = await getCurrentRestaurant();

  const bill = await db.bill.findFirst({
    where: { id: billId, restaurantId: restaurant.id },
    include: {
      table: true,
      payment: true,
      orders: {
        orderBy: { submittedAt: "asc" },
        include: { items: { include: { menuItem: true, optionChoices: true } } },
      },
    },
  });
  if (!bill) {
    notFound();
  }

  const cancelled = bill.status === "CLOSED" && !bill.payment;
  const totals = resolveBillTotals(bill, restaurant);
  const hasBreakdown = totals.taxCents > 0 || totals.serviceChargeCents > 0;

  return (
    <div className="space-y-6">
      <div className="print:hidden flex items-center justify-between">
        {bill.table ? (
          <Link
            href={`/waiter/${bill.table.id}`}
            className="text-sm text-neutral-500 underline hover:text-neutral-900"
          >
            ← Back to table
          </Link>
        ) : (
          <Link
            href={bill.status === "OPEN" ? `/waiter/takeaway/${bill.id}` : "/waiter/takeaway"}
            className="text-sm text-neutral-500 underline hover:text-neutral-900"
          >
            ← Back to takeaway orders
          </Link>
        )}
        <div className="print:hidden">
          <ThermalPrintButton
            id={bill.id}
            printAction={printReceiptToThermal}
            autoPrint={autoprint === "1"}
          />
        </div>
      </div>

      <div className="rounded-lg border border-neutral-200 bg-white p-6 print:border-0">
        <div className="text-center">
          <h1 className="text-lg font-semibold">{restaurant.name}</h1>
          {restaurant.receiptHeaderText && (
            <p className="whitespace-pre-line text-sm text-neutral-600">{restaurant.receiptHeaderText}</p>
          )}
          {restaurant.receiptShowAddress && restaurant.address && (
            <p className="text-xs text-neutral-500">{restaurant.address}</p>
          )}
          {restaurant.receiptShowPhone && restaurant.contactPhone && (
            <p className="text-xs text-neutral-500">{restaurant.contactPhone}</p>
          )}
          <p className="text-sm text-neutral-500">{bill.table ? bill.table.label : "Takeaway"}</p>
          <p className="text-xs text-neutral-400">
            {formatDateTime(bill.closedAt ?? bill.openedAt, restaurant.timezone)}
          </p>
        </div>

        <div className="mt-4 space-y-4 border-t border-neutral-200 pt-4">
          {bill.orders.map((order) => (
            <div key={order.id} className="space-y-2">
              {order.isTakeaway && (
                <div className="flex items-center gap-2 text-xs font-medium text-amber-700">
                  <span className="rounded-full bg-amber-100 px-2 py-0.5">Takeaway</span>
                  {order.takeawayNote && <span className="text-neutral-500">{order.takeawayNote}</span>}
                </div>
              )}
              {order.items.map((item) => (
                <div key={item.id} className="flex items-start justify-between text-sm">
                  <div>
                    <div>
                      {item.quantity}× {item.menuItem.name}
                    </div>
                    {item.optionChoices.length > 0 && (
                      <div className="text-neutral-500">
                        {item.optionChoices.map((c) => c.choiceNameAtOrder).join(", ")}
                      </div>
                    )}
                    {item.notes && <div className="text-neutral-400">Note: {item.notes}</div>}
                  </div>
                  <span>{formatMoney(lineTotalCents(item), restaurant.currency)}</span>
                </div>
              ))}
            </div>
          ))}
        </div>

        <div className="mt-4 space-y-1 border-t border-neutral-200 pt-4 text-sm">
          {totals.discountCents > 0 && (
            <div className="flex justify-between text-neutral-600">
              <span>Discount</span>
              <span>-{formatMoney(totals.discountCents, restaurant.currency)}</span>
            </div>
          )}
          {hasBreakdown && (
            <div className="flex justify-between text-neutral-600">
              <span>Subtotal</span>
              <span>{formatMoney(totals.subtotalCents, restaurant.currency)}</span>
            </div>
          )}
          {totals.taxCents > 0 && (
            <div className="flex justify-between text-neutral-600">
              <span>{totals.pricesIncludeTax ? "Tax (incl.)" : "Tax"}</span>
              <span>{formatMoney(totals.taxCents, restaurant.currency)}</span>
            </div>
          )}
          {totals.serviceChargeCents > 0 && (
            <div className="flex justify-between text-neutral-600">
              <span>Service charge</span>
              <span>{formatMoney(totals.serviceChargeCents, restaurant.currency)}</span>
            </div>
          )}
          {totals.tipCents > 0 ? (
            <>
              <div className="flex justify-between">
                <span>Total</span>
                <span>{formatMoney(totals.totalCents, restaurant.currency)}</span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span>Tip</span>
                <span>{formatMoney(totals.tipCents, restaurant.currency)}</span>
              </div>
              <div className="flex justify-between pt-1 font-medium">
                <span>Amount paid</span>
                <span>{formatMoney(totals.totalCents + totals.tipCents, restaurant.currency)}</span>
              </div>
            </>
          ) : (
            <div className="flex justify-between pt-1 font-medium">
              <span>Total</span>
              <span>{formatMoney(totals.totalCents, restaurant.currency)}</span>
            </div>
          )}
        </div>

        <p className="mt-4 text-center text-sm text-neutral-500">
          {bill.payment
            ? `Paid via ${bill.payment.method.toLowerCase()} at ${formatDateTime(bill.payment.paidAt, restaurant.timezone)}`
            : cancelled
              ? "Cancelled"
              : "Not yet paid"}
        </p>
        {restaurant.receiptFooterText && (
          <p className="mt-2 whitespace-pre-line text-center text-xs text-neutral-400">
            {restaurant.receiptFooterText}
          </p>
        )}
      </div>
    </div>
  );
}
