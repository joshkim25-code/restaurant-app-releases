import Link from "next/link";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { getReservations } from "@/lib/reservations";
import { getRestaurantTables } from "@/lib/billHistory";
import { TableFilter } from "@/components/TableFilter";
import { Pagination } from "@/components/Pagination";
import { updateReservationStatus } from "../../(dashboard)/reservations/actions";
import { formatClockTime } from "@/lib/time";
import type { ReservationStatus } from "@/generated/prisma/client";

const STATUS_OPTIONS: { value: ReservationStatus; label: string }[] = [
  { value: "PENDING", label: "Pending" },
  { value: "CONFIRMED", label: "Confirmed" },
  { value: "CANCELLED", label: "Cancelled" },
  { value: "COMPLETED", label: "Completed" },
  { value: "NO_SHOW", label: "No-show" },
];

const NEXT_STATUS: Partial<Record<ReservationStatus, { value: ReservationStatus; label: string }[]>> = {
  PENDING: [
    { value: "CONFIRMED", label: "Confirm" },
    { value: "CANCELLED", label: "Cancel" },
  ],
  CONFIRMED: [
    { value: "COMPLETED", label: "Complete" },
    { value: "NO_SHOW", label: "No-show" },
    { value: "CANCELLED", label: "Cancel" },
    { value: "PENDING", label: "Unconfirm" },
  ],
  COMPLETED: [{ value: "CONFIRMED", label: "Undo" }],
  CANCELLED: [{ value: "PENDING", label: "Uncancel" }],
};


export default async function WaiterReservationsPage({
  searchParams,
}: {
  searchParams: Promise<{ table?: string; status?: string; page?: string }>;
}) {
  const params = await searchParams;
  const restaurant = await getCurrentRestaurant();

  const status = STATUS_OPTIONS.some((s) => s.value === params.status)
    ? (params.status as ReservationStatus)
    : undefined;
  const page = Math.max(1, Number(params.page) || 1);
  const today = new Date();

  const [tables, { reservations, hasNext, hasPrev }] = await Promise.all([
    getRestaurantTables(restaurant.id),
    getReservations(restaurant.id, { date: today, tableId: params.table, status, page }),
  ]);

  function statusHref(target?: ReservationStatus) {
    const p = new URLSearchParams();
    if (params.table) p.set("table", params.table);
    if (target) p.set("status", target);
    const query = p.toString();
    return query ? `/waiter/reservations?${query}` : "/waiter/reservations";
  }

  const pillClass = (active: boolean) =>
    `rounded-full px-3 py-1 text-sm ${
      active
        ? "bg-neutral-900 text-white"
        : "border border-neutral-300 text-neutral-600 hover:bg-neutral-100"
    }`;

  return (
    <div className="space-y-6">
      <div>
        <Link href="/waiter" className="text-sm text-neutral-500 underline hover:text-neutral-900">
          ← Back to tables
        </Link>
        <h1 className="mt-2 text-lg font-semibold">Reservations — Today</h1>
      </div>

      <TableFilter
        basePath="/waiter/reservations"
        tables={tables}
        selectedTableId={params.table}
        extraParams={{ status }}
      />

      <div className="flex flex-wrap gap-2 text-sm">
        <Link href={statusHref(undefined)} className={pillClass(!status)}>
          All statuses
        </Link>
        {STATUS_OPTIONS.map((s) => (
          <Link key={s.value} href={statusHref(s.value)} className={pillClass(status === s.value)}>
            {s.label}
          </Link>
        ))}
      </div>

      <div className="rounded-lg border border-neutral-200 bg-white p-4">
        {reservations.length === 0 ? (
          <p className="text-sm text-neutral-400">No reservations for today.</p>
        ) : (
          <ul className="divide-y divide-neutral-100">
            {reservations.map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-3 py-3 text-sm">
                <div>
                  <div className="font-medium">
                    {formatClockTime(r.startTime, restaurant.timezone)} · Party of {r.partySize} ·{" "}
                    {r.tableLabel ?? "Unassigned"}
                  </div>
                  <div className="text-neutral-500">
                    {r.customerName} · {r.customerPhone}
                  </div>
                  {r.specialRequests && (
                    <div className="text-neutral-400">{r.specialRequests}</div>
                  )}
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="text-neutral-600">
                    {STATUS_OPTIONS.find((s) => s.value === r.status)?.label ?? r.status}
                  </span>
                  <div className="flex gap-2">
                    {(NEXT_STATUS[r.status] ?? []).map((transition) => (
                      <form key={transition.value} action={updateReservationStatus}>
                        <input type="hidden" name="id" value={r.id} />
                        <input type="hidden" name="status" value={transition.value} />
                        <button
                          type="submit"
                          className={
                            transition.value === "CANCELLED"
                              ? "text-red-600 underline hover:text-red-800"
                              : "text-neutral-600 underline hover:text-neutral-900"
                          }
                        >
                          {transition.label}
                        </button>
                      </form>
                    ))}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <Pagination
        basePath="/waiter/reservations"
        page={page}
        hasPrev={hasPrev}
        hasNext={hasNext}
        searchParams={{ table: params.table, status }}
      />
    </div>
  );
}
