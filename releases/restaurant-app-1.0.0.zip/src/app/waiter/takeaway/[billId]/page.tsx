import { notFound } from "next/navigation";
import Link from "next/link";
import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { lineTotalCents } from "@/lib/billing";
import { formatMoney } from "@/lib/money";
import { formatClockTime } from "@/lib/time";
import { OrderCart } from "@/components/waiter/OrderCart";
import { CloseBillForm } from "@/components/waiter/CloseBillForm";
import { ThermalPrintButton } from "@/components/ThermalPrintButton";
import { submitOrder } from "@/app/waiter/[tableId]/actions";
import { printOrderTickets, reprintOrderTickets } from "@/app/waiter/kitchen-ticket/[orderId]/actions";

export default async function TakeawayOrderPage({
  params,
}: {
  params: Promise<{ billId: string }>;
}) {
  const { billId } = await params;
  const restaurant = await getCurrentRestaurant();

  const bill = await db.bill.findFirst({
    where: { id: billId, restaurantId: restaurant.id, tableId: null },
    include: {
      orders: {
        orderBy: { submittedAt: "desc" },
        include: { items: { include: { menuItem: true, optionChoices: true } } },
      },
    },
  });
  if (!bill) {
    notFound();
  }
  if (bill.status !== "OPEN") {
    notFound();
  }

  return (
    <div className="space-y-6">
      <div>
        <Link href="/waiter/takeaway" className="text-sm text-neutral-500 underline hover:text-neutral-900">
          ← Back to takeaway orders
        </Link>
        <div className="mt-1 flex items-center gap-2">
          <h1 className="text-xl font-semibold">Takeaway order</h1>
          <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-700">
            Unpaid
          </span>
        </div>
        <p className="text-sm text-neutral-500">
          Opened {formatClockTime(bill.openedAt, restaurant.timezone)}
        </p>
      </div>

      <CartSection billId={bill.id} restaurantId={restaurant.id} currency={restaurant.currency} />

      {bill.orders.length > 0 && (
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h2 className="font-medium">Submitted rounds</h2>
          <div className="mt-2 space-y-4">
            {bill.orders.map((order) => (
              <div key={order.id} className="border-t border-neutral-100 pt-2 first:border-t-0 first:pt-0">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">
                    {formatClockTime(order.submittedAt, restaurant.timezone)}
                  </span>
                  <div className="flex items-center gap-3">
                    <span className="text-neutral-500">{order.status}</span>
                    <ThermalPrintButton
                      id={order.id}
                      printAction={reprintOrderTickets}
                      label="Reprint kitchen ticket"
                    />
                  </div>
                </div>
                {order.takeawayNote && (
                  <p className="text-sm text-neutral-500">Note: {order.takeawayNote}</p>
                )}
                <ul className="mt-1 space-y-1 text-sm text-neutral-600">
                  {order.items.map((item) => (
                    <li key={item.id}>
                      {item.quantity}× {item.menuItem.name}
                      {item.optionChoices.length > 0 &&
                        ` — ${item.optionChoices.map((c) => c.choiceNameAtOrder).join(", ")}`}
                      {item.notes && ` | Note: ${item.notes}`}
                      <span className="text-neutral-400">
                        {" "}
                        ({formatMoney(lineTotalCents(item), restaurant.currency)})
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="rounded-lg border border-neutral-200 bg-white p-4">
        <div className="flex items-center justify-between">
          <h2 className="font-medium">Close order</h2>
          <Link
            href={`/waiter/receipts/${bill.id}`}
            className="text-sm text-neutral-600 underline hover:text-neutral-900"
          >
            Print receipt
          </Link>
        </div>
        <CloseBillForm
          bill={bill}
          restaurant={restaurant}
          closeLabel="Mark as paid"
          cancelLabel="Cancel order"
        />
      </div>
    </div>
  );
}

async function CartSection({
  billId,
  restaurantId,
  currency,
}: {
  billId: string;
  restaurantId: string;
  currency: string;
}) {
  const categories = await db.menuCategory.findMany({
    where: { restaurantId },
    orderBy: { sortOrder: "asc" },
    include: {
      items: {
        where: { archivedAt: null },
        orderBy: { sortOrder: "asc" },
        include: {
          optionGroups: {
            orderBy: { sortOrder: "asc" },
            include: { choices: { orderBy: { sortOrder: "asc" } } },
          },
        },
      },
    },
  });

  return (
    <OrderCart
      billId={billId}
      categories={categories}
      submitOrder={submitOrder}
      printOrderTickets={printOrderTickets}
      mode="takeaway"
      currency={currency}
    />
  );
}
