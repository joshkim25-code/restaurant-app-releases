"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { createTakeawayBill } from "@/lib/orders";

export async function openTakeawayBill() {
  const restaurant = await getCurrentRestaurant();
  const bill = await createTakeawayBill(restaurant);

  revalidatePath("/waiter/takeaway");
  redirect(`/waiter/takeaway/${bill.id}`);
}
