import Link from "next/link";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { db } from "@/lib/db";
import { computeBillTotalCents, lineTotalCents } from "@/lib/billing";
import { formatMoney } from "@/lib/money";
import { formatClockTime } from "@/lib/time";
import { AutoRefresh } from "@/components/AutoRefresh";
import { closeBill } from "@/app/waiter/[tableId]/actions";
import { openTakeawayBill } from "./actions";

export default async function TakeawayListPage() {
  const restaurant = await getCurrentRestaurant();

  const [bills, phoneOrders] = await Promise.all([
    db.bill.findMany({
      where: { restaurantId: restaurant.id, status: "OPEN", tableId: null },
      orderBy: { openedAt: "asc" },
      include: {
        orders: { include: { items: { include: { menuItem: true, optionChoices: true } } } },
      },
    }),
    db.bill.findMany({
      where: { restaurantId: restaurant.id, status: "OPEN", tableId: null, source: "PHONE" },
      orderBy: { openedAt: "asc" },
      include: {
        customer: true,
        orders: { include: { items: { include: { menuItem: true, optionChoices: true } } } },
      },
    }),
  ]);

  return (
    <div className="space-y-6">
      <AutoRefresh />
      <div>
        <Link href="/waiter" className="text-sm text-neutral-500 underline hover:text-neutral-900">
          ← Back to tables
        </Link>
        <h1 className="mt-1 text-xl font-semibold">Takeaway orders</h1>
      </div>

      {phoneOrders.length > 0 && (
        <div className="space-y-2">
          <h2 className="text-sm font-semibold text-neutral-700">
            📞 New phone orders ({phoneOrders.length})
          </h2>
          <div className="space-y-3">
            {phoneOrders.map((bill) => {
              const total = computeBillTotalCents(bill.orders);
              return (
                <div key={bill.id} className="rounded-lg border border-amber-200 bg-amber-50 p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">
                      {bill.customerNameAtBooking ?? bill.customer?.name ?? "Phone order"}
                    </span>
                    <Link
                      href={`/waiter/takeaway/${bill.id}`}
                      className="text-sm text-neutral-600 underline hover:text-neutral-900"
                    >
                      Open
                    </Link>
                  </div>
                  <div className="text-sm text-neutral-500">
                    {bill.customer?.phone ? `${bill.customer.phone} · ` : ""}
                    Opened {formatClockTime(bill.openedAt, restaurant.timezone)}
                  </div>
                  {bill.orders
                    .filter((order) => order.status !== "CANCELLED" && order.takeawayNote)
                    .map((order) => (
                      <p key={order.id} className="mt-1 text-sm font-medium text-amber-800">
                        Note: {order.takeawayNote}
                      </p>
                    ))}
                  <ul className="mt-2 space-y-1 text-sm text-neutral-700">
                    {bill.orders
                      .filter((order) => order.status !== "CANCELLED")
                      .flatMap((order) => order.items)
                      .map((item) => (
                        <li key={item.id}>
                          {item.quantity}× {item.menuItem.name}
                          {item.optionChoices.length > 0 &&
                            ` — ${item.optionChoices.map((c) => c.choiceNameAtOrder).join(", ")}`}
                          {item.notes && ` | Note: ${item.notes}`}
                          <span className="text-neutral-400">
                            {" "}
                            ({formatMoney(lineTotalCents(item), restaurant.currency)})
                          </span>
                        </li>
                      ))}
                  </ul>
                  <div className="mt-2 text-sm font-medium">
                    Total: {formatMoney(total, restaurant.currency)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <form action={openTakeawayBill}>
        <button
          type="submit"
          className="rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700"
        >
          Start takeaway order
        </button>
      </form>

      <div className="rounded-lg border border-neutral-200 bg-white p-4">
        {bills.length === 0 ? (
          <p className="text-sm text-neutral-400">No open takeaway orders.</p>
        ) : (
          <ul className="divide-y divide-neutral-100">
            {bills.map((bill) => {
              const total = computeBillTotalCents(bill.orders);
              const itemCount = bill.orders
                .filter((o) => o.status !== "CANCELLED")
                .flatMap((o) => o.items)
                .reduce((sum, item) => sum + item.quantity, 0);
              return (
                <li key={bill.id} className="flex items-center justify-between py-3 text-sm">
                  <Link href={`/waiter/takeaway/${bill.id}`} className="flex-1 hover:underline">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">Takeaway order</span>
                      <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-700">
                        Unpaid
                      </span>
                    </div>
                    <div className="text-neutral-500">
                      Opened {formatClockTime(bill.openedAt, restaurant.timezone)}
                      {" · "}
                      {itemCount} item{itemCount === 1 ? "" : "s"} ·{" "}
                      {formatMoney(total, restaurant.currency)}
                    </div>
                  </Link>
                  <form action={closeBill} className="flex items-center gap-2">
                    <input type="hidden" name="billId" value={bill.id} />
                    <select
                      name="method"
                      defaultValue="CASH"
                      className="rounded border border-neutral-300 px-2 py-1 text-sm"
                    >
                      <option value="CASH">Cash</option>
                      <option value="CARD">Card</option>
                      <option value="OTHER">Other</option>
                    </select>
                    <button
                      type="submit"
                      disabled={total === 0}
                      className="rounded bg-neutral-900 px-3 py-1 text-sm text-white hover:bg-neutral-700 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      Mark as paid
                    </button>
                  </form>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
