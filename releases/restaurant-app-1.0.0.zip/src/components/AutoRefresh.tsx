"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";

// Re-runs the current server component on an interval so lists (new phone reservations and
// orders) update without a manual reload. Skips while the tab is hidden or the user is
// typing in a field, so it never wipes a half-filled form.
export function AutoRefresh({ seconds = 5 }: { seconds?: number }) {
  const router = useRouter();

  useEffect(() => {
    const id = setInterval(() => {
      if (document.visibilityState !== "visible") return;
      const active = document.activeElement;
      if (active && ["INPUT", "TEXTAREA", "SELECT"].includes(active.tagName)) return;
      router.refresh();
    }, seconds * 1000);
    return () => clearInterval(id);
  }, [router, seconds]);

  return null;
}
