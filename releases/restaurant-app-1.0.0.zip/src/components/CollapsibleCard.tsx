// Plain <details>/<summary> — the browser owns open/closed state natively, so it's
// immune to snapping back open/closed after a Server Action revalidates the page (there's
// no server-sourced "current open state" for a fresh render to stomp on, unlike form values).
export function CollapsibleCard({
  summary,
  defaultOpen = true,
  children,
}: {
  summary: React.ReactNode;
  defaultOpen?: boolean;
  children: React.ReactNode;
}) {
  return (
    <details open={defaultOpen} className="group rounded-lg border border-neutral-200 bg-white">
      <summary className="flex cursor-pointer list-none items-center justify-between gap-3 p-5 [&::-webkit-details-marker]:hidden">
        <div className="min-w-0 flex-1">{summary}</div>
        <svg
          viewBox="0 0 20 20"
          fill="none"
          className="h-4 w-4 shrink-0 text-neutral-400 transition-transform group-open:rotate-180"
        >
          <path
            d="M5 7.5L10 12.5L15 7.5"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </summary>
      <div className="px-5 pb-5">{children}</div>
    </details>
  );
}
