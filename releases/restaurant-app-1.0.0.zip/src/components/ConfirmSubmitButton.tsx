"use client";

// A plain submit button that asks for confirmation first. The form beneath it still
// posts to a normal server action exactly as before — this only gates whether that
// submit goes through, so a misclick can't trigger an irreversible action.
export function ConfirmSubmitButton({
  confirmMessage,
  className,
  children,
}: {
  confirmMessage: string;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="submit"
      className={className}
      onClick={(e) => {
        if (!confirm(confirmMessage)) {
          e.preventDefault();
        }
      }}
    >
      {children}
    </button>
  );
}
