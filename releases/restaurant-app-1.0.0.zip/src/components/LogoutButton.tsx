export function LogoutButton() {
  return (
    <form action="/api/auth/logout" method="post">
      <button type="submit" className="text-sm text-neutral-500 underline hover:text-neutral-900">
        Log out
      </button>
    </form>
  );
}
