"use client";

import { useEffect, useRef, useState } from "react";
import { formatMoney } from "@/lib/money";

const STORAGE_KEY = "orderNotifier:lastSeenAt";
const POLL_INTERVAL_MS = 15_000;

interface Toast {
  id: string;
  customerName: string;
  itemCount: number;
  totalCents: number;
  note: string | null;
}

interface NewPhoneOrderResponse {
  orders: {
    id: string;
    customerName: string;
    itemCount: number;
    totalCents: number;
    note: string | null;
    createdAt: string;
  }[];
}

export function OrderNotifier({
  enabled = true,
  currency,
  durationSeconds,
}: {
  enabled?: boolean;
  currency: string;
  durationSeconds: number;
}) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const lastSeenRef = useRef<string | null>(null);

  useEffect(() => {
    if (!enabled) return;

    const stored = localStorage.getItem(STORAGE_KEY);
    const initial = stored ?? new Date().toISOString();
    lastSeenRef.current = initial;
    if (!stored) localStorage.setItem(STORAGE_KEY, initial);

    let cancelled = false;

    async function poll() {
      const since = lastSeenRef.current;
      if (!since) return;

      const res = await fetch(`/api/orders/new?since=${encodeURIComponent(since)}`);
      if (!res.ok || cancelled) return;

      const data: NewPhoneOrderResponse = await res.json();
      if (data.orders.length === 0) return;

      setToasts((prev) => [
        ...prev,
        ...data.orders.map((o) => ({
          id: o.id,
          customerName: o.customerName,
          itemCount: o.itemCount,
          totalCents: o.totalCents,
          note: o.note,
        })),
      ]);

      const newest = data.orders[data.orders.length - 1].createdAt;
      lastSeenRef.current = newest;
      localStorage.setItem(STORAGE_KEY, newest);

      for (const o of data.orders) {
        setTimeout(() => {
          setToasts((prev) => prev.filter((t) => t.id !== o.id));
        }, durationSeconds * 1000);
      }
    }

    poll();
    const interval = setInterval(poll, POLL_INTERVAL_MS);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [enabled, durationSeconds]);

  function dismiss(id: string) {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }

  if (toasts.length === 0) return null;

  return (
    <div className="print:hidden fixed bottom-4 left-4 z-50 flex flex-col gap-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="w-72 rounded-lg border border-amber-200 bg-white p-3 shadow-lg"
        >
          <div className="flex items-start justify-between gap-2">
            <div className="text-sm font-medium">📞 New phone order</div>
            <button
              type="button"
              onClick={() => dismiss(t.id)}
              className="text-xs text-neutral-400 hover:text-neutral-700"
            >
              Dismiss
            </button>
          </div>
          <div className="mt-1 text-sm text-neutral-700">
            {t.customerName} · {t.itemCount} item{t.itemCount === 1 ? "" : "s"} ·{" "}
            {formatMoney(t.totalCents, currency)}
          </div>
          {t.note && <div className="text-xs font-medium text-amber-700">Note: {t.note}</div>}
        </div>
      ))}
    </div>
  );
}
