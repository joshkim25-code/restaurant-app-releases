import Link from "next/link";

export function Pagination({
  basePath,
  page,
  hasPrev,
  hasNext,
  searchParams = {},
}: {
  basePath: string;
  page: number;
  hasPrev: boolean;
  hasNext: boolean;
  searchParams?: Record<string, string | undefined>;
}) {
  function hrefForPage(targetPage: number) {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(searchParams)) {
      if (value) params.set(key, value);
    }
    params.set("page", String(targetPage));
    return `${basePath}?${params.toString()}`;
  }

  const linkClass = "rounded px-3 py-1.5 text-sm border border-neutral-300 hover:bg-neutral-100";
  const disabledClass = "rounded px-3 py-1.5 text-sm border border-neutral-200 text-neutral-300";

  return (
    <div className="flex items-center justify-between">
      {hasPrev ? (
        <Link href={hrefForPage(page - 1)} className={linkClass}>
          ← Previous
        </Link>
      ) : (
        <span className={disabledClass}>← Previous</span>
      )}
      <span className="text-sm text-neutral-500">Page {page}</span>
      {hasNext ? (
        <Link href={hrefForPage(page + 1)} className={linkClass}>
          Next →
        </Link>
      ) : (
        <span className={disabledClass}>Next →</span>
      )}
    </div>
  );
}
