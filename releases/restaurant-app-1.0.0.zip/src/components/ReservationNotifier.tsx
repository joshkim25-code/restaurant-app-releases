"use client";

import { useEffect, useRef, useState } from "react";
import { formatClockTime } from "@/lib/time";

const STORAGE_KEY = "reservationNotifier:lastSeenAt";
const POLL_INTERVAL_MS = 15_000;

interface Toast {
  id: string;
  customerName: string;
  partySize: number;
  startTime: string;
  tableLabel: string | null;
}

interface NewReservationResponse {
  reservations: {
    id: string;
    customerName: string;
    partySize: number;
    startTime: string;
    tableLabel: string | null;
    createdAt: string;
  }[];
}

export function ReservationNotifier({
  enabled = true,
  timezone,
  durationSeconds,
}: {
  enabled?: boolean;
  timezone: string;
  durationSeconds: number;
}) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const lastSeenRef = useRef<string | null>(null);

  useEffect(() => {
    if (!enabled) return;

    const stored = localStorage.getItem(STORAGE_KEY);
    const initial = stored ?? new Date().toISOString();
    lastSeenRef.current = initial;
    if (!stored) localStorage.setItem(STORAGE_KEY, initial);

    let cancelled = false;

    async function poll() {
      const since = lastSeenRef.current;
      if (!since) return;

      const res = await fetch(`/api/reservations/new?since=${encodeURIComponent(since)}`);
      if (!res.ok || cancelled) return;

      const data: NewReservationResponse = await res.json();
      if (data.reservations.length === 0) return;

      setToasts((prev) => [
        ...prev,
        ...data.reservations.map((r) => ({
          id: r.id,
          customerName: r.customerName,
          partySize: r.partySize,
          startTime: r.startTime,
          tableLabel: r.tableLabel,
        })),
      ]);

      const newest = data.reservations[data.reservations.length - 1].createdAt;
      lastSeenRef.current = newest;
      localStorage.setItem(STORAGE_KEY, newest);

      for (const r of data.reservations) {
        setTimeout(() => {
          setToasts((prev) => prev.filter((t) => t.id !== r.id));
        }, durationSeconds * 1000);
      }
    }

    poll();
    const interval = setInterval(poll, POLL_INTERVAL_MS);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [enabled, durationSeconds]);

  function dismiss(id: string) {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }

  if (toasts.length === 0) return null;

  return (
    <div className="print:hidden fixed bottom-4 right-4 z-50 flex flex-col gap-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="w-72 rounded-lg border border-neutral-200 bg-white p-3 shadow-lg"
        >
          <div className="flex items-start justify-between gap-2">
            <div className="text-sm font-medium">🔔 New reservation</div>
            <button
              type="button"
              onClick={() => dismiss(t.id)}
              className="text-xs text-neutral-400 hover:text-neutral-700"
            >
              Dismiss
            </button>
          </div>
          <div className="mt-1 text-sm text-neutral-700">
            {t.customerName} · party of {t.partySize}
          </div>
          <div className="text-xs text-neutral-500">
            Today {formatClockTime(new Date(t.startTime), timezone)}
            {t.tableLabel ? ` · Table ${t.tableLabel}` : ""}
          </div>
        </div>
      ))}
    </div>
  );
}
