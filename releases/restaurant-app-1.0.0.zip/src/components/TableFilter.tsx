import Link from "next/link";

export function TableFilter({
  basePath,
  tables,
  selectedTableId,
  extraParams = {},
}: {
  basePath: string;
  tables: { id: string; label: string }[];
  selectedTableId?: string;
  extraParams?: Record<string, string | undefined>;
}) {
  function hrefFor(tableId: string | undefined) {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(extraParams)) {
      if (value) params.set(key, value);
    }
    if (tableId) params.set("table", tableId);
    const query = params.toString();
    return query ? `${basePath}?${query}` : basePath;
  }

  const pillClass = (active: boolean) =>
    `rounded-full px-3 py-1 text-sm ${
      active
        ? "bg-neutral-900 text-white"
        : "border border-neutral-300 text-neutral-600 hover:bg-neutral-100"
    }`;

  return (
    <div className="flex flex-wrap gap-2 text-sm">
      <Link href={hrefFor(undefined)} className={pillClass(!selectedTableId)}>
        All tables
      </Link>
      {tables.map((table) => (
        <Link
          key={table.id}
          href={hrefFor(table.id)}
          className={pillClass(selectedTableId === table.id)}
        >
          {table.label}
        </Link>
      ))}
    </div>
  );
}
