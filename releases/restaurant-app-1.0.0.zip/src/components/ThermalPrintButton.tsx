"use client";

import { useEffect, useRef, useState } from "react";

type Status = "idle" | "printing" | "done" | "error";

export function ThermalPrintButton({
  id,
  printAction,
  label = "Print receipt",
  autoPrint,
}: {
  id: string;
  printAction: (id: string) => Promise<void>;
  label?: string;
  autoPrint?: boolean;
}) {
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState<string | null>(null);
  const autoPrintedRef = useRef(false);

  async function doPrint() {
    setStatus("printing");
    setError(null);
    try {
      await printAction(id);
      setStatus("done");
      setTimeout(() => setStatus("idle"), 3000);
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Failed to print.");
    }
  }

  useEffect(() => {
    if (!autoPrint || autoPrintedRef.current) return;
    autoPrintedRef.current = true;
    Promise.resolve().then(() => doPrint());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoPrint]);

  return (
    <div className="flex flex-col items-end gap-1">
      <button
        type="button"
        onClick={doPrint}
        disabled={status === "printing"}
        className="rounded border border-neutral-300 px-4 py-1.5 text-neutral-700 hover:bg-neutral-100 disabled:opacity-50"
      >
        {status === "printing" ? "Printing…" : status === "done" ? "Printed" : label}
      </button>
      {error && <p className="max-w-64 text-right text-xs text-red-600">{error}</p>}
    </div>
  );
}
