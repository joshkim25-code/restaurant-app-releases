"use client";

import { useState, type CSSProperties, type PointerEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import type { TableShape } from "@/generated/prisma/client";
import type { TableWithStatus, TableDisplayStatus } from "@/lib/tables";
import type { TableLayoutUpdate } from "@/lib/floorPlanActions";
import {
  FLOOR_PLAN_WIDTH,
  FLOOR_PLAN_HEIGHT,
  MIN_TABLE_SIZE,
  MAX_TABLE_SIZE,
} from "@/lib/floorPlanConstants";
import { formatClockTime } from "@/lib/time";

interface Props {
  role: "owner" | "waiter";
  tables: TableWithStatus[];
  timezone: string;
  updateTableLayout: (id: string, updates: TableLayoutUpdate) => Promise<void>;
  createTable?: (formData: FormData) => Promise<void>;
  deleteTable?: (formData: FormData) => Promise<void>;
}

type DragKind = "move" | "resize";

interface DragState {
  id: string;
  kind: DragKind;
  shape: TableShape;
  startClientX: number;
  startClientY: number;
  startPosX: number;
  startPosY: number;
  startWidth: number;
  startHeight: number;
  posX: number;
  posY: number;
  width: number;
  height: number;
}

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}


function statusClasses(status: TableDisplayStatus) {
  switch (status) {
    case "ACTIVE":
      return "bg-green-100 border-green-600 text-green-800";
    case "RESERVED":
      return "bg-amber-100 border-amber-500 text-amber-800";
    case "INACTIVE":
      return "bg-neutral-200 border-neutral-300 text-neutral-500";
    default:
      return "bg-white border-neutral-300 text-neutral-700";
  }
}

export function FloorPlan({
  role,
  tables,
  timezone,
  updateTableLayout,
  createTable,
  deleteTable,
}: Props) {
  const router = useRouter();
  const [editMode, setEditMode] = useState(false);
  const [drag, setDrag] = useState<DragState | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  function startDrag(kind: DragKind, table: TableWithStatus, e: PointerEvent) {
    setDrag({
      id: table.id,
      kind,
      shape: table.shape,
      startClientX: e.clientX,
      startClientY: e.clientY,
      startPosX: table.posX,
      startPosY: table.posY,
      startWidth: table.width,
      startHeight: table.height,
      posX: table.posX,
      posY: table.posY,
      width: table.width,
      height: table.height,
    });
  }

  function handleBodyPointerDown(e: PointerEvent<HTMLDivElement>, table: TableWithStatus) {
    if (!editMode) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    startDrag("move", table, e);
  }

  function handleHandlePointerDown(e: PointerEvent<HTMLDivElement>, table: TableWithStatus) {
    if (!editMode) return;
    e.stopPropagation();
    e.currentTarget.setPointerCapture(e.pointerId);
    startDrag("resize", table, e);
  }

  function handlePointerMove(e: PointerEvent) {
    setDrag((prev) => {
      if (!prev) return prev;
      const dx = e.clientX - prev.startClientX;
      const dy = e.clientY - prev.startClientY;

      if (prev.kind === "move") {
        return {
          ...prev,
          posX: clamp(prev.startPosX + dx, 0, FLOOR_PLAN_WIDTH - prev.width),
          posY: clamp(prev.startPosY + dy, 0, FLOOR_PLAN_HEIGHT - prev.height),
        };
      }

      if (prev.shape === "CIRCLE") {
        const maxSize = Math.min(
          MAX_TABLE_SIZE,
          FLOOR_PLAN_WIDTH - prev.posX,
          FLOOR_PLAN_HEIGHT - prev.posY,
        );
        const size = clamp(prev.startWidth + Math.max(dx, dy), MIN_TABLE_SIZE, maxSize);
        return { ...prev, width: size, height: size };
      }

      const maxWidth = Math.min(MAX_TABLE_SIZE, FLOOR_PLAN_WIDTH - prev.posX);
      const maxHeight = Math.min(MAX_TABLE_SIZE, FLOOR_PLAN_HEIGHT - prev.posY);
      return {
        ...prev,
        width: clamp(prev.startWidth + dx, MIN_TABLE_SIZE, maxWidth),
        height: clamp(prev.startHeight + dy, MIN_TABLE_SIZE, maxHeight),
      };
    });
  }

  async function handlePointerUp() {
    if (!drag) return;
    const { id, posX, posY, width, height } = drag;
    try {
      await updateTableLayout(id, { posX, posY, width, height });
      router.refresh();
    } finally {
      setDrag(null);
    }
  }

  function handlePointerCancel() {
    setDrag(null);
  }

  async function handleToggleShape(table: TableWithStatus) {
    const nextShape: TableShape = table.shape === "CIRCLE" ? "RECTANGLE" : "CIRCLE";
    await updateTableLayout(table.id, { shape: nextShape });
    router.refresh();
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={() => setEditMode((prev) => !prev)}
          className={`rounded px-3 py-1.5 text-sm font-medium ${
            editMode
              ? "bg-neutral-900 text-white hover:bg-neutral-700"
              : "border border-neutral-300 text-neutral-700 hover:bg-neutral-100"
          }`}
        >
          {editMode ? "Done editing" : "Edit layout"}
        </button>
        {role === "owner" && editMode && createTable && (
          <button
            type="button"
            onClick={() => setShowAddForm((prev) => !prev)}
            className="rounded border border-neutral-300 px-3 py-1.5 text-sm text-neutral-700 hover:bg-neutral-100"
          >
            {showAddForm ? "Cancel" : "Add table"}
          </button>
        )}
      </div>

      {role === "owner" && editMode && showAddForm && createTable && (
        <form
          action={async (formData) => {
            await createTable(formData);
            setShowAddForm(false);
          }}
          className="flex flex-wrap items-end gap-3 rounded-lg border border-neutral-200 bg-white p-3"
        >
          <div className="flex flex-col gap-1">
            <label className="text-xs text-neutral-500">Label</label>
            <input
              name="label"
              required
              placeholder="T8"
              className="w-24 rounded border border-neutral-300 px-2 py-1"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs text-neutral-500">Seats</label>
            <input
              name="seats"
              type="number"
              min={1}
              required
              className="w-20 rounded border border-neutral-300 px-2 py-1"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs text-neutral-500">Shape</label>
            <select
              name="shape"
              defaultValue="RECTANGLE"
              className="rounded border border-neutral-300 px-2 py-1"
            >
              <option value="RECTANGLE">Rectangle</option>
              <option value="CIRCLE">Circle</option>
            </select>
          </div>
          <button
            type="submit"
            className="rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700"
          >
            Add
          </button>
        </form>
      )}

      <div className="overflow-auto rounded-lg border border-neutral-200 bg-neutral-50">
        <div
          className="relative"
          style={{ width: FLOOR_PLAN_WIDTH, height: FLOOR_PLAN_HEIGHT }}
        >
          {tables.map((table) => {
            const t = drag && drag.id === table.id ? drag : table;
            const shapeClasses = statusClasses(table.status);
            const borderRadius = t.shape === "CIRCLE" ? "9999px" : "0.5rem";
            const isDragging = drag?.id === table.id;

            const content = (
              <div className="flex h-full w-full flex-col items-center justify-center text-center text-xs font-medium leading-tight">
                <span>{table.label}</span>
                <span className="text-[10px] font-normal opacity-75">{table.seats} seats</span>
                {table.status === "RESERVED" && table.nextReservation && (
                  <span className="text-[10px] font-normal">
                    {formatClockTime(table.nextReservation.startTime, timezone)} ·{" "}
                    {table.nextReservation.partySize}p
                  </span>
                )}
              </div>
            );

            const baseStyle: CSSProperties = {
              position: "absolute",
              left: t.posX,
              top: t.posY,
              width: t.width,
              height: t.height,
              borderRadius,
            };

            if (!editMode) {
              const canNavigate = role === "waiter" && table.status !== "INACTIVE";
              if (canNavigate) {
                return (
                  <Link
                    key={table.id}
                    href={`/waiter/${table.id}`}
                    style={baseStyle}
                    className={`border-2 ${shapeClasses} hover:opacity-80`}
                  >
                    {content}
                  </Link>
                );
              }
              return (
                <div key={table.id} style={baseStyle} className={`border-2 ${shapeClasses}`}>
                  {content}
                </div>
              );
            }

            return (
              <div
                key={table.id}
                onPointerDown={(e) => handleBodyPointerDown(e, table)}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerCancel={handlePointerCancel}
                style={{ ...baseStyle, zIndex: isDragging ? 10 : 1, cursor: "grab" }}
                className={`touch-none border-2 ${shapeClasses}`}
              >
                {content}

                <div className="absolute -right-2 -top-2 flex gap-1">
                  <button
                    type="button"
                    onPointerDown={(e) => e.stopPropagation()}
                    onClick={() => handleToggleShape(table)}
                    title="Toggle shape"
                    className="flex h-5 w-5 items-center justify-center rounded-full border border-neutral-300 bg-white text-[10px] text-neutral-600 hover:bg-neutral-100"
                  >
                    {table.shape === "CIRCLE" ? "▭" : "●"}
                  </button>
                  {role === "owner" && deleteTable && (
                    <form action={deleteTable}>
                      <input type="hidden" name="id" value={table.id} />
                      <button
                        type="submit"
                        onPointerDown={(e) => e.stopPropagation()}
                        title="Delete table"
                        className="flex h-5 w-5 items-center justify-center rounded-full border border-red-300 bg-white text-[10px] text-red-600 hover:bg-red-50"
                      >
                        ×
                      </button>
                    </form>
                  )}
                </div>

                <div
                  onPointerDown={(e) => handleHandlePointerDown(e, table)}
                  className="absolute -bottom-2 -right-2 h-6 w-6 touch-none rounded-full border border-neutral-400 bg-white"
                  style={{ cursor: "nwse-resize" }}
                />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
