"use client";

import { useState } from "react";
import { currencySymbol } from "@/lib/money";
import type {
  MenuItemOptionGroup,
  MenuItemOptionChoice,
  OptionGroupSelectionType,
} from "@/generated/prisma/client";

type GroupWithChoices = MenuItemOptionGroup & { choices: MenuItemOptionChoice[] };

type ServerAction = (formData: FormData) => void | Promise<void>;

function RequiredToggle({
  required,
  onChange,
}: {
  required: boolean;
  onChange: (value: boolean) => void;
}) {
  const pillClass = (active: boolean) =>
    `rounded-full px-3 py-1 text-xs ${
      active
        ? "bg-neutral-900 text-white"
        : "border border-neutral-300 text-neutral-600 hover:bg-neutral-100"
    }`;
  return (
    <div className="flex flex-col gap-1">
      <label className="text-xs text-neutral-500">Required?</label>
      <div className="flex gap-1">
        <button type="button" onClick={() => onChange(true)} className={pillClass(required)}>
          Required
        </button>
        <button type="button" onClick={() => onChange(false)} className={pillClass(!required)}>
          Optional
        </button>
      </div>
      <input type="checkbox" name="isRequired" checked={required} readOnly className="hidden" />
    </div>
  );
}

interface Props {
  menuItemId: string;
  itemName: string;
  itemDescription: string | null;
  currency: string;
  optionGroups: GroupWithChoices[];
  updateMenuItemDetails: ServerAction;
  createOptionGroup: ServerAction;
  updateOptionGroup: ServerAction;
  deleteOptionGroup: ServerAction;
  createOptionChoice: ServerAction;
  updateOptionChoice: ServerAction;
  deleteOptionChoice: ServerAction;
}

export function CustomizeItemModal({
  menuItemId,
  itemName,
  itemDescription,
  currency,
  optionGroups,
  updateMenuItemDetails,
  createOptionGroup,
  updateOptionGroup,
  deleteOptionGroup,
  createOptionChoice,
  updateOptionChoice,
  deleteOptionChoice,
}: Props) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectionTypeDraft, setSelectionTypeDraft] = useState<
    Record<string, OptionGroupSelectionType>
  >({});
  const [isRequiredDraft, setIsRequiredDraft] = useState<Record<string, boolean>>({});

  function typeFor(key: string, fallback: OptionGroupSelectionType) {
    return selectionTypeDraft[key] ?? fallback;
  }

  function requiredFor(key: string, fallback: boolean) {
    return isRequiredDraft[key] ?? fallback;
  }

  function setRequired(key: string, value: boolean) {
    setIsRequiredDraft((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        className="text-neutral-600 underline hover:text-neutral-900"
      >
        Customize
      </button>
      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-start justify-center bg-black/40 p-4 pt-16"
          onClick={() => setIsOpen(false)}
        >
          <div
            className="w-full max-w-lg rounded-lg bg-white p-6 shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-medium">Customize: {itemName}</h2>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="text-sm text-neutral-500 hover:text-neutral-900"
              >
                Close
              </button>
            </div>

            <div className="max-h-[70vh] space-y-4 overflow-y-auto">
              <form
                action={updateMenuItemDetails}
                className="flex flex-wrap items-end gap-2 rounded border border-neutral-200 p-3"
              >
                <input type="hidden" name="id" value={menuItemId} />
                <div className="flex flex-col gap-1">
                  <label className="text-xs text-neutral-500">Name</label>
                  <input
                    name="name"
                    defaultValue={itemName}
                    required
                    className="rounded border border-neutral-300 px-2 py-1"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs text-neutral-500">Description</label>
                  <input
                    name="description"
                    defaultValue={itemDescription ?? ""}
                    placeholder="Mixed greens, vinaigrette"
                    className="w-64 rounded border border-neutral-300 px-2 py-1"
                  />
                </div>
                <button type="submit" className="text-neutral-600 underline hover:text-neutral-900">
                  Save
                </button>
              </form>

              {optionGroups.map((group) => {
                const type = typeFor(group.id, group.selectionType);
                return (
                  <div key={group.id} className="rounded border border-neutral-200 p-3">
                    <form action={updateOptionGroup} className="flex flex-wrap items-end gap-2">
                      <input type="hidden" name="id" value={group.id} />
                      <div className="flex flex-col gap-1">
                        <label className="text-xs text-neutral-500">Name</label>
                        <input
                          name="name"
                          defaultValue={group.name}
                          required
                          className="rounded border border-neutral-300 px-2 py-1"
                        />
                      </div>
                      <div className="flex flex-col gap-1">
                        <label className="text-xs text-neutral-500">Type</label>
                        <select
                          name="selectionType"
                          defaultValue={group.selectionType}
                          onChange={(e) =>
                            setSelectionTypeDraft((prev) => ({
                              ...prev,
                              [group.id]: e.target.value as OptionGroupSelectionType,
                            }))
                          }
                          className="rounded border border-neutral-300 px-2 py-1"
                        >
                          <option value="SINGLE">Single choice</option>
                          <option value="MULTI">Multiple choice</option>
                        </select>
                      </div>
                      <RequiredToggle
                        required={requiredFor(group.id, group.isRequired)}
                        onChange={(value) => setRequired(group.id, value)}
                      />
                      {type === "MULTI" && (
                        <>
                          <div className="flex flex-col gap-1">
                            <label className="text-xs text-neutral-500">Min</label>
                            <input
                              type="number"
                              name="minSelect"
                              min={0}
                              defaultValue={group.minSelect ?? 0}
                              className="w-16 rounded border border-neutral-300 px-2 py-1"
                            />
                          </div>
                          <div className="flex flex-col gap-1">
                            <label className="text-xs text-neutral-500">Max</label>
                            <input
                              type="number"
                              name="maxSelect"
                              min={1}
                              defaultValue={group.maxSelect ?? 1}
                              className="w-16 rounded border border-neutral-300 px-2 py-1"
                            />
                          </div>
                        </>
                      )}
                      <button type="submit" className="text-neutral-600 underline hover:text-neutral-900">
                        Save
                      </button>
                    </form>
                    <form action={deleteOptionGroup} className="mt-1">
                      <input type="hidden" name="id" value={group.id} />
                      <button type="submit" className="text-xs text-red-600 underline hover:text-red-800">
                        Delete group
                      </button>
                    </form>

                    <div className="mt-3 space-y-1 border-t border-neutral-100 pt-2">
                      {group.choices.map((choice) => (
                        <form key={choice.id} action={updateOptionChoice} className="flex items-center gap-2">
                          <input type="hidden" name="id" value={choice.id} />
                          <input
                            name="name"
                            defaultValue={choice.name}
                            required
                            className="flex-1 rounded border border-neutral-300 px-2 py-0.5 text-sm"
                          />
                          <span className="text-sm text-neutral-500">{currencySymbol(currency)}</span>
                          <input
                            type="number"
                            step="0.01"
                            name="priceAdjustment"
                            defaultValue={(choice.priceAdjustmentCents / 100).toFixed(2)}
                            className="w-20 rounded border border-neutral-300 px-2 py-0.5 text-sm"
                          />
                          <button type="submit" className="text-xs text-neutral-600 underline">
                            Save
                          </button>
                          <button
                            type="submit"
                            formAction={deleteOptionChoice}
                            className="text-xs text-red-600 underline"
                          >
                            Delete
                          </button>
                        </form>
                      ))}
                      <form action={createOptionChoice} className="flex items-center gap-2 pt-1">
                        <input type="hidden" name="optionGroupId" value={group.id} />
                        <input
                          name="name"
                          placeholder="Choice name"
                          required
                          className="flex-1 rounded border border-neutral-300 px-2 py-0.5 text-sm"
                        />
                        <span className="text-sm text-neutral-500">{currencySymbol(currency)}</span>
                        <input
                          type="number"
                          step="0.01"
                          name="priceAdjustment"
                          placeholder="0.00"
                          defaultValue="0.00"
                          className="w-20 rounded border border-neutral-300 px-2 py-0.5 text-sm"
                        />
                        <button type="submit" className="text-xs text-neutral-600 underline">
                          Add choice
                        </button>
                      </form>
                    </div>
                  </div>
                );
              })}

              <form
                action={createOptionGroup}
                className="flex flex-wrap items-end gap-2 rounded border border-dashed border-neutral-300 p-3"
              >
                <input type="hidden" name="menuItemId" value={menuItemId} />
                <div className="flex flex-col gap-1">
                  <label className="text-xs text-neutral-500">New group name</label>
                  <input
                    name="name"
                    required
                    placeholder="Meal type"
                    className="rounded border border-neutral-300 px-2 py-1"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs text-neutral-500">Type</label>
                  <select
                    name="selectionType"
                    defaultValue="SINGLE"
                    onChange={(e) =>
                      setSelectionTypeDraft((prev) => ({
                        ...prev,
                        new: e.target.value as OptionGroupSelectionType,
                      }))
                    }
                    className="rounded border border-neutral-300 px-2 py-1"
                  >
                    <option value="SINGLE">Single choice</option>
                    <option value="MULTI">Multiple choice</option>
                  </select>
                </div>
                <RequiredToggle
                  required={requiredFor("new", false)}
                  onChange={(value) => setRequired("new", value)}
                />
                {typeFor("new", "SINGLE") === "MULTI" && (
                  <>
                    <div className="flex flex-col gap-1">
                      <label className="text-xs text-neutral-500">Min</label>
                      <input
                        type="number"
                        name="minSelect"
                        min={0}
                        defaultValue={0}
                        className="w-16 rounded border border-neutral-300 px-2 py-1"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="text-xs text-neutral-500">Max</label>
                      <input
                        type="number"
                        name="maxSelect"
                        min={1}
                        defaultValue={1}
                        className="w-16 rounded border border-neutral-300 px-2 py-1"
                      />
                    </div>
                  </>
                )}
                <button
                  type="submit"
                  className="rounded bg-neutral-900 px-3 py-1.5 text-sm text-white hover:bg-neutral-700"
                >
                  Add group
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
