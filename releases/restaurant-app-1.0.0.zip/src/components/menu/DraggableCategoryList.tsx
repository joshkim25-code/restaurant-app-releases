"use client";

import { CollapsibleCard } from "@/components/CollapsibleCard";
import { ConfirmSubmitButton } from "@/components/ConfirmSubmitButton";
import { useDragReorder } from "@/lib/useDragReorder";
import { DraggableItemRows } from "./DraggableItemRows";
import { currencySymbol } from "@/lib/money";
import type {
  MenuCategory,
  MenuItem,
  MenuItemOptionGroup,
  MenuItemOptionChoice,
} from "@/generated/prisma/client";

type ItemWithOptions = MenuItem & {
  optionGroups: (MenuItemOptionGroup & { choices: MenuItemOptionChoice[] })[];
};
type CategoryWithItems = MenuCategory & { items: ItemWithOptions[] };

type ServerAction = (formData: FormData) => void | Promise<void>;

export function DraggableCategoryList({
  categories,
  printers,
  currency,
  reorderCategories,
  reorderMenuItems,
  createMenuItem,
  deleteCategory,
  moveMenuItem,
  updateMenuItemPrice,
  toggleItemAvailable,
  assignMenuItemPrinter,
  updateMenuItemDetails,
  createOptionGroup,
  updateOptionGroup,
  deleteOptionGroup,
  createOptionChoice,
  updateOptionChoice,
  deleteOptionChoice,
  duplicateMenuItem,
  deleteMenuItem,
}: {
  categories: CategoryWithItems[];
  printers: { id: string; name: string }[];
  currency: string;
  reorderCategories: (orderedIds: string[]) => Promise<void>;
  reorderMenuItems: (categoryId: string, orderedIds: string[]) => Promise<void>;
  createMenuItem: ServerAction;
  deleteCategory: ServerAction;
  moveMenuItem: ServerAction;
  updateMenuItemPrice: ServerAction;
  toggleItemAvailable: ServerAction;
  assignMenuItemPrinter: ServerAction;
  updateMenuItemDetails: ServerAction;
  createOptionGroup: ServerAction;
  updateOptionGroup: ServerAction;
  deleteOptionGroup: ServerAction;
  createOptionChoice: ServerAction;
  updateOptionChoice: ServerAction;
  deleteOptionChoice: ServerAction;
  duplicateMenuItem: ServerAction;
  deleteMenuItem: ServerAction;
}) {
  const { order, draggingId, onDragStart, onDragOver, onDragEnd } = useDragReorder(categories, reorderCategories);

  if (order.length === 0) {
    return (
      <p className="text-neutral-400">No categories yet — add one below to start building the menu.</p>
    );
  }

  return (
    <>
      {order.map((category) => (
        <div
          key={category.id}
          onDragOver={onDragOver(category.id)}
          className={draggingId === category.id ? "opacity-40" : ""}
        >
          <CollapsibleCard
            defaultOpen={false}
            summary={
              <div className="flex items-center gap-2">
                <span
                  draggable
                  onDragStart={onDragStart(category.id)}
                  onDragEnd={onDragEnd}
                  onClick={(e) => e.preventDefault()}
                  className="cursor-grab select-none text-neutral-300 active:cursor-grabbing"
                  title="Drag to reorder"
                >
                  ⠿
                </span>
                <h2 className="font-medium">
                  {category.name}{" "}
                  <span className="font-normal text-neutral-400">
                    ({category.items.length} item{category.items.length === 1 ? "" : "s"})
                  </span>
                </h2>
              </div>
            }
          >
            <table className="w-full border-collapse text-sm">
              <thead className="text-left text-neutral-600">
                <tr>
                  <th className="px-4 py-2" />
                  <th className="px-4 py-2 font-medium">Name</th>
                  <th className="px-4 py-2 font-medium">Description</th>
                  <th className="px-4 py-2 font-medium">Price</th>
                  <th className="px-4 py-2 font-medium">Available</th>
                  <th className="px-4 py-2 font-medium">Prints to</th>
                  <th className="px-4 py-2" />
                </tr>
              </thead>
              <tbody>
                <DraggableItemRows
                  categoryId={category.id}
                  items={category.items}
                  printers={printers}
                  currency={currency}
                  reorderMenuItems={reorderMenuItems}
                  moveMenuItem={moveMenuItem}
                  updateMenuItemPrice={updateMenuItemPrice}
                  toggleItemAvailable={toggleItemAvailable}
                  assignMenuItemPrinter={assignMenuItemPrinter}
                  updateMenuItemDetails={updateMenuItemDetails}
                  createOptionGroup={createOptionGroup}
                  updateOptionGroup={updateOptionGroup}
                  deleteOptionGroup={deleteOptionGroup}
                  createOptionChoice={createOptionChoice}
                  updateOptionChoice={updateOptionChoice}
                  deleteOptionChoice={deleteOptionChoice}
                  duplicateMenuItem={duplicateMenuItem}
                  deleteMenuItem={deleteMenuItem}
                />
              </tbody>
            </table>

            <form
              action={createMenuItem}
              className="flex flex-wrap items-end gap-4 border-t border-neutral-200 p-4"
            >
              <input type="hidden" name="categoryId" value={category.id} />
              <div className="flex flex-col gap-1">
                <label className="text-xs text-neutral-500">Name</label>
                <input
                  name="name"
                  required
                  placeholder="House Salad"
                  className="rounded border border-neutral-300 px-2 py-1"
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-xs text-neutral-500">Description (optional)</label>
                <input
                  name="description"
                  placeholder="Mixed greens, vinaigrette"
                  className="rounded border border-neutral-300 px-2 py-1"
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-xs text-neutral-500">Price</label>
                <div className="flex items-center gap-1">
                  <span>{currencySymbol(currency)}</span>
                  <input
                    name="price"
                    type="number"
                    step="0.01"
                    min={0}
                    required
                    className="w-24 rounded border border-neutral-300 px-2 py-1"
                  />
                </div>
              </div>
              <button
                type="submit"
                className="rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700"
              >
                Add item
              </button>
            </form>

            <form action={deleteCategory} className="border-t border-neutral-200 p-4">
              <input type="hidden" name="id" value={category.id} />
              <ConfirmSubmitButton
                confirmMessage={`Delete "${category.name}"? This can't be undone.`}
                className="text-xs text-red-600 underline hover:text-red-800"
              >
                Delete category
              </ConfirmSubmitButton>
            </form>
          </CollapsibleCard>
        </div>
      ))}
    </>
  );
}
