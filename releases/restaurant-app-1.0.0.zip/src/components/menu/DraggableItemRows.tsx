"use client";

import { useDragReorder } from "@/lib/useDragReorder";
import { CustomizeItemModal } from "./CustomizeItemModal";
import { ToggleSwitch } from "./ToggleSwitch";
import { PrinterAssignmentSelect } from "./PrinterAssignmentSelect";
import { ConfirmSubmitButton } from "@/components/ConfirmSubmitButton";
import { currencySymbol } from "@/lib/money";
import type {
  MenuItem,
  MenuItemOptionGroup,
  MenuItemOptionChoice,
} from "@/generated/prisma/client";

type ItemWithOptions = MenuItem & {
  optionGroups: (MenuItemOptionGroup & { choices: MenuItemOptionChoice[] })[];
};

type ServerAction = (formData: FormData) => void | Promise<void>;

export function DraggableItemRows({
  categoryId,
  items,
  printers,
  currency,
  reorderMenuItems,
  moveMenuItem,
  updateMenuItemPrice,
  toggleItemAvailable,
  assignMenuItemPrinter,
  updateMenuItemDetails,
  createOptionGroup,
  updateOptionGroup,
  deleteOptionGroup,
  createOptionChoice,
  updateOptionChoice,
  deleteOptionChoice,
  duplicateMenuItem,
  deleteMenuItem,
}: {
  categoryId: string;
  items: ItemWithOptions[];
  printers: { id: string; name: string }[];
  currency: string;
  reorderMenuItems: (categoryId: string, orderedIds: string[]) => Promise<void>;
  moveMenuItem: ServerAction;
  updateMenuItemPrice: ServerAction;
  toggleItemAvailable: ServerAction;
  assignMenuItemPrinter: ServerAction;
  updateMenuItemDetails: ServerAction;
  createOptionGroup: ServerAction;
  updateOptionGroup: ServerAction;
  deleteOptionGroup: ServerAction;
  createOptionChoice: ServerAction;
  updateOptionChoice: ServerAction;
  deleteOptionChoice: ServerAction;
  duplicateMenuItem: ServerAction;
  deleteMenuItem: ServerAction;
}) {
  const { order, draggingId, onDragStart, onDragOver, onDragEnd } = useDragReorder(items, (orderedIds) => {
    reorderMenuItems(categoryId, orderedIds);
  });

  if (order.length === 0) {
    return (
      <tr>
        <td colSpan={7} className="px-4 py-4 text-center text-neutral-400">
          No items in this category yet.
        </td>
      </tr>
    );
  }

  return (
    <>
      {order.map((item, index) => (
        <tr
          key={item.id}
          onDragOver={onDragOver(item.id)}
          className={`border-t border-neutral-200 ${draggingId === item.id ? "opacity-40" : ""}`}
        >
          <td className="px-2 py-2">
            <div className="flex items-center gap-1">
              <span
                draggable
                onDragStart={onDragStart(item.id)}
                onDragEnd={onDragEnd}
                className="cursor-grab select-none px-1 text-neutral-300 active:cursor-grabbing"
                title="Drag to reorder"
              >
                ⠿
              </span>
              <div className="flex flex-col">
                <form action={moveMenuItem}>
                  <input type="hidden" name="id" value={item.id} />
                  <input type="hidden" name="direction" value="up" />
                  <button
                    type="submit"
                    disabled={index === 0}
                    aria-label={`Move ${item.name} up`}
                    className="px-1 text-neutral-500 hover:text-neutral-900 disabled:invisible"
                  >
                    ▲
                  </button>
                </form>
                <form action={moveMenuItem}>
                  <input type="hidden" name="id" value={item.id} />
                  <input type="hidden" name="direction" value="down" />
                  <button
                    type="submit"
                    disabled={index === order.length - 1}
                    aria-label={`Move ${item.name} down`}
                    className="px-1 text-neutral-500 hover:text-neutral-900 disabled:invisible"
                  >
                    ▼
                  </button>
                </form>
              </div>
            </div>
          </td>
          <td className="px-4 py-2">
            <div>{item.name}</div>
            <div className="text-xs text-neutral-400">
              {item.optionGroups.length === 0
                ? "No options"
                : `${item.optionGroups.length} option group${
                    item.optionGroups.length === 1 ? "" : "s"
                  }: ${item.optionGroups.map((g) => g.name).join(", ")}`}
            </div>
          </td>
          <td className="px-4 py-2 text-neutral-500">{item.description ?? "—"}</td>
          <td className="px-4 py-2">
            <form action={updateMenuItemPrice} className="flex items-center gap-1">
              <input type="hidden" name="id" value={item.id} />
              <span>{currencySymbol(currency)}</span>
              <input
                type="number"
                name="price"
                step="0.01"
                min={0}
                defaultValue={(item.priceCents / 100).toFixed(2)}
                className="w-20 rounded border border-neutral-300 px-1 py-0.5"
              />
              <button type="submit" className="text-neutral-600 underline hover:text-neutral-900">
                Save
              </button>
            </form>
          </td>
          <td className="px-4 py-2">
            <ToggleSwitch
              action={toggleItemAvailable}
              hiddenFields={{ id: item.id, isAvailable: String(item.isAvailable) }}
              checked={item.isAvailable}
              label={item.isAvailable ? "Mark unavailable" : "Mark available"}
            />
          </td>
          <td className="px-4 py-2">
            <PrinterAssignmentSelect
              action={assignMenuItemPrinter}
              itemId={item.id}
              printerId={item.printerId}
              printers={printers}
            />
          </td>
          <td className="px-4 py-2 text-right">
            <div className="flex justify-end gap-3">
              <CustomizeItemModal
                menuItemId={item.id}
                itemName={item.name}
                itemDescription={item.description}
                currency={currency}
                optionGroups={item.optionGroups}
                updateMenuItemDetails={updateMenuItemDetails}
                createOptionGroup={createOptionGroup}
                updateOptionGroup={updateOptionGroup}
                deleteOptionGroup={deleteOptionGroup}
                createOptionChoice={createOptionChoice}
                updateOptionChoice={updateOptionChoice}
                deleteOptionChoice={deleteOptionChoice}
              />
              <form action={duplicateMenuItem}>
                <input type="hidden" name="id" value={item.id} />
                <button type="submit" className="text-neutral-600 underline hover:text-neutral-900">
                  Duplicate
                </button>
              </form>
              <form action={deleteMenuItem}>
                <input type="hidden" name="id" value={item.id} />
                <ConfirmSubmitButton
                  confirmMessage={`Delete "${item.name}"? This can't be undone.`}
                  className="text-red-600 underline hover:text-red-800"
                >
                  Delete
                </ConfirmSubmitButton>
              </form>
            </div>
          </td>
        </tr>
      ))}
    </>
  );
}
