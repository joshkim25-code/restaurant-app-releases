"use client";

export function PrinterAssignmentSelect({
  action,
  itemId,
  printerId,
  printers,
}: {
  action: (formData: FormData) => void | Promise<void>;
  itemId: string;
  printerId: string | null;
  printers: { id: string; name: string }[];
}) {
  return (
    <form action={action}>
      <input type="hidden" name="id" value={itemId} />
      <select
        name="printerId"
        key={printerId ?? ""}
        defaultValue={printerId ?? ""}
        onChange={(e) => e.currentTarget.form?.requestSubmit()}
        className="rounded border border-neutral-300 px-2 py-1 text-sm"
      >
        <option value="">Not sent to a printer</option>
        {printers.map((printer) => (
          <option key={printer.id} value={printer.id}>
            {printer.name}
          </option>
        ))}
      </select>
    </form>
  );
}
