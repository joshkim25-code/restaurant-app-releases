import Link from "next/link";
import { REPORT_RANGES, type ReportRange } from "@/lib/reports";
import { DateRangePicker } from "@/components/reports/DateRangePicker";

export function RangeFilter({
  basePath,
  range,
  from,
  to,
  extraParams = {},
}: {
  basePath: string;
  range: ReportRange;
  from?: string;
  to?: string;
  extraParams?: Record<string, string | undefined>;
}) {
  function hrefFor(rangeKey: string) {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(extraParams)) {
      if (value) params.set(key, value);
    }
    params.set("range", rangeKey);
    return `${basePath}?${params.toString()}`;
  }

  return (
    <div className="flex flex-wrap gap-2 text-sm">
      {REPORT_RANGES.map((r) => (
        <Link
          key={r.key}
          href={hrefFor(r.key)}
          className={`rounded-full px-3 py-1 ${
            r.key === range
              ? "bg-neutral-900 text-white"
              : "border border-neutral-300 text-neutral-600 hover:bg-neutral-100"
          }`}
        >
          {r.label}
        </Link>
      ))}
      <DateRangePicker
        basePath={basePath}
        from={from}
        to={to}
        active={range === "custom"}
        extraParams={extraParams}
      />
    </div>
  );
}
