"use client";

import { useState } from "react";
import { PrinterFieldRow } from "./PrinterFieldRow";
import { PrinterPicker } from "./PrinterPicker";
import { NetworkPrinterField } from "./NetworkPrinterField";

interface InstalledPrinter {
  name: string;
  status: string;
}

interface DiscoveredNetworkPrinter {
  ip: string;
  hostname: string | null;
}

export function ConnectionTypeFields({
  connectionType,
  ipAddress,
  port,
  printerName,
  installedPrinters,
  listInstalledPrinters,
  discoverNetworkPrinters,
}: {
  connectionType: string;
  ipAddress: string | null;
  port: number;
  printerName: string | null;
  installedPrinters: InstalledPrinter[];
  listInstalledPrinters: () => Promise<InstalledPrinter[]>;
  discoverNetworkPrinters: () => Promise<DiscoveredNetworkPrinter[]>;
}) {
  const [type, setType] = useState(connectionType);

  return (
    <>
      <PrinterFieldRow label="Connection type">
        <select
          name="connectionType"
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="w-72 rounded border border-neutral-300 px-2 py-1.5 text-sm"
        >
          <option value="network">Network</option>
          <option value="usb">USB</option>
        </select>
      </PrinterFieldRow>
      {type === "network" ? (
        <>
          <PrinterFieldRow label="Printer IP address" description="The printer's address on your network">
            <NetworkPrinterField
              name="ipAddress"
              value={ipAddress}
              placeholder="192.168.1.50"
              discoverNetworkPrinters={discoverNetworkPrinters}
            />
          </PrinterFieldRow>
          <PrinterFieldRow label="Printer port" description="9100 is standard for most receipt printers">
            <input
              type="number"
              name="port"
              key={port}
              defaultValue={port}
              min={1}
              className="w-24 rounded border border-neutral-300 px-2 py-1.5 text-sm"
            />
          </PrinterFieldRow>
        </>
      ) : (
        <PrinterFieldRow label="Printer" description="Pick from printers installed on this PC">
          <PrinterPicker
            name="printerName"
            value={printerName}
            printers={installedPrinters}
            listInstalledPrinters={listInstalledPrinters}
          />
        </PrinterFieldRow>
      )}
    </>
  );
}
