"use client";

import { useState } from "react";

export function GenerateAgentTokenButton({
  generateAgentToken,
}: {
  generateAgentToken: () => Promise<string>;
}) {
  const [token, setToken] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);

  async function generate() {
    setGenerating(true);
    try {
      setToken(await generateAgentToken());
    } finally {
      setGenerating(false);
    }
  }

  return (
    <div className="flex flex-col gap-2">
      <button
        type="button"
        onClick={generate}
        disabled={generating}
        className="w-fit rounded border border-neutral-300 px-4 py-1.5 text-sm text-neutral-700 hover:bg-neutral-100 disabled:opacity-50"
      >
        {generating ? "Generating…" : token ? "Regenerate token" : "Generate agent token"}
      </button>
      {token && (
        <div className="rounded border border-amber-300 bg-amber-50 p-3 text-sm">
          <p className="mb-1 text-xs text-amber-800">
            Copy this into <code>AGENT_TOKEN</code> in the print agent&rsquo;s <code>.env</code> file —
            it won&rsquo;t be shown again.
          </p>
          <code className="block break-all rounded bg-white px-2 py-1 text-xs">{token}</code>
        </div>
      )}
    </div>
  );
}
