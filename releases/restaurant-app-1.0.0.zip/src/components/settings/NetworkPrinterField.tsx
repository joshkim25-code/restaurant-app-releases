"use client";

import { useRef, useState } from "react";

interface DiscoveredNetworkPrinter {
  ip: string;
  hostname: string | null;
}

export function NetworkPrinterField({
  name,
  value,
  placeholder,
  discoverNetworkPrinters,
}: {
  name: string;
  value: string | null;
  placeholder: string;
  discoverNetworkPrinters: () => Promise<DiscoveredNetworkPrinter[]>;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [scanning, setScanning] = useState(false);
  const [results, setResults] = useState<DiscoveredNetworkPrinter[] | null>(null);

  async function scan() {
    setScanning(true);
    setResults(null);
    try {
      setResults(await discoverNetworkPrinters());
    } finally {
      setScanning(false);
    }
  }

  function fillIp(ip: string) {
    if (inputRef.current) inputRef.current.value = ip;
  }

  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-center gap-2">
        <input
          ref={inputRef}
          name={name}
          defaultValue={value ?? ""}
          placeholder={placeholder}
          className="w-72 rounded border border-neutral-300 px-2 py-1.5 text-sm"
        />
        <button
          type="button"
          onClick={scan}
          disabled={scanning}
          className="text-xs text-neutral-600 underline hover:text-neutral-900 disabled:opacity-50"
        >
          {scanning ? "Scanning…" : "Scan for network printers"}
        </button>
      </div>
      {results && (
        <div className="text-xs text-neutral-500">
          {results.length === 0 ? (
            <span>No printers found on the network.</span>
          ) : (
            <span>
              Found:{" "}
              {results.map((r, i) => (
                <span key={r.ip}>
                  {i > 0 && ", "}
                  <button
                    type="button"
                    onClick={() => fillIp(r.ip)}
                    className="underline hover:text-neutral-900"
                  >
                    {r.hostname ? `${r.hostname} (${r.ip})` : r.ip}
                  </button>
                </span>
              ))}
            </span>
          )}
        </div>
      )}
    </div>
  );
}
