import { PrinterFieldRow } from "./PrinterFieldRow";
import { PrinterKindFields } from "./PrinterKindFields";
import { TestPrintButton } from "./TestPrintButton";
import { CollapsibleCard } from "@/components/CollapsibleCard";

interface InstalledPrinter {
  name: string;
  status: string;
}

interface DiscoveredNetworkPrinter {
  ip: string;
  hostname: string | null;
}

interface PrinterInfo {
  id: string;
  name: string;
  kind: string;
  connectionType: string;
  ipAddress: string | null;
  port: number;
  printerName: string | null;
  isSummaryPrinter: boolean;
  fontSize: string;
}

function connectionPreview(printer: PrinterInfo): string {
  if (printer.kind === "STANDARD") {
    return `Normal printer · ${printer.printerName ?? "not set up yet"}`;
  }
  if (printer.connectionType === "usb") {
    return `USB · ${printer.printerName ?? "not set up yet"}`;
  }
  return `Network · ${printer.ipAddress ?? "not set up yet"}`;
}

export function PrinterCard({
  printer,
  removable,
  installedPrinters,
  listInstalledPrinters,
  discoverNetworkPrinters,
  updatePrinter,
  deletePrinter,
  setSummaryPrinter,
  sendTestPrintAction,
}: {
  printer: PrinterInfo;
  removable: boolean;
  installedPrinters: InstalledPrinter[];
  listInstalledPrinters: () => Promise<InstalledPrinter[]>;
  discoverNetworkPrinters: () => Promise<DiscoveredNetworkPrinter[]>;
  updatePrinter: (formData: FormData) => Promise<void>;
  deletePrinter: (formData: FormData) => Promise<void>;
  setSummaryPrinter: (formData: FormData) => Promise<void>;
  sendTestPrintAction: (printerId: string) => Promise<{ recoveredIp?: string } | void>;
}) {
  return (
    <CollapsibleCard
      summary={
        <div className="flex items-center gap-2 text-left">
          <span className="font-medium text-neutral-900">{printer.name}</span>
          <span className="text-sm text-neutral-500">{connectionPreview(printer)}</span>
          {printer.isSummaryPrinter && (
            <span className="rounded border border-amber-300 bg-amber-50 px-1.5 py-0.5 text-xs text-amber-700">
              ★ Summary
            </span>
          )}
        </div>
      }
    >
      <form action={updatePrinter} className="divide-y divide-neutral-100">
        <input type="hidden" name="id" value={printer.id} />

        <PrinterFieldRow label="Name" description="Shown on tickets and in this list">
          <input
            name="name"
            key={printer.name}
            defaultValue={printer.name}
            className="w-72 rounded border border-neutral-300 px-2 py-1.5 text-sm"
          />
        </PrinterFieldRow>

        <PrinterKindFields
          kind={printer.kind}
          connectionType={printer.connectionType}
          ipAddress={printer.ipAddress}
          port={printer.port}
          printerName={printer.printerName}
          installedPrinters={installedPrinters}
          listInstalledPrinters={listInstalledPrinters}
          discoverNetworkPrinters={discoverNetworkPrinters}
        />

        <PrinterFieldRow
          label="Text size"
          description="Makes everything this printer prints (receipts, tickets, or the summary) bigger and easier to read."
        >
          <select
            name="fontSize"
            key={printer.fontSize}
            defaultValue={printer.fontSize}
            className="rounded border border-neutral-300 px-2 py-1.5 text-sm"
          >
            <option value="NORMAL">Normal</option>
            <option value="LARGE">Large</option>
          </select>
        </PrinterFieldRow>

        <div className="flex items-center justify-between pt-4">
          <div className="flex items-center gap-3">
            <button
              type="submit"
              className="rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700"
            >
              Save
            </button>
            {removable && (
              <button
                type="submit"
                formAction={deletePrinter}
                className="rounded border border-red-300 px-4 py-1.5 text-sm text-red-600 hover:bg-red-50"
              >
                Remove printer
              </button>
            )}
            {printer.isSummaryPrinter ? (
              <span className="rounded border border-amber-300 bg-amber-50 px-3 py-1.5 text-sm text-amber-700">
                ★ Summary printer
              </span>
            ) : (
              <button
                type="submit"
                formAction={setSummaryPrinter}
                className="rounded border border-neutral-300 px-4 py-1.5 text-sm text-neutral-700 hover:bg-neutral-100"
              >
                Use for summary
              </button>
            )}
          </div>
          <TestPrintButton sendTestPrintAction={sendTestPrintAction.bind(null, printer.id)} />
        </div>
      </form>
    </CollapsibleCard>
  );
}
