export function PrinterFieldRow({
  label,
  description,
  children,
}: {
  label: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="grid grid-cols-[1fr_20rem] items-start gap-6 py-2.5">
      <div>
        <div className="text-sm font-medium text-neutral-700">{label}</div>
        {description && <div className="mt-0.5 text-xs text-neutral-500">{description}</div>}
      </div>
      <div>{children}</div>
    </div>
  );
}
