"use client";

import { useState } from "react";
import { PrinterFieldRow } from "./PrinterFieldRow";
import { PrinterPicker } from "./PrinterPicker";
import { ConnectionTypeFields } from "./ConnectionTypeFields";

interface InstalledPrinter {
  name: string;
  status: string;
}

interface DiscoveredNetworkPrinter {
  ip: string;
  hostname: string | null;
}

export function PrinterKindFields({
  kind,
  connectionType,
  ipAddress,
  port,
  printerName,
  installedPrinters,
  listInstalledPrinters,
  discoverNetworkPrinters,
}: {
  kind: string;
  connectionType: string;
  ipAddress: string | null;
  port: number;
  printerName: string | null;
  installedPrinters: InstalledPrinter[];
  listInstalledPrinters: () => Promise<InstalledPrinter[]>;
  discoverNetworkPrinters: () => Promise<DiscoveredNetworkPrinter[]>;
}) {
  const [printerKind, setPrinterKind] = useState(kind);

  return (
    <>
      <PrinterFieldRow
        label="Printer type"
        description="Thermal printers understand receipt commands directly; normal printers print a plain text page"
      >
        <select
          name="kind"
          value={printerKind}
          onChange={(e) => setPrinterKind(e.target.value)}
          className="w-72 rounded border border-neutral-300 px-2 py-1.5 text-sm"
        >
          <option value="POS">Thermal / POS printer</option>
          <option value="STANDARD">Normal printer</option>
        </select>
      </PrinterFieldRow>
      {printerKind === "STANDARD" ? (
        <PrinterFieldRow label="Printer" description="Pick from printers installed on this PC">
          <PrinterPicker
            name="printerName"
            value={printerName}
            printers={installedPrinters}
            listInstalledPrinters={listInstalledPrinters}
          />
        </PrinterFieldRow>
      ) : (
        <ConnectionTypeFields
          connectionType={connectionType}
          ipAddress={ipAddress}
          port={port}
          printerName={printerName}
          installedPrinters={installedPrinters}
          listInstalledPrinters={listInstalledPrinters}
          discoverNetworkPrinters={discoverNetworkPrinters}
        />
      )}
    </>
  );
}
