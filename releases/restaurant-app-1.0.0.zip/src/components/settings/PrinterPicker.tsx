"use client";

import { useState } from "react";

interface InstalledPrinter {
  name: string;
  status: string;
}

export function PrinterPicker({
  name,
  value,
  printers: initialPrinters,
  listInstalledPrinters,
}: {
  name: string;
  value: string | null;
  printers: InstalledPrinter[];
  listInstalledPrinters: () => Promise<InstalledPrinter[]>;
}) {
  const [printers, setPrinters] = useState(initialPrinters);
  const [refreshing, setRefreshing] = useState(false);

  async function refresh() {
    setRefreshing(true);
    try {
      setPrinters(await listInstalledPrinters());
    } finally {
      setRefreshing(false);
    }
  }

  const options = value && !printers.some((p) => p.name === value)
    ? [{ name: value, status: "not currently detected" }, ...printers]
    : printers;

  return (
    <div className="flex items-center gap-2">
      <select
        name={name}
        defaultValue={value ?? ""}
        className="w-72 rounded border border-neutral-300 px-2 py-1.5 text-sm"
      >
        <option value="" disabled>
          {printers.length === 0 ? "No printers found" : "Select a printer…"}
        </option>
        {options.map((printer) => (
          <option key={printer.name} value={printer.name}>
            {printer.name} ({printer.status})
          </option>
        ))}
      </select>
      <button
        type="button"
        onClick={refresh}
        disabled={refreshing}
        className="text-xs text-neutral-600 underline hover:text-neutral-900 disabled:opacity-50"
      >
        {refreshing ? "Refreshing…" : "Refresh list"}
      </button>
    </div>
  );
}
