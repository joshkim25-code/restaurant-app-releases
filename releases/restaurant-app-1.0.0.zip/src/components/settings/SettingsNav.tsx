"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const items = [
  { href: "/settings/profile", label: "Restaurant Profile" },
  { href: "/settings/notifications", label: "Notifications" },
  { href: "/settings/operational", label: "Operational Settings" },
  { href: "/settings/phone", label: "Phone Reservations" },
  { href: "/settings/payments", label: "Payments & Subscription" },
  { href: "/settings/receipts", label: "Receipts" },
];

export function SettingsNav() {
  const pathname = usePathname();

  return (
    <nav className="w-64 shrink-0 space-y-1">
      {items.map((item) => {
        const active = pathname === item.href;
        return (
          <Link
            key={item.href}
            href={item.href}
            className={`block rounded px-3 py-2 text-sm ${
              active ? "bg-neutral-900 text-white" : "text-neutral-600 hover:bg-neutral-100"
            }`}
          >
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
