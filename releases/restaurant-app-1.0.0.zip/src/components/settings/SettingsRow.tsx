export function SettingsRow({
  label,
  description,
  children,
}: {
  label: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-6 border-b border-neutral-100 py-4 last:border-b-0">
      <div>
        <div className="text-sm font-medium text-neutral-900">{label}</div>
        {description && <div className="text-xs text-neutral-500">{description}</div>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}
