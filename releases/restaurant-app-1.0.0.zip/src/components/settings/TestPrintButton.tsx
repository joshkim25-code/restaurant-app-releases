"use client";

import { useState } from "react";

type Status = "idle" | "printing" | "done" | "error";

export function TestPrintButton({
  sendTestPrintAction,
  label = "Send test print",
  doneLabel = "Printed",
}: {
  sendTestPrintAction: () => Promise<{ recoveredIp?: string } | void>;
  label?: string;
  doneLabel?: string;
}) {
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState<string | null>(null);
  const [recoveredIp, setRecoveredIp] = useState<string | null>(null);

  async function handleClick() {
    setStatus("printing");
    setError(null);
    setRecoveredIp(null);
    try {
      const result = await sendTestPrintAction();
      setStatus("done");
      if (result?.recoveredIp) setRecoveredIp(result.recoveredIp);
      setTimeout(() => setStatus("idle"), 3000);
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Failed to print.");
    }
  }

  return (
    <div className="flex flex-col items-start gap-1">
      <button
        type="button"
        onClick={handleClick}
        disabled={status === "printing"}
        className="rounded border border-neutral-300 px-3 py-1 text-sm text-neutral-700 hover:bg-neutral-100 disabled:opacity-50"
      >
        {status === "printing" ? "Printing…" : status === "done" ? doneLabel : label}
      </button>
      {error && <p className="max-w-56 text-xs text-red-600">{error}</p>}
      {recoveredIp && (
        <p className="max-w-56 text-xs text-amber-600">
          This printer&apos;s IP address had changed — updated automatically to {recoveredIp}.
        </p>
      )}
    </div>
  );
}
