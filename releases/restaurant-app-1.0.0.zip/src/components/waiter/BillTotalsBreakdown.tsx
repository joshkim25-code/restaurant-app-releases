import { computeBillTotals } from "@/lib/billing";
import { formatMoney } from "@/lib/money";
import type { Order, OrderItem, OrderItemOptionChoice } from "@/generated/prisma/client";

type OrderWithItems = Order & {
  items: (OrderItem & { optionChoices: OrderItemOptionChoice[] })[];
};

export function BillTotalsBreakdown({
  orders,
  restaurant,
  isTakeawayBill,
}: {
  orders: OrderWithItems[];
  restaurant: {
    taxRatePercent: number;
    serviceChargePercent: number;
    serviceChargeOnTakeaway: boolean;
    pricesIncludeTax: boolean;
    currency: string;
  };
  isTakeawayBill: boolean;
}) {
  const totals = computeBillTotals(orders, restaurant, 0, isTakeawayBill);
  const hasBreakdown = totals.taxCents > 0 || totals.serviceChargeCents > 0;

  return (
    <div className="mt-2 space-y-1 text-sm">
      {hasBreakdown && (
        <div className="flex justify-between text-neutral-500">
          <span>Subtotal</span>
          <span>{formatMoney(totals.subtotalCents, restaurant.currency)}</span>
        </div>
      )}
      {totals.taxCents > 0 && (
        <div className="flex justify-between text-neutral-500">
          <span>{restaurant.pricesIncludeTax ? "Tax (incl.)" : "Tax"}</span>
          <span>{formatMoney(totals.taxCents, restaurant.currency)}</span>
        </div>
      )}
      {totals.serviceChargeCents > 0 && (
        <div className="flex justify-between text-neutral-500">
          <span>Service charge</span>
          <span>{formatMoney(totals.serviceChargeCents, restaurant.currency)}</span>
        </div>
      )}
      <div className="flex justify-between font-medium">
        <span>Total</span>
        <span>{formatMoney(totals.totalCents, restaurant.currency)}</span>
      </div>
    </div>
  );
}
