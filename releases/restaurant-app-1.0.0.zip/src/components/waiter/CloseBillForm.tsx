import { computeBillTotals, parseTipPercentages } from "@/lib/billing";
import { formatMoney } from "@/lib/money";
import { BillTotalsBreakdown } from "@/components/waiter/BillTotalsBreakdown";
import { closeBill, cancelBill } from "@/app/waiter/[tableId]/actions";
import type { Order, OrderItem, OrderItemOptionChoice } from "@/generated/prisma/client";

type OrderWithItems = Order & {
  items: (OrderItem & { optionChoices: OrderItemOptionChoice[] })[];
};

export function CloseBillForm({
  bill,
  tableId,
  restaurant,
  closeLabel,
  cancelLabel,
}: {
  bill: { id: string; orders: OrderWithItems[] };
  tableId?: string;
  restaurant: {
    taxRatePercent: number;
    serviceChargePercent: number;
    serviceChargeOnTakeaway: boolean;
    pricesIncludeTax: boolean;
    defaultTipPercentages: string;
    currency: string;
  };
  closeLabel: string;
  cancelLabel: string;
}) {
  // No table means a takeaway bill (the takeaway page renders this without a tableId).
  const isTakeawayBill = !tableId;
  const totals = computeBillTotals(bill.orders, restaurant, 0, isTakeawayBill);
  const tipPercentages = parseTipPercentages(restaurant.defaultTipPercentages);

  return (
    <>
      <BillTotalsBreakdown orders={bill.orders} restaurant={restaurant} isTakeawayBill={isTakeawayBill} />
      <div className="mt-3 flex flex-wrap items-end gap-3">
        <form action={closeBill} className="flex flex-wrap items-end gap-3">
          <input type="hidden" name="billId" value={bill.id} />
          {tableId && <input type="hidden" name="tableId" value={tableId} />}

          <div className="flex flex-col gap-1">
            <label className="text-xs text-neutral-500">Payment method</label>
            <select
              name="method"
              defaultValue="CASH"
              className="rounded border border-neutral-300 px-2 py-1"
            >
              <option value="CASH">Cash</option>
              <option value="CARD">Card</option>
              <option value="OTHER">Other</option>
            </select>
          </div>

          <fieldset className="flex flex-col gap-1">
            <legend className="text-xs text-neutral-500">Tip</legend>
            <div className="flex flex-wrap items-center gap-2 text-sm">
              <label className="flex items-center gap-1">
                <input type="radio" name="tipMode" value="none" defaultChecked />
                No tip
              </label>
              {tipPercentages.map((pct) => (
                <label key={pct} className="flex items-center gap-1">
                  <input type="radio" name="tipMode" value={String(pct)} />
                  {pct}% ({formatMoney(Math.round((totals.totalCents * pct) / 100), restaurant.currency)})
                </label>
              ))}
              <label className="flex items-center gap-1">
                <input type="radio" name="tipMode" value="custom" />
                Custom:
                <input
                  type="number"
                  name="tipCustomAmount"
                  min={0}
                  step={0.01}
                  className="w-20 rounded border border-neutral-300 px-2 py-1"
                />
              </label>
            </div>
          </fieldset>

          <div className="flex flex-col gap-1">
            <label className="text-xs text-neutral-500">Tip paid by</label>
            <select
              name="tipMethod"
              defaultValue="CASH"
              className="rounded border border-neutral-300 px-2 py-1"
            >
              <option value="CASH">Cash</option>
              <option value="CARD">Card</option>
              <option value="OTHER">Other</option>
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-xs text-neutral-500">Discount %</label>
            <input
              type="number"
              name="discountPercent"
              min={0}
              max={100}
              step={1}
              defaultValue={0}
              className="w-16 rounded border border-neutral-300 px-2 py-1"
            />
          </div>

          <button
            type="submit"
            className="rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700"
          >
            {closeLabel}
          </button>
        </form>
        <form action={cancelBill}>
          <input type="hidden" name="billId" value={bill.id} />
          {tableId && <input type="hidden" name="tableId" value={tableId} />}
          <button
            type="submit"
            className="rounded border border-red-300 px-4 py-1.5 text-red-600 hover:bg-red-50"
          >
            {cancelLabel}
          </button>
        </form>
      </div>
    </>
  );
}
