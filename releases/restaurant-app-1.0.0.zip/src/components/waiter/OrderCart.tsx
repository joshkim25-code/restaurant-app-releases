"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CollapsibleCard } from "@/components/CollapsibleCard";
import { formatMoney } from "@/lib/money";
import type { CartItemInput } from "@/lib/orderTypes";
import type {
  MenuItem,
  MenuItemOptionGroup,
  MenuItemOptionChoice,
} from "@/generated/prisma/client";

type GroupWithChoices = MenuItemOptionGroup & { choices: MenuItemOptionChoice[] };
type MenuItemWithOptions = MenuItem & { optionGroups: GroupWithChoices[] };
type CategoryWithItems = { id: string; name: string; items: MenuItemWithOptions[] };

interface CartLine {
  key: string;
  menuItem: MenuItemWithOptions;
  quantity: number;
  notes: string;
  selections: { group: GroupWithChoices; choices: MenuItemOptionChoice[] }[];
}

interface Props {
  billId: string;
  categories: CategoryWithItems[];
  submitOrder: (
    billId: string,
    items: CartItemInput[],
    isTakeaway?: boolean,
    takeawayNote?: string,
  ) => Promise<{ id: string }>;
  printOrderTickets: (orderId: string) => Promise<{ printer: string; error: string }[]>;
  mode: "dineIn" | "takeaway";
  currency: string;
}

function lineUnitPriceCents(line: CartLine) {
  const adjustments = line.selections
    .flatMap((s) => s.choices)
    .reduce((sum, choice) => sum + choice.priceAdjustmentCents, 0);
  return line.menuItem.priceCents + adjustments;
}

function validateSelections(
  item: MenuItemWithOptions,
  selections: Record<string, string[]>,
): string | null {
  for (const group of item.optionGroups) {
    const chosen = selections[group.id] ?? [];
    if (group.selectionType === "SINGLE") {
      if (group.isRequired && chosen.length !== 1) {
        return `Please choose an option for "${group.name}".`;
      }
    } else {
      const min = group.minSelect ?? 0;
      const max = group.maxSelect ?? group.choices.length;
      if (chosen.length < min) {
        return `Choose at least ${min} option${min === 1 ? "" : "s"} for "${group.name}".`;
      }
      if (chosen.length > max) {
        return `Choose at most ${max} option${max === 1 ? "" : "s"} for "${group.name}".`;
      }
    }
  }
  return null;
}

export function OrderCart({
  billId,
  categories,
  submitOrder,
  printOrderTickets,
  mode,
  currency,
}: Props) {
  const router = useRouter();
  const [cart, setCart] = useState<CartLine[]>([]);
  const [configuringItem, setConfiguringItem] = useState<MenuItemWithOptions | null>(null);
  const [configSelections, setConfigSelections] = useState<Record<string, string[]>>({});
  const [configNotes, setConfigNotes] = useState("");
  const [configError, setConfigError] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [printWarning, setPrintWarning] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isTakeaway, setIsTakeaway] = useState(mode === "takeaway");
  const [takeawayNote, setTakeawayNote] = useState("");

  function openConfig(item: MenuItemWithOptions) {
    setConfiguringItem(item);
    setConfigSelections({});
    setConfigNotes("");
    setConfigError(null);
  }

  function closeConfig() {
    setConfiguringItem(null);
  }

  function quickAdd(item: MenuItemWithOptions) {
    setCart((prev) => [
      ...prev,
      { key: crypto.randomUUID(), menuItem: item, quantity: 1, notes: "", selections: [] },
    ]);
  }

  function toggleChoice(group: GroupWithChoices, choiceId: string) {
    setConfigError(null);
    setConfigSelections((prev) => {
      const current = prev[group.id] ?? [];
      if (group.selectionType === "SINGLE") {
        return { ...prev, [group.id]: [choiceId] };
      }
      if (current.includes(choiceId)) {
        return { ...prev, [group.id]: current.filter((id) => id !== choiceId) };
      }
      const max = group.maxSelect ?? group.choices.length;
      if (current.length >= max) {
        return prev;
      }
      return { ...prev, [group.id]: [...current, choiceId] };
    });
  }

  function handleAddToCart() {
    if (!configuringItem) return;

    const error = validateSelections(configuringItem, configSelections);
    if (error) {
      setConfigError(error);
      return;
    }

    const selections = configuringItem.optionGroups
      .map((group) => ({
        group,
        choices: (configSelections[group.id] ?? [])
          .map((id) => group.choices.find((c) => c.id === id))
          .filter((c): c is MenuItemOptionChoice => Boolean(c)),
      }))
      .filter((s) => s.choices.length > 0);

    setCart((prev) => [
      ...prev,
      {
        key: crypto.randomUUID(),
        menuItem: configuringItem,
        quantity: 1,
        notes: configNotes.trim(),
        selections,
      },
    ]);
    setConfiguringItem(null);
  }

  function updateQuantity(key: string, delta: number) {
    setCart((prev) =>
      prev
        .map((line) => (line.key === key ? { ...line, quantity: line.quantity + delta } : line))
        .filter((line) => line.quantity > 0),
    );
  }

  function removeLine(key: string) {
    setCart((prev) => prev.filter((line) => line.key !== key));
  }

  const cartTotalCents = cart.reduce(
    (sum, line) => sum + lineUnitPriceCents(line) * line.quantity,
    0,
  );

  async function handleSubmit() {
    if (cart.length === 0) return;
    setIsSubmitting(true);
    setSubmitError(null);
    setPrintWarning(null);
    try {
      const items: CartItemInput[] = cart.map((line) => ({
        menuItemId: line.menuItem.id,
        quantity: line.quantity,
        notes: line.notes,
        selections: line.selections.map((s) => ({
          groupId: s.group.id,
          choiceIds: s.choices.map((c) => c.id),
        })),
      }));
      const order = await submitOrder(billId, items, isTakeaway, takeawayNote);
      try {
        const failures = await printOrderTickets(order.id);
        if (failures.length > 0) {
          const summary = failures.map((f) => `${f.printer} didn't print: ${f.error}`).join("; ");
          setPrintWarning(`Order sent to kitchen, but ${summary}`);
        }
      } catch (printErr) {
        setPrintWarning(
          `Order sent to kitchen, but tickets didn't print: ${
            printErr instanceof Error ? printErr.message : "unknown error."
          }`,
        );
      }
      setCart([]);
      setTakeawayNote("");
      if (mode === "dineIn") setIsTakeaway(false);
      router.refresh();
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : "Failed to submit order.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <div className="text-sm font-medium">Menu</div>
        {categories.map((category) => (
          <CollapsibleCard
            key={category.id}
            defaultOpen={false}
            summary={`${category.name} (${category.items.length})`}
          >
            <div className="divide-y divide-neutral-100">
              {category.items.map((item) => (
                <div
                  key={item.id}
                  className={`flex items-center justify-between py-2 text-sm first:pt-0 last:pb-0 ${
                    item.isAvailable ? "" : "opacity-50"
                  }`}
                >
                  <div>
                    <div>{item.name}</div>
                    <div className="text-neutral-400">{formatMoney(item.priceCents, currency)}</div>
                  </div>
                  {item.isAvailable ? (
                    <button
                      type="button"
                      onClick={() =>
                        item.optionGroups.length > 0 ? openConfig(item) : quickAdd(item)
                      }
                      className="rounded bg-neutral-900 px-3 py-1 text-xs text-white hover:bg-neutral-700"
                    >
                      Add
                    </button>
                  ) : (
                    <span className="text-xs text-neutral-400">Unavailable</span>
                  )}
                </div>
              ))}
              {category.items.length === 0 && (
                <div className="py-2 text-sm text-neutral-400">No items in this category.</div>
              )}
            </div>
          </CollapsibleCard>
        ))}
      </div>

      {configuringItem && (
        <div
          className="fixed inset-0 z-50 flex items-start justify-center bg-black/40 p-4 pt-16"
          onClick={closeConfig}
        >
          <div
            className="w-full max-w-md rounded-lg bg-white p-6 shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-medium">{configuringItem.name}</h2>
              <button
                type="button"
                onClick={closeConfig}
                className="text-sm text-neutral-500 hover:text-neutral-900"
              >
                Close
              </button>
            </div>

            <div className="max-h-[60vh] space-y-4 overflow-y-auto">
              {configuringItem.optionGroups.map((group) => (
                <div key={group.id}>
                  <div className="text-sm font-medium">
                    {group.name}
                    {group.isRequired && <span className="text-red-600"> *</span>}
                    {group.selectionType === "MULTI" && (
                      <span className="ml-1 text-xs font-normal text-neutral-400">
                        (choose {group.minSelect ?? 0}–{group.maxSelect ?? group.choices.length})
                      </span>
                    )}
                  </div>
                  <div className="mt-1 space-y-1">
                    {group.choices.map((choice) => {
                      const selected = (configSelections[group.id] ?? []).includes(choice.id);
                      return (
                        <label key={choice.id} className="flex items-center gap-2 text-sm">
                          <input
                            type={group.selectionType === "SINGLE" ? "radio" : "checkbox"}
                            name={`group-${group.id}`}
                            checked={selected}
                            onChange={() => toggleChoice(group, choice.id)}
                          />
                          {choice.name}
                          {choice.priceAdjustmentCents !== 0 && (
                            <span className="text-neutral-400">
                              ({choice.priceAdjustmentCents > 0 ? "+" : "−"}
                              {formatMoney(Math.abs(choice.priceAdjustmentCents), currency)})
                            </span>
                          )}
                        </label>
                      );
                    })}
                  </div>
                </div>
              ))}

              <div>
                <label className="text-sm font-medium">Notes (optional)</label>
                <textarea
                  value={configNotes}
                  onChange={(e) => setConfigNotes(e.target.value)}
                  placeholder="e.g. no onions, extra spicy"
                  rows={2}
                  className="mt-1 w-full rounded border border-neutral-300 px-2 py-1 text-sm"
                />
              </div>

              {configError && <p className="text-sm text-red-600">{configError}</p>}

              <button
                type="button"
                onClick={handleAddToCart}
                className="w-full rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700"
              >
                Add to order
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="rounded-lg border border-neutral-200 bg-white p-4">
        <h2 className="font-medium">Current round</h2>
        {cart.length === 0 ? (
          <p className="mt-2 text-sm text-neutral-400">No items added yet.</p>
        ) : (
          <div className="mt-2 space-y-3">
            {cart.map((line) => (
              <div
                key={line.key}
                className="flex items-start justify-between border-b border-neutral-100 pb-2 text-sm"
              >
                <div>
                  <div className="font-medium">{line.menuItem.name}</div>
                  {line.selections.length > 0 && (
                    <div className="text-neutral-500">
                      {line.selections
                        .flatMap((s) => s.choices.map((c) => c.name))
                        .join(", ")}
                    </div>
                  )}
                  {line.notes && <div className="text-neutral-400">Note: {line.notes}</div>}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => updateQuantity(line.key, -1)}
                    className="rounded border border-neutral-300 px-2"
                  >
                    −
                  </button>
                  <span>{line.quantity}</span>
                  <button
                    type="button"
                    onClick={() => updateQuantity(line.key, 1)}
                    className="rounded border border-neutral-300 px-2"
                  >
                    +
                  </button>
                  <span className="w-16 text-right">
                    {formatMoney(lineUnitPriceCents(line) * line.quantity, currency)}
                  </span>
                  <button
                    type="button"
                    onClick={() => removeLine(line.key)}
                    className="text-xs text-red-600 underline"
                  >
                    Remove
                  </button>
                </div>
              </div>
            ))}
            <div className="flex justify-between pt-1 font-medium">
              <span>Total</span>
              <span>{formatMoney(cartTotalCents, currency)}</span>
            </div>
          </div>
        )}

        {mode === "dineIn" && (
          <label className="mt-4 flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={isTakeaway}
              onChange={(e) => setIsTakeaway(e.target.checked)}
            />
            Mark this round as takeaway
          </label>
        )}
        {isTakeaway && (
          <input
            type="text"
            value={takeawayNote}
            onChange={(e) => setTakeawayNote(e.target.value)}
            placeholder="Note (optional, e.g. who it's for)"
            className="mt-2 w-full rounded border border-neutral-300 px-2 py-1 text-sm"
          />
        )}

        {submitError && <p className="mt-2 text-sm text-red-600">{submitError}</p>}
        {printWarning && <p className="mt-2 text-sm text-amber-600">{printWarning}</p>}

        <button
          type="button"
          onClick={handleSubmit}
          disabled={cart.length === 0 || isSubmitting}
          className="mt-4 rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700 disabled:opacity-50"
        >
          {isSubmitting ? "Submitting…" : "Submit order to kitchen"}
        </button>
      </div>
    </div>
  );
}
