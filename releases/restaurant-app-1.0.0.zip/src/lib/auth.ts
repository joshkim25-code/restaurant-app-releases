import crypto from "node:crypto";
import { db } from "@/lib/db";

const TOKEN_TTL_MS = 15 * 60 * 1000;

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export async function createLoginToken(email: string): Promise<string> {
  const token = crypto.randomBytes(32).toString("hex");
  await db.loginToken.create({
    data: {
      email: email.toLowerCase().trim(),
      tokenHash: hashToken(token),
      expiresAt: new Date(Date.now() + TOKEN_TTL_MS),
    },
  });
  return token;
}

export async function consumeLoginToken(rawToken: string): Promise<string | null> {
  const record = await db.loginToken.findUnique({ where: { tokenHash: hashToken(rawToken) } });
  if (!record || record.usedAt || record.expiresAt < new Date()) {
    return null;
  }
  await db.loginToken.update({ where: { id: record.id }, data: { usedAt: new Date() } });
  return record.email;
}

export async function findOrCreateUser(email: string) {
  return db.user.upsert({ where: { email }, update: {}, create: { email } });
}
