import { db } from "@/lib/db";
import type { PaymentMethod } from "@/generated/prisma/client";
import { reportWindow, type ReportRange } from "@/lib/reports";

export interface BillHistoryEntry {
  id: string;
  tableLabel: string;
  closedAt: Date;
  status: "PAID" | "CANCELLED";
  totalCents: number;
  method: PaymentMethod | null;
}

export async function getRestaurantTables(restaurantId: string) {
  return db.table.findMany({
    where: { restaurantId },
    orderBy: { label: "asc" },
    select: { id: true, label: true },
  });
}

export async function getBillHistory(
  restaurantId: string,
  options: {
    range?: ReportRange;
    custom?: { from: Date; to: Date };
    tableId?: string;
    page?: number;
    pageSize?: number;
  } = {},
): Promise<{
  bills: BillHistoryEntry[];
  page: number;
  pageSize: number;
  hasNext: boolean;
  hasPrev: boolean;
}> {
  const page = Math.max(1, options.page ?? 1);
  const pageSize = options.pageSize ?? 25;

  const { since, until } = options.range
    ? reportWindow(options.range, options.custom)
    : { since: null, until: null };
  const closedAtFilter =
    since || until
      ? { closedAt: { ...(since ? { gte: since } : {}), ...(until ? { lt: until } : {}) } }
      : {};

  const rows = await db.bill.findMany({
    where: {
      restaurantId,
      status: "CLOSED",
      ...(options.tableId ? { tableId: options.tableId } : {}),
      ...closedAtFilter,
    },
    orderBy: { closedAt: "desc" },
    skip: (page - 1) * pageSize,
    take: pageSize + 1,
    include: {
      table: true,
      payment: true,
    },
  });

  const hasNext = rows.length > pageSize;
  const bills: BillHistoryEntry[] = rows.slice(0, pageSize).map((bill) => ({
    id: bill.id,
    tableLabel: bill.table?.label ?? "Takeaway",
    closedAt: bill.closedAt ?? bill.openedAt,
    status: bill.payment ? "PAID" : "CANCELLED",
    totalCents: bill.payment
      ? bill.payment.amountCents + bill.payment.tipCents
      : (bill.cancelledValueCents ?? 0),
    method: bill.payment?.method ?? null,
  }));

  return { bills, page, pageSize, hasNext, hasPrev: page > 1 };
}
