import type { Order, OrderItem, OrderItemOptionChoice } from "@/generated/prisma/client";

type OrderWithItems = Order & {
  items: (OrderItem & { optionChoices: OrderItemOptionChoice[] })[];
};

export function lineTotalCents(item: OrderItem & { optionChoices: OrderItemOptionChoice[] }) {
  const adjustments = item.optionChoices.reduce(
    (sum, choice) => sum + choice.priceAdjustmentCentsAtOrder,
    0,
  );
  return item.quantity * (item.unitPriceCentsAtOrder + adjustments);
}

export function computeBillTotalCents(orders: OrderWithItems[]) {
  return orders
    .filter((order) => order.status !== "CANCELLED")
    .flatMap((order) => order.items)
    .reduce((sum, item) => sum + lineTotalCents(item), 0);
}

interface TotalsRestaurant {
  taxRatePercent: number;
  serviceChargePercent: number;
  serviceChargeOnTakeaway: boolean;
  pricesIncludeTax: boolean;
}

// isTakeawayBill: the bill has no table (a takeaway/phone bill), so all of its orders count
// as takeaway. On a table bill, only orders individually flagged isTakeaway do.
export function computeBillTotals(
  orders: OrderWithItems[],
  restaurant: TotalsRestaurant,
  discountPercent = 0,
  isTakeawayBill = false,
) {
  // The raw sum of item prices, before any discount is applied.
  const rawGrossFoodCents = computeBillTotalCents(orders);
  const discountCents = Math.round((rawGrossFoodCents * discountPercent) / 100);

  // What the customer pays for food after discount, before service charge. Used as the
  // base for both tax and service charge regardless of pricing mode, so the customer's
  // food total never changes based on the pricing-mode setting — only how it's broken down.
  const grossFoodCents = rawGrossFoodCents - discountCents;

  let subtotalCents: number;
  let taxCents: number;
  if (restaurant.pricesIncludeTax) {
    // Menu prices already include tax — extract it out rather than adding it on top.
    // subtotal + tax always equals grossFoodCents exactly (tax is the exact complement,
    // not independently rounded), so nothing here changes what the customer pays.
    subtotalCents = Math.round(grossFoodCents / (1 + restaurant.taxRatePercent / 100));
    taxCents = grossFoodCents - subtotalCents;
  } else {
    subtotalCents = grossFoodCents;
    taxCents = Math.round((grossFoodCents * restaurant.taxRatePercent) / 100);
  }

  // Takeaway food can be exempt from the service charge (tax is unaffected). The discount
  // applies to the chargeable base the same way it does to the whole bill.
  const rawChargeableCents = restaurant.serviceChargeOnTakeaway
    ? rawGrossFoodCents
    : isTakeawayBill
      ? 0
      : computeBillTotalCents(orders.filter((order) => !order.isTakeaway));
  const chargeableCents = rawChargeableCents - Math.round((rawChargeableCents * discountPercent) / 100);
  const serviceChargeCents = Math.round((chargeableCents * restaurant.serviceChargePercent) / 100);
  return {
    subtotalCents,
    taxCents,
    serviceChargeCents,
    discountCents,
    totalCents: subtotalCents + taxCents + serviceChargeCents,
    pricesIncludeTax: restaurant.pricesIncludeTax,
  };
}

// Parses the comma-separated "Default tip options" setting (e.g. "15,18,20") into percentages.
export function parseTipPercentages(value: string): number[] {
  return value
    .split(",")
    .map((s) => Number(s.trim()))
    .filter((n) => Number.isFinite(n) && n > 0);
}

interface PaymentTotals {
  subtotalCents: number;
  taxCents: number;
  serviceChargeCents: number;
  amountCents: number;
  discountCents: number;
  tipCents: number;
  pricesIncludeTax: boolean;
  method: string;
  tipMethod: string | null;
}

export function resolveBillTotals(
  bill: {
    status: string;
    tableId: string | null;
    payment: PaymentTotals | null;
    orders: OrderWithItems[];
    cancelledValueCents: number | null;
  },
  restaurant: TotalsRestaurant,
) {
  if (bill.payment) {
    return {
      subtotalCents: bill.payment.subtotalCents,
      taxCents: bill.payment.taxCents,
      serviceChargeCents: bill.payment.serviceChargeCents,
      discountCents: bill.payment.discountCents,
      tipCents: bill.payment.tipCents,
      totalCents: bill.payment.amountCents,
      // Frozen alongside the numbers — a later change to the live setting shouldn't
      // relabel an already-paid bill's receipt while its amounts stay from the old mode.
      pricesIncludeTax: bill.payment.pricesIncludeTax,
      method: bill.payment.method,
      // Older payments never recorded a separate tip method - treat those as "same as
      // the order" rather than showing nothing.
      tipMethod: bill.payment.tipMethod ?? bill.payment.method,
    };
  }

  const cancelled = bill.status === "CLOSED";
  if (cancelled) {
    // Read the value frozen by cancelBill (computed before its orders were marked
    // CANCELLED) rather than recomputing live — computeBillTotalCents filters out
    // CANCELLED orders, so a live recompute here would always yield 0.
    const subtotalCents = bill.cancelledValueCents ?? 0;
    return {
      subtotalCents,
      taxCents: 0,
      serviceChargeCents: 0,
      discountCents: 0,
      tipCents: 0,
      totalCents: subtotalCents,
      pricesIncludeTax: restaurant.pricesIncludeTax,
      method: null,
      tipMethod: null,
    };
  }

  // Open bill: live preview. Tip/discount aren't decided until close-bill time, and there's
  // no payment method yet either.
  return {
    ...computeBillTotals(bill.orders, restaurant, 0, bill.tableId === null),
    tipCents: 0,
    method: null,
    tipMethod: null,
  };
}
