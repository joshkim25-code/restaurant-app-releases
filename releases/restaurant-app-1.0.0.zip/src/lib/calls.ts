import { db } from "@/lib/db";
import type { CallStatus } from "@/generated/prisma/client";

export interface CallListEntry {
  id: string;
  fromPhoneNumber: string;
  status: CallStatus;
  startedAt: Date;
  endedAt: Date | null;
  reservation: { id: string; partySize: number; startTime: Date } | null;
}

export async function getCallHistory(
  restaurantId: string,
  options: { page?: number; pageSize?: number } = {},
): Promise<{ calls: CallListEntry[]; page: number; hasNext: boolean; hasPrev: boolean }> {
  const page = Math.max(1, options.page ?? 1);
  const pageSize = options.pageSize ?? 25;

  const rows = await db.call.findMany({
    where: { restaurantId },
    orderBy: { startedAt: "desc" },
    skip: (page - 1) * pageSize,
    take: pageSize + 1,
    include: {
      reservation: { select: { id: true, partySize: true, startTime: true } },
    },
  });

  const hasNext = rows.length > pageSize;
  const calls: CallListEntry[] = rows.slice(0, pageSize).map((call) => ({
    id: call.id,
    fromPhoneNumber: call.fromPhoneNumber,
    status: call.status,
    startedAt: call.startedAt,
    endedAt: call.endedAt,
    reservation: call.reservation,
  }));

  return { calls, page, hasNext, hasPrev: page > 1 };
}

export async function getCallDetail(restaurantId: string, callId: string) {
  return db.call.findUnique({
    where: { id: callId, restaurantId },
    include: {
      messages: { orderBy: { createdAt: "asc" } },
      reservation: { select: { id: true, partySize: true, startTime: true, status: true } },
    },
  });
}
