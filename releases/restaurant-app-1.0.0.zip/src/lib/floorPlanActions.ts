"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import type { TableShape } from "@/generated/prisma/client";
import {
  FLOOR_PLAN_WIDTH,
  FLOOR_PLAN_HEIGHT,
  MIN_TABLE_SIZE,
  MAX_TABLE_SIZE,
} from "@/lib/floorPlanConstants";

export interface TableLayoutUpdate {
  posX?: number;
  posY?: number;
  width?: number;
  height?: number;
  shape?: TableShape;
}

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

export async function updateTableLayout(id: string, updates: TableLayoutUpdate) {
  const table = await db.table.findUnique({ where: { id } });
  if (!table) {
    throw new Error("Table not found.");
  }

  const shape = updates.shape ?? table.shape;
  let width = updates.width ?? table.width;
  let height = updates.height ?? table.height;
  if (shape === "CIRCLE") {
    const size = updates.width ?? updates.height ?? Math.max(width, height);
    width = size;
    height = size;
  }
  width = clamp(Math.round(width), MIN_TABLE_SIZE, MAX_TABLE_SIZE);
  height = clamp(Math.round(height), MIN_TABLE_SIZE, MAX_TABLE_SIZE);

  const posX = clamp(Math.round(updates.posX ?? table.posX), 0, FLOOR_PLAN_WIDTH - width);
  const posY = clamp(Math.round(updates.posY ?? table.posY), 0, FLOOR_PLAN_HEIGHT - height);

  await db.table.update({
    where: { id },
    data: { posX, posY, width, height, shape },
  });

  revalidatePath("/dashboard");
  revalidatePath("/waiter");
}
