import { Resend } from "resend";

const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;

export async function sendLoginEmail(email: string, token: string): Promise<void> {
  const url = `${process.env.PUBLIC_BASE_URL}/api/auth/verify?token=${encodeURIComponent(token)}`;

  if (!resend) {
    console.log(`[dev] Login link for ${email}: ${url}`);
    return;
  }

  const { error } = await resend.emails.send({
    from: "onboarding@resend.dev",
    to: email,
    subject: "Your login link",
    html: `<p><a href="${url}">Click to log in</a>. Expires in 15 minutes.</p>`,
  });

  // resend.emails.send() never throws for API errors — it returns { error } instead —
  // so this check is required, not optional, or a failed send looks identical to success.
  if (error) {
    throw new Error(`Could not send login email: ${error.message}`);
  }
}
