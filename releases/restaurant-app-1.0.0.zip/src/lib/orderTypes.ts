export interface CartSelectionInput {
  groupId: string;
  choiceIds: string[];
}

export interface CartItemInput {
  menuItemId: string;
  quantity: number;
  notes: string;
  selections: CartSelectionInput[];
}
