import { db } from "@/lib/db";
import { computeBillTotals, computeBillTotalCents } from "@/lib/billing";
import type {
  Restaurant,
  MenuItem,
  MenuItemOptionGroup,
  MenuItemOptionChoice,
} from "@/generated/prisma/client";
import type { CartItemInput } from "@/lib/orderTypes";

type MenuItemWithOptions = MenuItem & {
  optionGroups: (MenuItemOptionGroup & { choices: MenuItemOptionChoice[] })[];
};

interface ValidatedOrderItem {
  menuItemId: string;
  quantity: number;
  unitPriceCentsAtOrder: number;
  notes: string | null;
  optionChoices: {
    optionChoiceId: string;
    optionGroupNameAtOrder: string;
    choiceNameAtOrder: string;
    priceAdjustmentCentsAtOrder: number;
  }[];
  lineTotalCents: number;
}

// Validates one cart item's option selections against its menu item's option groups
// (SINGLE/MULTI cardinality, required groups, availability) and prices it. Shared by
// submitOrderCore (validating a whole cart at once, from fresh DB data) and the phone
// assistant's add_item_to_order tool (validating one item live, before it's committed),
// so the two never drift out of sync on what counts as a valid order.
export function validateAndPriceItem(
  menuItem: MenuItemWithOptions,
  item: Pick<CartItemInput, "quantity" | "notes" | "selections">,
): ValidatedOrderItem {
  if (!menuItem.isAvailable) {
    throw new Error(`"${menuItem.name}" is no longer available.`);
  }
  if (!Number.isInteger(item.quantity) || item.quantity < 1) {
    throw new Error(`Invalid quantity for ${menuItem.name}.`);
  }

  const selectionsByGroup = new Map(
    item.selections.map((selection) => [selection.groupId, selection.choiceIds]),
  );
  const optionChoicesData: ValidatedOrderItem["optionChoices"] = [];

  for (const group of menuItem.optionGroups) {
    const chosenIds = selectionsByGroup.get(group.id) ?? [];

    if (group.selectionType === "SINGLE") {
      if (chosenIds.length > 1) {
        throw new Error(`Only one choice is allowed for "${group.name}".`);
      }
      if (group.isRequired && chosenIds.length !== 1) {
        throw new Error(`"${group.name}" is required for ${menuItem.name}.`);
      }
    } else {
      const min = group.minSelect ?? 0;
      const max = group.maxSelect ?? group.choices.length;
      if (chosenIds.length < min || chosenIds.length > max) {
        throw new Error(`Choose between ${min} and ${max} option(s) for "${group.name}".`);
      }
    }

    for (const choiceId of chosenIds) {
      const choice = group.choices.find((c) => c.id === choiceId);
      if (!choice) {
        throw new Error(`Invalid choice selected for "${group.name}".`);
      }
      optionChoicesData.push({
        optionChoiceId: choice.id,
        optionGroupNameAtOrder: group.name,
        choiceNameAtOrder: choice.name,
        priceAdjustmentCentsAtOrder: choice.priceAdjustmentCents,
      });
    }
  }

  const adjustmentCents = optionChoicesData.reduce((sum, c) => sum + c.priceAdjustmentCentsAtOrder, 0);

  return {
    menuItemId: menuItem.id,
    quantity: item.quantity,
    unitPriceCentsAtOrder: menuItem.priceCents,
    notes: item.notes.trim() || null,
    optionChoices: optionChoicesData,
    lineTotalCents: item.quantity * (menuItem.priceCents + adjustmentCents),
  };
}

export async function submitOrderCore(
  restaurant: Restaurant,
  billId: string,
  items: CartItemInput[],
  isTakeaway = false,
  takeawayNote?: string,
): Promise<{ id: string; tableId: string | null }> {
  if (items.length === 0) {
    throw new Error("Cannot submit an empty order.");
  }

  const bill = await db.bill.findUnique({ where: { id: billId, restaurantId: restaurant.id } });
  if (!bill || bill.status !== "OPEN") {
    throw new Error("This bill is not open.");
  }

  const menuItems = await db.menuItem.findMany({
    where: { id: { in: items.map((item) => item.menuItemId) }, restaurantId: restaurant.id },
    include: { optionGroups: { include: { choices: true } } },
  });
  const menuItemsById = new Map(menuItems.map((item) => [item.id, item]));

  const orderItemsData = items.map((item) => {
    const menuItem = menuItemsById.get(item.menuItemId);
    if (!menuItem) {
      throw new Error("A menu item in this order no longer exists.");
    }
    const validated = validateAndPriceItem(menuItem, item);
    return {
      menuItemId: validated.menuItemId,
      quantity: validated.quantity,
      unitPriceCentsAtOrder: validated.unitPriceCentsAtOrder,
      notes: validated.notes,
      optionChoices: { create: validated.optionChoices },
    };
  });

  const order = await db.order.create({
    data: {
      billId,
      isTakeaway,
      takeawayNote: takeawayNote?.trim() || null,
      items: { create: orderItemsData },
    },
  });

  return { id: order.id, tableId: bill.tableId };
}

export async function createTakeawayBill(
  restaurant: Restaurant,
  opts?: { callId?: string; customerId?: string; customerNameAtBooking?: string },
): Promise<{ id: string }> {
  const bill = await db.bill.create({
    data: {
      restaurantId: restaurant.id,
      tableId: null,
      status: "OPEN",
      source: opts?.callId ? "PHONE" : "WAITER",
      createdByCallId: opts?.callId,
      customerId: opts?.customerId,
      customerNameAtBooking: opts?.customerNameAtBooking,
    },
  });
  return { id: bill.id };
}

export async function getMenuItemWithOptions(restaurantId: string, menuItemId: string) {
  return db.menuItem.findFirst({
    where: { id: menuItemId, restaurantId },
    include: { optionGroups: { include: { choices: true } } },
  });
}

export interface CreateOrderFromCallInput {
  restaurant: Restaurant;
  callId: string;
  name: string;
  phone: string;
  items: CartItemInput[];
  takeawayNote?: string;
}

export type CreateOrderFromCallResult =
  | { ok: true; billId: string; totalCents: number }
  | { ok: false; reason: string };

export async function createOrderFromCall(
  input: CreateOrderFromCallInput,
): Promise<CreateOrderFromCallResult> {
  const { restaurant, callId, name, phone, items, takeawayNote } = input;

  if (!name.trim() || !phone.trim()) {
    return { ok: false, reason: "A customer name and phone number are required." };
  }
  if (items.length === 0) {
    return { ok: false, reason: "No items have been added yet." };
  }

  const customer = await db.customer.upsert({
    where: { restaurantId_phone: { restaurantId: restaurant.id, phone } },
    update: { name },
    create: { restaurantId: restaurant.id, name, phone },
  });

  const bill = await createTakeawayBill(restaurant, {
    callId,
    customerId: customer.id,
    customerNameAtBooking: name,
  });

  try {
    await submitOrderCore(restaurant, bill.id, items, true, takeawayNote);
  } catch (err) {
    return { ok: false, reason: err instanceof Error ? err.message : "Could not submit the order." };
  }

  const billWithOrders = await db.bill.findUnique({
    where: { id: bill.id },
    include: { orders: { include: { items: { include: { optionChoices: true } } } } },
  });
  const totalCents = billWithOrders ? computeBillTotals(billWithOrders.orders, restaurant, 0, true).totalCents : 0;

  return { ok: true, billId: bill.id, totalCents };
}

export interface NewPhoneOrderNotice {
  id: string;
  customerName: string;
  itemCount: number;
  totalCents: number;
  note: string | null;
  createdAt: Date;
}

export async function getPhoneOrdersCreatedAfter(
  restaurantId: string,
  since: Date,
): Promise<NewPhoneOrderNotice[]> {
  const rows = await db.bill.findMany({
    where: { restaurantId, source: "PHONE", openedAt: { gt: since } },
    orderBy: { openedAt: "asc" },
    include: {
      customer: true,
      orders: { include: { items: { include: { optionChoices: true } } } },
    },
  });
  return rows.map((bill) => {
    const activeOrders = bill.orders.filter((order) => order.status !== "CANCELLED");
    return {
      id: bill.id,
      customerName: bill.customerNameAtBooking ?? bill.customer?.name ?? "Phone order",
      itemCount: activeOrders.flatMap((order) => order.items).reduce((sum, item) => sum + item.quantity, 0),
      totalCents: computeBillTotalCents(bill.orders),
      note: activeOrders.find((order) => order.takeawayNote)?.takeawayNote ?? null,
      createdAt: bill.openedAt,
    };
  });
}
