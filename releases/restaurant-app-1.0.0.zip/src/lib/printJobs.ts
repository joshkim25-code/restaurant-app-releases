import { db } from "@/lib/db";
import type { PrinterConfig, TicketCommand } from "@/lib/ticketWriter";
import type { PrintJobType, Prisma } from "@/generated/prisma/client";

const POLL_INTERVAL_MS = 500;
const DEFAULT_TIMEOUT_MS = 20000;

export async function enqueuePrintJob(
  restaurantId: string,
  type: Extract<PrintJobType, "RECEIPT" | "TICKET" | "SUMMARY" | "TEST">,
  printerConfig: PrinterConfig,
  commands: TicketCommand[]
) {
  return db.printJob.create({
    data: {
      restaurantId,
      type,
      payload: { printerConfig, commands } as unknown as Prisma.InputJsonValue,
    },
  });
}

export async function enqueueDiscoveryJob(
  restaurantId: string,
  type: Extract<PrintJobType, "LIST_INSTALLED" | "DISCOVER_NETWORK">
) {
  return db.printJob.create({
    data: { restaurantId, type, payload: {} },
  });
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Polls until the local agent picks up and completes the job, or throws on failure/timeout.
// Callers pass a generic T for jobs whose `result` matters (discovery jobs); print jobs
// just await completion (T = void).
export async function awaitJobResult<T = void>(
  jobId: string,
  timeoutMs = DEFAULT_TIMEOUT_MS
): Promise<T> {
  const deadline = Date.now() + timeoutMs;

  while (Date.now() < deadline) {
    const job = await db.printJob.findUniqueOrThrow({ where: { id: jobId } });

    if (job.status === "DONE") {
      return job.result as T;
    }
    if (job.status === "FAILED") {
      throw new Error(job.error ?? "The print agent reported a failure.");
    }

    await sleep(POLL_INTERVAL_MS);
  }

  throw new Error(
    "The print agent did not respond in time — check it's running and connected."
  );
}
