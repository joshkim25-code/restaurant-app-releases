// Type definitions shared between the cloud app and the local print agent. The actual
// discovery implementations (shelling out to PowerShell / scanning the LAN) are
// Windows/local-machine-specific and live in agent/printerDiscovery.ts instead — the
// cloud app only ever sees their results via a PrintJob's `result` payload.

export interface InstalledPrinter {
  name: string;
  status: string;
}

export interface DiscoveredNetworkPrinter {
  ip: string;
  hostname: string | null;
}
