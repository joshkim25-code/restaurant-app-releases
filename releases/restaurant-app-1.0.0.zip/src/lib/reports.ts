import { db } from "@/lib/db";
import { lineTotalCents } from "@/lib/billing";
import { formatDate } from "@/lib/time";

export type ReportRange = "today" | "7d" | "30d" | "all" | "custom";

export const REPORT_RANGES: { key: Exclude<ReportRange, "custom">; label: string }[] = [
  { key: "today", label: "Today" },
  { key: "7d", label: "Last 7 days" },
  { key: "30d", label: "Last 30 days" },
  { key: "all", label: "All time" },
];

export function isPresetRange(value: string | undefined): value is Exclude<ReportRange, "custom"> {
  return REPORT_RANGES.some((r) => r.key === value);
}

export function parseISODate(value: string | undefined): Date | undefined {
  if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return undefined;
  const [y, m, d] = value.split("-").map(Number);
  const date = new Date(y, m - 1, d);
  return Number.isNaN(date.getTime()) ? undefined : date;
}

// Human label for a report period, e.g. for a printed summary's subtitle.
export function reportRangeLabel(
  range: ReportRange,
  custom: { from: Date; to: Date } | undefined,
  timezone: string
): string {
  if (range === "custom" && custom) {
    return `${formatDate(custom.from, timezone)} – ${formatDate(custom.to, timezone)}`;
  }
  return REPORT_RANGES.find((r) => r.key === range)?.label ?? "Custom range";
}

export function rangeStart(range: Exclude<ReportRange, "custom">, now = new Date()): Date | null {
  if (range === "all") return null;
  if (range === "today") {
    return new Date(now.getFullYear(), now.getMonth(), now.getDate());
  }
  const days = range === "7d" ? 7 : 30;
  return new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
}

export interface ReportWindow {
  since: Date | null;
  /** Exclusive upper bound. */
  until: Date | null;
}

export function reportWindow(
  range: ReportRange,
  custom: { from: Date; to: Date } | undefined,
  now = new Date(),
): ReportWindow {
  if (range === "custom") {
    if (!custom) return { since: null, until: null };
    const since = new Date(custom.from.getFullYear(), custom.from.getMonth(), custom.from.getDate());
    const until = new Date(custom.to.getFullYear(), custom.to.getMonth(), custom.to.getDate() + 1);
    return { since, until };
  }
  return { since: rangeStart(range, now), until: null };
}

export async function getSalesReport(
  restaurantId: string,
  range: ReportRange,
  custom?: { from: Date; to: Date },
) {
  const { since, until } = reportWindow(range, custom);
  const closedAtFilter =
    since || until
      ? { closedAt: { ...(since ? { gte: since } : {}), ...(until ? { lt: until } : {}) } }
      : {};

  const bills = await db.bill.findMany({
    where: {
      restaurantId,
      status: "CLOSED",
      payment: { isNot: null },
      ...closedAtFilter,
    },
    orderBy: { closedAt: "asc" },
    include: {
      payment: true,
      orders: {
        include: {
          items: { include: { menuItem: { include: { category: true } }, optionChoices: true } },
        },
      },
    },
  });

  const cancelledAgg = await db.bill.aggregate({
    where: {
      restaurantId,
      status: "CLOSED",
      payment: { is: null },
      ...closedAtFilter,
    },
    _count: { _all: true },
    _sum: { cancelledValueCents: true },
  });
  const cancelledCount = cancelledAgg._count._all;
  const cancelledValueCents = cancelledAgg._sum.cancelledValueCents ?? 0;

  const revenueCents = bills.reduce((sum, bill) => sum + (bill.payment?.amountCents ?? 0), 0);
  const taxCents = bills.reduce((sum, bill) => sum + (bill.payment?.taxCents ?? 0), 0);
  const serviceChargeCents = bills.reduce((sum, bill) => sum + (bill.payment?.serviceChargeCents ?? 0), 0);
  const billCount = bills.length;
  const averageBillCents = billCount > 0 ? Math.round(revenueCents / billCount) : 0;

  const revenueByMethod = new Map<string, { revenueCents: number; count: number }>();
  for (const bill of bills) {
    if (!bill.payment) continue;
    const existing = revenueByMethod.get(bill.payment.method) ?? { revenueCents: 0, count: 0 };
    existing.revenueCents += bill.payment.amountCents;
    existing.count += 1;
    revenueByMethod.set(bill.payment.method, existing);
  }

  // Cash tips are usually kept directly by staff; card tips typically need a separate
  // payout, so which method a tip came through matters for real money handling.
  const tipsByMethod = new Map<string, number>();
  let tipsCents = 0;
  for (const bill of bills) {
    if (!bill.payment || bill.payment.tipCents === 0) continue;
    // The tip can be paid differently than the order (card order, cash tip) - falls back
    // to the order's method only for pre-migration payments that never recorded one.
    const tipMethod = bill.payment.tipMethod ?? bill.payment.method;
    tipsByMethod.set(tipMethod, (tipsByMethod.get(tipMethod) ?? 0) + bill.payment.tipCents);
    tipsCents += bill.payment.tipCents;
  }

  const revenueByBillSource = new Map<string, number>();
  for (const bill of bills) {
    if (!bill.payment) continue;
    revenueByBillSource.set(
      bill.source,
      (revenueByBillSource.get(bill.source) ?? 0) + bill.payment.amountCents,
    );
  }

  const revenueByDay = new Map<string, number>();
  for (const bill of bills) {
    const day = (bill.closedAt ?? bill.openedAt).toISOString().slice(0, 10);
    revenueByDay.set(day, (revenueByDay.get(day) ?? 0) + (bill.payment?.amountCents ?? 0));
  }

  const itemStats = new Map<
    string,
    { menuItemId: string; name: string; quantity: number; revenueCents: number }
  >();
  const categoryStats = new Map<string, { categoryId: string; name: string; revenueCents: number }>();
  let dineInCents = 0;
  let takeawayCents = 0;
  for (const bill of bills) {
    for (const order of bill.orders) {
      if (order.status === "CANCELLED") continue;
      for (const item of order.items) {
        const cents = lineTotalCents(item);

        const existing = itemStats.get(item.menuItemId) ?? {
          menuItemId: item.menuItemId,
          name: item.menuItem.name,
          quantity: 0,
          revenueCents: 0,
        };
        existing.quantity += item.quantity;
        existing.revenueCents += cents;
        itemStats.set(item.menuItemId, existing);

        // A sold item's category can be gone by report time - categories are deletable once
        // they have no active items left, even if an archived (previously-ordered) item still
        // references one via a now-cleared, nullable categoryId (see MenuItem.categoryId).
        const categoryKey = item.menuItem.categoryId ?? "uncategorized";
        const cat = categoryStats.get(categoryKey) ?? {
          categoryId: categoryKey,
          name: item.menuItem.category?.name ?? "Uncategorized",
          revenueCents: 0,
        };
        cat.revenueCents += cents;
        categoryStats.set(categoryKey, cat);

        if (order.isTakeaway) takeawayCents += cents;
        else dineInCents += cents;
      }
    }
  }

  const topItems = [...itemStats.values()].sort((a, b) => b.quantity - a.quantity).slice(0, 10);
  const revenueByCategory = [...categoryStats.values()].sort((a, b) => b.revenueCents - a.revenueCents);

  return {
    range,
    since,
    until,
    billCount,
    cancelledCount,
    cancelledValueCents,
    revenueCents,
    averageBillCents,
    taxCents,
    serviceChargeCents,
    revenueByMethod: [...revenueByMethod.entries()].sort((a, b) => b[1].revenueCents - a[1].revenueCents),
    tipsCents,
    tipsByMethod: [...tipsByMethod.entries()].sort((a, b) => b[1] - a[1]),
    revenueByDay: [...revenueByDay.entries()].sort((a, b) => (a[0] < b[0] ? -1 : 1)),
    revenueByCategory,
    revenueByFulfillment: { dineInCents, takeawayCents },
    revenueByBillSource: [...revenueByBillSource.entries()].sort((a, b) => b[1] - a[1]),
    topItems,
  };
}
