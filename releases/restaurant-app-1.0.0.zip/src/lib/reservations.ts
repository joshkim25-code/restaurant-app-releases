import { db } from "@/lib/db";
import { zonedMidnight } from "@/lib/time";
import type { Restaurant, ReservationStatus } from "@/generated/prisma/client";

const ACTIVE_STATUSES: ReservationStatus[] = ["PENDING", "CONFIRMED"];

export async function getPendingReservationCount(restaurantId: string): Promise<number> {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return db.reservation.count({
    where: { restaurantId, status: "PENDING", date: { gte: todayStart } },
  });
}

export interface NewReservationNotice {
  id: string;
  customerName: string;
  partySize: number;
  startTime: Date;
  tableLabel: string | null;
  createdAt: Date;
}

export async function getReservationsCreatedAfter(
  restaurantId: string,
  since: Date,
): Promise<NewReservationNotice[]> {
  const rows = await db.reservation.findMany({
    where: { restaurantId, createdAt: { gt: since } },
    orderBy: { createdAt: "asc" },
    include: { customer: true, table: true },
  });
  return rows.map((r) => ({
    id: r.id,
    customerName: r.customerNameAtBooking ?? r.customer.name,
    partySize: r.partySize,
    startTime: r.startTime,
    tableLabel: r.table?.label ?? null,
    createdAt: r.createdAt,
  }));
}

export function reservationWindowMinutes(
  restaurant: Pick<Restaurant, "reservationDurationMinutes" | "turnoverBufferMinutes">,
) {
  return restaurant.reservationDurationMinutes + restaurant.turnoverBufferMinutes;
}

function overlaps(aStart: Date, aEnd: Date, bStart: Date, bEnd: Date) {
  return aStart < bEnd && bStart < aEnd;
}

export async function isTableAvailable(
  tableId: string,
  startTime: Date,
  windowMinutes: number,
  excludeReservationId?: string,
): Promise<boolean> {
  const endTime = new Date(startTime.getTime() + windowMinutes * 60_000);

  const others = await db.reservation.findMany({
    where: {
      tableId,
      status: { in: ACTIVE_STATUSES },
      ...(excludeReservationId ? { id: { not: excludeReservationId } } : {}),
    },
    select: { startTime: true },
  });

  return others.every((other) => {
    const otherEnd = new Date(other.startTime.getTime() + windowMinutes * 60_000);
    return !overlaps(startTime, endTime, other.startTime, otherEnd);
  });
}

export async function findAvailableTable(
  restaurantId: string,
  partySize: number,
  startTime: Date,
  windowMinutes: number,
): Promise<{ id: string; label: string } | null> {
  const candidates = await db.table.findMany({
    where: { restaurantId, isActive: true, seats: { gte: partySize } },
    orderBy: { seats: "asc" },
    select: { id: true, label: true },
  });

  for (const table of candidates) {
    if (await isTableAvailable(table.id, startTime, windowMinutes)) {
      return table;
    }
  }
  return null;
}

export interface CreateReservationFromCallInput {
  restaurant: Restaurant;
  callId: string;
  name: string;
  phone: string;
  partySize: number;
  startTime: Date;
  specialRequests?: string | null;
}

export type CreateReservationFromCallResult =
  | { ok: true; reservationId: string; tableLabel: string; startTime: Date }
  | { ok: false; reason: string };

export async function createReservationFromCall(
  input: CreateReservationFromCallInput,
): Promise<CreateReservationFromCallResult> {
  const { restaurant, callId, name, phone, partySize, startTime, specialRequests } = input;

  if (!name.trim() || !phone.trim()) {
    return { ok: false, reason: "A customer name and phone number are required." };
  }
  if (!Number.isInteger(partySize) || partySize <= 0) {
    return { ok: false, reason: "Party size must be a positive whole number." };
  }
  if (Number.isNaN(startTime.getTime())) {
    return { ok: false, reason: "Invalid date or time." };
  }
  if (partySize < restaurant.minPartySize || partySize > restaurant.maxPartySize) {
    return {
      ok: false,
      reason: `Party size must be between ${restaurant.minPartySize} and ${restaurant.maxPartySize}.`,
    };
  }

  const now = new Date();
  const bookingLimit = new Date(now.getTime() + restaurant.bookingWindowDays * 24 * 60 * 60 * 1000);
  if (startTime < now) {
    return { ok: false, reason: "That time is in the past." };
  }
  if (startTime > bookingLimit) {
    return {
      ok: false,
      reason: `Reservations can only be made up to ${restaurant.bookingWindowDays} days in advance.`,
    };
  }

  const windowMinutes = reservationWindowMinutes(restaurant);
  const table = await findAvailableTable(restaurant.id, partySize, startTime, windowMinutes);
  if (!table) {
    return { ok: false, reason: "No table is free for that party size and time." };
  }

  const customer = await db.customer.upsert({
    where: { restaurantId_phone: { restaurantId: restaurant.id, phone } },
    update: { name },
    create: { restaurantId: restaurant.id, name, phone },
  });

  const dayStart = zonedMidnight(startTime, restaurant.timezone);

  const reservation = await db.reservation.create({
    data: {
      restaurantId: restaurant.id,
      tableId: table.id,
      customerId: customer.id,
      partySize,
      date: dayStart,
      startTime,
      status: "PENDING",
      specialRequests: specialRequests?.trim() || null,
      source: "PHONE",
      createdByCallId: callId,
      customerNameAtBooking: name,
    },
  });

  return { ok: true, reservationId: reservation.id, tableLabel: table.label, startTime };
}

export interface ReservationListEntry {
  id: string;
  startTime: Date;
  partySize: number;
  status: ReservationStatus;
  specialRequests: string | null;
  customerName: string;
  customerPhone: string;
  tableId: string | null;
  tableLabel: string | null;
}

export async function getReservations(
  restaurantId: string,
  options: {
    date: Date;
    tableId?: string;
    status?: ReservationStatus;
    page?: number;
    pageSize?: number;
  },
): Promise<{
  reservations: ReservationListEntry[];
  page: number;
  pageSize: number;
  hasNext: boolean;
  hasPrev: boolean;
}> {
  const page = Math.max(1, options.page ?? 1);
  const pageSize = options.pageSize ?? 25;

  const dayStart = new Date(
    options.date.getFullYear(),
    options.date.getMonth(),
    options.date.getDate(),
  );
  const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);

  const rows = await db.reservation.findMany({
    where: {
      restaurantId,
      date: { gte: dayStart, lt: dayEnd },
      ...(options.tableId ? { tableId: options.tableId } : {}),
      ...(options.status ? { status: options.status } : {}),
    },
    orderBy: { startTime: "asc" },
    skip: (page - 1) * pageSize,
    take: pageSize + 1,
    include: { customer: true, table: true },
  });

  const hasNext = rows.length > pageSize;
  const reservations: ReservationListEntry[] = rows.slice(0, pageSize).map((r) => ({
    id: r.id,
    startTime: r.startTime,
    partySize: r.partySize,
    status: r.status,
    specialRequests: r.specialRequests,
    customerName: r.customerNameAtBooking ?? r.customer.name,
    customerPhone: r.customer.phone,
    tableId: r.tableId,
    tableLabel: r.table?.label ?? null,
  }));

  return { reservations, page, pageSize, hasNext, hasPrev: page > 1 };
}

export async function getPendingReservations(restaurantId: string): Promise<ReservationListEntry[]> {
  const rows = await db.reservation.findMany({
    where: { restaurantId, status: "PENDING" },
    orderBy: { startTime: "asc" },
    include: { customer: true, table: true },
  });

  return rows.map((r) => ({
    id: r.id,
    startTime: r.startTime,
    partySize: r.partySize,
    status: r.status,
    specialRequests: r.specialRequests,
    customerName: r.customerNameAtBooking ?? r.customer.name,
    customerPhone: r.customer.phone,
    tableId: r.tableId,
    tableLabel: r.table?.label ?? null,
  }));
}
