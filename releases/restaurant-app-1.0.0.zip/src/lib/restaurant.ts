import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getCurrentUserId } from "@/lib/session";

export async function getCurrentRestaurant() {
  const userId = await getCurrentUserId();
  if (!userId) {
    redirect("/login");
  }

  const membership = await db.membership.findFirst({
    where: { userId },
    orderBy: { createdAt: "asc" },
    include: { restaurant: true },
  });

  if (!membership) {
    redirect("/onboarding");
  }

  return membership.restaurant;
}
