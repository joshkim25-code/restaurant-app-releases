import type { SessionOptions } from "iron-session";

export type SessionData = {
  userId?: string;
};

// A sliding 60-day expiry - without an explicit maxAge this is a true session cookie that
// dies with whatever process holds it, which is fine for a browser tab but breaks a
// persistent desktop client (the planned launcher's WebView2 profile survives the launcher
// process exiting, but only if the cookie itself carries an expiry to persist alongside it).
const SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 60;

export const sessionOptions: SessionOptions = {
  cookieName: "restaurant_session",
  password: process.env.SESSION_SECRET!,
  cookieOptions: {
    secure: process.env.NODE_ENV === "production",
    maxAge: SESSION_MAX_AGE_SECONDS,
  },
};
