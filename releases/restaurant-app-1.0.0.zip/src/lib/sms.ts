import twilio from "twilio";
import { formatDateTime } from "@/lib/time";

const client =
  process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN
    ? twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN)
    : null;

export async function sendReservationConfirmationSms(params: {
  to: string;
  from: string;
  customerName: string;
  partySize: number;
  startTime: Date;
  timezone: string;
  restaurantName: string;
}): Promise<void> {
  const body = `Hi ${params.customerName}, your table for ${params.partySize} at ${params.restaurantName} on ${formatDateTime(params.startTime, params.timezone)} is confirmed. See you then!`;

  if (!client) {
    console.log(`[dev] Confirmation SMS to ${params.to}: ${body}`);
    return;
  }

  await client.messages.create({ to: params.to, from: params.from, body });
}
