import { db } from "@/lib/db";

export type TableDisplayStatus = "ACTIVE" | "RESERVED" | "AVAILABLE" | "INACTIVE";

const RESERVED_LOOKAHEAD_MINUTES = 120;

export async function getTablesWithStatus(restaurantId: string) {
  const now = new Date();
  const reservedWindowEnd = new Date(now.getTime() + RESERVED_LOOKAHEAD_MINUTES * 60_000);

  const tables = await db.table.findMany({
    where: { restaurantId },
    orderBy: { label: "asc" },
    include: {
      bills: { where: { status: "OPEN" }, select: { id: true }, take: 1 },
      reservations: {
        where: {
          status: { in: ["PENDING", "CONFIRMED"] },
          startTime: { gte: now, lte: reservedWindowEnd },
        },
        orderBy: { startTime: "asc" },
        select: { startTime: true, partySize: true },
        take: 1,
      },
    },
  });

  return tables.map((table) => {
    const status: TableDisplayStatus = !table.isActive
      ? "INACTIVE"
      : table.bills.length > 0
        ? "ACTIVE"
        : table.reservations.length > 0
          ? "RESERVED"
          : "AVAILABLE";
    return { ...table, status, nextReservation: table.reservations[0] ?? null };
  });
}

export type TableWithStatus = Awaited<ReturnType<typeof getTablesWithStatus>>[number];
