// Builds ticket/receipt/summary content as a sequence of TicketWriter commands, without
// touching any printer directly. This is what runs on the cloud side — the recorded
// commands become a PrintJob's payload, which the local agent later replays against a
// real writer (see src/lib/ticketWriter.ts's replayCommands and the agent/ directory).
import { formatMoney } from "@/lib/money";
import { formatDateTime } from "@/lib/time";
import { lineTotalCents } from "@/lib/billing";
import { RecordingWriter, type PrinterConfig, type TicketCommand } from "@/lib/ticketWriter";
import type { Bill, Order, OrderItem, OrderItemOptionChoice, Table } from "@/generated/prisma/client";

type OrderWithItems = Order & {
  items: (OrderItem & {
    optionChoices: OrderItemOptionChoice[];
    menuItem: { name: string; printerId: string | null };
  })[];
};
type BillWithOrders = Bill & { table: Table | null; orders: OrderWithItems[] };
type OrderWithTicketDetails = OrderWithItems & { bill: { table: Table | null } };

interface Totals {
  subtotalCents: number;
  taxCents: number;
  serviceChargeCents: number;
  discountCents: number;
  tipCents: number;
  totalCents: number;
  pricesIncludeTax: boolean;
  method: string | null;
  tipMethod: string | null;
}

const PAYMENT_METHOD_LABEL: Record<string, string> = {
  CASH: "Cash",
  CARD: "Card",
  OTHER: "Other",
};

interface RestaurantInfo {
  timezone: string;
}

// A single println call renders an embedded newline as one garbled/mis-padded line
// (leftRight/centering math is per-call, not per-line) - split multi-line owner text
// (header/footer) into one println per line instead.
function printLines(printer: RecordingWriter, text: string): void {
  for (const line of text.split(/\r?\n/)) {
    printer.println(line);
  }
}

export function buildReceiptCommands(
  restaurant: RestaurantInfo & {
    name: string;
    currency: string;
    receiptHeaderText: string | null;
    receiptFooterText: string | null;
    receiptShowAddress: boolean;
    receiptShowPhone: boolean;
    address: string | null;
    contactPhone: string | null;
  },
  bill: BillWithOrders,
  totals: Totals,
  printerConfig: { fontSize: string }
): TicketCommand[] {
  const printer = new RecordingWriter();

  printer.alignCenter();
  printer.bold(true);
  printer.println(restaurant.name);
  printer.bold(false);
  if (restaurant.receiptHeaderText) printLines(printer, restaurant.receiptHeaderText);
  if (restaurant.receiptShowAddress && restaurant.address) printer.println(restaurant.address);
  if (restaurant.receiptShowPhone && restaurant.contactPhone) printer.println(restaurant.contactPhone);
  printer.println(bill.table ? bill.table.label : "Takeaway");
  printer.println(formatDateTime(bill.closedAt ?? bill.openedAt, restaurant.timezone));
  printer.drawLine();

  printer.alignLeft();
  printer.textSize(printerConfig.fontSize === "LARGE" ? "large" : "normal");
  for (const order of bill.orders) {
    for (const item of order.items) {
      printer.leftRight(
        `${item.quantity}x ${item.menuItem.name}`,
        formatMoney(lineTotalCents(item), restaurant.currency)
      );
      for (const choice of item.optionChoices) {
        printer.println(`  ${choice.choiceNameAtOrder}`);
      }
    }
  }
  printer.drawLine();

  if (totals.discountCents > 0) {
    printer.leftRight("Discount", `-${formatMoney(totals.discountCents, restaurant.currency)}`);
  }
  const hasBreakdown = totals.taxCents > 0 || totals.serviceChargeCents > 0;
  if (hasBreakdown) {
    printer.leftRight("Subtotal", formatMoney(totals.subtotalCents, restaurant.currency));
  }
  if (totals.taxCents > 0) {
    printer.leftRight(
      totals.pricesIncludeTax ? "Tax (incl.)" : "Tax",
      formatMoney(totals.taxCents, restaurant.currency)
    );
  }
  if (totals.serviceChargeCents > 0) {
    printer.leftRight("Service charge", formatMoney(totals.serviceChargeCents, restaurant.currency));
  }
  if (totals.tipCents > 0) {
    printer.leftRight("Total", formatMoney(totals.totalCents, restaurant.currency));
    const tipLabel = totals.tipMethod
      ? `Tip (${PAYMENT_METHOD_LABEL[totals.tipMethod] ?? totals.tipMethod})`
      : "Tip";
    printer.leftRight(tipLabel, formatMoney(totals.tipCents, restaurant.currency));
    printer.bold(true);
    printer.leftRight("Amount paid", formatMoney(totals.totalCents + totals.tipCents, restaurant.currency));
    printer.bold(false);
  } else {
    printer.bold(true);
    printer.leftRight("Total", formatMoney(totals.totalCents, restaurant.currency));
    printer.bold(false);
  }

  if (totals.method) {
    printer.leftRight("Paid by", PAYMENT_METHOD_LABEL[totals.method] ?? totals.method);
  }

  printer.textSize("normal");

  if (restaurant.receiptFooterText) {
    printer.drawLine();
    printer.alignCenter();
    printLines(printer, restaurant.receiptFooterText);
  }

  printer.cut();

  return printer.getCommands();
}

function writeTicketHeader(
  printer: RecordingWriter,
  heading: string,
  order: OrderWithTicketDetails,
  timezone: string
) {
  printer.alignCenter();
  printer.bold(true);
  printer.println(heading);
  printer.bold(false);
  printer.println(order.bill.table ? order.bill.table.label : "Takeaway");
  if (order.isTakeaway) printer.println("TAKEAWAY");
  if (order.takeawayNote) printer.println(order.takeawayNote);
  printer.println(formatDateTime(order.submittedAt, timezone));
  printer.drawLine();
  printer.alignLeft();
}

function writeTicketItems(
  printer: RecordingWriter,
  items: OrderWithItems["items"],
  fontSize: string
) {
  printer.textSize(fontSize === "LARGE" ? "large" : "normal");
  for (const item of items) {
    printer.bold(true);
    printer.println(`${item.quantity}x ${item.menuItem.name}`);
    printer.bold(false);
    for (const choice of item.optionChoices) {
      printer.println(`  ${choice.choiceNameAtOrder}`);
    }
    if (item.notes) printer.println(`  Note: ${item.notes}`);
  }
  printer.textSize("normal");
}

// Prints only the items assigned to this printer (via MenuItem.printerId) — e.g. a
// Kitchen, Bar, or Expo printer. Returns null if no items in the round are assigned here.
export function buildTicketForPrinterCommands(
  printerConfig: PrinterConfig,
  restaurant: RestaurantInfo,
  order: OrderWithTicketDetails
): TicketCommand[] | null {
  const items = order.items.filter((item) => item.menuItem.printerId === printerConfig.id);
  if (items.length === 0) return null;

  const printer = new RecordingWriter();
  writeTicketHeader(printer, `${printerConfig.name.toUpperCase()} TICKET`, order, restaurant.timezone);
  writeTicketItems(printer, items, printerConfig.fontSize);
  printer.cut();

  return printer.getCommands();
}

// Prints every item in the round, unfiltered, to the receipt printer — a complete
// record of what was ordered even when some items aren't routed to any ticket printer.
export function buildOrderTicketCommands(
  restaurant: RestaurantInfo,
  order: OrderWithTicketDetails,
  printerConfig: { fontSize: string }
): TicketCommand[] {
  const printer = new RecordingWriter();
  writeTicketHeader(printer, "ORDER TICKET", order, restaurant.timezone);
  writeTicketItems(printer, order.items, printerConfig.fontSize);
  printer.cut();

  return printer.getCommands();
}

export function buildTestPrintCommands(
  printerConfig: PrinterConfig,
  restaurant: RestaurantInfo & { name: string }
): TicketCommand[] {
  const printer = new RecordingWriter();
  printer.alignCenter();
  printer.bold(true);
  printer.println(restaurant.name);
  printer.bold(false);
  printer.textSize(printerConfig.fontSize === "LARGE" ? "large" : "normal");
  printer.println(`${printerConfig.name} test print`);
  printer.textSize("normal");
  printer.println(formatDateTime(new Date(), restaurant.timezone));
  printer.cut();

  return printer.getCommands();
}

export interface SummaryReport {
  billCount: number;
  cancelledCount: number;
  cancelledValueCents: number;
  revenueCents: number;
  averageBillCents: number;
  taxCents: number;
  serviceChargeCents: number;
  revenueByMethod: [string, { revenueCents: number; count: number }][];
  tipsByMethod: [string, number][];
  revenueByCategory: { categoryId: string; name: string; revenueCents: number }[];
  revenueByFulfillment: { dineInCents: number; takeawayCents: number };
  revenueByBillSource: [string, number][];
  topItems: { name: string; quantity: number; revenueCents: number }[];
}

export function buildSummaryCommands(
  restaurant: RestaurantInfo & {
    name: string;
    currency: string;
    summaryShowRevenue: boolean;
    summaryShowBillCount: boolean;
    summaryShowCancelled: boolean;
    summaryShowAverageBill: boolean;
    summaryShowPaymentMethods: boolean;
    summaryShowTipsByMethod: boolean;
    summaryShowTopItems: boolean;
    summaryShowTax: boolean;
    summaryShowServiceCharge: boolean;
    summaryShowCancelledRevenue: boolean;
    summaryShowRevenueByCategory: boolean;
    summaryShowFulfillmentSplit: boolean;
    summaryShowRevenueBySource: boolean;
  },
  periodLabel: string,
  report: SummaryReport,
  printerConfig: { fontSize: string }
): TicketCommand[] {
  const printer = new RecordingWriter();

  printer.alignCenter();
  printer.bold(true);
  printer.println(restaurant.name);
  printer.bold(false);
  printer.println("SUMMARY");
  printer.println(periodLabel);
  printer.drawLine();

  printer.alignLeft();
  printer.textSize(printerConfig.fontSize === "LARGE" ? "large" : "normal");
  if (restaurant.summaryShowBillCount) {
    printer.leftRight("Bills paid", String(report.billCount));
  }
  if (restaurant.summaryShowCancelled) {
    printer.leftRight("Bills cancelled", String(report.cancelledCount));
  }
  if (restaurant.summaryShowCancelledRevenue) {
    printer.leftRight("Lost revenue", formatMoney(report.cancelledValueCents, restaurant.currency));
  }
  if (restaurant.summaryShowRevenue) {
    printer.leftRight("Revenue", formatMoney(report.revenueCents, restaurant.currency));
  }
  if (restaurant.summaryShowAverageBill) {
    printer.leftRight("Average bill", formatMoney(report.averageBillCents, restaurant.currency));
  }
  if (restaurant.summaryShowTax) {
    printer.leftRight("Tax", formatMoney(report.taxCents, restaurant.currency));
  }
  if (restaurant.summaryShowServiceCharge) {
    printer.leftRight("Service charge", formatMoney(report.serviceChargeCents, restaurant.currency));
  }

  if (restaurant.summaryShowPaymentMethods && report.revenueByMethod.length > 0) {
    printer.drawLine();
    printer.bold(true);
    printer.println("By payment method");
    printer.bold(false);
    for (const [method, stats] of report.revenueByMethod) {
      printer.leftRight(`${method} (${stats.count})`, formatMoney(stats.revenueCents, restaurant.currency));
    }
  }

  if (restaurant.summaryShowTipsByMethod && report.tipsByMethod.length > 0) {
    printer.drawLine();
    printer.bold(true);
    printer.println("Tips by method");
    printer.bold(false);
    for (const [method, cents] of report.tipsByMethod) {
      printer.leftRight(method, formatMoney(cents, restaurant.currency));
    }
  }

  if (restaurant.summaryShowTopItems && report.topItems.length > 0) {
    printer.drawLine();
    printer.bold(true);
    printer.println("Top items");
    printer.bold(false);
    for (const item of report.topItems) {
      printer.leftRight(`${item.quantity}x ${item.name}`, formatMoney(item.revenueCents, restaurant.currency));
    }
  }

  if (restaurant.summaryShowRevenueByCategory && report.revenueByCategory.length > 0) {
    printer.drawLine();
    printer.bold(true);
    printer.println("By category");
    printer.bold(false);
    for (const cat of report.revenueByCategory) {
      printer.leftRight(cat.name, formatMoney(cat.revenueCents, restaurant.currency));
    }
  }

  if (restaurant.summaryShowFulfillmentSplit) {
    printer.drawLine();
    printer.bold(true);
    printer.println("Dine-in vs takeaway");
    printer.bold(false);
    printer.leftRight("Dine-in", formatMoney(report.revenueByFulfillment.dineInCents, restaurant.currency));
    printer.leftRight("Takeaway", formatMoney(report.revenueByFulfillment.takeawayCents, restaurant.currency));
  }

  if (restaurant.summaryShowRevenueBySource && report.revenueByBillSource.length > 0) {
    printer.drawLine();
    printer.bold(true);
    printer.println("By order source");
    printer.bold(false);
    for (const [source, cents] of report.revenueByBillSource) {
      printer.leftRight(source, formatMoney(cents, restaurant.currency));
    }
  }

  printer.textSize("normal");
  printer.cut();

  return printer.getCommands();
}
