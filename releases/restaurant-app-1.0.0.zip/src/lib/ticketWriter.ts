// Shared between the cloud app (which builds ticket content) and the local print agent
// (which sends it to a real printer). Deliberately dependency-free — no fs/child_process/
// network imports here — so it's safe to import from either side without pulling in
// Windows-only code into the Next.js server bundle.

export interface PrinterConfig {
  id: string;
  name: string;
  kind: string;
  connectionType: string;
  ipAddress: string | null;
  port: number;
  printerName: string | null;
  fontSize: string;
}

// The subset of ThermalPrinter's API our formatting code actually uses. Implemented both
// by a thin ESC/POS wrapper (real thermal/POS printers) and by a plain-text renderer
// (normal printers, which don't understand ESC/POS control codes) — and, on the cloud
// side, by RecordingWriter below, which just records the calls instead of sending them.
// println/leftRight may need to go out to a real printer async (e.g. rendering an
// unsupported character as an image) - every implementation can stay sync where that's
// not needed (a sync `void` return still satisfies a `void | Promise<void>` signature).
export interface TicketWriter {
  alignCenter(): void;
  alignLeft(): void;
  bold(on: boolean): void;
  println(text: string): void | Promise<void>;
  leftRight(left: string, right: string): void | Promise<void>;
  drawLine(): void;
  textSize(size: "normal" | "large"): void;
  cut(): void;
}

export type TicketCommand =
  | { op: "alignCenter" }
  | { op: "alignLeft" }
  | { op: "bold"; on: boolean }
  | { op: "println"; text: string }
  | { op: "leftRight"; left: string; right: string }
  | { op: "drawLine" }
  | { op: "textSize"; size: "normal" | "large" }
  | { op: "cut" };

// Records TicketWriter calls as plain-data commands instead of sending them anywhere —
// the cloud app uses this to build a PrintJob's payload; the local agent replays the
// recorded commands against a real writer (see replayCommands below).
export class RecordingWriter implements TicketWriter {
  private commands: TicketCommand[] = [];

  alignCenter() {
    this.commands.push({ op: "alignCenter" });
  }
  alignLeft() {
    this.commands.push({ op: "alignLeft" });
  }
  bold(on: boolean) {
    this.commands.push({ op: "bold", on });
  }
  println(text: string) {
    this.commands.push({ op: "println", text });
  }
  leftRight(left: string, right: string) {
    this.commands.push({ op: "leftRight", left, right });
  }
  drawLine() {
    this.commands.push({ op: "drawLine" });
  }
  textSize(size: "normal" | "large") {
    this.commands.push({ op: "textSize", size });
  }
  cut() {
    this.commands.push({ op: "cut" });
  }

  getCommands(): TicketCommand[] {
    return this.commands;
  }
}

export async function replayCommands(writer: TicketWriter, commands: TicketCommand[]): Promise<void> {
  for (const command of commands) {
    switch (command.op) {
      case "alignCenter":
        writer.alignCenter();
        break;
      case "alignLeft":
        writer.alignLeft();
        break;
      case "bold":
        writer.bold(command.on);
        break;
      case "println":
        await writer.println(command.text);
        break;
      case "leftRight":
        await writer.leftRight(command.left, command.right);
        break;
      case "drawLine":
        writer.drawLine();
        break;
      case "textSize":
        writer.textSize(command.size);
        break;
      case "cut":
        writer.cut();
        break;
    }
  }
}
