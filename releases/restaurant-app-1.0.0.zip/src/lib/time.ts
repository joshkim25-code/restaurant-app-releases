export function formatClockTime(date: Date, timezone: string): string {
  return new Intl.DateTimeFormat("en-US", {
    timeZone: timezone,
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).format(date);
}

export function formatDate(date: Date, timezone: string): string {
  return new Intl.DateTimeFormat("en-US", {
    timeZone: timezone,
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(date);
}

export function formatDateTime(date: Date, timezone: string): string {
  return `${formatDate(date, timezone)}, ${formatClockTime(date, timezone)}`;
}

// Converts a wall-clock "YYYY-MM-DDTHH:mm" in a named IANA timezone (e.g. what a caller or
// staff member means by "3pm") into the correct UTC instant - unlike `new Date(str)`, which
// interprets a zone-less string using whatever system timezone the running process happens
// to have. That's a real bug once the same code can run on both a UK PC and a UTC cloud
// server (Railway): the exact same input would silently shift by an hour during BST.
export function zonedDateTimeToUtc(dateTimeStr: string, timezone: string): Date {
  // Treat the string as if it were UTC, just to get a reference instant to probe with.
  const naiveUtc = new Date(`${dateTimeStr}:00Z`);
  if (Number.isNaN(naiveUtc.getTime())) return naiveUtc;

  // Ask what that instant's wall-clock reads as in the target timezone, then measure how
  // far that is from the naive guess - that gap is the zone's UTC offset at this date
  // (DST-aware, since it's evaluated at this specific instant, not a fixed offset).
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat("en-US", {
      timeZone: timezone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    })
      .formatToParts(naiveUtc)
      .map((p) => [p.type, p.value]),
  );
  const hour = parts.hour === "24" ? 0 : Number(parts.hour);
  const asIfUtc = Date.UTC(
    Number(parts.year),
    Number(parts.month) - 1,
    Number(parts.day),
    hour,
    Number(parts.minute),
    Number(parts.second),
  );

  return new Date(naiveUtc.getTime() + (naiveUtc.getTime() - asIfUtc));
}

// Midnight, in the given timezone, of the calendar day `instant` falls on there - the
// UTC instant that a same-timezone process's `new Date(y, m, d)` day-bucket would also
// produce. Used to keep Reservation.date consistent regardless of which system timezone
// the writing process happens to run in.
export function zonedMidnight(instant: Date, timezone: string): Date {
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat("en-US", {
      timeZone: timezone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    })
      .formatToParts(instant)
      .map((p) => [p.type, p.value]),
  );
  return zonedDateTimeToUtc(`${parts.year}-${parts.month}-${parts.day}T00:00`, timezone);
}
