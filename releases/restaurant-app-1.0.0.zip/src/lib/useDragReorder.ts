"use client";

import { useState } from "react";

// Native HTML5 drag events (draggable/onDragStart/onDragOver/onDrop) - no extra dependency
// needed for a single-column reorderable list. Keeps a locally-reordered copy so the list
// visually reflows as you drag, then persists once on drop via the caller's server action.
export function useDragReorder<T extends { id: string }>(
  items: T[],
  onReorder: (orderedIds: string[]) => void,
) {
  const [order, setOrder] = useState(items);
  const [draggingId, setDraggingId] = useState<string | null>(null);

  // The list prop is the source of truth after a server round-trip (revalidatePath) - stay
  // in sync with it whenever we're not actively mid-drag. (React's documented pattern for
  // deriving state from props: a guarded setState call in the render body itself.)
  //
  // Two cases, handled differently:
  // - The set of ids changed (an item was added/removed elsewhere, e.g. the "Add item" form,
  //   or a delete) - adopt the fresh list wholesale, including the server's order for it.
  // - The set of ids is the same, possibly just reordered locally mid-drag/just-dropped (this
  //   component's own optimistic reorder, not yet reflected in `items` until the server round
  //   trip completes) - keep the locally-established sequence, but still swap in each item's
  //   latest object so edited fields (price, name, availability, a newly-added sibling item's
  //   own nested content, etc.) show up without a manual refresh. Comparing only `.id` here
  //   (the previous approach) missed exactly this case: same ids, same order, stale content.
  if (!draggingId) {
    if (!sameIdSet(order, items)) {
      setOrder(items);
    } else {
      const byId = new Map(items.map((item) => [item.id, item]));
      const refreshed = order.map((item) => byId.get(item.id) ?? item);
      if (refreshed.some((item, i) => item !== order[i])) {
        setOrder(refreshed);
      }
    }
  }

  function onDragStart(id: string) {
    return () => setDraggingId(id);
  }

  function onDragOver(overId: string) {
    return (e: React.DragEvent) => {
      e.preventDefault();
      if (!draggingId || draggingId === overId) return;
      setOrder((prev) => {
        const from = prev.findIndex((i) => i.id === draggingId);
        const to = prev.findIndex((i) => i.id === overId);
        if (from === -1 || to === -1) return prev;
        const next = [...prev];
        const [moved] = next.splice(from, 1);
        next.splice(to, 0, moved);
        return next;
      });
    };
  }

  function onDragEnd() {
    setDraggingId(null);
    onReorder(order.map((i) => i.id));
  }

  return { order, draggingId, onDragStart, onDragOver, onDragEnd };
}

function sameIdSet<T extends { id: string }>(a: T[], b: T[]): boolean {
  if (a.length !== b.length) return false;
  const bIds = new Set(b.map((item) => item.id));
  return a.every((item) => bIds.has(item.id));
}
