import type { InterruptSensitivity, VoicePreset } from "@/generated/prisma/client";

interface VoicePresetConfig {
  ttsProvider: string;
  voice: string;
  ttsLanguage: string;
}

// Amazon Polly voice identifiers, confirmed against Twilio's ConversationRelay and
// <Say> docs. DEFAULT deliberately has no config - omitting these TwiML attributes
// entirely preserves Twilio's own built-in default voice. Male voices only exist for
// American/British/Australian in Polly's catalog - no male voice for the other accents.
const VOICE_PRESET_CONFIG: Record<VoicePreset, VoicePresetConfig | null> = {
  DEFAULT: null,
  AMERICAN: { ttsProvider: "Amazon", voice: "Joanna-Neural", ttsLanguage: "en-US" },
  BRITISH: { ttsProvider: "Amazon", voice: "Amy-Neural", ttsLanguage: "en-GB" },
  AUSTRALIAN: { ttsProvider: "Amazon", voice: "Olivia-Neural", ttsLanguage: "en-AU" },
  INDIAN: { ttsProvider: "Amazon", voice: "Raveena", ttsLanguage: "en-IN" },
  IRISH: { ttsProvider: "Amazon", voice: "Niamh-Neural", ttsLanguage: "en-IE" },
  SOUTH_AFRICAN: { ttsProvider: "Amazon", voice: "Ayanda-Neural", ttsLanguage: "en-ZA" },
  NEW_ZEALAND: { ttsProvider: "Amazon", voice: "Aria-Neural", ttsLanguage: "en-NZ" },
  AMERICAN_MALE: { ttsProvider: "Amazon", voice: "Matthew-Neural", ttsLanguage: "en-US" },
  BRITISH_MALE: { ttsProvider: "Amazon", voice: "Brian-Neural", ttsLanguage: "en-GB" },
  AUSTRALIAN_MALE: { ttsProvider: "Amazon", voice: "Russell", ttsLanguage: "en-AU" },
};

export const VOICE_PRESET_LABELS: Record<VoicePreset, string> = {
  DEFAULT: "Default (Twilio's built-in voice)",
  AMERICAN: "American (female)",
  BRITISH: "British (female)",
  AUSTRALIAN: "Australian (female)",
  INDIAN: "Indian (female)",
  IRISH: "Irish (female)",
  SOUTH_AFRICAN: "South African (female)",
  NEW_ZEALAND: "New Zealand (female)",
  AMERICAN_MALE: "American (male)",
  BRITISH_MALE: "British (male)",
  AUSTRALIAN_MALE: "Australian (male)",
};

export const INTERRUPT_SENSITIVITY_LABELS: Record<InterruptSensitivity, string> = {
  LOW: "Low - best for noisy places (default)",
  MEDIUM: "Medium",
  HIGH: "High - caller can interrupt easily, best for quiet places",
};

export function getVoicePresetConfig(preset: VoicePreset): VoicePresetConfig | null {
  return VOICE_PRESET_CONFIG[preset];
}
