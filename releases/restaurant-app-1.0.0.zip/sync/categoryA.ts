// Category A: the operational ledger — Bill (+ nested Order/OrderItem/
// OrderItemOptionChoice, and its Payment). Only syncs bills once CLOSED — an in-progress
// bill isn't done cooking yet and doesn't matter for backup/reporting. No separate
// watermark needed for the nested rows: they're immutable once their parent bill has
// closed, so whenever the bill itself is due for sync, its whole tree goes with it.
import { localDb, cloudDb } from "./db";

async function getWatermark(restaurantId: string): Promise<Date> {
  const state = await localDb.syncState.findUnique({
    where: { restaurantId_table: { restaurantId, table: "Bill" } },
  });
  return state?.lastSyncedAt ?? new Date(0);
}

async function setWatermark(restaurantId: string, at: Date): Promise<void> {
  await localDb.syncState.upsert({
    where: { restaurantId_table: { restaurantId, table: "Bill" } },
    create: { restaurantId, table: "Bill", lastSyncedAt: at },
    update: { lastSyncedAt: at },
  });
}

export async function syncCategoryA(restaurantId: string): Promise<void> {
  const now = new Date();
  const watermark = await getWatermark(restaurantId);

  const bills = await localDb.bill.findMany({
    where: { restaurantId, status: "CLOSED", updatedAt: { gt: watermark } },
    include: {
      payment: true,
      orders: { include: { items: { include: { optionChoices: true } } } },
    },
  });

  for (const bill of bills) {
    const { payment, orders, ...billData } = bill;
    await cloudDb.bill.upsert({ where: { id: billData.id }, create: billData, update: billData });

    for (const order of orders) {
      const { items, ...orderData } = order;
      await cloudDb.order.upsert({ where: { id: orderData.id }, create: orderData, update: orderData });

      for (const item of items) {
        const { optionChoices, ...itemData } = item;
        await cloudDb.orderItem.upsert({ where: { id: itemData.id }, create: itemData, update: itemData });

        for (const choice of optionChoices) {
          await cloudDb.orderItemOptionChoice.upsert({
            where: { id: choice.id },
            create: choice,
            update: choice,
          });
        }
      }
    }

    if (payment) {
      await cloudDb.payment.upsert({ where: { id: payment.id }, create: payment, update: payment });
    }
  }

  await setWatermark(restaurantId, now);
}
