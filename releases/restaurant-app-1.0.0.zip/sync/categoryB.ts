// Category B: small config tables (bounded by "how many tables/printers/menu items a
// restaurant has", not transaction volume) — full mirror-replace every cycle instead of
// incremental diffing. Upserts every local row, then deletes any cloud row that's no
// longer present locally. Cascades in the cloud schema (identical migrations to local)
// handle cleanup of any children of a deleted parent automatically.
import { localDb, cloudDb } from "./db";

interface RestaurantScopedDelegate<T extends { id: string }> {
  findMany(args: { where: { restaurantId: string } }): Promise<T[]>;
  upsert(args: { where: { id: string }; create: T; update: T }): Promise<unknown>;
  deleteMany(args: { where: { id: { in: string[] } } }): Promise<unknown>;
}

// Upserting parents before children (as syncCategoryB does below) keeps a create/update
// cycle safe. But deleting stale cloud rows is the opposite: a stale parent (e.g. a
// deleted MenuCategory) can't be removed from the cloud while a stale child row (a
// MenuItem still pointing at it, not yet deleted itself) references it — so every
// mirrorTable call upserts immediately, but only queues its stale-row deletion, and
// syncCategoryB runs the returned deletions child-first, in the reverse of the upsert order.
async function mirrorTable<T extends { id: string }>(
  local: RestaurantScopedDelegate<T>,
  cloud: RestaurantScopedDelegate<T>,
  restaurantId: string
): Promise<() => Promise<void>> {
  const localRows = await local.findMany({ where: { restaurantId } });
  const localIds = new Set(localRows.map((row) => row.id));

  for (const row of localRows) {
    await cloud.upsert({ where: { id: row.id }, create: row, update: row });
  }

  return async () => {
    const cloudRows = await cloud.findMany({ where: { restaurantId } });
    const staleIds = cloudRows.filter((row) => !localIds.has(row.id)).map((row) => row.id);
    if (staleIds.length > 0) {
      await cloud.deleteMany({ where: { id: { in: staleIds } } });
    }
  };
}

// The restaurant row itself — single row, always upserted, never deleted. Holds the owner's
// settings (voice, greeting, instructions), so it syncs every cycle rather than with the
// heavier menu/table mirror below.
export async function syncRestaurantRow(restaurantId: string): Promise<void> {
  const restaurant = await localDb.restaurant.findUniqueOrThrow({ where: { id: restaurantId } });
  await cloudDb.restaurant.upsert({ where: { id: restaurant.id }, create: restaurant, update: restaurant });
}

export async function syncCategoryB(restaurantId: string): Promise<void> {
  await syncRestaurantRow(restaurantId);

  // Users referenced by this restaurant's memberships — additive only, never deleted here
  // (a user might belong to other restaurants too). No password/credential fields exist
  // on User (auth is a separate magic-link token, not synced), so this is safe to mirror.
  const memberships = await localDb.membership.findMany({
    where: { restaurantId },
    include: { user: true },
  });
  for (const membership of memberships) {
    const { user } = membership;
    await cloudDb.user.upsert({ where: { id: user.id }, create: user, update: user });
  }

  // Upserts run parents before children, matching the schema's own FK dependency order.
  const deleteTable = await mirrorTable(localDb.table, cloudDb.table, restaurantId);
  const deleteMenuCategory = await mirrorTable(localDb.menuCategory, cloudDb.menuCategory, restaurantId);
  const deletePrinter = await mirrorTable(localDb.printer, cloudDb.printer, restaurantId);
  const deleteBusinessHours = await mirrorTable(localDb.businessHours, cloudDb.businessHours, restaurantId);
  const deleteMenuItem = await mirrorTable(localDb.menuItem, cloudDb.menuItem, restaurantId); // needs category + printer
  const deleteOptionGroup = await mirrorTable(
    localDb.menuItemOptionGroup,
    cloudDb.menuItemOptionGroup,
    restaurantId,
  ); // needs menuItem
  const deleteOptionChoice = await mirrorTable(
    localDb.menuItemOptionChoice,
    cloudDb.menuItemOptionChoice,
    restaurantId,
  ); // needs optionGroup
  const deleteMembership = await mirrorTable(localDb.membership, cloudDb.membership, restaurantId); // needs user (synced above)

  // Deletions run children before parents — the reverse of the upsert order above.
  await deleteOptionChoice();
  await deleteOptionGroup();
  await deleteMenuItem();
  await deleteBusinessHours();
  await deletePrinter();
  await deleteMenuCategory();
  await deleteTable();
  await deleteMembership();
}
