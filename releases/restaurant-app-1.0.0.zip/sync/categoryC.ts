// Category C: Customer + Reservation — small, but matter on their own for remote
// visibility (e.g. an owner checking tonight's bookings from outside the restaurant),
// independent of whether any bill has closed. Incremental via a per-table watermark.
import { localDb, cloudDb } from "./db";

async function getWatermark(restaurantId: string, table: string): Promise<Date> {
  const state = await localDb.syncState.findUnique({ where: { restaurantId_table: { restaurantId, table } } });
  return state?.lastSyncedAt ?? new Date(0);
}

async function setWatermark(restaurantId: string, table: string, at: Date): Promise<void> {
  await localDb.syncState.upsert({
    where: { restaurantId_table: { restaurantId, table } },
    create: { restaurantId, table, lastSyncedAt: at },
    update: { lastSyncedAt: at },
  });
}

export async function syncCategoryC(restaurantId: string): Promise<void> {
  const now = new Date();

  const customerWatermark = await getWatermark(restaurantId, "Customer");
  const customers = await localDb.customer.findMany({
    where: {
      restaurantId,
      OR: [{ createdAt: { gt: customerWatermark } }, { updatedAt: { gt: customerWatermark } }],
    },
  });
  for (const customer of customers) {
    await cloudDb.customer.upsert({ where: { id: customer.id }, create: customer, update: customer });
  }
  await setWatermark(restaurantId, "Customer", now);

  // Customers must exist in the cloud DB before reservations referencing them, hence
  // Customer syncing first within this same pass.
  const reservationWatermark = await getWatermark(restaurantId, "Reservation");
  const reservations = await localDb.reservation.findMany({
    where: {
      restaurantId,
      OR: [{ createdAt: { gt: reservationWatermark } }, { updatedAt: { gt: reservationWatermark } }],
    },
  });
  for (const reservation of reservations) {
    await cloudDb.reservation.upsert({
      where: { id: reservation.id },
      create: reservation,
      update: reservation,
    });
  }
  await setWatermark(restaurantId, "Reservation", now);
}
