// Two independent database connections — confirmed safe to construct two PrismaClient
// instances in one process, each with its own connection pool (see the auth/print-agent
// research this session). Deliberately not importing src/lib/db.ts's app singleton, which
// is wired to exactly one connection string.
import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";

function createClient(connectionString: string) {
  return new PrismaClient({ adapter: new PrismaPg({ connectionString }) });
}

const localUrl = process.env.LOCAL_DATABASE_URL || process.env.DATABASE_URL;
const cloudUrl = process.env.CLOUD_DATABASE_URL;

if (!localUrl) {
  throw new Error("LOCAL_DATABASE_URL (or DATABASE_URL) is not set.");
}
if (!cloudUrl) {
  throw new Error("CLOUD_DATABASE_URL is not set — nothing to sync to.");
}

export const localDb = createClient(localUrl);
export const cloudDb = createClient(cloudUrl);
