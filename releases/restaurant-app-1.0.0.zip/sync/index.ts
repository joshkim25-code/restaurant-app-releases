// Local-to-cloud backup sync. Run from the repo root with `npm run sync` (or
// `npx tsx -r dotenv/config sync/index.ts`). Pushes a copy of this machine's restaurant
// data to CLOUD_DATABASE_URL every cycle, for backup and future remote reporting — the
// app itself never depends on this succeeding, by design (see the plan this came from).
import { localDb } from "./db";
import { syncCategoryB, syncRestaurantRow } from "./categoryB";
import { syncCategoryC } from "./categoryC";
import { syncCategoryA } from "./categoryA";
import { pullPhoneRecords, pushMissingCalls } from "./pull";

// Short cycle: phone records pulled down (their latency is also the staff notification
// latency) plus reservations/bills pushed up (keeps the cloud phone service's availability
// view fresh). The config mirror (menu/tables/settings) is heavier and changes rarely, so
// it only runs every CONFIG_INTERVAL_MS.
const CYCLE_INTERVAL_MS = 30 * 1000;
const CONFIG_INTERVAL_MS = 5 * 60 * 1000;

const lastConfigSyncAt = new Map<string, number>();

async function syncRestaurant(restaurantId: string): Promise<void> {
  // Every step here is independent — one failing (e.g. the config mirror hitting a stale
  // FK reference) must never block the others, especially the phone-record pull, whose
  // latency is also the staff notification latency.
  const steps: ((restaurantId: string) => Promise<void>)[] = [
    syncRestaurantRow,
    pullPhoneRecords,
    pushMissingCalls,
    syncCategoryC,
    syncCategoryA,
  ];

  const configDue = Date.now() - (lastConfigSyncAt.get(restaurantId) ?? 0) >= CONFIG_INTERVAL_MS;
  if (configDue) {
    // Parents before children: B (menu/tables/printers) before C/A above, which can
    // reference tables and menu items.
    steps.unshift(async (id) => {
      await syncCategoryB(id);
      lastConfigSyncAt.set(id, Date.now());
    });
  }

  const errors: unknown[] = [];
  for (const step of steps) {
    try {
      await step(restaurantId);
    } catch (err) {
      errors.push(err);
    }
  }
  if (errors.length > 0) throw errors[0];
}

async function runCycle(): Promise<void> {
  const restaurants = await localDb.restaurant.findMany({ select: { id: true, name: true } });
  for (const restaurant of restaurants) {
    try {
      await syncRestaurant(restaurant.id);
    } catch (err) {
      console.error(`Sync failed for ${restaurant.name}:`, err instanceof Error ? err.message : err);
    }
  }
}

async function loop() {
  console.log("Sync process started");
  for (;;) {
    try {
      await runCycle();
    } catch (err) {
      console.error("Sync cycle error:", err instanceof Error ? err.message : err);
    }
    await new Promise((resolve) => setTimeout(resolve, CYCLE_INTERVAL_MS));
  }
}

loop();
