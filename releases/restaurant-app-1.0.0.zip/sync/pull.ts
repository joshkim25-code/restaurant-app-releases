// Cloud-to-local pull of records the cloud-hosted AI phone service created (Calls,
// reservations, takeaway orders). Create-only: an existing local row is never overwritten,
// so anything staff have already changed locally always wins. Idempotent — safe to
// re-run over an overlapping window.
import { Prisma } from "../src/generated/prisma/client";
import { localDb, cloudDb } from "./db";

const WATERMARK_TABLE = "CloudPull";
const OVERLAP_MS = 2 * 60 * 1000;

async function getWatermark(restaurantId: string): Promise<Date> {
  const state = await localDb.syncState.findUnique({
    where: { restaurantId_table: { restaurantId, table: WATERMARK_TABLE } },
  });
  return state?.lastSyncedAt ?? new Date(0);
}

async function setWatermark(restaurantId: string, at: Date): Promise<void> {
  await localDb.syncState.upsert({
    where: { restaurantId_table: { restaurantId, table: WATERMARK_TABLE } },
    create: { restaurantId, table: WATERMARK_TABLE, lastSyncedAt: at },
    update: { lastSyncedAt: at },
  });
}

function omit<T extends object, K extends keyof T>(obj: T, key: K): Omit<T, K> {
  const copy = { ...obj };
  delete (copy as Partial<T>)[key];
  return copy;
}

type CloudCallMessage = Awaited<ReturnType<typeof cloudDb.callMessage.findMany>>[number];

// Prisma's create input wants JsonNull rather than a plain null for nullable Json columns.
function messageCreateData(messages: CloudCallMessage[]): Prisma.CallMessageCreateManyInput[] {
  return messages.map((m) => ({
    ...m,
    toolInput: m.toolInput === null ? Prisma.JsonNull : m.toolInput,
    toolResult: m.toolResult === null ? Prisma.JsonNull : m.toolResult,
  }));
}

async function ensureCall(callId: string): Promise<void> {
  if (await localDb.call.findUnique({ where: { id: callId }, select: { id: true } })) return;
  const { messages, ...call } = await cloudDb.call.findUniqueOrThrow({
    where: { id: callId },
    include: { messages: true },
  });
  await localDb.call.create({ data: call });
  if (messages.length > 0) {
    await localDb.callMessage.createMany({ data: messageCreateData(messages), skipDuplicates: true });
  }
}

// Reservations and bills point at the Call that created them, so any call the cloud
// doesn't have yet (e.g. taken before phone hosting moved to the cloud) must exist there
// before those rows are pushed up. Create-only: the cloud owns calls it already has.
export async function pushMissingCalls(restaurantId: string): Promise<void> {
  const cloudIds = (
    await cloudDb.call.findMany({ where: { restaurantId }, select: { id: true } })
  ).map((c) => c.id);

  const missing = await localDb.call.findMany({
    where: { restaurantId, id: { notIn: cloudIds } },
    include: { messages: true },
  });

  for (const { messages, ...call } of missing) {
    await cloudDb.call.create({ data: call });
    if (messages.length > 0) {
      await cloudDb.callMessage.createMany({ data: messageCreateData(messages), skipDuplicates: true });
    }
  }
}

async function syncCalls(restaurantId: string, since: Date): Promise<void> {
  const openLocal = await localDb.call.findMany({
    where: { restaurantId, status: "IN_PROGRESS" },
    select: { id: true },
  });

  const cloudCalls = await cloudDb.call.findMany({
    where: {
      restaurantId,
      OR: [{ startedAt: { gt: since } }, { id: { in: openLocal.map((c) => c.id) } }],
    },
    include: { messages: true },
  });

  for (const { messages, ...call } of cloudCalls) {
    await localDb.call.upsert({
      where: { id: call.id },
      create: call,
      update: { status: call.status, endedAt: call.endedAt },
    });
    if (messages.length > 0) {
      await localDb.callMessage.createMany({ data: messageCreateData(messages), skipDuplicates: true });
    }
  }
}

// Maps a cloud customer onto its local row. The phone number is unique per restaurant, so
// if this phone already exists locally under a different id, use that one and rename the
// cloud customer to match (ON UPDATE CASCADE carries its reservations/bills along).
async function resolveCustomer(customerId: string): Promise<string> {
  const cloudCustomer = await cloudDb.customer.findUniqueOrThrow({ where: { id: customerId } });

  if (await localDb.customer.findUnique({ where: { id: cloudCustomer.id }, select: { id: true } })) {
    return cloudCustomer.id;
  }

  const sameName = await localDb.customer.findUnique({
    where: {
      restaurantId_phone: { restaurantId: cloudCustomer.restaurantId, phone: cloudCustomer.phone },
    },
  });
  if (sameName) {
    try {
      await cloudDb.customer.update({ where: { id: cloudCustomer.id }, data: { id: sameName.id } });
    } catch (err) {
      console.warn(
        `Could not re-key cloud customer ${cloudCustomer.id} to ${sameName.id}:`,
        err instanceof Error ? err.message : err,
      );
    }
    return sameName.id;
  }

  await localDb.customer.create({ data: cloudCustomer });
  return cloudCustomer.id;
}

async function syncReservations(restaurantId: string, since: Date, now: Date): Promise<number> {
  const cloudReservations = await cloudDb.reservation.findMany({
    where: { restaurantId, createdByCallId: { not: null }, createdAt: { gt: since } },
  });
  if (cloudReservations.length === 0) return 0;

  const existing = new Set(
    (
      await localDb.reservation.findMany({
        where: { id: { in: cloudReservations.map((r) => r.id) } },
        select: { id: true },
      })
    ).map((r) => r.id),
  );

  let failures = 0;
  for (const reservation of cloudReservations) {
    if (existing.has(reservation.id)) continue;
    try {
      if (reservation.createdByCallId) await ensureCall(reservation.createdByCallId);
      const customerId = await resolveCustomer(reservation.customerId);
      const tableExists =
        reservation.tableId &&
        (await localDb.table.findUnique({ where: { id: reservation.tableId }, select: { id: true } }));

      await localDb.reservation.create({
        data: {
          ...reservation,
          customerId,
          tableId: tableExists ? reservation.tableId : null,
          // Stamped with local arrival time so the in-app "new reservation" toast, which
          // compares against the browser's last poll, doesn't miss a row created earlier
          // in the cloud.
          createdAt: now,
          updatedAt: now,
        },
      });
    } catch (err) {
      failures++;
      console.error(
        `Failed to pull reservation ${reservation.id}:`,
        err instanceof Error ? err.message : err,
      );
    }
  }
  return failures;
}

async function syncBills(restaurantId: string, since: Date, now: Date): Promise<number> {
  const cloudBills = await cloudDb.bill.findMany({
    where: { restaurantId, createdByCallId: { not: null }, openedAt: { gt: since } },
    include: { orders: { include: { items: { include: { optionChoices: true } } } } },
  });
  if (cloudBills.length === 0) return 0;

  const existing = new Set(
    (
      await localDb.bill.findMany({
        where: { id: { in: cloudBills.map((b) => b.id) } },
        select: { id: true },
      })
    ).map((b) => b.id),
  );

  let failures = 0;
  for (const bill of cloudBills) {
    if (existing.has(bill.id)) continue;
    try {
      const { orders, ...billData } = bill;

      const menuItemIds = [...new Set(orders.flatMap((o) => o.items.map((i) => i.menuItemId)))];
      const localMenuItems = await localDb.menuItem.findMany({
        where: { id: { in: menuItemIds } },
        select: { id: true },
      });
      if (localMenuItems.length !== menuItemIds.length) {
        throw new Error("references a menu item that no longer exists locally");
      }

      const choiceIds = orders.flatMap((o) =>
        o.items.flatMap((i) => i.optionChoices.map((c) => c.optionChoiceId).filter((id): id is string => !!id)),
      );
      const localChoiceIds = new Set(
        (
          await localDb.menuItemOptionChoice.findMany({
            where: { id: { in: choiceIds } },
            select: { id: true },
          })
        ).map((c) => c.id),
      );

      if (bill.createdByCallId) await ensureCall(bill.createdByCallId);
      const customerId = bill.customerId ? await resolveCustomer(bill.customerId) : null;
      const tableExists =
        bill.tableId &&
        (await localDb.table.findUnique({ where: { id: bill.tableId }, select: { id: true } }));

      await localDb.bill.create({
        data: {
          ...billData,
          customerId,
          tableId: tableExists ? bill.tableId : null,
          openedAt: now,
          updatedAt: now,
          orders: {
            create: orders.map((order) => ({
              ...omit(omit(order, "billId"), "items"),
              items: {
                create: order.items.map((item) => ({
                  ...omit(omit(item, "orderId"), "optionChoices"),
                  optionChoices: {
                    create: item.optionChoices.map((choice) => ({
                      ...omit(choice, "orderItemId"),
                      optionChoiceId:
                        choice.optionChoiceId && localChoiceIds.has(choice.optionChoiceId)
                          ? choice.optionChoiceId
                          : null,
                    })),
                  },
                })),
              },
            })),
          },
        },
      });
    } catch (err) {
      failures++;
      console.error(`Failed to pull bill ${bill.id}:`, err instanceof Error ? err.message : err);
    }
  }
  return failures;
}

// Booking under a phone number that already exists replaces that customer's name with the
// newest one (same rule the manual and phone booking code uses), so a name the cloud
// service updated must reach the local row too. Newest updatedAt wins.
async function syncCustomerEdits(restaurantId: string): Promise<void> {
  const cloudCustomers = await cloudDb.customer.findMany({ where: { restaurantId } });
  const localById = new Map(
    (await localDb.customer.findMany({ where: { restaurantId } })).map((c) => [c.id, c]),
  );

  for (const cloud of cloudCustomers) {
    const local = localById.get(cloud.id);
    if (local && cloud.updatedAt > local.updatedAt) {
      await localDb.customer.update({
        where: { id: local.id },
        data: { name: cloud.name, notes: cloud.notes },
      });
    }
  }
}

export async function pullPhoneRecords(restaurantId: string): Promise<void> {
  const now = new Date();
  const since = new Date((await getWatermark(restaurantId)).getTime() - OVERLAP_MS);

  await syncCalls(restaurantId, since);
  const failures =
    (await syncReservations(restaurantId, since, now)) + (await syncBills(restaurantId, since, now));
  await syncCustomerEdits(restaurantId);

  // Hold the watermark when something failed, so the same window is retried next cycle.
  if (failures === 0) await setWatermark(restaurantId, now);
}
