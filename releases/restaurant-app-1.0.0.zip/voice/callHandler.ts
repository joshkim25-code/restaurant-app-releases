import type Anthropic from "@anthropic-ai/sdk";
import type { Restaurant, Call, CallMessageRole } from "../src/generated/prisma/client";
import { db } from "./db";
import { anthropic, MODEL, TOOLS, executeTool, transferCallToStaff, type CartLine } from "./claude";
import { formatMoney } from "../src/lib/money";

const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

async function buildMenuText(restaurantId: string, currency: string): Promise<string> {
  const categories = await db.menuCategory.findMany({
    where: { restaurantId },
    orderBy: { sortOrder: "asc" },
    include: {
      items: {
        where: { isAvailable: true, archivedAt: null },
        orderBy: { sortOrder: "asc" },
        include: {
          optionGroups: {
            orderBy: { sortOrder: "asc" },
            include: { choices: { orderBy: { sortOrder: "asc" } } },
          },
        },
      },
    },
  });

  const sections = categories
    .filter((category) => category.items.length > 0)
    .map((category) => {
      const itemLines = category.items.map((item) => {
        const groupsText = item.optionGroups.length
          ? " — options: " +
            item.optionGroups
              .map((group) => {
                const cardinality =
                  group.selectionType === "SINGLE"
                    ? group.isRequired
                      ? "choose exactly 1, required"
                      : "choose 0 or 1"
                    : `choose ${group.minSelect ?? 0}-${group.maxSelect ?? group.choices.length}`;
                const choicesText = group.choices
                  .map(
                    (choice) =>
                      `${choice.name} (id=${choice.id}, ${choice.priceAdjustmentCents >= 0 ? "+" : ""}${formatMoney(choice.priceAdjustmentCents, currency)})`,
                  )
                  .join(", ");
                return `[${group.name} (id=${group.id}, ${cardinality}): ${choicesText}]`;
              })
              .join(" ")
          : "";
        return `- id=${item.id} "${item.name}" — ${formatMoney(item.priceCents, currency)}${groupsText}`;
      });
      return `## ${category.name}\n${itemLines.join("\n")}`;
    });

  return sections.length > 0 ? sections.join("\n\n") : "No menu items are currently available.";
}

export function welcomeGreeting(restaurant: Restaurant): string {
  return restaurant.voiceGreeting || `Thanks for calling ${restaurant.name}, how can I help you?`;
}

async function buildSystemPrompt(restaurant: Restaurant, callerPhone: string): Promise<string> {
  const hours = await db.businessHours.findMany({
    where: { restaurantId: restaurant.id },
    orderBy: { dayOfWeek: "asc" },
  });
  const hoursText = hours.length
    ? hours
        .map((h) => `${DAY_NAMES[h.dayOfWeek]}: ${h.isClosed ? "closed" : `${h.openTime}-${h.closeTime}`}`)
        .join(", ")
    : "not configured — do not guess, ask the caller to call back during business hours if unsure";

  const menuText = await buildMenuText(restaurant.id, restaurant.currency);
  const now = new Date();

  return [
    `You are the phone assistant for ${restaurant.name}, answering an incoming phone call. You can take table reservations and takeaway phone orders.`,
    `Speak naturally and briefly, like a host answering the phone — not like a chatbot. One or two sentences per turn.`,
    `Today's date is ${now.toISOString().slice(0, 10)} (${DAY_NAMES[now.getDay()]}).`,
    `Business hours: ${hoursText}.`,
    `Reservations accepted for party sizes ${restaurant.minPartySize}-${restaurant.maxPartySize}, up to ${restaurant.bookingWindowDays} days in advance.`,
    restaurant.cancellationPolicy ? `Cancellation policy: ${restaurant.cancellationPolicy}.` : "",
    `The caller's phone number is already known from caller ID: ${callerPhone}. Don't ask for it — only ask for a different number if they explicitly want confirmation/contact sent elsewhere.`,
    `--- Reservations ---`,
    `Collect the caller's name, party size, and desired date/time. Use check_availability before promising a time.`,
    `Confirm all details back to the caller before calling create_reservation, including reading back the phone number that will be used, so they can correct it if it's wrong. If create_reservation fails, explain why in plain language and offer to try a different time.`,
    `--- Takeaway orders ---`,
    `Current menu (only available items are listed; item/option/choice ids are real — copy them exactly, never invent one):`,
    menuText,
    `Use add_item_to_order as the caller orders each item, remove_item_from_order to correct mistakes, and get_current_order if you need to double check what's been added. Item subtotals do not include tax — mention that the final total (given by finalize_order) includes tax.`,
    `Before calling finalize_order, read back every item and the subtotal and get explicit confirmation. Payment happens at pickup (cash or card in person) — never ask for card details over the phone. Give a vague pickup timing ("we'll have it ready soon, staff will confirm timing") unless the restaurant's instructions below say otherwise.`,
    `If the caller mentions a pickup time request, an allergy, or anything else staff need to see that isn't a per-item note, pass it in finalize_order's notes field.`,
    `--- Other ---`,
    `If the caller asks to speak to a real person, wants to change or ask about an order/reservation already placed, or seems frustrated with you, offer to connect them and then call transfer_to_staff.`,
    `Callers are often in noisy places. If what was transcribed looks like background noise or is unclear, ask them to repeat instead of guessing. If one of your earlier messages is marked as interrupted, the caller only heard the part before the marker — briefly repeat only what matters that they missed (a question you asked, a total, a time).`,
    `The caller has already been greeted automatically with: "${welcomeGreeting(restaurant)}" — never greet them again; respond directly to what they say.`,
    `When the conversation is naturally finished, say your goodbye and call end_call. If the restaurant's instructions below specify how to end the call, that exact wording is your goodbye.`,
    restaurant.voiceAssistantInstructions
      ? `Restaurant instructions — the owner wrote these, and they take priority over any general guidance above wherever they conflict (including how to word greetings and goodbyes). Follow them exactly:\n${restaurant.voiceAssistantInstructions}`
      : "",
  ]
    .filter(Boolean)
    .join("\n");
}

async function persistMessage(
  callId: string,
  role: CallMessageRole,
  content: string,
  extra?: { toolName?: string; toolInput?: unknown; toolResult?: unknown },
) {
  await db.callMessage.create({
    data: {
      callId,
      role,
      content,
      toolName: extra?.toolName,
      toolInput: extra?.toolInput === undefined ? undefined : (extra.toolInput as object),
      toolResult: extra?.toolResult === undefined ? undefined : (extra.toolResult as object),
    },
  });
}

export class CallSession {
  private history: Anthropic.MessageParam[] = [];
  // In-progress takeaway order, built up across several tool calls and only written to
  // the database once, on finalize_order — mirrors OrderCart.tsx's client-side cart.
  private cart: CartLine[] = [];

  private constructor(
    private restaurant: Restaurant,
    private call: Call,
    private systemPrompt: string,
    private sendToTwilio: (message: Record<string, unknown>) => void,
  ) {}

  static async create(
    restaurant: Restaurant,
    call: Call,
    sendToTwilio: (message: Record<string, unknown>) => void,
  ): Promise<CallSession> {
    const systemPrompt = await buildSystemPrompt(restaurant, call.fromPhoneNumber);
    return new CallSession(restaurant, call, systemPrompt, sendToTwilio);
  }

  // The caller cut the AI off mid-sentence: record only what they actually heard, so the model
  // doesn't assume its whole last reply landed.
  handleInterrupt(spokenSoFar: string): void {
    const last = this.history[this.history.length - 1];
    if (!last || last.role !== "assistant" || typeof last.content === "string") return;
    if (last.content.some((block) => block.type !== "text")) return;

    const heard = spokenSoFar.trim();
    this.history[this.history.length - 1] = {
      role: "assistant",
      content: heard
        ? `${heard} [the caller interrupted here; the rest was not heard]`
        : "[the caller interrupted before any of this reply was heard]",
    };
  }

  async handlePrompt(voicePrompt: string): Promise<void> {
    await persistMessage(this.call.id, "USER", voicePrompt);
    this.history.push({ role: "user", content: voicePrompt });

    // Guard against a runaway tool-calling loop. Bumped from the original 5 - a single
    // spoken order ("a burger, fries, a coke, and an ice cream") can reasonably need
    // more tool-call rounds than a reservation ever does.
    for (let iteration = 0; iteration < 8; iteration++) {
      const response = await anthropic.messages.create({
        model: MODEL,
        max_tokens: 1024,
        system: this.systemPrompt,
        tools: TOOLS,
        messages: this.history,
      });

      this.history.push({ role: "assistant", content: response.content });

      const toolUseBlocks = response.content.filter(
        (block): block is Anthropic.ToolUseBlock => block.type === "tool_use",
      );

      if (toolUseBlocks.length === 0) {
        const text = response.content
          .filter((block): block is Anthropic.TextBlock => block.type === "text")
          .map((block) => block.text)
          .join(" ")
          .trim();
        // Claude can occasionally return no text and no tool call at all - without this,
        // the caller was left in total silence with nothing said and nothing persisted.
        await this.speak(text || "Sorry, could you say that again?");
        return;
      }

      let shouldEndCall = false;
      let shouldTransfer = false;
      const toolResults: Anthropic.ToolResultBlockParam[] = [];
      for (const toolUse of toolUseBlocks) {
        const { result, endCall, transfer } = await executeTool(
          toolUse.name,
          toolUse.input as Record<string, unknown>,
          { restaurant: this.restaurant, callId: this.call.id, callerPhone: this.call.fromPhoneNumber, cart: this.cart },
        );
        await persistMessage(this.call.id, "TOOL", toolUse.name, {
          toolName: toolUse.name,
          toolInput: toolUse.input,
          toolResult: result,
        });
        if (endCall) shouldEndCall = true;
        if (transfer) shouldTransfer = true;
        toolResults.push({
          type: "tool_result",
          tool_use_id: toolUse.id,
          content: JSON.stringify(result),
        });
      }
      this.history.push({ role: "user", content: toolResults });

      if (shouldEndCall || shouldTransfer) {
        // Let the model produce one more line (goodbye, or a transition line before
        // transferring) on the next loop iteration, then apply the side effect.
        const finalResponse = await anthropic.messages.create({
          model: MODEL,
          max_tokens: 1024,
          system: this.systemPrompt,
          tools: TOOLS,
          messages: this.history,
        });
        const text = finalResponse.content
          .filter((block): block is Anthropic.TextBlock => block.type === "text")
          .map((block) => block.text)
          .join(" ")
          .trim();
        if (text) {
          await this.speak(text);
        }

        if (shouldTransfer) {
          // The REST redirect below tears down the ConversationRelay WebSocket itself,
          // so no {type:"end"} here - sending one would just race the teardown.
          await transferCallToStaff(this.call.twilioCallSid, this.restaurant.fallbackPhoneNumber!);
          await db.call.update({
            where: { id: this.call.id },
            data: { status: "TRANSFERRED", endedAt: new Date() },
          });
        } else {
          this.sendToTwilio({ type: "end" });
        }
        return;
      }
    }

    // Hit the iteration cap without ever producing a final reply (e.g. stuck retrying
    // tool calls) - say something rather than leaving the caller in dead air.
    await this.speak("Sorry, I'm having trouble with that — could you tell me again what you'd like?");
  }

  private async speak(text: string): Promise<void> {
    await persistMessage(this.call.id, "ASSISTANT", text);
    this.sendToTwilio({ type: "text", token: text, last: true });
  }
}
