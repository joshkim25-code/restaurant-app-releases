import Anthropic from "@anthropic-ai/sdk";
import twilio from "twilio";
import crypto from "node:crypto";
import type { Restaurant } from "../src/generated/prisma/client";
import { findAvailableTable, createReservationFromCall, reservationWindowMinutes } from "../src/lib/reservations";
import {
  validateAndPriceItem,
  getMenuItemWithOptions,
  createOrderFromCall,
} from "../src/lib/orders";
import type { CartItemInput, CartSelectionInput } from "../src/lib/orderTypes";
import { zonedDateTimeToUtc } from "../src/lib/time";

const apiKey = process.env.ANTHROPIC_API_KEY;
if (!apiKey) {
  throw new Error("ANTHROPIC_API_KEY is not set.");
}

export const anthropic = new Anthropic({ apiKey });
export const MODEL = process.env.LLM_MODEL || "claude-sonnet-5";

const twilioClient =
  process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN
    ? twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN)
    : null;

export async function transferCallToStaff(twilioCallSid: string, staffNumber: string): Promise<void> {
  if (!twilioClient) {
    throw new Error("Twilio REST client not configured.");
  }
  const twiml = `<Response><Say>Connecting you now, please hold.</Say><Dial>${staffNumber}</Dial></Response>`;
  await twilioClient.calls(twilioCallSid).update({ twiml });
}

export const TOOLS: Anthropic.Tool[] = [
  {
    name: "check_availability",
    description:
      "Check whether a table is free for a given party size, date, and time. Does not book anything.",
    input_schema: {
      type: "object",
      properties: {
        partySize: { type: "integer", description: "Number of guests." },
        date: { type: "string", description: "Date in YYYY-MM-DD format." },
        time: { type: "string", description: "24-hour time in HH:MM format." },
      },
      required: ["partySize", "date", "time"],
    },
  },
  {
    name: "create_reservation",
    description:
      "Book a table reservation. Only call this after confirming the details with the caller, including reading the date, time, and party size back to them.",
    input_schema: {
      type: "object",
      properties: {
        name: { type: "string", description: "Name the reservation should be under." },
        phone: {
          type: "string",
          description:
            "Only needed if the caller wants confirmation sent to a different number than the one they're calling from — otherwise omit it and the caller's number is used automatically.",
        },
        partySize: { type: "integer", description: "Number of guests." },
        date: { type: "string", description: "Date in YYYY-MM-DD format." },
        time: { type: "string", description: "24-hour time in HH:MM format." },
        specialRequests: { type: "string", description: "Optional notes (allergies, occasion, seating preference)." },
      },
      required: ["name", "partySize", "date", "time"],
    },
  },
  {
    name: "end_call",
    description: "End the phone call. Call this once the conversation is naturally finished.",
    input_schema: { type: "object", properties: {} },
  },
  {
    name: "transfer_to_staff",
    description:
      "Transfer the call to a real staff member. Use when the caller explicitly asks for a person, has a request outside reservations or ordering (complaints, existing-order changes), or is getting frustrated with the automated system.",
    input_schema: { type: "object", properties: {} },
  },
  {
    name: "add_item_to_order",
    description:
      "Add one menu item to the caller's takeaway order. Use the exact item id from the menu listing in your instructions - never invent one. Returns the running order and subtotal so far (subtotal excludes tax, which is added at the end).",
    input_schema: {
      type: "object",
      properties: {
        menuItemId: { type: "string", description: "The item's id, copied exactly from the menu listing." },
        quantity: { type: "integer", description: "How many of this item." },
        selections: {
          type: "array",
          description: "One entry per option group this item has, if any.",
          items: {
            type: "object",
            properties: {
              groupId: { type: "string", description: "The option group's id, from the menu listing." },
              choiceIds: { type: "array", items: { type: "string" }, description: "Chosen choice id(s) within that group." },
            },
            required: ["groupId", "choiceIds"],
          },
        },
        notes: { type: "string", description: "Optional free-text note for this item, e.g. \"no onions\"." },
      },
      required: ["menuItemId", "quantity"],
    },
  },
  {
    name: "remove_item_from_order",
    description: "Remove one item from the caller's in-progress takeaway order, by its lineId.",
    input_schema: {
      type: "object",
      properties: {
        lineId: { type: "string", description: "The lineId returned when the item was added." },
      },
      required: ["lineId"],
    },
  },
  {
    name: "get_current_order",
    description: "Get everything currently in the caller's takeaway order and the running subtotal, before finalizing.",
    input_schema: { type: "object", properties: {} },
  },
  {
    name: "finalize_order",
    description:
      "Submit the caller's takeaway order for real. Only call this after reading back every item and the subtotal and getting explicit confirmation. Payment happens at pickup, not over the phone - never ask for card details.",
    input_schema: {
      type: "object",
      properties: {
        name: { type: "string", description: "Name the order should be under." },
        phone: {
          type: "string",
          description:
            "Only needed if the caller wants a different contact number than the one they're calling from — otherwise omit it.",
        },
        notes: {
          type: "string",
          description:
            "Any special request the caller mentioned that isn't captured by a per-item note — a requested pickup time (\"in an hour\"), an allergy warning, anything staff need to see.",
        },
      },
      required: ["name"],
    },
  },
];

// The caller means this date/time in the restaurant's own timezone, not whatever
// timezone the server process happens to be running in (Railway runs in UTC).
function parseDateTime(date: unknown, time: unknown, timezone: string): Date {
  return zonedDateTimeToUtc(`${String(date)}T${String(time)}`, timezone);
}

export interface CartLine {
  lineId: string;
  menuItemId: string;
  name: string;
  quantity: number;
  notes: string;
  selections: CartSelectionInput[];
  unitPriceCentsAtOrder: number;
  optionChoiceSummaries: string[];
  lineTotalCents: number;
}

export interface ToolExecutionContext {
  restaurant: Restaurant;
  callId: string;
  callerPhone: string;
  cart: CartLine[];
}

const PHONE_NUMBER_PATTERN = /^\+?[0-9][0-9\s-]{6,}$/;

export interface ToolExecutionResult {
  result: unknown;
  endCall: boolean;
  transfer?: boolean;
}

export async function executeTool(
  name: string,
  input: Record<string, unknown>,
  ctx: ToolExecutionContext,
): Promise<ToolExecutionResult> {
  switch (name) {
    case "check_availability": {
      const startTime = parseDateTime(input.date, input.time, ctx.restaurant.timezone);
      if (Number.isNaN(startTime.getTime())) {
        return { result: { available: false, reason: "Invalid date or time." }, endCall: false };
      }
      const windowMinutes = reservationWindowMinutes(ctx.restaurant);
      const table = await findAvailableTable(
        ctx.restaurant.id,
        Number(input.partySize),
        startTime,
        windowMinutes,
      );
      return {
        result: table ? { available: true } : { available: false, reason: "No table free at that time." },
        endCall: false,
      };
    }
    case "create_reservation": {
      const phone = input.phone ? String(input.phone) : ctx.callerPhone;
      if (!PHONE_NUMBER_PATTERN.test(phone)) {
        return {
          result: { ok: false, reason: "No valid phone number available — ask the caller for one and pass it explicitly." },
          endCall: false,
        };
      }
      const startTime = parseDateTime(input.date, input.time, ctx.restaurant.timezone);
      const outcome = await createReservationFromCall({
        restaurant: ctx.restaurant,
        callId: ctx.callId,
        name: String(input.name ?? ""),
        phone,
        partySize: Number(input.partySize),
        startTime,
        specialRequests: input.specialRequests ? String(input.specialRequests) : null,
      });
      return { result: outcome, endCall: false };
    }
    case "end_call": {
      return { result: { ok: true }, endCall: true };
    }
    case "transfer_to_staff": {
      if (!ctx.restaurant.fallbackPhoneNumber) {
        return {
          result: { ok: false, reason: "No staff number configured — apologize and keep helping directly." },
          endCall: false,
        };
      }
      return { result: { ok: true }, endCall: false, transfer: true };
    }
    case "add_item_to_order": {
      const menuItem = await getMenuItemWithOptions(ctx.restaurant.id, String(input.menuItemId ?? ""));
      if (!menuItem) {
        return { result: { ok: false, reason: "Menu item not found — check the id and try again." }, endCall: false };
      }
      const selections = Array.isArray(input.selections) ? (input.selections as CartSelectionInput[]) : [];
      try {
        const validated = validateAndPriceItem(menuItem, {
          quantity: Number(input.quantity ?? 1),
          notes: input.notes ? String(input.notes) : "",
          selections,
        });
        const line: CartLine = {
          lineId: crypto.randomUUID(),
          menuItemId: menuItem.id,
          name: menuItem.name,
          quantity: validated.quantity,
          notes: validated.notes ?? "",
          selections,
          unitPriceCentsAtOrder: validated.unitPriceCentsAtOrder,
          optionChoiceSummaries: validated.optionChoices.map((c) => c.choiceNameAtOrder),
          lineTotalCents: validated.lineTotalCents,
        };
        ctx.cart.push(line);
        return {
          result: {
            ok: true,
            lineId: line.lineId,
            added: { name: line.name, quantity: line.quantity, lineTotalCents: line.lineTotalCents },
            cartSubtotalCents: ctx.cart.reduce((sum, l) => sum + l.lineTotalCents, 0),
          },
          endCall: false,
        };
      } catch (err) {
        return {
          result: { ok: false, reason: err instanceof Error ? err.message : "Could not add item." },
          endCall: false,
        };
      }
    }
    case "remove_item_from_order": {
      const lineId = String(input.lineId ?? "");
      const idx = ctx.cart.findIndex((l) => l.lineId === lineId);
      if (idx === -1) {
        return { result: { ok: false, reason: "No such item in the current order." }, endCall: false };
      }
      const [removed] = ctx.cart.splice(idx, 1);
      return {
        result: {
          ok: true,
          removed: removed.name,
          cartSubtotalCents: ctx.cart.reduce((sum, l) => sum + l.lineTotalCents, 0),
        },
        endCall: false,
      };
    }
    case "get_current_order": {
      return {
        result: {
          items: ctx.cart.map((l) => ({
            lineId: l.lineId,
            name: l.name,
            quantity: l.quantity,
            options: l.optionChoiceSummaries,
            notes: l.notes || undefined,
            lineTotalCents: l.lineTotalCents,
          })),
          subtotalCents: ctx.cart.reduce((sum, l) => sum + l.lineTotalCents, 0),
        },
        endCall: false,
      };
    }
    case "finalize_order": {
      if (ctx.cart.length === 0) {
        return { result: { ok: false, reason: "No items have been added yet." }, endCall: false };
      }
      const phone = input.phone ? String(input.phone) : ctx.callerPhone;
      if (!PHONE_NUMBER_PATTERN.test(phone)) {
        return {
          result: { ok: false, reason: "No valid phone number available — ask the caller for one and pass it explicitly." },
          endCall: false,
        };
      }
      const items: CartItemInput[] = ctx.cart.map((l) => ({
        menuItemId: l.menuItemId,
        quantity: l.quantity,
        notes: l.notes,
        selections: l.selections,
      }));
      const outcome = await createOrderFromCall({
        restaurant: ctx.restaurant,
        callId: ctx.callId,
        name: String(input.name ?? ""),
        phone,
        items,
        takeawayNote: input.notes ? String(input.notes) : undefined,
      });
      if (outcome.ok) {
        ctx.cart.length = 0;
      }
      return { result: outcome, endCall: false };
    }
    default:
      return { result: { error: `Unknown tool: ${name}` }, endCall: false };
  }
}
