// Standalone process — constructs its own PrismaClient rather than importing
// src/lib/db.ts's app singleton, same reasoning as sync/db.ts.
import { PrismaClient } from "../src/generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";

const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
  throw new Error("DATABASE_URL is not set.");
}

export const db = new PrismaClient({ adapter: new PrismaPg({ connectionString }) });
