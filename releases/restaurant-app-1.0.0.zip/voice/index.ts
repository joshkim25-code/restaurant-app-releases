// The AI phone-reservation server. Run from the repo root with `npm run voice` (or
// `npx tsx -r dotenv/config voice/index.ts`). Handles Twilio's incoming-call webhook
// (returns TwiML connecting the call to ConversationRelay) and the ConversationRelay
// WebSocket itself (caller speech in, Claude's spoken responses out), reusing the same
// reservation logic and local database as the main app — see the plan this came from.
import http from "node:http";
import twilio from "twilio";
import { WebSocketServer, type WebSocket } from "ws";
import { db } from "./db";
import { CallSession, welcomeGreeting } from "./callHandler";
import { getVoicePresetConfig } from "../src/lib/voicePresets";
import type { Restaurant } from "../src/generated/prisma/client";

// A call that ends this quickly with no booking is almost certainly a hang-up before
// any real conversation happened, not a genuine (if bookingless) interaction.
const ABANDONED_THRESHOLD_SECONDS = 10;

// Documented camelCase names - the SDK's types spell ignoreBackchannel lowercase, which Twilio silently ignores.
function interruptionAttributes(restaurant: Restaurant) {
  return {
    interruptSensitivity: restaurant.voiceInterruptSensitivity.toLowerCase(),
    ignoreBackchannel: "true",
  };
}

const PORT = Number(process.env.PORT ?? process.env.VOICE_PORT ?? 3100);
const PUBLIC_URL = (process.env.VOICE_PUBLIC_URL ?? `http://localhost:${PORT}`).replace(/\/$/, "");
const AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN;

if (!AUTH_TOKEN) {
  console.error("TWILIO_AUTH_TOKEN is not set.");
  process.exit(1);
}

function wsUrl(): string {
  return PUBLIC_URL.replace(/^http/, "ws") + "/voice/stream";
}

async function readBody(req: http.IncomingMessage): Promise<string> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) chunks.push(chunk as Buffer);
  return Buffer.concat(chunks).toString("utf8");
}

async function handleIncomingCall(req: http.IncomingMessage, res: http.ServerResponse) {
  const bodyText = await readBody(req);
  const params = Object.fromEntries(new URLSearchParams(bodyText));

  const signature = req.headers["x-twilio-signature"];
  const valid =
    typeof signature === "string" &&
    twilio.validateRequest(AUTH_TOKEN!, signature, `${PUBLIC_URL}/voice/incoming`, params);
  if (!valid) {
    console.warn(`Rejected incoming call with invalid Twilio signature (To: ${params.To ?? "unknown"})`);
    res.writeHead(403).end("Invalid signature");
    return;
  }

  const to = params.To ?? "";
  const from = params.From ?? "";
  const callSid = params.CallSid ?? "";

  const restaurant = await db.restaurant.findUnique({ where: { twilioPhoneNumber: to } });

  const twiml = new twilio.twiml.VoiceResponse();
  if (!restaurant) {
    console.warn(`Rejected incoming call to unregistered number ${to} (from ${from})`);
    twiml.say("This number isn't set up for reservations yet. Goodbye.");
    twiml.hangup();
    res.writeHead(200, { "Content-Type": "text/xml" }).end(twiml.toString());
    return;
  }

  if (!restaurant.voiceAcceptCalls) {
    // Owner switched the AI off: ring the staff phone if there is one, and if nobody picks up
    // (or there's no number) play a message - the caller is never left on a dead line.
    const staffNumber = restaurant.fallbackPhoneNumber?.trim() || null;
    if (staffNumber) twiml.dial({ timeout: 25 }, staffNumber);
    twiml.say("Sorry, we can't take your call right now. Please try again later.");
    twiml.hangup();

    await db.call.create({
      data: {
        restaurantId: restaurant.id,
        twilioCallSid: callSid,
        fromPhoneNumber: from,
        status: staffNumber ? "TRANSFERRED" : "COMPLETED",
        endedAt: new Date(),
      },
    });
    res.writeHead(200, { "Content-Type": "text/xml" }).end(twiml.toString());
    return;
  }

  await db.call.create({
    data: { restaurantId: restaurant.id, twilioCallSid: callSid, fromPhoneNumber: from, status: "IN_PROGRESS" },
  });

  const connect = twiml.connect();
  connect.conversationRelay({
    url: wsUrl(),
    welcomeGreeting: welcomeGreeting(restaurant),
    ...interruptionAttributes(restaurant),
    ...(getVoicePresetConfig(restaurant.voicePreset) ?? {}),
  });

  res.writeHead(200, { "Content-Type": "text/xml" }).end(twiml.toString());
}

const server = http.createServer((req, res) => {
  if (req.method === "POST" && req.url === "/voice/incoming") {
    handleIncomingCall(req, res).catch((err) => {
      console.error("Error handling incoming call:", err);
      res.writeHead(500).end("Internal error");
    });
    return;
  }
  res.writeHead(404).end();
});

const wss = new WebSocketServer({ noServer: true });

server.on("upgrade", (req, socket, head) => {
  if (req.url !== "/voice/stream") {
    socket.destroy();
    return;
  }
  wss.handleUpgrade(req, socket, head, (ws) => wss.emit("connection", ws, req));
});

wss.on("connection", (ws: WebSocket) => {
  let session: CallSession | null = null;
  let callId: string | null = null;

  ws.on("message", (raw) => {
    (async () => {
      const message = JSON.parse(raw.toString());

      switch (message.type) {
        case "setup": {
          const call = await db.call.findUnique({ where: { twilioCallSid: message.callSid } });
          if (!call) {
            console.error(`No Call row for callSid ${message.callSid}`);
            ws.close();
            return;
          }
          const restaurant = await db.restaurant.findUnique({ where: { id: call.restaurantId } });
          if (!restaurant) {
            ws.close();
            return;
          }
          callId = call.id;
          session = await CallSession.create(restaurant, call, (payload) =>
            ws.send(JSON.stringify(payload)),
          );
          return;
        }
        case "prompt": {
          if (session && message.last) {
            await session.handlePrompt(String(message.voicePrompt ?? ""));
          }
          return;
        }
        case "interrupt": {
          session?.handleInterrupt(String(message.utteranceUntilInterrupt ?? ""));
          return;
        }
        case "error": {
          console.error("ConversationRelay error:", message.description);
          if (callId) {
            await db.call.update({ where: { id: callId }, data: { status: "FAILED", endedAt: new Date() } });
          }
          return;
        }
        default:
          return;
      }
    })().catch((err) => console.error("Error handling voice message:", err));
  });

  ws.on("close", () => {
    const id = callId;
    if (!id) return;
    (async () => {
      const call = await db.call.findUnique({ where: { id }, include: { reservation: true } });
      // A prior "error" message already marked this FAILED - Twilio closes the socket
      // right after, so don't let that get clobbered back to COMPLETED here.
      if (!call || call.status !== "IN_PROGRESS") return;

      const durationSeconds = (Date.now() - call.startedAt.getTime()) / 1000;
      const abandoned = !call.reservation && durationSeconds < ABANDONED_THRESHOLD_SECONDS;

      await db.call.update({
        where: { id },
        data: { status: abandoned ? "ABANDONED" : "COMPLETED", endedAt: new Date() },
      });
    })().catch((err) => console.error("Error closing call:", err));
  });
});

server.listen(PORT, () => {
  console.log(`Voice server listening on port ${PORT} (public: ${PUBLIC_URL})`);
});
