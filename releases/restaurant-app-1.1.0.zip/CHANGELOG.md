# Changelog

All notable changes to this app are recorded here. This is also what the planned
auto-updating launcher reads (via each release's `version.json`) to decide whether a newer
version is available and what changed.

Versions follow [Semantic Versioning](https://semver.org/): `MAJOR.MINOR.PATCH`.

## [1.1.0] - 2026-09-23

- A new restaurant created via `/onboarding` now gets its print agent connection token
  (`agentToken`) generated automatically, instead of needing someone to find Settings →
  Receipts and click "Generate" by hand before printing works.
- The dashboard shows a one-time welcome banner right after onboarding, pointing at what's
  optional to finish setting up (Twilio/Anthropic keys for AI phone reservations) versus
  what already works out of the box.

## [1.0.0] - 2026-09-23

First version-tracked release. The app had been under active development for a while before
this point without formal versioning; `1.0.0` marks the baseline this restaurant is opening
on, and the point real versioning/release tracking starts (needed as the foundation for the
planned auto-updating launcher - see `launcher/README.md`).

Highlights as of this baseline: table/order/billing management, reservations, an AI phone
reservation line (Twilio + Claude), receipt/kitchen-ticket printing (USB and network thermal
printers, including image-rendered fallback for characters outside the printer's character
set), a drag-and-drop menu editor, tip/discount/service-charge tracking, and a local-primary
architecture (per-restaurant local Postgres + Windows Services, with a background sync to a
cloud backup database).
