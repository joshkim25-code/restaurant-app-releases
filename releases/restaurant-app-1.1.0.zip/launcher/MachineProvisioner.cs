using System.Diagnostics;

namespace RestaurantLauncher;

/// <summary>
/// Runs scripts/provision-machine.ps1 elevated, the same way UpdateApplier runs
/// apply-update.ps1 - only this step (and the update-apply step) ever needs admin rights;
/// normal day-to-day launching doesn't.
/// </summary>
public static class MachineProvisioner
{
    public static async Task<bool> ProvisionAsync(LauncherConfig config, string exeDirectory)
    {
        var scriptPath = Path.Combine(exeDirectory, "scripts", "provision-machine.ps1");
        if (!File.Exists(scriptPath))
        {
            throw new FileNotFoundException($"Provisioning script not found at {scriptPath} - reinstall the launcher.");
        }

        var arguments = string.Join(' ', new[]
        {
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", Quote(scriptPath),
            "-ManifestUrl", Quote(config.ManifestUrl),
            "-InstallDir", Quote(config.InstallDir),
        });

        var psi = new ProcessStartInfo
        {
            FileName = "powershell.exe",
            Arguments = arguments,
            UseShellExecute = true,
            Verb = "runas",
        };

        return await Task.Run(() =>
        {
            using var process = Process.Start(psi);
            if (process is null) return false;
            process.WaitForExit();
            return process.ExitCode == 0;
        });
    }

    private static string Quote(string value) => $"\"{value}\"";
}
