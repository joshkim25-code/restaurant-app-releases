# Restaurant App Launcher

A small Windows desktop launcher, modeled on how the Riot Client works for League of Legends:
it makes sure the app's services are running (or sets them up from scratch on a blank
machine), checks for and applies updates automatically, then opens the app behind its
existing login. This covers **Phase 1 and Phase 2** of turning the restaurant app into a
distributable product other restaurants can run independently — see the full phased roadmap
this came out of for what's still deliberately deferred (licensing, a real onboarding wizard,
a real distribution-grade code-signing certificate, etc.).

## What this is (and isn't)

- **Is**: a thin WebView2 window around the app, plus an update-check-and-apply flow, plus
  (Phase 2) a from-scratch installer for a machine that has none of it yet.
- **Isn't**: its own auth system. The app's existing magic-link login
  (`src/app/login/`, `src/proxy.ts`) already gates the entire app server-side — the launcher
  just opens a browser view at it. There's nothing to keep in sync between "the launcher's
  login" and "the app's login" because they're the same login.
- **Isn't**: a restaurant-onboarding tool. Phase 2 gets a blank machine to a running,
  logged-out app; creating an actual restaurant still goes through the app's own existing
  `/onboarding` flow after that — see "Phase 2" below for why that boundary is where it is.

## Why WebView2, not Electron

Windows 11 ships the WebView2 runtime as an evergreen component (already confirmed present
on this machine), so a self-contained `dotnet publish` gives a real Chromium-grade renderer —
the app looks and behaves exactly as it does in a browser today — without bundling a second
copy of Chromium the way Electron would. It also avoids adding a whole second packaging
pipeline (`electron-builder`, its own signing/notarization) to a repo that has none today.

**Measured, not estimated** (built and published on 2026-09-23): the self-contained
single-file exe is **~155MB**. That's the full .NET runtime bundled in so the target machine
needs nothing pre-installed beyond WebView2 (which Windows 11 already has) — not a browser
engine, unlike Electron's bundle, which is the actual architectural difference this section's
size comparison is about, not raw byte count (Electron apps commonly land in a similar or
larger range once Chromium + Node are included). If install size becomes worth optimizing
later, two independent levers exist without changing the approach: framework-dependent
deployment (`SelfContained=false`, a few MB, but then the target machine needs the .NET 8
runtime installed too) or trimming (`PublishTrimmed`) — not attempted here since WinForms
trimming support is limited/risky and not worth the complexity for Phase 1. Neither is needed
for this phase; noted for Phase 5 (distribution polish) if it matters by then.
Electron's auto-updater ecosystem (`electron-updater`/Squirrel) isn't actually the right fit
here anyway: updating *this* app means stopping 3 Windows Services, replacing a Next.js
build, and running Prisma migrations against a live local Postgres — that orchestration is
bespoke regardless of launcher technology (see `scripts/apply-update.ps1`).

## Layout

```
launcher/
  RestaurantLauncher.csproj   Project file (net8.0-windows, self-contained win-x64)
  Program.cs                  Entry point
  MainForm.cs                 The one window: startup sequence + WebView2 host
  ServiceSupervisor.cs        Starts core services if stopped; app health-check polling
  UpdateChecker.cs            Fetches the release manifest, compares versions
  UpdateManifest.cs           version.json shape
  UpdateApplier.cs            Runs apply-update.ps1 elevated (only step that needs admin)
  MachineProvisioner.cs       Runs provision-machine.ps1 elevated (fresh-machine setup)
  LauncherConfig.cs           Optional launcher.config.json override (manifest URL, etc.)
  SemVer.cs                   Minimal MAJOR.MINOR.PATCH comparison
  scripts/apply-update.ps1        stop -> backup -> replace -> migrate -> restart flow
  scripts/provision-machine.ps1   Node/Postgres/services from nothing, on a blank machine
  scripts/lib/install-app.ps1     Shared unpack -> deps -> build helpers (both scripts above)
  scripts/sign-launcher.ps1       Dev-machine code-signing workaround (see "Code signing")
  tools/nssm.exe                  Bundled so provisioning never depends on WinGet
  release-manifest.example.json
```

## Building

Requires the .NET 8 SDK (not installed in the environment this was scaffolded in — install
with `winget install Microsoft.DotNet.SDK.8` if `dotnet --version` doesn't work yet).

```
cd launcher
dotnet restore
dotnet build
```

To produce the actual distributable single-file exe:

```
dotnet publish -c Release -r win-x64 --self-contained
```

**Status (2026-09-23):**
- Builds and publishes cleanly: `dotnet restore`/`build`/`publish -c Release -r win-x64
  --self-contained` all succeed with 0 errors (.NET 8 SDK 8.0.425; one benign `MSB3277`
  warning - the WebView2 package ships both WinForms and WPF assembly variants, only
  WinForms is actually used at runtime). Published exe is ~155MB (self-contained .NET
  runtime, not a bundled browser - see "Why WebView2, not Electron" above).
- **Run and verified, end-to-end, against this restaurant's real machine** (no second
  machine was available, so this became the de facto test target for the *non-destructive*
  parts only - see caveat below): launches cleanly, starts core services (were already
  running), opens a real WebView2 window at the app, shows the existing login page, and a
  real magic-link login completed through the window. Verified headlessly (no screen access
  in that session) by reading the actual `restaurant_session` cookie out of WebView2's own
  SQLite cookie store (`%LOCALAPPDATA%\RestaurantApp\WebView2\EBWebView\Default\Network\
  Cookies`) - confirmed a real 60-day expiry once the app was rebuilt with the `maxAge` fix
  (it initially showed iron-session's 14-day *default*, because the running production
  build hadn't been rebuilt yet - not a flaw in the fix itself, see `src/lib/
  session-options.ts`). Then closed and relaunched the actual desktop shortcut: landed
  straight on the dashboard, no re-login needed - the core "stays logged in" promise works.
- **The update-apply path is now proven too** (`scripts/apply-update.ps1`, the piece that
  stops services, replaces the install directory, and runs migrations - previously the
  highest-risk untested part). No second machine was available, so instead of pointing it at
  the live install, a reusable harness (`scripts/test-update-flow.ps1` /
  `test-update-flow.bat`) sets up one fully isolated, disposable install on this same
  machine - own directory (`C:\ProgramData\RestaurantApp-test\app`), own Postgres database
  (`restaurant_test`), own temporary Windows Services (`RestaurantAppTest`/etc.), own port
  (3100) - and runs the real, unmodified script against *that*. Both paths genuinely pass:
  - **Happy path**: stop -> backup -> replace -> `npm ci` -> `prisma generate` -> build ->
    `prisma migrate deploy` -> restart -> health check -> cleanup, end to end.
  - **Failure/rollback path**: a release with one deliberately broken migration correctly
    rolls back to the previous version, restarts it successfully, and leaves a clear log -
    exactly what the design promises.

  Getting a *clean* pass took a few real rounds of debugging against real failures (all now
  fixed, kept for the record since they're the kind of thing worth knowing about):
  - `psql` returning zero rows came back as PowerShell `$null`, and `$null.Trim()` threw -
    masked what was actually a normal "database doesn't exist yet" case as a crash.
  - **A genuine bug in `apply-update.ps1` itself**, not just the test harness:
    `src/generated/prisma` (the Prisma Client `src/lib/db.ts` imports) is gitignored, so it's
    never in a release archive. `prisma migrate deploy` deliberately does not generate it
    (only `migrate dev` does), and nothing else in the script did either - every *real* future
    update would have hit `Module not found: '@/generated/prisma/client'` at the build step.
    Fixed by adding an explicit `prisma generate` before the build.
  - The test harness's own service setup used a `-p <port>` CLI flag to keep the test app off
    the real app's port 3000 - but `apply-update.ps1` deliberately resets `AppParameters` to
    plain `run start` on every successful update (correct for the *real* service), which
    silently wiped that flag and made the test service try to rebind onto port 3000. Fixed by
    driving the port through a `PORT` environment variable instead (NSSM
    `AppEnvironmentExtra`), which survives that reset.
  - A real bug in the test harness's own pass/fail check: the nested `apply-update.ps1`
    process's console output wasn't suppressed, so it became extra elements in the array
    PowerShell's `return $LASTEXITCODE` actually produced - comparing that array with
    `-eq 0`/`-ne 0` checks *array membership*, not the exit code, silently wrong either way
    regardless of the real result. (This is why an early run reported "PASS" - a coincidence
    of which comparison operator was used, not a real check.) Fixed by piping the nested
    process's output to `Out-Host` instead of leaving it to leak into the function's return
    value.

  None of this touched the real `RestaurantApp`/`RestaurantPrintAgent`/`RestaurantSync`
  services or the real `restaurant` database at any point.

## Release hosting

The main app repo (`restaurant-reservation-app`) is **private** (confirmed via the GitHub
API - an anonymous request to it 404s). Publishing release artifacts as public GitHub
Releases on that repo would expose the entire source tree, which defeats the point of
building this as a product. Decision: **a separate, dedicated releases repo**
(`restaurant-app-releases` by convention — update `LauncherConfig`'s default `ManifestUrl` if
you name it differently) that holds **only** built release zips + `version.json` manifests,
never source. This also means the launcher never needs an embedded GitHub token just to check
for updates — it's a plain anonymous `raw.githubusercontent.com` fetch of a public
`latest.json`.

**Not yet done**: actually creating that repo. Until it exists, `UpdateChecker.FetchLatestAsync`
will just fail to fetch (handled gracefully — the launcher opens whatever version is already
installed, no update applied) or you can point a `launcher.config.json` next to the exe at a
throwaway test repo/URL first.

### Cutting a release (once the releases repo exists)

1. Bump `package.json`'s `version`, add a `CHANGELOG.md` entry.
2. Build the app for production and zip up exactly what an install needs (source +
   `package.json`/`package-lock.json`/`prisma/` — **not** `node_modules`, `.env`, or the
   rotated `*.log` files sitting in the repo root today; `npm ci && npm run build` happens
   on the restaurant's machine during the update, per `apply-update.ps1`).
3. Compute the zip's SHA256 (`Get-FileHash -Algorithm SHA256`), publish the zip as a GitHub
   Release on the releases repo, and commit a `latest.json` (shape: see
   `release-manifest.example.json`) to the releases repo pointing at it.

## Verification (per the approved plan)

1. ✅ `dotnet build` cleanly.
2. ✅ `maxAge` fix: cookie carries a real 60-day expiry, survives closing/reopening WebView2.
3. ✅ Launches, starts services, shows the login gate, reaches the dashboard, stays logged in
   across a launcher restart. (No second machine was available, so this ran against this
   restaurant's real machine — but only the read-only/non-destructive parts: starting
   already-configured services, opening a browser view, completing a login. See the Status
   section above for exactly why the update-apply path specifically was *not* tested this
   way.)
4. ✅ Full update path (detect → stop → replace → migrate → restart → healthy), proven via
   `scripts/test-update-flow.ps1`'s disposable, fully isolated test install rather than the
   real one — deliberately safer than "a second machine" for this specific step, since it
   avoids ever needing physical access to a second machine at all while still using real
   Windows Services, a real Postgres database, and the actual unmodified script.
5. ✅ Failure/rollback path (a deliberately broken migration), proven the same way.
6. **Still outstanding**: an actual second machine (or at least a fresh clone) test — today's
   testing proves the *mechanism* works correctly, but every run so far has been on this one
   machine's already-configured environment (existing Node/NSSM/Postgres installs, etc.).
   Worth doing before this is trusted for a real restaurant that isn't this one.

## What's deliberately NOT in Phase 1

Postgres/Node/NSSM auto-provisioning for a brand-new machine (now built - see "Phase 2"
below), licensing/accounts/billing, a multi-restaurant switcher UI (the
`User`↔`Restaurant` `Membership` schema already supports it, just no UI yet), voice/ngrok
automation (already moved to cloud, nothing local to automate), a real (paid/CA-issued)
code-signing certificate for actual distribution (see "Code signing" below — this turned out
to be a harder requirement than expected, not deferrable purely as "nice to have"), and a
real onboarding wizard that collects Twilio/Anthropic/Resend keys and generates `AGENT_TOKEN`
(Phase 3 - see "Phase 2" below for why that boundary is where it is).

## Code signing

**Correction to an earlier assumption in this doc**: running an unsigned exe was expected to
trigger a dismissible Windows SmartScreen warning ("Run anyway"). What actually happened on
this machine, confirmed via the `Microsoft-Windows-CodeIntegrity/Operational` event log
(event IDs 3077/3033): **Windows 11's Smart App Control** (a separate, stricter mechanism)
blocked the launcher outright — "did not meet the Enterprise signing level requirements" —
with no click-through override. Checked its actual state
(`HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy\VerifiedAndReputablePolicyState`): `1`
(fully "On"/enforced), not the "Evaluation" mode that allows unsigned apps while it learns.
Per Microsoft's own design, once Smart App Control reaches "On" it **cannot be turned off
without reinstalling Windows** — it's built that way specifically so malware can't disable
it.

**Dev-machine workaround** (`launcher/scripts/sign-launcher.ps1`, no elevation needed): a
self-signed code-signing certificate, installed into this machine's own `CurrentUser\Root`
and `CurrentUser\TrustedPublisher` stores, then used to sign the published exe. Smart App
Control accepted this — its requirement is a valid trust chain, not specifically a paid CA.
**Run this after every `dotnet publish`** — publishing always produces a fresh, unsigned exe,
so an unsigned rebuild will get blocked again until it's re-signed.

**This does not solve distribution** — it only makes this one machine trust a certificate
*this session generated on it*. A different restaurant's fresh Windows machine has no reason
to trust that certificate and would hit the identical block with no fix available this way.
Real distribution needs a real Authenticode certificate from a CA, ideally EV (which gets
instant reputation, vs. a standard cert that has to build reputation over time via other
users actually running signed builds) — this is now a confirmed, real requirement for Phase 5
(or possibly worth pulling earlier), not just a "SmartScreen is a bit annoying" inconvenience
as originally framed.

## Phase 2 — installer for a brand-new machine

Gets a genuinely blank Windows machine (no Node, no Postgres, no services) to a working
install, driven by the launcher instead of by hand — the thing Phase 1 always assumed was
already done. `MainForm.cs`'s "missing services" branch now offers a **"Set up this
machine"** button instead of a dead-end error message; clicking it elevates once (same
pattern as the update-apply step) and runs `scripts/provision-machine.ps1`.

**What it does, in order**: installs Node.js if missing (official MSI, silent), installs
PostgreSQL if missing (official EDB installer, unattended, then creates a dedicated
`restaurant` role/database), generates a fresh `.env` (real `SESSION_SECRET` and
`DATABASE_URL`; Twilio/Anthropic/Resend keys and `AGENT_TOKEN` are left blank — see below for
why), fetches the latest release from the manifest, builds it, migrates the (empty) database,
and registers + starts the three core services at `C:\ProgramData\RestaurantApp\app` — a
plain, non-cloud-synced path, so the OneDrive-junction class of problem (see `next.config.ts`,
`scripts/rebuild-app.ps1`) never needs to exist on a new install at all.

**Where this phase deliberately stops**: it does not create a restaurant. `AGENT_TOKEN` lives
on the `Restaurant` row in the database, which doesn't exist yet at this point — opening the
app for the first time after provisioning lands on the **existing** `/login` → `/onboarding`
flow to create one, same as it already does today. Collecting Twilio/Anthropic/Resend keys
and wiring `AGENT_TOKEN` into `.env` automatically is Phase 3's job (a real onboarding
wizard), not this one's.

**Shared logic, not duplicated**: `scripts/lib/install-app.ps1` now holds the
unpack → `npm ci` → `prisma generate` → build sequence (and `Find-Nssm`/`Find-Npm`), used by
`apply-update.ps1`, `provision-machine.ps1`, and `test-update-flow.ps1` alike — extracted
specifically because the three scripts had already drifted apart once for real (the
`prisma generate` fix originally landed in `apply-update.ps1` and had to be separately ported
to the test harness).

**NSSM is now bundled** (`tools/nssm.exe`, shipped in the launcher's own publish output),
not discovered via a WinGet install that a brand-new machine has no reason to have.

**Status: builds, compiles, and the non-installation logic is verified** — `dotnet build`
clean, the publish output's file layout manually inspected and confirmed correct (`scripts\`,
`scripts\lib\`, `tools\nssm.exe` all land where the C# code expects), the manifest-fetch and
already-installed-detection logic tested directly against real Node/Postgres on this machine
(both correctly detected as already present, so their "skip" branches were exercised for
real). **The actual install-from-scratch branches (silently installing Node/Postgres) have
not been run for real** — this machine already has both, so those branches can't be
meaningfully exercised here, the same honest gap Phase 1's "a second machine" step never fully
closed either. A real pass needs a genuinely blank Windows VM.

**Bugs caught before ever running for real**, worth keeping on record:
- `New-RandomSecret` originally used `RandomNumberGenerator`'s static `::Fill()` method — a
  .NET 6+ API that doesn't exist under Windows PowerShell 5.1's .NET Framework runtime.
  Confirmed by testing it directly: it failed with `MethodNotFound`, but — worse — the buffer
  was left as all zeros rather than the call throwing loudly, so every "random" secret
  (`SESSION_SECRET`, the generated Postgres password) would have been byte-for-byte identical
  on every fresh install. Fixed with the .NET Framework-compatible
  `::Create()` + `.GetBytes()` pattern and re-verified it produces genuinely distinct output.
- The csproj's script-bundling glob included an explicit `<Link>` that was relative to the
  glob's own base folder, not the project root — silently stripped the `scripts\` prefix and
  copied every script flat into the publish root instead of `scripts\...`, where the C# code
  (`Path.Combine(exeDirectory, "scripts", ...)`) actually looks for them. Caught by actually
  listing the publish output's file layout, not just checking `dotnet build` succeeded.
- `tools\nssm.exe`, bundled via a plain `<None Include>` (works fine for the `.ps1` scripts),
  silently never reached the publish output specifically — present in the ordinary build
  output, absent from `publish\`, no warning either way. `PublishSingleFile` evidently filters
  `.exe` content items differently. Fixed via an explicit `ResolvedFileToPublish` target
  (the documented mechanism for forcing an extra native file into single-file publish output),
  and re-verified the file actually lands at `publish\tools\nssm.exe` with the right size.
