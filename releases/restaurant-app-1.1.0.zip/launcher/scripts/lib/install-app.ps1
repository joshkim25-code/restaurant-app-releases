# Shared helpers, dot-sourced by apply-update.ps1, provision-machine.ps1, and
# test-update-flow.ps1 - the same unpack -> dependencies -> build sequence, and the same
# npm/nssm discovery, needs to behave identically everywhere it's used, or the scripts
# silently drift apart. That already happened once for real: `prisma generate` was added
# only to apply-update.ps1 first, and test-update-flow.ps1 needed the identical fix
# separately - exactly the kind of duplication this file exists to prevent going forward.
#
# Not a standalone script - has no param block of its own, only function definitions.
# Callers: `. (Join-Path $PSScriptRoot "lib\install-app.ps1")`

function Find-Nssm {
  # $BundledPath (a launcher publish output's own tools\nssm.exe, see provision-machine.ps1)
  # is checked first - a brand-new machine has no WinGet install to scan for at all. Existing
  # callers that never pass it (apply-update.ps1, test-update-flow.ps1, both still running
  # against machines set up the original hand-configured way) get the original behavior
  # unchanged.
  param([string]$BundledPath)
  if ($BundledPath -and (Test-Path $BundledPath)) { return $BundledPath }
  $found = Get-ChildItem -Path "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Filter "nssm.exe" -Recurse -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -like "*win64*" } | Select-Object -First 1 -ExpandProperty FullName
  if ($found) { return $found }
  $onPath = Get-Command nssm.exe -ErrorAction SilentlyContinue
  if ($onPath) { return $onPath.Source }
  throw "nssm.exe not found - install it first: winget install --id NSSM.NSSM -e"
}

function Find-Npm {
  $default = "C:\Program Files\nodejs\npm.cmd"
  if (Test-Path $default) { return $default }
  $onPath = Get-Command npm.cmd -ErrorAction SilentlyContinue
  if ($onPath) { return $onPath.Source }
  throw "npm.cmd not found - install Node.js first."
}

# Downloads a release zip and verifies its checksum before anything touches disk beyond the
# download itself - refuses to extract a corrupted or tampered file.
function Get-VerifiedRelease {
  param(
    [Parameter(Mandatory = $true)][string]$Url,
    [Parameter(Mandatory = $true)][string]$ExpectedSha256,
    [Parameter(Mandatory = $true)][string]$OutPath
  )
  Write-Output "Downloading release..."
  Invoke-WebRequest -Uri $Url -OutFile $OutPath -UseBasicParsing

  $actualSha256 = (Get-FileHash -Path $OutPath -Algorithm SHA256).Hash
  if ($actualSha256 -ne $ExpectedSha256) {
    throw "Downloaded file's SHA256 ($actualSha256) doesn't match the expected value ($ExpectedSha256) - refusing to install a corrupted or tampered download."
  }
}

# npm ci -> prisma generate -> npm run build, against an already-extracted install directory
# that already has its own .env in place (callers are responsible for that part - an update
# copies one forward from a backup, a fresh install generates one; genuinely different enough
# between the two that it doesn't belong in a shared helper).
function Install-AppDependencies {
  param([Parameter(Mandatory = $true)][string]$InstallDir)

  $npmCmd = Find-Npm
  Push-Location $InstallDir
  try {
    Write-Output "Installing dependencies..."
    & $npmCmd ci
    if ($LASTEXITCODE -ne 0) { throw "npm ci failed with exit code $LASTEXITCODE." }

    # src/generated/prisma (the Prisma Client code src/lib/db.ts imports) is gitignored, so
    # it's never part of a release archive - a fresh extraction has no client at all until
    # this runs. `prisma migrate deploy` deliberately does NOT generate it (unlike
    # `migrate dev`), and the build fails outright without it - confirmed by an actual test
    # run against a disposable install (see launcher/scripts/test-update-flow.ps1): "Module
    # not found: Can't resolve '@/generated/prisma/client'".
    Write-Output "Generating Prisma Client..."
    & npx prisma generate
    if ($LASTEXITCODE -ne 0) { throw "prisma generate failed with exit code $LASTEXITCODE." }

    Write-Output "Building..."
    & $npmCmd run build
    if ($LASTEXITCODE -ne 0) { throw "npm run build failed with exit code $LASTEXITCODE." }

    # Same reasoning as scripts/rebuild-app.ps1: a successful build command doesn't always
    # mean BUILD_ID has actually finished writing yet.
    $buildId = Join-Path $InstallDir ".next-prod\BUILD_ID"
    $waited = 0
    while (-not (Test-Path $buildId) -and $waited -lt 30) {
      Start-Sleep -Seconds 1
      $waited++
    }
    if (-not (Test-Path $buildId)) {
      throw "Build did not produce .next-prod\BUILD_ID after ${waited}s - build likely incomplete."
    }
  } finally {
    Pop-Location
  }
}
