# Gets a genuinely blank Windows machine (no Node, no Postgres, no services) to a working,
# freshly-installed app: installs Node.js and PostgreSQL if missing, creates a dedicated
# Postgres role/database, generates a fresh .env, fetches the latest release from the
# manifest, builds it, migrates the (empty) database, and registers + starts the three core
# services. Does NOT create a restaurant - opening the app for the first time after this
# lands on the existing /login -> /onboarding flow for that (see launcher/README.md's Phase 2
# notes on why that boundary is where it is: agentToken lives on the Restaurant row, which
# can't exist yet here).
#
# Invoked by the launcher when it finds no core services registered at all - not meant to be
# run by hand day-to-day, though it can be for testing. Must run elevated (msiexec, the
# Postgres installer, and NSSM service registration all need admin rights) - same pattern as
# apply-update.ps1: the launcher requests elevation only for this step.
#
# Idempotent - safe to re-run; each stage is skipped if its result already exists, same
# philosophy as test-update-flow.ps1.
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File provision-machine.ps1 `
#     -ManifestUrl "https://raw.githubusercontent.com/.../latest.json" `
#     -InstallDir "C:\ProgramData\RestaurantApp\app"

param(
  [string]$ManifestUrl = "https://raw.githubusercontent.com/joshkim25-code/restaurant-app-releases/main/latest.json",
  [string]$InstallDir = "C:\ProgramData\RestaurantApp\app",
  [string]$DbName = "restaurant",
  [string]$DbUser = "restaurant",
  [string]$AppServiceName = "RestaurantApp",
  [string]$PrintAgentServiceName = "RestaurantPrintAgent",
  [string]$SyncServiceName = "RestaurantSync",
  [string]$HealthCheckUrl = "http://localhost:3000/login"
)

$ErrorActionPreference = "Stop"

. (Join-Path $PSScriptRoot "lib\install-app.ps1")

$logDir = Join-Path (Split-Path -Parent $InstallDir) "provision-logs"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$logFile = Join-Path $logDir "provision-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
Start-Transcript -Path $logFile -Force | Out-Null

# Pinned, not "latest" - deliberately the same version already proven to build and run this
# exact codebase on this machine throughout this whole project, not a moving target that
# could silently introduce an incompatibility. Bump these on purpose, not by drift.
$NodeVersion = "24.19.0"
$NodeMsiUrl = "https://nodejs.org/dist/v$NodeVersion/node-v$NodeVersion-x64.msi"
$PostgresVersion = "17.6-1"
$PostgresInstallerUrl = "https://get.enterprisedb.com/postgresql/postgresql-$PostgresVersion-windows-x64.exe"

function New-RandomSecret {
  # RandomNumberGenerator's static ::Fill() is a newer (.NET 6+) API not available under
  # Windows PowerShell 5.1's .NET Framework runtime (confirmed by testing this in isolation -
  # it fails with MethodNotFound and, worse, doesn't throw loudly enough to stop the script:
  # the buffer is silently left as all zeros, producing the exact same "random" secret every
  # time). ::Create() + .GetBytes() is the .NET Framework-compatible pattern.
  param([int]$Bytes = 32)
  $buffer = New-Object byte[] $Bytes
  $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
  try {
    $rng.GetBytes($buffer)
  } finally {
    $rng.Dispose()
  }
  return [Convert]::ToBase64String($buffer)
}

function Ensure-NodeInstalled {
  $existing = Get-Command node.exe -ErrorAction SilentlyContinue
  if ((Test-Path "C:\Program Files\nodejs\node.exe") -or $existing) {
    Write-Output "Node.js already installed."
    return
  }

  Write-Output "Node.js not found - downloading and installing v$NodeVersion..."
  $msiPath = Join-Path $env:TEMP "node-v$NodeVersion-x64.msi"
  Invoke-WebRequest -Uri $NodeMsiUrl -OutFile $msiPath -UseBasicParsing

  $proc = Start-Process -FilePath "msiexec.exe" -ArgumentList @("/i", "`"$msiPath`"", "/quiet", "/norestart") -Wait -PassThru
  if ($proc.ExitCode -ne 0) {
    throw "Node.js installer exited with code $($proc.ExitCode)."
  }
  Remove-Item $msiPath -ErrorAction SilentlyContinue

  if (-not (Test-Path "C:\Program Files\nodejs\node.exe")) {
    throw "Node.js install reported success but node.exe still isn't at the expected path."
  }
  Write-Output "Node.js v$NodeVersion installed."
}

function Ensure-PostgresInstalled {
  # Returns the generated/discovered superuser password, needed later to create the app's
  # own role - only meaningful on a fresh install; an already-installed Postgres (e.g. this
  # dev machine) keeps whatever credentials it already has, and this function can't know
  # them, so the caller has to handle "already installed" separately (see Ensure-AppDatabase).
  $existingService = Get-Service -Name "postgresql-x64-*" -ErrorAction SilentlyContinue
  if ($existingService) {
    Write-Output "PostgreSQL already installed ($($existingService.Name))."
    return $null
  }

  Write-Output "PostgreSQL not found - downloading and installing v$PostgresVersion..."
  $installerPath = Join-Path $env:TEMP "postgresql-$PostgresVersion-windows-x64.exe"
  Invoke-WebRequest -Uri $PostgresInstallerUrl -OutFile $installerPath -UseBasicParsing

  $superPassword = New-RandomSecret -Bytes 24
  $proc = Start-Process -FilePath $installerPath -ArgumentList @(
    "--mode", "unattended",
    "--unattendedmodeui", "none",
    "--superpassword", $superPassword,
    "--serverport", "5432",
    "--disable-components", "pgAdmin,stackbuilder"
  ) -Wait -PassThru
  if ($proc.ExitCode -ne 0) {
    throw "PostgreSQL installer exited with code $($proc.ExitCode)."
  }
  Remove-Item $installerPath -ErrorAction SilentlyContinue

  $service = Get-Service -Name "postgresql-x64-*" -ErrorAction SilentlyContinue
  if (-not $service) {
    throw "PostgreSQL install reported success but no postgresql-x64-* service was found."
  }
  # The installer starts the service itself, but give it a moment to finish accepting
  # connections before anything tries to use it.
  Start-Sleep -Seconds 5
  Write-Output "PostgreSQL v$PostgresVersion installed and running ($($service.Name))."
  return $superPassword
}

function Find-PgBin {
  $bin = Get-ChildItem "C:\Program Files\PostgreSQL" -Directory -ErrorAction SilentlyContinue |
    Sort-Object Name -Descending |
    ForEach-Object { Join-Path $_.FullName "bin" } |
    Where-Object { Test-Path (Join-Path $_ "psql.exe") } |
    Select-Object -First 1
  if (-not $bin) { throw "Postgres bin directory (with psql.exe) not found under C:\Program Files\PostgreSQL." }
  return $bin
}

function Invoke-Psql {
  param([string[]]$PsqlArgs)
  $psql = Join-Path (Find-PgBin) "psql.exe"
  $output = & $psql @PsqlArgs 2>&1
  if ($LASTEXITCODE -ne 0) {
    throw "psql failed (exit $LASTEXITCODE): $($output -join "`n")"
  }
  return $output
}

function Ensure-AppDatabase {
  param([string]$SuperPassword)

  if (-not $SuperPassword) {
    throw "PostgreSQL was already installed before this script ran, so its superuser " +
      "password is unknown here - can't create the app's role/database unattended. " +
      "Create them by hand (see .env.example's default DATABASE_URL for the expected " +
      "shape: role '$DbUser', database '$DbName'), or run this against a machine where " +
      "PostgreSQL doesn't exist yet so this script can install and configure it fully."
  }

  $appPassword = New-RandomSecret -Bytes 18

  $env:PGPASSWORD = $SuperPassword
  try {
    $roleExists = (Invoke-Psql @("-h", "localhost", "-p", "5432", "-U", "postgres", "-d", "postgres", "-tAc", "SELECT 1 FROM pg_roles WHERE rolname = '$DbUser'") -join "").Trim()
    if ($roleExists -eq "1") {
      Write-Output "Role '$DbUser' already exists."
    } else {
      Invoke-Psql @("-h", "localhost", "-p", "5432", "-U", "postgres", "-d", "postgres", "-c", "CREATE ROLE $DbUser WITH LOGIN CREATEDB PASSWORD '$appPassword';") | Out-Null
      Write-Output "Created role '$DbUser'."
    }

    $dbExists = (Invoke-Psql @("-h", "localhost", "-p", "5432", "-U", "postgres", "-d", "postgres", "-tAc", "SELECT 1 FROM pg_database WHERE datname = '$DbName'") -join "").Trim()
    if ($dbExists -eq "1") {
      Write-Output "Database '$DbName' already exists."
    } else {
      Invoke-Psql @("-h", "localhost", "-p", "5432", "-U", "postgres", "-d", "postgres", "-c", "CREATE DATABASE $DbName OWNER $DbUser;") | Out-Null
      Write-Output "Created database '$DbName'."
    }
  } finally {
    Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue
  }

  return "postgresql://${DbUser}:${appPassword}@localhost:5432/${DbName}?schema=public"
}

function New-FreshEnvFile {
  param([string]$DatabaseUrl)

  # Real values for the two things this script can generate on its own; everything else
  # (Twilio/Anthropic/Resend keys, AGENT_TOKEN) is left blank - collecting those is Phase 3's
  # job (an onboarding wizard), not this one. AGENT_TOKEN specifically can't be generated yet
  # at all: it lives on the Restaurant row, which doesn't exist until someone completes the
  # existing /onboarding flow after this script finishes.
  @"
DATABASE_URL="$DatabaseUrl"

TWILIO_ACCOUNT_SID=""
TWILIO_AUTH_TOKEN=""
TWILIO_PHONE_NUMBER=""

ANTHROPIC_API_KEY=""
LLM_MODEL="claude-sonnet-5"

PUBLIC_BASE_URL="http://localhost:3000"

SESSION_SECRET="$(New-RandomSecret -Bytes 32)"

RESEND_API_KEY=""

AGENT_TOKEN=""

LOCAL_DATABASE_URL=""
CLOUD_DATABASE_URL=""

VOICE_PORT="3100"
VOICE_PUBLIC_URL="http://localhost:3100"
"@ | Set-Content -Path (Join-Path $InstallDir ".env") -Encoding utf8
}

function Get-LatestManifest {
  Write-Output "Fetching release manifest..."
  $json = Invoke-WebRequest -Uri $ManifestUrl -UseBasicParsing | Select-Object -ExpandProperty Content
  return $json | ConvertFrom-Json
}

Write-Output "=== Provisioning a fresh install ==="
Write-Output "Install dir: $InstallDir"

Ensure-NodeInstalled
$superPassword = Ensure-PostgresInstalled
$databaseUrl = Ensure-AppDatabase -SuperPassword $superPassword

if (Test-Path (Join-Path $InstallDir ".next-prod\BUILD_ID")) {
  Write-Output "App already installed and built at $InstallDir - skipping fetch/build."
} else {
  $manifest = Get-LatestManifest
  Write-Output "Latest release: $($manifest.version)"

  $zipPath = Join-Path $env:TEMP "restaurant-app-$($manifest.version).zip"
  Get-VerifiedRelease -Url $manifest.downloadUrl -ExpectedSha256 $manifest.sha256 -OutPath $zipPath

  New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
  Write-Output "Extracting..."
  Expand-Archive -Path $zipPath -DestinationPath $InstallDir -Force
  Remove-Item $zipPath -ErrorAction SilentlyContinue

  New-FreshEnvFile -DatabaseUrl $databaseUrl
  Install-AppDependencies -InstallDir $InstallDir

  Push-Location $InstallDir
  try {
    Write-Output "Migrating the database (fresh, empty)..."
    & npx prisma migrate deploy
    if ($LASTEXITCODE -ne 0) { throw "prisma migrate deploy failed with exit code $LASTEXITCODE." }
  } finally {
    Pop-Location
  }
}

# The launcher's own publish output ships tools\nssm.exe alongside this script (see
# RestaurantLauncher.csproj) - no WinGet dependency needed for a install this script itself
# is doing (Find-Nssm still falls back to the old discovery if this script is ever run
# outside the launcher's publish layout, e.g. directly from the repo for testing).
$bundledNssm = Join-Path (Split-Path -Parent $PSScriptRoot) "tools\nssm.exe"
$nssm = Find-Nssm -BundledPath $bundledNssm
$npmCmd = Find-Npm

function Install-CoreService($Name, $Params, $LogFile) {
  if (Get-Service -Name $Name -ErrorAction SilentlyContinue) {
    Write-Output "Service '$Name' already registered."
    return
  }
  Write-Output "Registering service '$Name'..."
  & $nssm install $Name $npmCmd $Params | Out-Null
  & $nssm set $Name AppDirectory $InstallDir | Out-Null
  & $nssm set $Name AppStdout (Join-Path $InstallDir $LogFile) | Out-Null
  & $nssm set $Name AppStderr (Join-Path $InstallDir $LogFile) | Out-Null
  & $nssm set $Name AppRotateFiles 1 | Out-Null
  & $nssm set $Name AppRotateBytes 5242880 | Out-Null
  & $nssm set $Name Start SERVICE_AUTO_START | Out-Null
  & $nssm set $Name AppExit Default Restart | Out-Null
  & $nssm set $Name AppRestartDelay 3000 | Out-Null
  & $nssm start $Name | Out-Null
}

Install-CoreService $AppServiceName "run start" "app.log"
Install-CoreService $PrintAgentServiceName "run agent" "agent.log"
Install-CoreService $SyncServiceName "run sync" "sync.log"

Write-Output "Waiting for the app to respond..."
$deadline = (Get-Date).AddSeconds(30)
$healthy = $false
while ((Get-Date) -lt $deadline) {
  try {
    $resp = Invoke-WebRequest -Uri $HealthCheckUrl -UseBasicParsing -TimeoutSec 5
    if ($resp.StatusCode -eq 200) { $healthy = $true; break }
  } catch {
    # Not up yet - keep polling.
  }
  Start-Sleep -Seconds 1
}

if (-not $healthy) {
  Write-Output ""
  Write-Output "WARNING: services were registered and started, but the app didn't respond"
  Write-Output "healthy within 30s. Check the services by hand (Get-Service Restaurant*) and"
  Write-Output "this log: $logFile"
  Stop-Transcript | Out-Null
  exit 1
}

Write-Output ""
Write-Output "Provisioning complete - the app is running and reachable."
Write-Output "Next step (not done by this script): open the app, log in, and create the"
Write-Output "restaurant via the existing onboarding flow."
Stop-Transcript | Out-Null
exit 0
