# Signs the published launcher exe with this machine's dev self-signed certificate.
#
# Why this exists: Windows 11's Smart App Control (a stricter successor to SmartScreen, with
# no "Run anyway" click-through once enforced) blocks unsigned exes outright - confirmed on
# this machine (Application Control policy block, CodeIntegrity event ID 3077/3033: "did not
# meet the Enterprise signing level requirements"). `dotnet publish` produces a fresh,
# unsigned exe every time, so this needs to run after every publish, not just once.
#
# This is a DEV/TEST fix for iterating on THIS machine, not a distribution solution - a
# self-signed cert trusted only in this machine's own CurrentUser store obviously doesn't
# help a different restaurant's fresh Windows machine, which would hit the identical block
# with no fix available this way. Real distribution needs a real Authenticode certificate
# (see launcher/README.md's Phase 5) - this confirmed that's a hard requirement, not just
# a nice-to-have SmartScreen-warning inconvenience.
#
# Usage:  powershell -ExecutionPolicy Bypass -File launcher\scripts\sign-launcher.ps1
# (No elevation needed - CurrentUser cert stores don't require it.)

$ErrorActionPreference = "Stop"

$exePath = Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) "launcher\bin\Release\net8.0-windows\win-x64\publish\RestaurantLauncher.exe"
if (-not (Test-Path $exePath)) {
  throw "Published exe not found at $exePath - run `dotnet publish -c Release -r win-x64 --self-contained` first."
}

$certSubject = "CN=Restaurant App Launcher Dev"
$cert = Get-ChildItem "Cert:\CurrentUser\My" | Where-Object { $_.Subject -eq $certSubject } | Select-Object -First 1

if (-not $cert) {
  Write-Output "No dev signing cert found - creating one (one-time setup on this machine)..."
  $cert = New-SelfSignedCertificate `
    -Type CodeSigningCert `
    -Subject $certSubject `
    -CertStoreLocation "Cert:\CurrentUser\My" `
    -KeyUsage DigitalSignature `
    -FriendlyName "Restaurant App Launcher Dev Signing Cert" `
    -NotAfter (Get-Date).AddYears(5)

  foreach ($storeName in @("Root", "TrustedPublisher")) {
    $store = New-Object System.Security.Cryptography.X509Certificates.X509Store($storeName, "CurrentUser")
    $store.Open("ReadWrite")
    $store.Add($cert)
    $store.Close()
  }
  Write-Output "Created and trusted new dev signing cert (thumbprint $($cert.Thumbprint))."
}

$result = Set-AuthenticodeSignature -FilePath $exePath -Certificate $cert -TimestampServer "http://timestamp.digicert.com"
if ($result.Status -ne "Valid") {
  throw "Signing failed: $($result.Status) - $($result.StatusMessage)"
}

Write-Output "Signed: $exePath"
Write-Output "Status: $($result.Status) - $($result.StatusMessage)"
