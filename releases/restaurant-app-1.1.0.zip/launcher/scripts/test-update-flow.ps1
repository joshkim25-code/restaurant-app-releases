# Proves out apply-update.ps1 for real, safely: sets up one disposable, fully isolated test
# install on THIS machine (its own directory, its own Postgres database, its own temporarily
# registered Windows Services, its own port) and runs the actual, unmodified update script
# against it - both the happy path and the deliberate-migration-failure/rollback path.
#
# Never touches the real RestaurantApp/RestaurantPrintAgent/RestaurantSync services, the real
# app directory, or the real `restaurant` database - see launcher/README.md and the plan this
# came out of for why (the update script renames/replaces whatever directory it's pointed at
# and runs real migrations, so pointing it at the live repo/DB to "just test it" would risk
# losing uncommitted work or touching real customer data, not just risking downtime).
#
# Safe to re-run: setup steps are skipped if already done. Requires an elevated (Administrator)
# PowerShell, same as apply-update.ps1 (NSSM service control needs it).
#
# Usage:  powershell -ExecutionPolicy Bypass -File launcher\scripts\test-update-flow.ps1

$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$applyUpdateScript = Join-Path $PSScriptRoot "apply-update.ps1"

. (Join-Path $PSScriptRoot "lib\install-app.ps1")

$TestInstallDir = "C:\ProgramData\RestaurantApp-test\app"
$TestDbName = "restaurant_test"
$TestPort = 3100
$TestHealthCheckUrl = "http://localhost:$TestPort/login"
$TestAppService = "RestaurantAppTest"
$TestPrintAgentService = "RestaurantPrintAgentTest"
$TestSyncService = "RestaurantSyncTest"
$FileServerPort = 8123

function Find-Node {
  $default = "C:\Program Files\nodejs\node.exe"
  if (Test-Path $default) { return $default }
  $onPath = Get-Command node.exe -ErrorAction SilentlyContinue
  if ($onPath) { return $onPath.Source }
  throw "node.exe not found - install Node.js first."
}

function Find-PgBin {
  $bin = Get-ChildItem "C:\Program Files\PostgreSQL" -Directory -ErrorAction SilentlyContinue |
    Sort-Object Name -Descending |
    ForEach-Object { Join-Path $_.FullName "bin" } |
    Where-Object { Test-Path (Join-Path $_ "psql.exe") } |
    Select-Object -First 1
  if (-not $bin) { throw "Postgres bin directory (with psql.exe) not found under C:\Program Files\PostgreSQL." }
  return $bin
}

function Get-RealDatabaseUrlParts {
  $envPath = Join-Path $repoRoot ".env"
  $line = Get-Content $envPath | Where-Object { $_ -match '^DATABASE_URL=' } | Select-Object -First 1
  if (-not $line) { throw "DATABASE_URL not found in $envPath" }
  $value = $line -replace '^DATABASE_URL=', '' -replace '^"|"$', ''
  if ($value -notmatch '^postgresql://([^:]+):([^@]+)@([^:/]+):(\d+)/([^?]+)(\?.*)?$') {
    throw "Could not parse DATABASE_URL - expected postgresql://user:pass@host:port/dbname[?params]"
  }
  return [ordered]@{
    User = $Matches[1]; Password = $Matches[2]; Host = $Matches[3]; Port = $Matches[4]
    Database = $Matches[5]; Params = $Matches[6]
  }
}

function Invoke-Psql {
  # $ErrorActionPreference = "Stop" does NOT make a native exe's failure terminate the
  # script (that's a PowerShell 7.3+ behavior, not 5.1) - psql can fail silently with
  # nothing on stdout while its real error goes to stderr, which is exactly what happened
  # here (a null-valued-expression crash two lines away from the actual problem). Merge
  # stderr into the captured output and check the exit code explicitly instead.
  param([string[]]$PsqlArgs)
  $output = & $script:psql @PsqlArgs 2>&1
  if ($LASTEXITCODE -ne 0) {
    throw "psql failed (exit $LASTEXITCODE): $($output -join "`n")"
  }
  return $output
}

function Ensure-TestDatabase {
  param($DbParts)
  $pgBin = Find-PgBin
  $script:psql = Join-Path $pgBin "psql.exe"
  $env:PGPASSWORD = $DbParts.Password
  try {
    $exists = Invoke-Psql @("-h", $DbParts.Host, "-p", $DbParts.Port, "-U", $DbParts.User, "-d", "postgres", "-tAc", "SELECT 1 FROM pg_database WHERE datname = '$TestDbName'")
    if (($exists -join "").Trim() -eq "1") {
      Write-Output "Test database '$TestDbName' already exists."
    } else {
      Write-Output "Creating test database '$TestDbName'..."
      Invoke-Psql @("-h", $DbParts.Host, "-p", $DbParts.Port, "-U", $DbParts.User, "-d", "postgres", "-c", "CREATE DATABASE $TestDbName OWNER $($DbParts.User);") | Out-Null
    }
  } finally {
    Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue
  }
}

function Ensure-TestInstall {
  param($DbParts)
  $buildMarker = Join-Path $TestInstallDir ".next-prod\BUILD_ID"
  if (Test-Path $buildMarker) {
    Write-Output "Test install already present and built at $TestInstallDir."
    return
  }
  if (Test-Path $TestInstallDir) {
    # Present but incomplete (e.g. a previous run failed partway, like an npm run build
    # failure) - package.json existing alone isn't proof of a working install, so don't
    # treat it as "already done". Safe to wipe and redo: this whole directory is disposable
    # by design. Running elevated (same as the rest of this script) is what makes this
    # reliably possible - a partial install's files can end up with permissions a later
    # non-elevated cleanup attempt can't touch.
    Write-Output "Found an incomplete previous test install at $TestInstallDir - removing and redoing it."
    Remove-Item -Recurse -Force $TestInstallDir
  }

  Write-Output "Setting up test install at $TestInstallDir..."
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $TestInstallDir) | Out-Null

  $seedZip = Join-Path $env:TEMP "restaurant-app-test-seed.zip"
  Push-Location $repoRoot
  git archive --format=zip --output $seedZip HEAD
  Pop-Location
  Expand-Archive -Path $seedZip -DestinationPath $TestInstallDir -Force
  Remove-Item $seedZip -ErrorAction SilentlyContinue

  # Deliberately old, so there's always an "update" to test against.
  $pkgPath = Join-Path $TestInstallDir "package.json"
  $pkg = Get-Content -Raw $pkgPath | ConvertFrom-Json
  $pkg.version = "0.9.0"
  $pkg | ConvertTo-Json -Depth 20 | Set-Content -Path $pkgPath

  # Own .env: same secrets as the real install (fine - never leaves this machine, nothing here
  # is exposed publicly), but its own isolated database and its own port, so it can never
  # collide with or affect the real install.
  $realEnv = Get-Content (Join-Path $repoRoot ".env")
  $testDatabaseUrl = "postgresql://$($DbParts.User):$($DbParts.Password)@$($DbParts.Host):$($DbParts.Port)/$TestDbName$($DbParts.Params)"
  $testEnv = $realEnv | ForEach-Object {
    if ($_ -match '^DATABASE_URL=') { "DATABASE_URL=`"$testDatabaseUrl`"" }
    elseif ($_ -match '^PUBLIC_BASE_URL=') { "PUBLIC_BASE_URL=`"http://localhost:$TestPort`"" }
    else { $_ }
  }
  Set-Content -Path (Join-Path $TestInstallDir ".env") -Value $testEnv

  Install-AppDependencies -InstallDir $TestInstallDir

  Push-Location $TestInstallDir
  try {
    Write-Output "Migrating test database to current schema (baseline, matches a real pre-existing install)..."
    & npx prisma migrate deploy
    if ($LASTEXITCODE -ne 0) { throw "Baseline prisma migrate deploy failed against $TestDbName." }
  } finally {
    Pop-Location
  }
}

function Ensure-TestServices {
  $nssm = Find-Nssm
  $npmCmd = Find-Npm

  function Install-TestService($Name, $Params, $LogFile, $ExtraEnv) {
    # Only the install step itself is skipped for an already-registered service - every
    # `set` below is re-applied regardless, so re-running this script also self-heals a
    # service left misconfigured by an earlier run (e.g. one registered before this script
    # knew to set AppEnvironmentExtra) instead of silently leaving it broken forever.
    if (Get-Service -Name $Name -ErrorAction SilentlyContinue) {
      Write-Output "Test service '$Name' already registered - reapplying its config."
    } else {
      Write-Output "Registering test service '$Name'..."
      & $nssm install $Name $npmCmd $Params | Out-Null
    }
    & $nssm set $Name AppParameters $Params | Out-Null
    & $nssm set $Name AppDirectory $TestInstallDir | Out-Null
    & $nssm set $Name AppStdout (Join-Path $TestInstallDir $LogFile) | Out-Null
    & $nssm set $Name AppStderr (Join-Path $TestInstallDir $LogFile) | Out-Null
    & $nssm set $Name AppRotateFiles 1 | Out-Null
    & $nssm set $Name AppRotateBytes 5242880 | Out-Null
    & $nssm set $Name Start SERVICE_AUTO_START | Out-Null
    & $nssm set $Name AppExit Default Restart | Out-Null
    & $nssm set $Name AppRestartDelay 3000 | Out-Null
    if ($ExtraEnv) { & $nssm set $Name AppEnvironmentExtra $ExtraEnv | Out-Null }
    & $nssm restart $Name | Out-Null
  }

  # Print agent / sync will repeatedly fail to authenticate against this empty test database
  # (no Restaurant row exists in it) - that's expected and harmless (logged, not fatal, see
  # agent/index.ts's poll loop), they just need to exist as real services apply-update.ps1 can
  # stop/start like the real ones. Only the app service needs to actually serve real pages.
  #
  # Port comes from a PORT env var (next start's own documented fallback when no -p flag is
  # given), not an AppParameters "-p" flag - apply-update.ps1 resets AppParameters to plain
  # "run start" on every successful update (correct for the real service, which belongs on
  # the default port), which would otherwise silently wipe out a custom port flag here and
  # try to rebind onto port 3000 - already owned by the real, live RestaurantApp service.
  # Registering with plain "run start" from the start too, so setup and post-update state
  # are identical and this whole class of mismatch can't recur.
  Install-TestService $TestAppService "run start" "app.log" "PORT=$TestPort"
  Install-TestService $TestPrintAgentService "run agent" "agent.log"
  Install-TestService $TestSyncService "run sync" "sync.log"

  Start-Sleep -Seconds 2
  Get-Service $TestAppService, $TestPrintAgentService, $TestSyncService | Format-Table Name, Status -AutoSize
}

function Start-LocalFileServer {
  param([string]$FilePath, [int]$Port)
  $serverScript = Join-Path $env:TEMP "release-file-server.cjs"
  @"
const http = require('http');
const fs = require('fs');
const filePath = process.argv[2];
const port = Number(process.argv[3]);
const server = http.createServer((req, res) => {
  if (req.url === '/release.zip') {
    res.writeHead(200, { 'Content-Type': 'application/zip' });
    fs.createReadStream(filePath).pipe(res);
  } else {
    res.writeHead(404);
    res.end();
  }
});
server.listen(port, '127.0.0.1', () => console.log('serving on ' + port));
"@ | Set-Content -Path $serverScript -Encoding utf8

  $proc = Start-Process -FilePath (Find-Node) -ArgumentList @($serverScript, $FilePath, $Port) -PassThru -WindowStyle Hidden
  Start-Sleep -Seconds 1
  return $proc
}

function Build-ReleaseZip {
  param([string]$OutPath, [string]$ExtraMigrationSql = $null)

  if (-not $ExtraMigrationSql) {
    Push-Location $repoRoot
    git archive --format=zip --output $OutPath HEAD
    Pop-Location
    return
  }

  # Failure-path release: same source, plus one deliberately broken migration appended after
  # every real one, so `prisma migrate deploy` genuinely fails - not built via `git archive`
  # (this migration is never committed to the real repo) but as a plain directory zip, which
  # Expand-Archive (used by apply-update.ps1) reads identically either way.
  $scratchDir = Join-Path $env:TEMP "restaurant-app-test-broken-$(Get-Random)"
  $seedZip = Join-Path $env:TEMP "restaurant-app-test-broken-seed.zip"
  Push-Location $repoRoot
  git archive --format=zip --output $seedZip HEAD
  Pop-Location
  Expand-Archive -Path $seedZip -DestinationPath $scratchDir -Force
  Remove-Item $seedZip -ErrorAction SilentlyContinue

  $migrationName = "$(Get-Date -Format 'yyyyMMddHHmmss')_test_deliberately_broken"
  $migrationDir = Join-Path $scratchDir "prisma\migrations\$migrationName"
  New-Item -ItemType Directory -Force -Path $migrationDir | Out-Null
  Set-Content -Path (Join-Path $migrationDir "migration.sql") -Value $ExtraMigrationSql

  if (Test-Path $OutPath) { Remove-Item $OutPath }
  Compress-Archive -Path (Join-Path $scratchDir "*") -DestinationPath $OutPath
  Remove-Item -Recurse -Force $scratchDir -ErrorAction SilentlyContinue

  return $migrationName
}

function Invoke-TestUpdate {
  param([string]$ZipPath, [string]$Version)

  $sha256 = (Get-FileHash -Path $ZipPath -Algorithm SHA256).Hash
  $server = Start-LocalFileServer -FilePath $ZipPath -Port $FileServerPort
  try {
    # Piped to Out-Host (not left to flow into this function's own output) so it still
    # prints live for whoever's watching, without becoming part of what this function
    # *returns* - without this, every Write-Output line from the nested apply-update.ps1
    # run becomes an extra element in the array `return $LASTEXITCODE` actually produces,
    # and comparing that array with `-eq 0`/`-ne 0` later checks array *membership*, not
    # the exit code - silently wrong regardless of the real result.
    & powershell -NoProfile -ExecutionPolicy Bypass -File $applyUpdateScript `
      -InstallDir $TestInstallDir `
      -DownloadUrl "http://localhost:$FileServerPort/release.zip" `
      -ExpectedSha256 $sha256 `
      -Version $Version `
      -AppServiceName $TestAppService `
      -PrintAgentServiceName $TestPrintAgentService `
      -SyncServiceName $TestSyncService `
      -HealthCheckUrl $TestHealthCheckUrl | Out-Host
    return $LASTEXITCODE
  } finally {
    Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue
  }
}

function Get-InstalledTestVersion {
  $pkgPath = Join-Path $TestInstallDir "package.json"
  return (Get-Content -Raw $pkgPath | ConvertFrom-Json).version
}

# ============================== Setup (idempotent) ==============================

Write-Output "=== Setting up the disposable test install (skips anything already present) ==="
$dbParts = Get-RealDatabaseUrlParts
Ensure-TestDatabase -DbParts $dbParts
Ensure-TestInstall -DbParts $dbParts
Ensure-TestServices

# ============================== Happy-path test ==============================

Write-Output ""
Write-Output "=== Happy-path test: update to current committed code ==="
$versionBefore = Get-InstalledTestVersion
Write-Output "Test install version before: $versionBefore"

$happyZip = Join-Path $env:TEMP "restaurant-app-test-happy.zip"
Build-ReleaseZip -OutPath $happyZip
$targetVersion = (Get-Content -Raw (Join-Path $repoRoot "package.json") | ConvertFrom-Json).version
$happyExitCode = Invoke-TestUpdate -ZipPath $happyZip -Version $targetVersion
Remove-Item $happyZip -ErrorAction SilentlyContinue

$versionAfterHappy = Get-InstalledTestVersion
$happyPassed = ($happyExitCode -eq 0) -and ($versionAfterHappy -eq $targetVersion)
Write-Output "Exit code: $happyExitCode. Version after: $versionAfterHappy (expected $targetVersion)."
Write-Output $(if ($happyPassed) { "HAPPY PATH: PASS" } else { "HAPPY PATH: FAIL" })

# ============================== Failure-path test ==============================

Write-Output ""
Write-Output "=== Failure-path test: a release with one deliberately broken migration ==="
$versionBeforeFailure = Get-InstalledTestVersion
Write-Output "Test install version before: $versionBeforeFailure"

$brokenSql = "SELECT * FROM this_table_does_not_exist_and_never_will;"
$failureZip = Join-Path $env:TEMP "restaurant-app-test-failure.zip"
$brokenMigrationName = Build-ReleaseZip -OutPath $failureZip -ExtraMigrationSql $brokenSql
$failureExitCode = Invoke-TestUpdate -ZipPath $failureZip -Version "test-broken-migration"
Remove-Item $failureZip -ErrorAction SilentlyContinue

$versionAfterFailure = Get-InstalledTestVersion
$failurePassed = ($failureExitCode -ne 0) -and ($versionAfterFailure -eq $versionBeforeFailure)
Write-Output "Exit code: $failureExitCode. Version after: $versionAfterFailure (expected unchanged: $versionBeforeFailure)."
Write-Output $(if ($failurePassed) { "FAILURE/ROLLBACK PATH: PASS" } else { "FAILURE/ROLLBACK PATH: FAIL" })

# The failed migration leaves a "dirty" row in _prisma_migrations that blocks every future
# `migrate deploy` against this database until resolved - realistic (a real broken migration
# needs a human to resolve it too), but this test database needs to stay usable for the next
# time this harness runs, so resolve it as rolled-back now that we've verified the failure.
Write-Output "Resolving the deliberately-broken test migration so the test database stays reusable..."
Push-Location $TestInstallDir
& npx prisma migrate resolve --rolled-back $brokenMigrationName
Pop-Location

# ============================== Summary ==============================

Write-Output ""
Write-Output "=== Summary ==="
Write-Output "Happy path:        $(if ($happyPassed) { 'PASS' } else { 'FAIL' })"
Write-Output "Failure/rollback:  $(if ($failurePassed) { 'PASS' } else { 'FAIL' })"
Write-Output ""
Write-Output "Reminder: the REAL RestaurantApp/RestaurantPrintAgent/RestaurantSync services and"
Write-Output "the real 'restaurant' database were never touched by any of this."

if (-not ($happyPassed -and $failurePassed)) { exit 1 }
exit 0
