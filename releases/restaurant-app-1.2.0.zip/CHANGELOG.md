# Changelog

All notable changes to this app are recorded here. This is also what the planned
auto-updating launcher reads (via each release's `version.json`) to decide whether a newer
version is available and what changed.

Versions follow [Semantic Versioning](https://semver.org/): `MAJOR.MINOR.PATCH`.

## [1.2.0] - 2026-09-30

- Login is now email+password, with an automatic magic-link fallback for a first login or a
  forgotten password - previously magic-link-only. Logging in with the right password on a
  brand-new machine (no local data yet) now restores this restaurant's entire local database
  automatically from its cloud backup, gated by that same password - no manual steps needed to
  move to a new machine.
- A new restaurant's print-agent connection token (`AGENT_TOKEN`) is now written into the
  local `.env` automatically the moment it's generated (at onboarding, or when regenerated
  from Settings) - the print agent picks it up and stops crash-looping within seconds, with
  no copy-paste into `.env` required.
- Login-link email and Twilio phone numbers/SMS no longer require a restaurant owner's own
  Resend or Twilio account. Both now proxy through the cloud-hosted voice service (the same
  one that already handles AI phone reservations and Stripe billing), under one master
  account - a restaurant gets working login emails immediately, and can get a real phone
  number for AI reservations and SMS confirmations with one click in Settings > Phone.
  (Previously, phone numbers were never actually provisioned for any restaurant at all -
  Twilio credentials and `ANTHROPIC_API_KEY` are no longer local `.env` fields.)

## [1.1.0] - 2026-09-23

- A new restaurant created via `/onboarding` now gets its print agent connection token
  (`agentToken`) generated automatically, instead of needing someone to find Settings →
  Receipts and click "Generate" by hand before printing works.
- The dashboard shows a one-time welcome banner right after onboarding, pointing at what's
  optional to finish setting up (Twilio/Anthropic keys for AI phone reservations) versus
  what already works out of the box.

## [1.0.0] - 2026-09-23

First version-tracked release. The app had been under active development for a while before
this point without formal versioning; `1.0.0` marks the baseline this restaurant is opening
on, and the point real versioning/release tracking starts (needed as the foundation for the
planned auto-updating launcher - see `launcher/README.md`).

Highlights as of this baseline: table/order/billing management, reservations, an AI phone
reservation line (Twilio + Claude), receipt/kitchen-ticket printing (USB and network thermal
printers, including image-rendered fallback for characters outside the printer's character
set), a drag-and-drop menu editor, tip/discount/service-charge tracking, and a local-primary
architecture (per-restaurant local Postgres + Windows Services, with a background sync to a
cloud backup database).
