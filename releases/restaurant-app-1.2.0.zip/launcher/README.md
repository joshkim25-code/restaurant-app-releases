# Restaurant App Launcher

A small Windows desktop launcher, modeled on how the Riot Client works for League of Legends:
it makes sure the app's services are running (or sets them up from scratch on a blank
machine), checks for and applies updates automatically, then opens the app behind its
existing login. This covers **Phase 1 and Phase 2** of turning the restaurant app into a
distributable product other restaurants can run independently — see the full phased roadmap
this came out of for what's still deliberately deferred (licensing, a real onboarding wizard,
a real distribution-grade code-signing certificate, etc.).

## What this is (and isn't)

- **Is**: a thin WebView2 window around the app, plus an update-check-and-apply flow, plus
  (Phase 2) a from-scratch installer for a machine that has none of it yet.
- **Isn't**: its own auth system. The app's existing magic-link login
  (`src/app/login/`, `src/proxy.ts`) already gates the entire app server-side — the launcher
  just opens a browser view at it. There's nothing to keep in sync between "the launcher's
  login" and "the app's login" because they're the same login.
- **Isn't**: a restaurant-onboarding tool. Phase 2 gets a blank machine to a running,
  logged-out app; creating an actual restaurant still goes through the app's own existing
  `/onboarding` flow after that — see "Phase 2" below for why that boundary is where it is.

## Why WebView2, not Electron

Windows 11 ships the WebView2 runtime as an evergreen component (already confirmed present
on this machine), so a self-contained `dotnet publish` gives a real Chromium-grade renderer —
the app looks and behaves exactly as it does in a browser today — without bundling a second
copy of Chromium the way Electron would. It also avoids adding a whole second packaging
pipeline (`electron-builder`, its own signing/notarization) to a repo that has none today.

**Measured, not estimated** (built and published on 2026-09-23): the self-contained
single-file exe is **~155MB**. That's the full .NET runtime bundled in so the target machine
needs nothing pre-installed beyond WebView2 (which Windows 11 already has) — not a browser
engine, unlike Electron's bundle, which is the actual architectural difference this section's
size comparison is about, not raw byte count (Electron apps commonly land in a similar or
larger range once Chromium + Node are included). If install size becomes worth optimizing
later, two independent levers exist without changing the approach: framework-dependent
deployment (`SelfContained=false`, a few MB, but then the target machine needs the .NET 8
runtime installed too) or trimming (`PublishTrimmed`) — not attempted here since WinForms
trimming support is limited/risky and not worth the complexity for Phase 1. Neither is needed
for this phase; noted for Phase 5 (distribution polish) if it matters by then.
Electron's auto-updater ecosystem (`electron-updater`/Squirrel) isn't actually the right fit
here anyway: updating *this* app means stopping 3 Windows Services, replacing a Next.js
build, and running Prisma migrations against a live local Postgres — that orchestration is
bespoke regardless of launcher technology (see `scripts/apply-update.ps1`).

## Layout

```
launcher/
  RestaurantLauncher.csproj   Project file (net8.0-windows, self-contained win-x64)
  Program.cs                  Entry point
  MainForm.cs                 The one window: startup sequence + WebView2 host
  ServiceSupervisor.cs        Starts core services if stopped; app health-check polling
  UpdateChecker.cs            Fetches the release manifest, compares versions
  UpdateManifest.cs           version.json shape
  UpdateApplier.cs            Runs apply-update.ps1 elevated (only step that needs admin)
  MachineProvisioner.cs       Runs provision-machine.ps1 elevated (fresh-machine setup)
  LauncherConfig.cs           Optional launcher.config.json override (manifest URL, etc.)
  SemVer.cs                   Minimal MAJOR.MINOR.PATCH comparison
  scripts/apply-update.ps1        stop -> backup -> replace -> migrate -> restart flow
  scripts/provision-machine.ps1   Node/Postgres/services from nothing, on a blank machine
  scripts/lib/install-app.ps1     Shared unpack -> deps -> build helpers (both scripts above)
  scripts/sign-launcher.ps1       Dev-machine code-signing workaround (see "Code signing")
  tools/nssm.exe                  Bundled so provisioning never depends on WinGet
  release-manifest.example.json
```

## This machine's `launcher.config.json` (not committed - gitignored publish output)

The default `installDir` (`LauncherConfig.cs`) is the Phase 2 standard path,
`C:\ProgramData\RestaurantApp\app` - correct for a machine provisioned by
`provision-machine.ps1`. **This machine predates that** - its real install is the git
checkout itself (`C:\Users\joshu\OneDrive\바탕 화면\Restaurant`), set up by hand long before
Phase 2 existed. Caught before it caused real damage: once the releases repo had a real
manifest to compare against, the default `installDir` would have made `UpdateChecker` see
this machine as running version `0.0.0` (no `package.json` at the default path at all) and
treat every real release as "newer" - `apply-update.ps1` would have stopped this machine's
**actual live production services**, extracted the release into an empty
`C:\ProgramData\RestaurantApp\app`, then failed on a missing `.env` there (never having
existed at that path) and fallen into its own recovery path - not destructive by design, but
a real, avoidable disruption. Fixed with a `launcher.config.json` next to the published exe
overriding `installDir` to this machine's actual path - re-verified afterward that the real
launcher correctly reports no update needed once installed/latest versions genuinely match.

## Downloading (v1.0.28, published 2026-09-30)

```
https://raw.githubusercontent.com/joshkim25-code/restaurant-app-releases/main/launcher/RestaurantAppLauncher-1.0.28.zip
```
SHA256: `642865451433E94BF0D5A6BB996718E711E333C57BDF3DBD2D4618E1E764D668`

**1.0.28** — the exact same `Digest: 653103452` error came back on the same device running
1.0.27, proving that fix incomplete. Traced further: `Ensure-PostgresInstalled` unconditionally
uninstalls and reinstalls this script's own dedicated Postgres instance on *every* run (confirmed
by reading `Uninstall-OwnPostgres`'s call site — always called first, no "already installed,
skip" guard exists at all), so `Ensure-AppDatabase`'s returned `$databaseUrl` is *always* a
brand-new value — 1.0.27's fix (ALTERing the role's password when it already existed) never even
gets reached in practice, since the role never survives the Postgres wipe that happens first
every time. The actual gap: the main script only ever wrote that fresh `$databaseUrl` into `.env`
inside the "app not yet built" branch (`New-FreshEnvFile`) — re-running "Set up this machine" on
a device that already had a built app (`BUILD_ID` present, e.g. because services were removed for
re-testing but the app itself was left in place) skipped that branch entirely, leaving `.env`'s
`DATABASE_URL` pointing at a role Postgres no longer has. Fixed properly this time: a new shared
`Set-EnvFileVar` helper (`lib/install-app.ps1`, mirrors `src/lib/localEnv.ts`'s single-line patch
exactly) now corrects just the `DATABASE_URL` line in an already-existing `.env` unconditionally,
on every run, regardless of which branch runs next — preserving `AGENT_TOKEN` and everything else
already in it, unlike regenerating the whole file would. The "stop core services first" step
(previously only in the rebuild branch) moved earlier and now runs unconditionally too, so a
DATABASE_URL correction is never applied underneath an already-running process —
`Install-CoreService` further down (re)starts everything with the corrected `.env` regardless of
which branch ran. Verified directly in this environment: a unit test of `Set-EnvFileVar` confirms
it replaces the line in place, is a no-op when already correct, and appends when the key is
missing, without disturbing any other line. **A device already hit by this** just needs "Set up
this machine" run again with this version.

**1.0.27** — a real device hit a generic `Application error ... Digest: 653103452` right after
submitting an email on the login page. The real error, only visible in `app.log`
(`C:\ProgramData\RestaurantApp\app\app.log`, since Next.js hides real error text behind a digest
in production), was Prisma `P1000`: `"Authentication failed against the database server, the
provided database credentials for restaurant are not valid"`. Root cause in `Ensure-AppDatabase`:
it generates a fresh random `$appPassword` on *every* run, but only ever applied it to Postgres
in the `CREATE ROLE` branch — if the `restaurant` role already existed (exactly what happens
re-running "Set up this machine" on a device provisioned before, which is how this device had
been tested throughout this whole release cycle), the code logged "already exists" and skipped
setting a password, while still writing that unused new password into `.env`'s `DATABASE_URL` a
few lines later — guaranteeing the next login attempt would fail. Fixed: the role's password is
now set unconditionally (`ALTER ROLE ... WITH PASSWORD` when it already exists, `CREATE ROLE ...
PASSWORD` when it doesn't), so `.env` always matches what Postgres actually has, whether this is
a genuinely fresh machine or a repeat run. **A device already hit by this** just needs "Set up
this machine" run again with this version — no manual Postgres cleanup needed.

**1.0.26** — a fresh install's `.env` no longer leaves `RESEND_API_KEY`, `TWILIO_ACCOUNT_SID`/
`TWILIO_AUTH_TOKEN`/`TWILIO_PHONE_NUMBER`, or `ANTHROPIC_API_KEY` blank - none of these were ever
things a non-technical restaurant owner could reasonably be expected to fill in by hand, and this
matters now that the app is meant to be distributed beyond the owner's own use. Investigated with
two research passes across the whole app (not just the launcher script): login-link email and
Twilio phone numbers/SMS now proxy through the cloud-hosted voice service instead of requiring
local credentials, the same pattern already established for Stripe billing and cloud restore
(`voice/mail.ts` and `voice/phoneNumbers.ts`, new) - a restaurant owner gets working login emails
immediately with no Resend account, and can click one "Get a phone number" button in Settings
with no Twilio account, purchased under the one master Twilio account and idempotent (never
double-purchases). `AGENT_TOKEN` (previously also left blank, requiring a manual copy-paste into
`.env` that most owners would have no idea to do) now gets written automatically the instant a
restaurant is created (`src/lib/localEnv.ts`) - the print-agent Windows service has already been
crash-looping since install waiting for exactly this value (NSSM's `AppExit=Restart`), so it
self-heals within a few seconds with zero manual intervention. `ANTHROPIC_API_KEY` and
`TWILIO_PHONE_NUMBER` are removed from the template entirely - confirmed dead, zero code
anywhere in the local app ever read either one. `New-FreshEnvFile`'s template is correspondingly
shorter. Note: this version changes only what a fresh `.env` *contains*, not any provisioning
*logic* - it doesn't need the same kind of real-device re-verification 1.0.17 through 1.0.25 each
needed, since nothing about the install sequence itself changed.

**1.0.25** — following 1.0.24's fix, tested on the same real device: it already had its core
services (`RestaurantApp`, `RestaurantPrintAgent`, `RestaurantSync`) registered and running from
an earlier successful setup (that's how it got as far as showing a login page before), and its
`.next-prod\BUILD_ID` was deleted by hand (1.0.24's own documented recovery step) to force a
clean rebuild picking up the corrected `.env`. `npm ci` then failed with `EPERM: operation not
permitted, unlink '...\node_modules\@next\swc-win32-x64-msvc\next-swc.win32-x64-msvc.node'` -
Windows refuses to delete a native binary a running process still has loaded, and the
still-running `RestaurantApp` service had exactly that file loaded. This script had only ever
been designed around a genuinely blank machine with no services registered yet (the launcher
only offers "Set up this machine" in that case in the first place); it never accounted for the
hybrid state a real recovery flow can now produce: services already registered and running, but
a rebuild still needed. The rebuild path now stops any already-registered core services first -
releasing whatever file locks they hold - before touching `node_modules`, and `Install-
CoreService` now explicitly (re)starts a service even when it finds one already registered,
rather than assuming "already registered" still means "currently running" (no longer a safe
assumption once a service can be stopped mid-script for exactly this reason).

**1.0.24** — the actual root cause behind the entire "password stopped verifying since it was
set" mystery from 1.0.19-1.0.23, and separately behind a corrupted `DATABASE_URL` that broke
login after a real device finally got all the way through setup for the first time. Confirmed by
direct live testing in this environment, not guessed: in PowerShell, when a caller captures a
function's result (`$x = Some-Function`), it captures *every object written to the success/
output stream during that entire call* - not just the value passed to the function's final
`return` statement. Every `Write-Output "..."` progress message inside `Ensure-
PostgresInstalled`, `Uninstall-OwnPostgres` (called from within it), `Get-VerifiedRelease`
(likewise), `Ensure-AppDatabase`, and `Get-LatestManifest` was silently becoming part of their
own captured return values wherever a caller assigned them (`$superPassword = Ensure-
PostgresInstalled`, `$databaseUrl = Ensure-AppDatabase ...`, `$manifest = Get-LatestManifest`) -
garbling `$superPassword` into a single huge string of every progress message concatenated with
the real password, and `$databaseUrl` into progress messages concatenated with the real
connection string. This explains both earlier mysteries as the same bug: the password genuinely
looked like it kept "reverting" itself because `Ensure-AppDatabase` was comparing a garbled
password against the clean one actually stored in Postgres (set correctly, since that happens
from a still-clean *local* variable inside `Ensure-PostgresInstalled`, before the pollution ever
happens at the outer capture point) - the self-heal logic added in 1.0.19 only "fixed" this by
resetting Postgres's real password to match the garbled value, which is also exactly how a
garbled string (containing the literal substring "data`base`") ended up written into `.env`'s
`DATABASE_URL`, producing Prisma's `"Can't reach database server at \`base\`"` on login. Fix:
every progress message inside these functions now uses `Write-Host` instead of `Write-Output` -
it bypasses the success/output stream entirely, so it's still visible on screen and still
captured by the transcript, but can never again leak into a captured return value. Verified
directly: reproduced the exact corruption mechanism and confirmed `Write-Host` fixes it cleanly.
**Any existing install that already has a built app needs one clean re-run to pick this up** -
delete `C:\ProgramData\RestaurantApp\app\.next-prod\BUILD_ID` before retrying "Set up this
machine", since the script otherwise skips regenerating `.env` entirely once that file exists,
which would keep reusing the already-corrupted `DATABASE_URL` indefinitely.

**1.0.23** — setup got further still on a real device: all the way to `prisma migrate deploy`,
which failed with only `"prisma migrate deploy failed with exit code 1"` - zero indication of
what prisma itself actually reported. This whole phase (`npm ci`, `prisma generate`,
`npm run build`, `prisma migrate deploy`) had never run end-to-end on a real device before
either, since every prior real-device run had failed earlier in the script. Every one of these
calls only ever checked `$LASTEXITCODE`, discarding the command's real stdout/stderr entirely -
the exact same diagnostic gap already fixed once for `psql` calls (1.0.17-1.0.19), just not yet
extended to npm/prisma. `Invoke-NativeAllowingStderr` moved out of `provision-machine.ps1` and
into the shared `lib/install-app.ps1` (dot-sourced by both `provision-machine.ps1` and
`apply-update.ps1`, avoiding the exact duplication-drift that file's own header comment already
warns against), alongside a new `Invoke-CheckedCommand` helper that captures a native command's
real output, still streams it live to the transcript exactly as before, and includes it in the
thrown message on a non-zero exit instead of a bare exit code. Applied to all of `Install-
AppDependencies`'s three calls and both scripts' own `prisma migrate deploy` calls. Verified live
in this environment: both the success path (output streams and returns correctly) and the
failure path (throws with the command's real captured error text, not just its exit code).

**1.0.22** — 1.0.20's line-number diagnostic paid off immediately: got the exact failing line on
the very first try, `$roleExists = (Invoke-Psql @(...) -join "").Trim()` at line 466, a
genuinely new `"You cannot call a method on a null-valued expression."` Root cause, confirmed by
direct live testing in this environment rather than guessed: `(Func @(args) -join "")` does NOT
apply `-join` to `Func`'s return value the way it visually appears to. Once PowerShell's parser
commits to command-invocation syntax (a bare function name as the first token inside the
parens), every token after it - including `-join` and its `""` operand - gets parsed as MORE
ARGUMENTS to that function call, not as an operator applied to its result afterward. `Invoke-
Psql` never reads `$args`, so those two extra tokens were always silently swallowed, and `-join`
never actually ran even once; the parenthesized expression's value was always just `Invoke-
Psql`'s own raw return value, unmodified. This bug has existed since these two lines were first
written and was completely invisible for as long as `Invoke-Psql` happened to return a single
non-null string (any real query match) - it only crashes on `.Trim()` when the query returns
nothing at all, which is exactly what a `-tAc` role/database-existence check returns on a
genuinely fresh install (the ordinary, ever-present case here, not a rare edge case). Both
occurrences (`$roleExists`, `$dbExists` in `Ensure-AppDatabase`) now wrap the `Invoke-Psql` call
in its own parens first - `((Invoke-Psql @(...)) -join "")` - forcing it to fully resolve to a
value before `-join` (now unambiguously an operator, since it no longer trails a bare function
call) is applied to it. Verified directly: the broken pattern reproducibly throws the exact same
error against a function that returns `$null`, and the double-parens form fixes it cleanly.

**1.0.21** — the TLS fix from 1.0.15 came back on a real device: a fresh Postgres installer
download failed with the identical `"underlying connection was closed: An unexpected error
occurred on a send."` error even with `SecurityProtocol` forced to TLS 1.2. Switched from a flat
assignment (`SecurityProtocol = Tls12`, replacing the whole enabled protocol set) to `-bor`
(`SecurityProtocol = SecurityProtocol -bor Tls12`, adding Tls12 without removing whatever the OS
already had enabled) in both `provision-machine.ps1` and `apply-update.ps1` - a flat assignment
can strip out protocol/negotiation state some endpoints' handshake quirks still depend on even
when TLS 1.2 is the protocol actually selected for the connection. Confirmed against the real
device this was failing on. Separately: `get.enterprisedb.com`'s installer download specifically
has now shown three distinct flaky-network symptoms across independent real-device incidents -
severe throttling (1.0.8), a TLS negotiation failure (1.0.15), and this mid-download connection
reset - all against the same handful of large, third-party-hosted files this script has no
control over. `Get-VerifiedRelease` (`lib/install-app.ps1`, shared by both scripts) now retries
a failed download or checksum mismatch up to 3 times with a 5s delay before giving up, instead
of failing outright on the first transient network hiccup.

**1.0.20** — 1.0.19 got further than any prior version ever has on a real device: far enough to
hit `"You cannot call a method on a null-valued expression"`, a bare PowerShell runtime error
with no line number or any other indication of where it came from. This is genuinely uncharted
territory - no real device has ever gotten past the password-auth step before this run, so the
entire rest of the script (fetching the app release, `npm ci`/`prisma generate`/`npm run build`,
`.env` creation, service registration) had never actually been exercised end-to-end against a
real machine. Several `.Method()` call sites exist across the file (`$PostgresVersion.Split()`,
`$NewPassword.Replace()`, `.Trim()` on psql output, etc.) and guessing which one hit a null
value isn't worth another real-device round trip just to find out it was wrong. The top-level
`catch` block now appends `$_.InvocationInfo.ScriptLineNumber` and the actual offending source
line text (`$_.InvocationInfo.Line`) to `last-error.txt`, so the next failure - whatever it is -
names its own exact line instead of requiring another guess.

**1.0.19** — 1.0.18's real-error surfacing paid off immediately: the actual psql text came back
on the same real device this was being tested on: `FATAL: password authentication failed for
user "postgres"`. That's a real, reproducible rejection, not a timing gap - reaching that exact
error means the server was already up and `pg_hba.conf` was already asking for a password (not
still stuck in trust mode), and the specific password `Reset-PostgresSuperuserPassword`'s own
check had just verified moments earlier was now being genuinely rejected. Something external
changes the stored password in that window; EDB's Windows installer (a BitRock-style
bootstrapper) is the leading suspect, since `-Wait` on its launcher process doesn't guarantee an
async post-install child has actually finished touching the instance by the time control
returns. Rather than spend another real-device round trip chasing exactly which process does it,
`Ensure-AppDatabase` now self-heals: if its first connection check fails, it re-runs the same
unconditional, password-independent trust-mode reset already used right after install
(`Reset-PostgresSuperuserPassword`, via a new shared `Get-PgServiceName` so both call sites
derive the service name identically) immediately before it actually needs the connection, rather
than giving up on the first failure - trust-mode auth doesn't care what the current password
actually is, so it works regardless of whatever reverted it.

**1.0.18** — 1.0.17's `Invoke-NativeAllowingStderr` fix worked exactly as intended: tested
minutes later on a real device, setup correctly reached `Reset-PostgresSuperuserPassword`'s own
retry loop this time and let it finish (it self-verified successfully) - proof the EAP bug fix
is real - but then failed with a *new, different, coded* error from `Ensure-AppDatabase`'s own
connection check moments later: `"Could not connect as postgres with the password this script
just set, even after 5 attempts - something beyond a simple timing gap is wrong."` That message
was itself a dead end - it was written as a guess back when this script could never actually see
real psql error text, because every previous attempt died to the EAP bug before reaching this
code path at all. `Wait-ForPostgresAuth` now captures the actual psql output/exit code from the
last failed attempt into `$script:LastPgAuthError` and both callers (`Reset-
PostgresSuperuserPassword`'s own check and `Ensure-AppDatabase`'s) include it in their thrown
message instead of a generic "something is wrong." Its retry budget is also raised from 5 to 8
attempts (still 2s apart) as a reasonable safety margin now that retries are confirmed to
genuinely execute. If this exact failure happens again, the new message will say what psql is
actually reporting - connection refused, a real auth mismatch, role/database not existing yet,
etc. - instead of requiring another guess-and-ship round to find out.

**1.0.17** — found the actual, sole root cause behind every "password authentication failed"
failure chased since 1.0.3, confirmed by live-testing PowerShell's own behavior in this
environment rather than guessing again. This script sets `$ErrorActionPreference = "Stop"`
globally, and every `psql` call redirects the native command's stderr via `2>&1` to capture it
for error messages - but under PowerShell 5.1 (not PowerShell 7.3+, which behaves differently
here), that combination makes PowerShell throw a *terminating* exception on the native
command's very first stderr line, carrying that raw line as the exception message, regardless
of the command's actual exit code and *before* any `$LASTEXITCODE` check written after it is
ever reached. Every retry/verification loop built across 1.0.11 through 1.0.16
(`Reset-PostgresSuperuserPassword`'s own check, then the shared `Wait-ForPostgresAuth`) was
correctly written but never actually got to run past the very first failed attempt - the first
failing psql call always threw straight out of the function immediately, skipping the retry
loop entirely. This is exactly why the identical raw, unwrapped `psql: FATAL: password
authentication failed` error kept reappearing verbatim on 1.0.16 despite it supposedly retrying
5 times with a delay. Verified live: `$ErrorActionPreference = "Stop"; & cmd.exe /c "echo x
1>&2 & exit 1" 2>&1 | Out-Null` throws immediately on `"x"`, never reaching a `$LASTEXITCODE`
check placed right after it. Fix: a new `Invoke-NativeAllowingStderr` helper wraps every `psql`
call site (`Reset-PostgresSuperuserPassword`'s `ALTER USER`, `Wait-ForPostgresAuth`'s `SELECT
1`, and the general-purpose `Invoke-Psql`), temporarily relaxing `$ErrorActionPreference` to
`"Continue"` around just that native call and restoring it immediately after - the standard,
documented fix for this exact PowerShell 5.1 behavior - so `$LASTEXITCODE` checks and retry
loops actually execute as written instead of being silently bypassed.

**1.0.16** — the password-auth failure showed up once more, but this time from
`Ensure-AppDatabase`'s own connection, not `Reset-PostgresSuperuserPassword`'s (which has had
its own verification since 1.0.13, and would show a different, specific error if it were the
cause here). That means the password reset likely verified fine, but the very next connection
attempt moments later still failed once - a genuine transient/timing gap right at that
boundary, not a repeat of the underlying logic bug. The retry-with-delay logic from 1.0.13 is
now factored into a shared `Wait-ForPostgresAuth` function and used by both
`Reset-PostgresSuperuserPassword`'s own check *and* `Ensure-AppDatabase`'s first connection,
rather than assuming one successful verification earlier in the flow means every later
connection attempt is automatically safe too.

**1.0.15** fixed a fresh Windows machine failing setup with a generic `"The underlying
connection was closed: An unexpected error occurred on a send."` - Windows PowerShell 5.1's
default enabled TLS protocol set can leave TLS 1.2 disabled even on an up-to-date Windows
install (unlike a real browser, which negotiates independently of this), and every host this
script talks to (nodejs.org, get.enterprisedb.com, raw.githubusercontent.com) requires TLS
1.2+. `provision-machine.ps1` and `apply-update.ps1` (a separate script, a separate
`powershell.exe` process - needed its own fix, not shared automatically) now both force
`[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12` before any
web request. Every download/fetch (`Ensure-NodeInstalled`, `Get-VerifiedRelease` in
`lib/install-app.ps1` - shared by the Postgres installer and app zip downloads, and
`Get-LatestManifest`) also now wraps its request and includes the actual URL in the error
message if it fails, instead of a bare .NET exception message with no indication of which of
several requests this script makes was the one that failed. Verified directly: the TLS setting
applies cleanly, and a deliberately-failed request against a nonexistent host confirmed the
wrapped error message correctly names the URL.

**1.0.14** — no more manual cleanup needed between setup retries. After four rounds of asking
the person to manually uninstall a leftover PostgreSQL install between attempts,
`provision-machine.ps1` now does it itself: a new `Uninstall-OwnPostgres` unconditionally
removes its own dedicated PostgreSQL instance (exact major version, exact install directory,
exact service name - derived from `$PostgresVersion`, never anything else that happens to be on
the machine) before every fresh install attempt. Deliberately different from the earlier,
declined idea of auto-uninstalling *any* Postgres a Get-Service/directory search happened to
find (too risky - could be genuinely unrelated software's real database) - this only ever
touches the one instance this exact script owns by construction. Safe unconditionally because
of *when* this script runs at all: only when the launcher has already determined core services
aren't registered yet, meaning no real restaurant data can exist in this instance regardless of
how far a previous attempt got.

**1.0.13** — the password-auth failure came back yet again on a *fourth* real device, this one
genuinely clean (only ever had PostgreSQL 16 on it at all - ruling out 1.0.12's
wrong-coexisting-instance bug as the cause here). `Reset-PostgresSuperuserPassword` now
verifies its own work immediately - reconnecting with the new password, retrying up to 5 times
with a short delay between attempts - rather than trusting that the `ALTER USER` inside it
"succeeded" and finding out from a downstream symptom later, four separate times, that it
didn't actually take effect. This covers a real, plausible timing gap (the final restart,
reverting `pg_hba.conf` back to requiring a password, may need longer than a few seconds to be
fully ready on some machines) as well as giving a specific, immediate error naming this exact
step if the cause turns out to be something else entirely - instead of the same generic
`Ensure-AppDatabase` connection failure this bug has surfaced as every time so far.

**1.0.12** — 1.0.11's explicit password-reset never actually ran against the right instance.
`Find-PgBin`/`Find-PgDataDir` searched `C:\Program Files\PostgreSQL` and picked whichever
version directory sorted highest (`Sort-Object Name -Descending` + `Select-Object -First 1`) -
with a leftover PostgreSQL 17 still present on the same real device (from an attempt before
this script switched to installing 16), that always resolved to 17, not the 16 this script had
just installed and actually needed to fix. `Reset-PostgresSuperuserPassword` was silently
running against the wrong, unrelated instance every time - explaining why the fix had no effect
at all. Also fixed the same-class bug in the post-install service lookup
(`Get-Service -Name "postgresql-x64-*"` matches both coexisting services at once and returns an
array, which would have passed an invalid, multi-name value straight into `Restart-Service`).
Both now derive the exact target deterministically from `$PostgresVersion` (the version this
script itself just installed - `Find-PgMajorVersionDir`, new), never searching or guessing
among whatever else happens to be on the machine, regardless of how many other Postgres
installations coexist there.

**1.0.11** — the `psql: FATAL: password authentication failed for user "postgres"` bug came
back a *third* time on the same real device, this time on a genuinely fresh, isolated
PostgreSQL 16 install (1.0.10's fix) with no other explanation available - `--superpassword`
has now proven unreliable across three separate real-machine failures (special characters,
unrecognized installer flags, and now a clean install with neither of those factors present)
for reasons that don't reduce to one single root cause. Rather than continuing to chase why,
`provision-machine.ps1` no longer trusts `--superpassword` at all: after install, it explicitly
sets the superuser password itself via `Reset-PostgresSuperuserPassword`, a standard,
well-established Postgres recovery technique - temporarily allow passwordless ("trust") local
connections in `pg_hba.conf` (inserted at the top, since `pg_hba.conf` is first-match-wins),
use that to run a normal `ALTER USER postgres WITH PASSWORD ...`, then restore `pg_hba.conf`
exactly as it was (in a `finally` block, so this happens even if the `ALTER USER` itself fails).
This works unconditionally, independent of whatever `--superpassword` does or doesn't do - the
file-manipulation logic (prepend the trust rules, then restore byte-for-byte) was verified by
hand against a throwaway file before shipping; the full service-restart-and-auth flow could not
be safely dry-run against this machine's own real, in-use PostgreSQL install.

**1.0.10** — 1.0.9's dedicated-port fix (5433) wasn't the whole story on the same real device:
by the time it ran, that machine already had a leftover PostgreSQL 17 install from an earlier
attempt (before 1.0.9 existed) sitting on port 5432, and the *new* install (targeting 5433)
reported success but left nothing actually listening there. Standard PostgreSQL installers
don't reliably support two separate instances of the *same major version* side by side, even on
different ports/`--serverport` values - the installer detected the existing v17 install and
didn't create a genuinely new, separate one. Fixed by installing **PostgreSQL 16** instead of
17 - a different major version installs as a fully independent instance (own directory, own
service, own everything), which sidesteps this entire class of problem regardless of what
version anything else on the machine happens to be, without this script ever needing to detect
or touch it.

**1.0.9** fixed a real port collision, found on a real device that already ran a POS system
with its own separate PostgreSQL install. `provision-machine.ps1` previously always installed
on Postgres's default port (5432) and only checked whether a service literally named
`postgresql-x64-*` already existed before deciding to install fresh — a check that can't tell
"we already set this up" apart from "something else entirely installed Postgres for its own
reasons," since a Postgres bundled by completely unrelated software (the POS, in the confirmed
case) can register under that exact same naming pattern. This app's dedicated PostgreSQL
instance now always installs on its own port (`$DbPort`, defaulting to 5433 — a script
parameter, not user-configurable via the UI) so it can never collide with anything else already
on the machine, and `Ensure-PostgresInstalled`'s "already installed" check now looks at whether
*that specific port* is listening (`Get-NetTCPConnection -LocalPort $DbPort -State Listen`),
not at service names — the only thing that can legitimately already be on `$DbPort` is an
earlier successful run of this exact script.

**1.0.8** fixed the `psql: FATAL: password authentication failed for user "postgres"` bug
(thought fixed in 1.0.3) coming back on a real device running 1.0.6. Root cause: 1.0.4's
`--debugtrace`/`--debuglevel` flags, added to the Postgres installer call for diagnostics, were
only ever confirmed against EDB's docs for their commercial EPAS product — never for the plain
community PostgreSQL installer this script actually uses. Most likely explanation: those
unrecognized flags, sitting right after `--superpassword` in the argument list, corrupted how
the installer parsed that value. Removed entirely — not worth keeping an unverified diagnostic
aid that may be actively causing the bug it was meant to help diagnose. Also added real SHA256
verification for the Postgres installer download itself (there wasn't one before, unlike the
app zip download which already had this via `Get-VerifiedRelease` — now reused here too) — a
corrupted/truncated download was another live possibility, given how severely throttled the
connection to that specific server turned out to be on the same real device (~350-500 kbps
against a 74 Mbps connection — confirmed via independent browser test, traced to that host
specifically, not the device, PowerShell, or antivirus).

**1.0.7** fixed a freshly-provisioned machine's generated `.env` defaulting
`VOICE_PUBLIC_URL` to `http://localhost:3100` — silently broken on every fresh install, since
voice now runs cloud-hosted (Railway) for every restaurant, not locally per-machine. Billing
pages and the new auto-restore-on-login (`src/app/login/actions.ts`) both depend on this being
correct. `provision-machine.ps1`'s `New-FreshEnvFile` now bakes in the real production URL —
safe to include since it's a public HTTPS endpoint, not a credential (unlike
`CLOUD_DATABASE_URL`, which deliberately stays blank).

**1.0.6** surfaces the real reason a setup failure happened directly in the launcher's own
status text, instead of a generic "check provision-logs" message pointing at a log file the
person then had to go find themselves. `provision-machine.ps1`'s main body is now wrapped in a
top-level try/catch that writes a clean, single-message `last-error.txt` (in the same
`provision-logs` folder as its full transcript) on any failure — deliberately separate from the
noisy PowerShell transcript formatting, specifically so it's fit to show directly in a UI.
`MachineProvisioner.ReadLastError` reads it; `MainForm.cs`'s failure branch shows it instead of
the old generic message (falling back to that generic message only if the failure happened too
early for `last-error.txt` to exist at all). Also: `provision-machine.ps1` and
`lib/install-app.ps1` now explicitly delete any leftover partial download before retrying,
rather than relying on `Invoke-WebRequest`'s implicit overwrite behavior.

**1.0.5** fixed setup appearing to hang for over an hour on a real device, stuck downloading
the ~350MB Postgres installer. Root cause: Windows PowerShell 5.1's `Invoke-WebRequest` renders
a progress bar by default, and updating it per chunk has severe overhead on large files — a
well-documented issue that can make a multi-hundred-MB download take dramatically longer than a
normal browser download, to the point of looking hung. `provision-machine.ps1` now sets
`$ProgressPreference = "SilentlyContinue"` before any download (Node MSI, Postgres installer,
manifest fetch, app zip, and the post-install health-check poll all benefit, since they all go
through `Invoke-WebRequest`).

**1.0.4** — on a *third* real device, past 1.0.3's password fix, the EDB Postgres installer
itself failed with a bare "exited with code 1", no further detail. Confirmed via EDB's own
command-line options reference that `--debugtrace`/`--debuglevel` are real, standard flags of
the InstallBuilder framework this installer is built with. Added both to the installer call in
`Ensure-PostgresInstalled`, writing a real trace log to
`provision-logs\postgres-installer-<timestamp>.log` alongside the existing transcript. **Does
not itself claim to fix the exit-code-1 failure** — the root cause is still unknown without
that trace log; this exists to get real diagnostic detail if/when it happens again, rather than
guessing blind a second time.

**1.0.3** fixes `provision-machine.ps1`'s fresh-install path failing with `psql: FATAL:
password authentication failed for user "postgres"` on the same real second Windows 10 device,
right after the button became clickable — confirmed a genuinely blank machine, no prior
PostgreSQL. Root cause: `New-RandomSecret`'s Base64 output (can contain `+`/`/`/`=`) is used for
the generated Postgres superuser/app passwords, and those get passed as a command-line argument
into the EDB Postgres installer's own unattended-mode parsing (`--superpassword`) and later
embedded unescaped in a `postgresql://` connection string — either of which can mangle special
characters. A fresh `New-RandomAlphanumericSecret` (alphanumeric-only) is now used for both,
sidestepping both risks. Anyone who already hit this exact error on 1.0.2 or earlier: Postgres
was actually installed on that machine before the failure, just under a password nobody knows —
uninstall it via Settings → Apps (and delete `C:\Program Files\PostgreSQL` if anything's left
over) before retrying, so the next run is a genuinely fresh install again.

**1.0.2** fixed the "Set up this machine" button still not appearing on the real second Windows
10 device even after 1.0.1's re-centering fix, confirmed even after resizing the window (which
re-triggers the centering logic but nothing z-order-related) and confirmed the device really
was on the new build. Real root cause: `_statusLabel` (`Dock = DockStyle.Fill`) is added to
`Controls` before `_setUpButton`, which only becomes `Visible` well after the form's initial
layout/paint pass (from `StartupAsync`, at least one `await` later) — a non-docked sibling
shown that late, at the same screen location as a `Dock.Fill` control, can end up not actually
painted on top even with a correct `Location`/`Size` and `Visible` genuinely `true`. Fixed in
`MainForm.cs`'s `ShowSetUpButton` by also calling `_setUpButton.BringToFront()` when showing it.

**1.0.1** (superseded, not kept) fixed a real but incomplete first theory — the button's
`AutoSize`-based position was only computed once, at window load, never recalculated at the
moment it was actually shown — which turned out not to be the (whole) cause on this device.

Downloaded and the link/checksum verified working (fetched it back down independently and
confirmed the hash matches exactly). Published as a raw committed file on
`restaurant-app-releases`, same as the app's own release zips - not a real GitHub Release
object, since publishing those needs GitHub API/CLI access this environment doesn't have.
`1.0.0` is kept in that repo for reference.

**⚠️ Not code-signed** - this is the real remaining gap for distribution, not a "nice to have"
(see "Code signing" below). Deliberately published unsigned rather than with this machine's
self-signed dev cert, which would look signed without actually helping anyone else's machine -
more likely to confuse than help. Only reliably runs today on a machine where Smart App
Control is off or still in "Evaluation" mode; on a machine with it fully enforced, it will be
blocked with no override, exactly as it was here before the local dev-cert workaround.
Revisit this download once a real Authenticode certificate is in place.

## Building

Requires the .NET 8 SDK (not installed in the environment this was scaffolded in — install
with `winget install Microsoft.DotNet.SDK.8` if `dotnet --version` doesn't work yet).

```
cd launcher
dotnet restore
dotnet build
```

To produce the actual distributable single-file exe:

```
dotnet publish -c Release -r win-x64 --self-contained
```

**Status (2026-09-23):**
- Builds and publishes cleanly: `dotnet restore`/`build`/`publish -c Release -r win-x64
  --self-contained` all succeed with 0 errors (.NET 8 SDK 8.0.425; one benign `MSB3277`
  warning - the WebView2 package ships both WinForms and WPF assembly variants, only
  WinForms is actually used at runtime). Published exe is ~155MB (self-contained .NET
  runtime, not a bundled browser - see "Why WebView2, not Electron" above).
- **Run and verified, end-to-end, against this restaurant's real machine** (no second
  machine was available, so this became the de facto test target for the *non-destructive*
  parts only - see caveat below): launches cleanly, starts core services (were already
  running), opens a real WebView2 window at the app, shows the existing login page, and a
  real magic-link login completed through the window. Verified headlessly (no screen access
  in that session) by reading the actual `restaurant_session` cookie out of WebView2's own
  SQLite cookie store (`%LOCALAPPDATA%\RestaurantApp\WebView2\EBWebView\Default\Network\
  Cookies`) - confirmed a real 60-day expiry once the app was rebuilt with the `maxAge` fix
  (it initially showed iron-session's 14-day *default*, because the running production
  build hadn't been rebuilt yet - not a flaw in the fix itself, see `src/lib/
  session-options.ts`). Then closed and relaunched the actual desktop shortcut: landed
  straight on the dashboard, no re-login needed - the core "stays logged in" promise works.
- **The update-apply path is now proven too** (`scripts/apply-update.ps1`, the piece that
  stops services, replaces the install directory, and runs migrations - previously the
  highest-risk untested part). No second machine was available, so instead of pointing it at
  the live install, a reusable harness (`scripts/test-update-flow.ps1` /
  `test-update-flow.bat`) sets up one fully isolated, disposable install on this same
  machine - own directory (`C:\ProgramData\RestaurantApp-test\app`), own Postgres database
  (`restaurant_test`), own temporary Windows Services (`RestaurantAppTest`/etc.), own port
  (3100) - and runs the real, unmodified script against *that*. Both paths genuinely pass:
  - **Happy path**: stop -> backup -> replace -> `npm ci` -> `prisma generate` -> build ->
    `prisma migrate deploy` -> restart -> health check -> cleanup, end to end.
  - **Failure/rollback path**: a release with one deliberately broken migration correctly
    rolls back to the previous version, restarts it successfully, and leaves a clear log -
    exactly what the design promises.

  Getting a *clean* pass took a few real rounds of debugging against real failures (all now
  fixed, kept for the record since they're the kind of thing worth knowing about):
  - `psql` returning zero rows came back as PowerShell `$null`, and `$null.Trim()` threw -
    masked what was actually a normal "database doesn't exist yet" case as a crash.
  - **A genuine bug in `apply-update.ps1` itself**, not just the test harness:
    `src/generated/prisma` (the Prisma Client `src/lib/db.ts` imports) is gitignored, so it's
    never in a release archive. `prisma migrate deploy` deliberately does not generate it
    (only `migrate dev` does), and nothing else in the script did either - every *real* future
    update would have hit `Module not found: '@/generated/prisma/client'` at the build step.
    Fixed by adding an explicit `prisma generate` before the build.
  - The test harness's own service setup used a `-p <port>` CLI flag to keep the test app off
    the real app's port 3000 - but `apply-update.ps1` deliberately resets `AppParameters` to
    plain `run start` on every successful update (correct for the *real* service), which
    silently wiped that flag and made the test service try to rebind onto port 3000. Fixed by
    driving the port through a `PORT` environment variable instead (NSSM
    `AppEnvironmentExtra`), which survives that reset.
  - A real bug in the test harness's own pass/fail check: the nested `apply-update.ps1`
    process's console output wasn't suppressed, so it became extra elements in the array
    PowerShell's `return $LASTEXITCODE` actually produced - comparing that array with
    `-eq 0`/`-ne 0` checks *array membership*, not the exit code, silently wrong either way
    regardless of the real result. (This is why an early run reported "PASS" - a coincidence
    of which comparison operator was used, not a real check.) Fixed by piping the nested
    process's output to `Out-Host` instead of leaving it to leak into the function's return
    value.

  None of this touched the real `RestaurantApp`/`RestaurantPrintAgent`/`RestaurantSync`
  services or the real `restaurant` database at any point.

## Release hosting

The main app repo (`restaurant-reservation-app`) is **private** (confirmed via the GitHub
API - an anonymous request to it 404s). Publishing release artifacts as public GitHub
Releases on that repo would expose the entire source tree, which defeats the point of
building this as a product. Decision: **a separate, dedicated releases repo**
(`restaurant-app-releases` by convention — update `LauncherConfig`'s default `ManifestUrl` if
you name it differently) that holds **only** built release zips + `version.json` manifests,
never source. This also means the launcher never needs an embedded GitHub token just to check
for updates — it's a plain anonymous `raw.githubusercontent.com` fetch of a public
`latest.json`.

**Not yet done**: actually creating that repo. Until it exists, `UpdateChecker.FetchLatestAsync`
will just fail to fetch (handled gracefully — the launcher opens whatever version is already
installed, no update applied) or you can point a `launcher.config.json` next to the exe at a
throwaway test repo/URL first.

### Cutting a release (once the releases repo exists)

1. Bump `package.json`'s `version`, add a `CHANGELOG.md` entry.
2. Build the app for production and zip up exactly what an install needs (source +
   `package.json`/`package-lock.json`/`prisma/` — **not** `node_modules`, `.env`, or the
   rotated `*.log` files sitting in the repo root today; `npm ci && npm run build` happens
   on the restaurant's machine during the update, per `apply-update.ps1`).
3. Compute the zip's SHA256 (`Get-FileHash -Algorithm SHA256`), publish the zip as a GitHub
   Release on the releases repo, and commit a `latest.json` (shape: see
   `release-manifest.example.json`) to the releases repo pointing at it.

## Verification (per the approved plan)

1. ✅ `dotnet build` cleanly.
2. ✅ `maxAge` fix: cookie carries a real 60-day expiry, survives closing/reopening WebView2.
3. ✅ Launches, starts services, shows the login gate, reaches the dashboard, stays logged in
   across a launcher restart. (No second machine was available, so this ran against this
   restaurant's real machine — but only the read-only/non-destructive parts: starting
   already-configured services, opening a browser view, completing a login. See the Status
   section above for exactly why the update-apply path specifically was *not* tested this
   way.)
4. ✅ Full update path (detect → stop → replace → migrate → restart → healthy), proven via
   `scripts/test-update-flow.ps1`'s disposable, fully isolated test install rather than the
   real one — deliberately safer than "a second machine" for this specific step, since it
   avoids ever needing physical access to a second machine at all while still using real
   Windows Services, a real Postgres database, and the actual unmodified script.
5. ✅ Failure/rollback path (a deliberately broken migration), proven the same way.
6. **Still outstanding**: an actual second machine (or at least a fresh clone) test — today's
   testing proves the *mechanism* works correctly, but every run so far has been on this one
   machine's already-configured environment (existing Node/NSSM/Postgres installs, etc.).
   Worth doing before this is trusted for a real restaurant that isn't this one.

## What's deliberately NOT in Phase 1

Postgres/Node/NSSM auto-provisioning for a brand-new machine (now built - see "Phase 2"
below), licensing/accounts/billing, a multi-restaurant switcher UI (the
`User`↔`Restaurant` `Membership` schema already supports it, just no UI yet), voice/ngrok
automation (already moved to cloud, nothing local to automate), a real (paid/CA-issued)
code-signing certificate for actual distribution (see "Code signing" below — this turned out
to be a harder requirement than expected, not deferrable purely as "nice to have"), and a
real onboarding wizard that collects Twilio/Anthropic/Resend keys and generates `AGENT_TOKEN`
(Phase 3 - see "Phase 2" below for why that boundary is where it is).

## Code signing

**Correction to an earlier assumption in this doc**: running an unsigned exe was expected to
trigger a dismissible Windows SmartScreen warning ("Run anyway"). What actually happened on
this machine, confirmed via the `Microsoft-Windows-CodeIntegrity/Operational` event log
(event IDs 3077/3033): **Windows 11's Smart App Control** (a separate, stricter mechanism)
blocked the launcher outright — "did not meet the Enterprise signing level requirements" —
with no click-through override. Checked its actual state
(`HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy\VerifiedAndReputablePolicyState`): `1`
(fully "On"/enforced), not the "Evaluation" mode that allows unsigned apps while it learns.
Per Microsoft's own design, once Smart App Control reaches "On" it **cannot be turned off
without reinstalling Windows** — it's built that way specifically so malware can't disable
it.

**Dev-machine workaround** (`launcher/scripts/sign-launcher.ps1`, no elevation needed): a
self-signed code-signing certificate, installed into this machine's own `CurrentUser\Root`
and `CurrentUser\TrustedPublisher` stores, then used to sign the published exe. Smart App
Control accepted this — its requirement is a valid trust chain, not specifically a paid CA.
**Run this after every `dotnet publish`** — publishing always produces a fresh, unsigned exe,
so an unsigned rebuild will get blocked again until it's re-signed.

**This does not solve distribution** — it only makes this one machine trust a certificate
*this session generated on it*. A different restaurant's fresh Windows machine has no reason
to trust that certificate and would hit the identical block with no fix available this way.
Real distribution needs a real Authenticode certificate from a CA, ideally EV (which gets
instant reputation, vs. a standard cert that has to build reputation over time via other
users actually running signed builds) — this is now a confirmed, real requirement for Phase 5
(or possibly worth pulling earlier), not just a "SmartScreen is a bit annoying" inconvenience
as originally framed.

## Phase 2 — installer for a brand-new machine

Gets a genuinely blank Windows machine (no Node, no Postgres, no services) to a working
install, driven by the launcher instead of by hand — the thing Phase 1 always assumed was
already done. `MainForm.cs`'s "missing services" branch now offers a **"Set up this
machine"** button instead of a dead-end error message; clicking it elevates once (same
pattern as the update-apply step) and runs `scripts/provision-machine.ps1`.

**What it does, in order**: installs Node.js if missing (official MSI, silent), installs
PostgreSQL if missing (official EDB installer, unattended, then creates a dedicated
`restaurant` role/database), generates a fresh `.env` (real `SESSION_SECRET` and
`DATABASE_URL`; Twilio/Anthropic/Resend keys and `AGENT_TOKEN` are left blank — see below for
why), fetches the latest release from the manifest, builds it, migrates the (empty) database,
and registers + starts the three core services at `C:\ProgramData\RestaurantApp\app` — a
plain, non-cloud-synced path, so the OneDrive-junction class of problem (see `next.config.ts`,
`scripts/rebuild-app.ps1`) never needs to exist on a new install at all.

**Where this phase deliberately stops**: it does not create a restaurant. `AGENT_TOKEN` lives
on the `Restaurant` row in the database, which doesn't exist yet at this point — opening the
app for the first time after provisioning lands on the **existing** `/login` → `/onboarding`
flow to create one, same as it already does today. Collecting Twilio/Anthropic/Resend keys
and wiring `AGENT_TOKEN` into `.env` automatically is Phase 3's job (a real onboarding
wizard), not this one's.

**Shared logic, not duplicated**: `scripts/lib/install-app.ps1` now holds the
unpack → `npm ci` → `prisma generate` → build sequence (and `Find-Nssm`/`Find-Npm`), used by
`apply-update.ps1`, `provision-machine.ps1`, and `test-update-flow.ps1` alike — extracted
specifically because the three scripts had already drifted apart once for real (the
`prisma generate` fix originally landed in `apply-update.ps1` and had to be separately ported
to the test harness).

**NSSM is now bundled** (`tools/nssm.exe`, shipped in the launcher's own publish output),
not discovered via a WinGet install that a brand-new machine has no reason to have.

**Status: builds, compiles, and the non-installation logic is verified** — `dotnet build`
clean, the publish output's file layout manually inspected and confirmed correct (`scripts\`,
`scripts\lib\`, `tools\nssm.exe` all land where the C# code expects), the manifest-fetch and
already-installed-detection logic tested directly against real Node/Postgres on this machine
(both correctly detected as already present, so their "skip" branches were exercised for
real). **The actual install-from-scratch branches (silently installing Node/Postgres) have
not been run for real** — this machine already has both, so those branches can't be
meaningfully exercised here, the same honest gap Phase 1's "a second machine" step never fully
closed either. A real pass needs a genuinely blank Windows VM.

**Bugs caught before ever running for real**, worth keeping on record:
- `New-RandomSecret` originally used `RandomNumberGenerator`'s static `::Fill()` method — a
  .NET 6+ API that doesn't exist under Windows PowerShell 5.1's .NET Framework runtime.
  Confirmed by testing it directly: it failed with `MethodNotFound`, but — worse — the buffer
  was left as all zeros rather than the call throwing loudly, so every "random" secret
  (`SESSION_SECRET`, the generated Postgres password) would have been byte-for-byte identical
  on every fresh install. Fixed with the .NET Framework-compatible
  `::Create()` + `.GetBytes()` pattern and re-verified it produces genuinely distinct output.
- The csproj's script-bundling glob included an explicit `<Link>` that was relative to the
  glob's own base folder, not the project root — silently stripped the `scripts\` prefix and
  copied every script flat into the publish root instead of `scripts\...`, where the C# code
  (`Path.Combine(exeDirectory, "scripts", ...)`) actually looks for them. Caught by actually
  listing the publish output's file layout, not just checking `dotnet build` succeeded.
- `tools\nssm.exe`, bundled via a plain `<None Include>` (works fine for the `.ps1` scripts),
  silently never reached the publish output specifically — present in the ordinary build
  output, absent from `publish\`, no warning either way. `PublishSingleFile` evidently filters
  `.exe` content items differently. Fixed via an explicit `ResolvedFileToPublish` target
  (the documented mechanism for forcing an extra native file into single-file publish output),
  and re-verified the file actually lands at `publish\tools\nssm.exe` with the right size.
