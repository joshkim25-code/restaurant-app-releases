# Applies one update to a Restaurant App install: stops the 3 core services, replaces the
# app's code with a new release, runs pending Prisma migrations, and restarts - or, if the
# migration step fails, restores the previous version instead of leaving a half-updated,
# possibly-broken install running unattended on a restaurant's machine.
#
# This is invoked by the launcher (RestaurantLauncher.exe) when it finds a newer version -
# not meant to be run by hand day-to-day, though it can be for testing (see launcher/README.md).
# Must run elevated (NSSM service control requires admin rights) - the launcher requests
# elevation via `Start-Process -Verb RunAs` only for this step, not for normal app use.
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File apply-update.ps1 `
#     -InstallDir "C:\ProgramData\RestaurantApp\app" `
#     -DownloadUrl "https://github.com/.../restaurant-app-1.2.0.zip" `
#     -ExpectedSha256 "abc123..." `
#     -Version "1.2.0"
#
# -AppServiceName/-PrintAgentServiceName/-SyncServiceName/-HealthCheckUrl default to the real
# service names/URL, so normal (real) use is unaffected - they exist so
# launcher/scripts/test-update-flow.ps1 can point this exact, unmodified script at a
# disposable test install (different service names, different port) instead of ever running
# it against the live install while proving it out.

param(
  [Parameter(Mandatory = $true)][string]$InstallDir,
  [Parameter(Mandatory = $true)][string]$DownloadUrl,
  [Parameter(Mandatory = $true)][string]$ExpectedSha256,
  [Parameter(Mandatory = $true)][string]$Version,
  [string]$AppServiceName = "RestaurantApp",
  [string]$PrintAgentServiceName = "RestaurantPrintAgent",
  [string]$SyncServiceName = "RestaurantSync",
  [string]$HealthCheckUrl = "http://localhost:3000/login"
)

$ErrorActionPreference = "Stop"

# Same fix as provision-machine.ps1's own - a separate script, a separate powershell.exe
# process, so this has to be set here too, not just there. Windows PowerShell 5.1's default
# enabled SecurityProtocol set can leave TLS 1.2 disabled even on an up-to-date Windows
# install; without this, the download below can fail with a generic, unhelpful "underlying
# connection was closed" error instead of actually explaining what went wrong. -bor (add Tls12)
# rather than a flat assignment (replace the whole set) - see provision-machine.ps1's own
# comment on this same line for why: confirmed necessary on a real device.
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

. (Join-Path $PSScriptRoot "lib\install-app.ps1")

$logDir = Join-Path (Split-Path -Parent $InstallDir) "update-logs"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$logFile = Join-Path $logDir "update-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
Start-Transcript -Path $logFile -Force | Out-Null

$services = @($AppServiceName, $PrintAgentServiceName, $SyncServiceName)
# RestaurantVoice / RestaurantVoiceTunnel are deliberately left alone - voice now runs in
# the cloud, and these are typically already stopped/manual on a restaurant's machine.

function Stop-CoreServices($nssm) {
  foreach ($name in $services) {
    if (Get-Service -Name $name -ErrorAction SilentlyContinue) {
      Write-Output "Stopping $name..."
      & $nssm stop $name | Out-Null
    }
  }
}

function Start-CoreServices($nssm) {
  foreach ($name in $services) {
    if (Get-Service -Name $name -ErrorAction SilentlyContinue) {
      Write-Output "Starting $name..."
      & $nssm start $name | Out-Null
    }
  }
}

function Wait-ForHealthy {
  param([int]$TimeoutSeconds = 30)
  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  while ((Get-Date) -lt $deadline) {
    try {
      $resp = Invoke-WebRequest -Uri $HealthCheckUrl -UseBasicParsing -TimeoutSec 5
      if ($resp.StatusCode -eq 200) { return $true }
    } catch {
      # Not up yet - keep polling.
    }
    Start-Sleep -Seconds 1
  }
  return $false
}

$nssm = Find-Nssm

$backupDir = "$InstallDir.bak"
$downloadedZip = Join-Path $env:TEMP "restaurant-app-$Version.zip"

Write-Output "=== Applying update to version $Version ==="
Write-Output "Install dir: $InstallDir"

try {
  Get-VerifiedRelease -Url $DownloadUrl -ExpectedSha256 $ExpectedSha256 -OutPath $downloadedZip

  Stop-CoreServices $nssm
  Start-Sleep -Seconds 1

  # Rename rather than delete - the cheap escape hatch this whole flow depends on: if
  # anything below fails, the previous, known-good install is still sitting right here.
  if (Test-Path $backupDir) { Remove-Item -Recurse -Force $backupDir }
  if (Test-Path $InstallDir) { Rename-Item -Path $InstallDir -NewName (Split-Path -Leaf $backupDir) }

  Write-Output "Extracting new version..."
  Expand-Archive -Path $downloadedZip -DestinationPath $InstallDir -Force

  # .env holds per-install secrets (DATABASE_URL, SESSION_SECRET, AGENT_TOKEN, etc.) - never
  # part of a release archive, always carried forward from the install being replaced.
  $envBackup = Join-Path $backupDir ".env"
  if (Test-Path $envBackup) {
    Copy-Item -Path $envBackup -Destination (Join-Path $InstallDir ".env") -Force
  } else {
    throw "No .env found in the previous install at $backupDir - can't safely continue without it."
  }

  Install-AppDependencies -InstallDir $InstallDir

  # The one genuinely unattended-unsafe step: a failed migration here can't be reliably
  # auto-reversed, so on failure this flow restores the OLD code (still compatible with
  # whatever the DB looked like before this migration attempt) rather than starting NEW
  # code against a possibly half-migrated schema.
  Write-Output "Running database migrations..."
  Push-Location $InstallDir
  # 2>&1 + Invoke-NativeAllowingStderr (lib\install-app.ps1) rather than a bare "& npx prisma
  # migrate deploy" - without it, this script's own $ErrorActionPreference = "Stop" would throw
  # on prisma's first stderr line before $migrateExitCode below is ever set, and separately, a
  # bare exit-code-only failure here gives no indication of what actually went wrong beyond
  # "exit code 1" - confirmed on a real device to be useless for diagnosing an actual failure.
  $migrateOutput = Invoke-NativeAllowingStderr { & npx prisma migrate deploy 2>&1 }
  $migrateOutput | ForEach-Object { Write-Output $_ }
  $migrateExitCode = $LASTEXITCODE
  Pop-Location

  if ($migrateExitCode -ne 0) {
    Write-Output ""
    Write-Output "MIGRATION FAILED (exit code $migrateExitCode) - rolling back to the previous version."
    Write-Output "prisma migrate deploy's own output: $($migrateOutput -join ' | ')"
    Write-Output "The database was NOT rolled back automatically (migrations aren't reliably"
    Write-Output "auto-reversible) - it's left exactly where the failed migration left it."
    Write-Output "Full details are in this log: $logFile"

    Remove-Item -Recurse -Force $InstallDir
    Rename-Item -Path $backupDir -NewName (Split-Path -Leaf $InstallDir)

    Start-CoreServices $nssm
    $healthy = Wait-ForHealthy
    if ($healthy) {
      Write-Output "Previous version restored and running - nothing was lost."
    } else {
      Write-Output "WARNING: previous version restored but didn't come back up healthy within 30s - check the services by hand (Get-Service Restaurant*)."
    }
    Stop-Transcript | Out-Null
    exit 1
  }

  Write-Output "Migrations applied successfully."

  # Match scripts/switch-app-to-production.ps1: ensure the service runs the built production
  # server, not `next dev` (relevant on a fresh install where this hasn't been set yet).
  & $nssm set $AppServiceName AppParameters "run start" | Out-Null

  Start-CoreServices $nssm
  $healthy = Wait-ForHealthy
  if (-not $healthy) {
    Write-Output ""
    Write-Output "WARNING: update applied and migrations succeeded, but the app didn't respond"
    Write-Output "healthy within 30s after restart. Automatic rollback isn't attempted at this"
    Write-Output "point - the database has already been migrated forward, so the OLD code is not"
    Write-Output "guaranteed compatible with it. Check services by hand (Get-Service Restaurant*)"
    Write-Output "and this log: $logFile"
    Stop-Transcript | Out-Null
    exit 1
  }

  Remove-Item -Recurse -Force $backupDir -ErrorAction SilentlyContinue
  Remove-Item -Force $downloadedZip -ErrorAction SilentlyContinue

  Write-Output ""
  Write-Output "Update to $Version complete and healthy."
  Stop-Transcript | Out-Null
  exit 0

} catch {
  Write-Output ""
  Write-Output "UPDATE FAILED: $($_.Exception.Message)"
  Write-Output "Attempting to restore the previous version if it's still available..."

  if ((Test-Path $backupDir) -and -not (Test-Path $InstallDir)) {
    Rename-Item -Path $backupDir -NewName (Split-Path -Leaf $InstallDir)
    Start-CoreServices $nssm
    $healthy = Wait-ForHealthy
    if ($healthy) {
      Write-Output "Previous version restored and running - nothing was lost."
    } else {
      Write-Output "WARNING: attempted to restore the previous version but it isn't responding healthy - check services by hand."
    }
  } elseif (Test-Path $InstallDir) {
    Write-Output "Install directory still present - starting services on whatever is there."
    Start-CoreServices $nssm
  } else {
    Write-Output "CRITICAL: neither the new nor the previous install directory could be found. Manual recovery needed - see $logFile."
  }

  Stop-Transcript | Out-Null
  exit 1
}
