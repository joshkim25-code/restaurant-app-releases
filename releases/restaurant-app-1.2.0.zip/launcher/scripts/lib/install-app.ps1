# Shared helpers, dot-sourced by apply-update.ps1, provision-machine.ps1, and
# test-update-flow.ps1 - the same unpack -> dependencies -> build sequence, and the same
# npm/nssm discovery, needs to behave identically everywhere it's used, or the scripts
# silently drift apart. That already happened once for real: `prisma generate` was added
# only to apply-update.ps1 first, and test-update-flow.ps1 needed the identical fix
# separately - exactly the kind of duplication this file exists to prevent going forward.
#
# Not a standalone script - has no param block of its own, only function definitions.
# Callers: `. (Join-Path $PSScriptRoot "lib\install-app.ps1")`

# The actual root cause behind a whole string of confusing failures chased in provision-
# machine.ps1's own history, confirmed by direct testing: with $ErrorActionPreference = "Stop"
# (set globally by every caller of this file) and a native command's stderr redirected via 2>&1,
# PowerShell throws a TERMINATING exception on the very first stderr line - carrying that raw
# line as the exception message - regardless of the command's real exit code, and BEFORE any
# $LASTEXITCODE check written after it is ever reached. Shared here (not just in
# provision-machine.ps1, where it originated) because every native command this file's own
# functions call (npm, npx prisma, and provision-machine.ps1/apply-update.ps1's own
# `prisma migrate deploy`) needs the identical fix to safely capture real error output instead
# of either losing it entirely or hitting this exact bug. Fix: temporarily relax
# $ErrorActionPreference around the native call only, restore it right after, then check
# $LASTEXITCODE normally - the standard, documented fix for this exact PowerShell 5.1 behavior.
function Invoke-NativeAllowingStderr {
  param([Parameter(Mandatory = $true)][scriptblock]$Command)
  $prevEap = $ErrorActionPreference
  $ErrorActionPreference = "Continue"
  try {
    & $Command
  } finally {
    $ErrorActionPreference = $prevEap
  }
}

# Runs a native command (its scriptblock MUST redirect stderr via 2>&1 itself, e.g.
# `{ & $npmCmd ci 2>&1 }`), streams its output live (so it still shows up in the transcript as
# it happens, same as before), and throws with the command's own real output included if it
# exits non-zero - instead of just "X failed with exit code 1", which was confirmed on a real
# device to be useless for diagnosing an actual failure once this script finally got far enough
# to reach these calls at all (no real device had ever exercised the app-install/migrate phase
# before that point). Every guess about a bare exit-code failure costs a full real-device round
# trip to even find out what actually went wrong; capturing the real text once here pays for
# itself immediately for all of npm ci / prisma generate / npm run build / prisma migrate deploy.
function Invoke-CheckedCommand {
  param(
    [Parameter(Mandatory = $true)][scriptblock]$Command,
    [Parameter(Mandatory = $true)][string]$Description
  )
  $output = Invoke-NativeAllowingStderr $Command
  $output | ForEach-Object { Write-Output $_ }
  if ($LASTEXITCODE -ne 0) {
    throw "$Description failed (exit ${LASTEXITCODE}): $($output -join "`n")"
  }
  return $output
}

# Patches a single KEY="value" line into an existing .env file in place, replacing it if
# present or appending it if not, and leaving every other line untouched - mirrors
# src/lib/localEnv.ts's setLocalEnvVar exactly, since both exist for the same reason (change
# one credential without disturbing whatever else is already in this restaurant's real .env).
# Used by provision-machine.ps1 to correct DATABASE_URL on a repeat run without wiping
# AGENT_TOKEN or anything else New-FreshEnvFile would otherwise reset to blank.
function Set-EnvFileVar {
  param(
    [Parameter(Mandatory = $true)][string]$EnvPath,
    [Parameter(Mandatory = $true)][string]$Key,
    [Parameter(Mandatory = $true)][string]$Value
  )
  $newLine = "$Key=`"$Value`""
  if (-not (Test-Path $EnvPath)) {
    Set-Content -Path $EnvPath -Value $newLine -Encoding utf8
    return
  }

  $lines = Get-Content -Path $EnvPath
  $pattern = "^$([regex]::Escape($Key))="
  $matchIndex = -1
  for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match $pattern) { $matchIndex = $i; break }
  }

  if ($matchIndex -ge 0) {
    if ($lines[$matchIndex] -eq $newLine) { return }
    $lines[$matchIndex] = $newLine
    Set-Content -Path $EnvPath -Value $lines -Encoding utf8
  } else {
    Add-Content -Path $EnvPath -Value $newLine -Encoding utf8
  }
}

function Find-Nssm {
  # $BundledPath (a launcher publish output's own tools\nssm.exe, see provision-machine.ps1)
  # is checked first - a brand-new machine has no WinGet install to scan for at all. Existing
  # callers that never pass it (apply-update.ps1, test-update-flow.ps1, both still running
  # against machines set up the original hand-configured way) get the original behavior
  # unchanged.
  param([string]$BundledPath)
  if ($BundledPath -and (Test-Path $BundledPath)) { return $BundledPath }
  $found = Get-ChildItem -Path "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Filter "nssm.exe" -Recurse -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -like "*win64*" } | Select-Object -First 1 -ExpandProperty FullName
  if ($found) { return $found }
  $onPath = Get-Command nssm.exe -ErrorAction SilentlyContinue
  if ($onPath) { return $onPath.Source }
  throw "nssm.exe not found - install it first: winget install --id NSSM.NSSM -e"
}

function Find-Npm {
  $default = "C:\Program Files\nodejs\npm.cmd"
  if (Test-Path $default) { return $default }
  $onPath = Get-Command npm.cmd -ErrorAction SilentlyContinue
  if ($onPath) { return $onPath.Source }
  throw "npm.cmd not found - install Node.js first."
}

# Downloads a release zip and verifies its checksum before anything touches disk beyond the
# download itself - refuses to extract a corrupted or tampered file.
#
# Retries a few times rather than failing on the first bad attempt - this exact class of
# download (large, third-party-hosted files this script has no control over: nodejs.org,
# get.enterprisedb.com, raw.githubusercontent.com) has shown up as genuinely flaky across
# multiple independent real-device incidents now: severe throttling, a TLS negotiation failure,
# and a mid-download connection reset, all against the same handful of hosts. A short retry
# costs nothing on the common case (succeeds on the first attempt) and turns a real but
# transient failure into a non-event instead of forcing a full manual re-run of the whole script.
#
# Progress messages use Write-Host, not Write-Output: this function is called from inside
# provision-machine.ps1's own Ensure-PostgresInstalled without its output being suppressed, and
# Ensure-PostgresInstalled's result IS captured by its caller (`$superPassword = Ensure-
# PostgresInstalled`) - confirmed as a real, active bug on a real device, Write-Output here would
# silently become part of that captured value alongside the real password. See the larger
# comment on this exact fix in Ensure-PostgresInstalled for the full mechanism.
function Get-VerifiedRelease {
  param(
    [Parameter(Mandatory = $true)][string]$Url,
    [Parameter(Mandatory = $true)][string]$ExpectedSha256,
    [Parameter(Mandatory = $true)][string]$OutPath,
    [int]$MaxAttempts = 3,
    [int]$DelaySeconds = 5
  )
  for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
    Write-Host "Downloading release from $Url (attempt $attempt of $MaxAttempts)..."
    Remove-Item $OutPath -ErrorAction SilentlyContinue
    $lastError = $null
    try {
      Invoke-WebRequest -Uri $Url -OutFile $OutPath -UseBasicParsing
      $actualSha256 = (Get-FileHash -Path $OutPath -Algorithm SHA256).Hash
      if ($actualSha256 -eq $ExpectedSha256) { return }
      $lastError = "downloaded file's SHA256 ($actualSha256) doesn't match the expected value ($ExpectedSha256)"
    } catch {
      # The underlying .NET exception on a failed request (TLS negotiation, DNS, timeout, etc.)
      # never names which URL it was trying - confirmed confusing on a real machine when this
      # failed with a generic "underlying connection was closed" error. Carried through to the
      # final throw below with the URL attached, so whoever reads this later (last-error.txt,
      # surfaced in the launcher's own status text) doesn't have to guess which of several
      # downloads this script makes was it.
      $lastError = $_.Exception.Message
    }
    if ($attempt -lt $MaxAttempts) {
      Write-Host "Download attempt $attempt failed ($lastError) - retrying in ${DelaySeconds}s..."
      Start-Sleep -Seconds $DelaySeconds
    }
  }
  throw "Request to $Url failed after $MaxAttempts attempts: $lastError"
}

# npm ci -> prisma generate -> npm run build, against an already-extracted install directory
# that already has its own .env in place (callers are responsible for that part - an update
# copies one forward from a backup, a fresh install generates one; genuinely different enough
# between the two that it doesn't belong in a shared helper).
function Install-AppDependencies {
  param([Parameter(Mandatory = $true)][string]$InstallDir)

  # Write-Host for progress messages, not Write-Output - this function's own result isn't
  # currently captured by any caller, but every function this fix touched elsewhere in this file
  # WAS captured and got silently corrupted by exactly this pattern (see Get-VerifiedRelease's
  # own comment above), so the same defensive fix is applied here too rather than leaving another
  # instance of the same landmine for whoever next captures this function's output.
  $npmCmd = Find-Npm
  Push-Location $InstallDir
  try {
    Write-Host "Installing dependencies..."
    Invoke-CheckedCommand -Description "npm ci" -Command { & $npmCmd ci 2>&1 } | Out-Null

    # src/generated/prisma (the Prisma Client code src/lib/db.ts imports) is gitignored, so
    # it's never part of a release archive - a fresh extraction has no client at all until
    # this runs. `prisma migrate deploy` deliberately does NOT generate it (unlike
    # `migrate dev`), and the build fails outright without it - confirmed by an actual test
    # run against a disposable install (see launcher/scripts/test-update-flow.ps1): "Module
    # not found: Can't resolve '@/generated/prisma/client'".
    Write-Host "Generating Prisma Client..."
    Invoke-CheckedCommand -Description "prisma generate" -Command { & npx prisma generate 2>&1 } | Out-Null

    Write-Host "Building..."
    Invoke-CheckedCommand -Description "npm run build" -Command { & $npmCmd run build 2>&1 } | Out-Null

    # Same reasoning as scripts/rebuild-app.ps1: a successful build command doesn't always
    # mean BUILD_ID has actually finished writing yet.
    $buildId = Join-Path $InstallDir ".next-prod\BUILD_ID"
    $waited = 0
    while (-not (Test-Path $buildId) -and $waited -lt 30) {
      Start-Sleep -Seconds 1
      $waited++
    }
    if (-not (Test-Path $buildId)) {
      throw "Build did not produce .next-prod\BUILD_ID after ${waited}s - build likely incomplete."
    }
  } finally {
    Pop-Location
  }
}
