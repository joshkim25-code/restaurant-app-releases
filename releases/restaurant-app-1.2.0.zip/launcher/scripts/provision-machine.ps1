# Gets a genuinely blank Windows machine (no Node, no Postgres, no services) to a working,
# freshly-installed app: installs Node.js and PostgreSQL if missing, creates a dedicated
# Postgres role/database, generates a fresh .env, fetches the latest release from the
# manifest, builds it, migrates the (empty) database, and registers + starts the three core
# services. Does NOT create a restaurant - opening the app for the first time after this
# lands on the existing /login -> /onboarding flow for that (see launcher/README.md's Phase 2
# notes on why that boundary is where it is: agentToken lives on the Restaurant row, which
# can't exist yet here).
#
# Invoked by the launcher when it finds no core services registered at all - not meant to be
# run by hand day-to-day, though it can be for testing. Must run elevated (msiexec, the
# Postgres installer, and NSSM service registration all need admin rights) - same pattern as
# apply-update.ps1: the launcher requests elevation only for this step.
#
# Idempotent - safe to re-run; each stage is skipped if its result already exists, same
# philosophy as test-update-flow.ps1.
#
# Usage:
#   powershell -ExecutionPolicy Bypass -File provision-machine.ps1 `
#     -ManifestUrl "https://raw.githubusercontent.com/.../latest.json" `
#     -InstallDir "C:\ProgramData\RestaurantApp\app"

param(
  [string]$ManifestUrl = "https://raw.githubusercontent.com/joshkim25-code/restaurant-app-releases/main/latest.json",
  [string]$InstallDir = "C:\ProgramData\RestaurantApp\app",
  [string]$DbName = "restaurant",
  [string]$DbUser = "restaurant",
  # NOT Postgres's default (5432) - deliberately. Confirmed on a real machine: this script only
  # ever checked for a service literally named postgresql-x64-* before assuming a fresh install
  # was safe, and a machine can easily already have some OTHER, unrelated software's Postgres
  # (a POS system, in the confirmed case) registered under a different name, quietly listening
  # on 5432 already. Installing there too collides, and this script has no business ever
  # touching a Postgres instance it didn't create itself. Its own dedicated instance on its own
  # dedicated port can't conflict with anything already on the machine, full stop - no
  # detection logic needed, no risk of guessing wrong about what else's data is on 5432.
  [int]$DbPort = 5433,
  [string]$AppServiceName = "RestaurantApp",
  [string]$PrintAgentServiceName = "RestaurantPrintAgent",
  [string]$SyncServiceName = "RestaurantSync",
  [string]$HealthCheckUrl = "http://localhost:3000/login"
)

$ErrorActionPreference = "Stop"

# Windows PowerShell 5.1's Invoke-WebRequest renders a progress bar by default, and updating it
# per chunk has severe overhead on large files - a well-documented issue that can make a
# multi-hundred-MB download (the Postgres installer, ~350MB) take dramatically longer than a
# normal browser download, to the point of looking hung. Confirmed on a real machine: stuck for
# over an hour on that exact download. SilentlyContinue skips the rendering entirely.
$ProgressPreference = "SilentlyContinue"

# Windows PowerShell 5.1 runs on .NET Framework, whose default enabled SecurityProtocol set
# depends on the machine's own configuration/OS defaults and can leave TLS 1.2 disabled even on
# an otherwise up-to-date Windows 10/11 install - unlike a real browser, which negotiates TLS
# version independently of this. Every host this script talks to (nodejs.org,
# get.enterprisedb.com, raw.githubusercontent.com) requires TLS 1.2+; without this, requests
# fail with a generic, unhelpful "The underlying connection was closed: An unexpected error
# occurred on a send." - confirmed on a real fresh Windows machine. Set once, process-wide,
# before any request below (including ones made from lib\install-app.ps1's functions, dot-
# sourced into this same process next).
#
# -bor (add Tls12 to whatever's already enabled) rather than a flat assignment (replace the
# whole set with only Tls12) - confirmed necessary on a real device where the flat-assignment
# version still hit the same "underlying connection was closed" error against
# get.enterprisedb.com specifically. A flat assignment can strip out protocol/negotiation state
# some endpoints' handshake quirks still depend on even when TLS 1.2 is the one actually
# selected; OR-ing it in is strictly additive and never removes anything the OS already enabled.
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

. (Join-Path $PSScriptRoot "lib\install-app.ps1")

$logDir = Join-Path (Split-Path -Parent $InstallDir) "provision-logs"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$logFile = Join-Path $logDir "provision-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
Start-Transcript -Path $logFile -Force | Out-Null

# Pinned, not "latest" - deliberately the same version already proven to build and run this
# exact codebase on this machine throughout this whole project, not a moving target that
# could silently introduce an incompatibility. Bump these on purpose, not by drift.
$NodeVersion = "24.19.0"
$NodeMsiUrl = "https://nodejs.org/dist/v$NodeVersion/node-v$NodeVersion-x64.msi"
# Major version 16, not 17 - deliberately different from whatever major version this script
# might have installed on an earlier attempt, or whatever unrelated software already has on the
# machine (confirmed on a real device: a POS system's own separate PostgreSQL install).
# Different major versions install as fully independent, non-conflicting instances (own
# directory, own service, own everything) - the standard installer does NOT reliably support
# two separate instances of the SAME major version side by side even on different ports, which
# is almost certainly why an earlier attempt on this exact machine reported success but left
# nothing actually listening on the new port (Get-Service matched the pre-existing v17 service,
# not a genuinely new one). Switching major version sidesteps needing to know or touch whatever
# else is already on the machine at all.
$PostgresVersion = "16.14-2"
$PostgresInstallerUrl = "https://get.enterprisedb.com/postgresql/postgresql-$PostgresVersion-windows-x64.exe"

function New-RandomSecret {
  # RandomNumberGenerator's static ::Fill() is a newer (.NET 6+) API not available under
  # Windows PowerShell 5.1's .NET Framework runtime (confirmed by testing this in isolation -
  # it fails with MethodNotFound and, worse, doesn't throw loudly enough to stop the script:
  # the buffer is silently left as all zeros, producing the exact same "random" secret every
  # time). ::Create() + .GetBytes() is the .NET Framework-compatible pattern.
  param([int]$Bytes = 32)
  $buffer = New-Object byte[] $Bytes
  $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
  try {
    $rng.GetBytes($buffer)
  } finally {
    $rng.Dispose()
  }
  return [Convert]::ToBase64String($buffer)
}

function New-RandomAlphanumericSecret {
  # Base64 (New-RandomSecret above) can contain +, /, = - fine for a quoted .env value, but not
  # safe passed as a command-line argument into the Postgres installer's own unattended-mode
  # parsing, nor safe embedded unescaped in a postgresql:// connection string URL. Confirmed on
  # a real machine: the installer's --superpassword argument didn't survive a Base64 password
  # intact, so a later psql connection with the same (script's-side) password failed with
  # "password authentication failed". Alphanumeric avoids both classes of problem entirely.
  param([int]$Length = 24)
  $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
  $buffer = New-Object byte[] $Length
  $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
  try {
    $rng.GetBytes($buffer)
  } finally {
    $rng.Dispose()
  }
  return -join ($buffer | ForEach-Object { $chars[$_ % $chars.Length] })
}

function Ensure-NodeInstalled {
  $existing = Get-Command node.exe -ErrorAction SilentlyContinue
  if ((Test-Path "C:\Program Files\nodejs\node.exe") -or $existing) {
    Write-Output "Node.js already installed."
    return
  }

  Write-Output "Node.js not found - downloading and installing v$NodeVersion..."
  $msiPath = Join-Path $env:TEMP "node-v$NodeVersion-x64.msi"
  # Invoke-WebRequest -OutFile overwrites an existing file anyway, but a stale partial file
  # from a prior interrupted run (e.g. the setup window was killed mid-download) is removed
  # explicitly first rather than relying on that implicitly - also sidesteps the rare case
  # of a locked leftover file from a crashed process blocking the write.
  Remove-Item $msiPath -ErrorAction SilentlyContinue
  try {
    Invoke-WebRequest -Uri $NodeMsiUrl -OutFile $msiPath -UseBasicParsing
  } catch {
    throw "Request to $NodeMsiUrl failed: $($_.Exception.Message)"
  }

  $proc = Start-Process -FilePath "msiexec.exe" -ArgumentList @("/i", "`"$msiPath`"", "/quiet", "/norestart") -Wait -PassThru
  if ($proc.ExitCode -ne 0) {
    throw "Node.js installer exited with code $($proc.ExitCode)."
  }
  Remove-Item $msiPath -ErrorAction SilentlyContinue

  if (-not (Test-Path "C:\Program Files\nodejs\node.exe")) {
    throw "Node.js install reported success but node.exe still isn't at the expected path."
  }
  Write-Output "Node.js v$NodeVersion installed."
}

# Unconditionally removes OUR OWN dedicated instance (the exact major version this script
# installs, at its own dedicated port - never Postgres's default 5432, never anything another
# program might depend on) before every fresh-install attempt, rather than trying to detect
# whether a previous attempt left something usable. Safe specifically because of *when* this
# whole script ever runs at all: only when the launcher has already determined core services
# aren't registered yet (see MainForm.cs) - meaning no real restaurant data can possibly exist
# in this instance yet, regardless of how far a previous attempt got. This removes the entire
# class of "it's already installed, but is it actually usable, and if not why" ambiguity that
# caused four separate real-machine failures in a row to chase down individually.
function Uninstall-OwnPostgres {
  $majorVersion = $PostgresVersion.Split('.')[0]
  $installDir = "C:\Program Files\PostgreSQL\$majorVersion"
  if (-not (Test-Path $installDir)) { return }

  Write-Host "Removing a previous PostgreSQL $majorVersion install before setting up fresh..."

  $serviceName = "postgresql-x64-$majorVersion"
  $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
  if ($service -and $service.Status -ne "Stopped") {
    Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue
  }

  $uninstaller = Join-Path $installDir "uninstall-postgresql.exe"
  if (Test-Path $uninstaller) {
    # --mode unattended/--unattendedmodeui none aren't published in EDB's own uninstall docs
    # (only their install docs cover unattended mode) - the same InstallBuilder-framework
    # flags the installer itself uses, corroborated by real-world unattended-uninstall scripts
    # elsewhere, but not confirmed by EDB directly. Acceptable here specifically because the
    # worst case (it doesn't fully clean up, or exits non-zero) just leaves the directory
    # behind for the Remove-Item below to finish the job anyway - there's no real data in this
    # instance to lose either way, unlike the earlier, declined idea of auto-uninstalling a
    # potentially-unrelated, potentially-real Postgres install elsewhere on a machine.
    $proc = Start-Process -FilePath $uninstaller -ArgumentList @("--mode", "unattended", "--unattendedmodeui", "none") -Wait -PassThru
    if ($proc.ExitCode -ne 0) {
      Write-Host "PostgreSQL $majorVersion uninstaller exited with code $($proc.ExitCode) - removing its directory directly instead."
    }
  }

  # EDB's uninstaller deliberately leaves the data directory behind (documented behavior, so it
  # never silently discards a real database) - remove the whole directory explicitly, since
  # there's genuinely nothing worth preserving in our own dedicated instance at the point this
  # script ever runs.
  Remove-Item -Path $installDir -Recurse -Force -ErrorAction SilentlyContinue
  Start-Sleep -Seconds 2
}

# Single source of truth for this script's own dedicated PostgreSQL service name - shared by
# Ensure-PostgresInstalled (which looks it up right after install) and Ensure-AppDatabase (which
# needs it again to re-run Reset-PostgresSuperuserPassword if the password stops verifying).
# Deterministic from $PostgresVersion, same reasoning as Find-PgMajorVersionDir below.
function Get-PgServiceName {
  return "postgresql-x64-$($PostgresVersion.Split('.')[0])"
}

function Ensure-PostgresInstalled {
  # Returns the generated superuser password, needed later to create the app's own role.
  #
  # Every progress message inside this function (and inside Uninstall-OwnPostgres and
  # Get-VerifiedRelease, both called from here without suppressing their output) uses Write-Host,
  # never Write-Output - confirmed as a real, active bug on a real device: the caller captures
  # this function's result as `$superPassword = Ensure-PostgresInstalled`, and in PowerShell that
  # captures EVERY object written to the success/output stream during the whole call, not just
  # the value passed to the final `return` - Write-Output calls (this function's own, plus any
  # from nested calls whose output isn't piped to `| Out-Null`) all become part of what gets
  # captured, silently corrupting $superPassword into a garbled string containing every progress
  # message concatenated with the real password. Write-Host bypasses the success stream entirely
  # (still visible on screen and still captured by Start-Transcript), so it can never leak into a
  # captured return value this way.
  Uninstall-OwnPostgres

  Write-Host "PostgreSQL not found - downloading and installing v$PostgresVersion..."
  $installerPath = Join-Path $env:TEMP "postgresql-$PostgresVersion-windows-x64.exe"
  # Verified by hand (two independent downloads, identical hash) against the real file at
  # $PostgresInstallerUrl on 2026-09-25 - not published by EDB anywhere this script can fetch
  # automatically, so it's pinned here the same way $PostgresVersion itself is. Catches a
  # corrupted/truncated download outright instead of handing a bad file to the installer and
  # getting a confusing failure - a real risk on an unreliable connection, confirmed on a real
  # machine where this exact download was severely throttled.
  $PostgresInstallerSha256 = "6D3919BC23CFB45E79C6E391DE8B689C32101F2C1B73377AA26E4CE593C0EF28"
  Get-VerifiedRelease -Url $PostgresInstallerUrl -ExpectedSha256 $PostgresInstallerSha256 -OutPath $installerPath

  $superPassword = New-RandomAlphanumericSecret -Length 24
  # Deliberately NOT passing --debugtrace/--debuglevel here anymore (added in 1.0.4, removed in
  # 1.0.8) - those flags were only ever confirmed against EDB's docs for their commercial EPAS
  # product, never for this plain community PostgreSQL installer, and were flagged as
  # unverified-but-likely-fine at the time. Real machine evidence says otherwise: the
  # password-authentication-failure bug 1.0.3 already fixed once (a generated password not
  # surviving into the installer) came back on 1.0.6, which has 1.0.3's alphanumeric-password
  # fix but also these flags - the flags landing right after --superpassword in the argument
  # list, unrecognized by this installer, are the most likely explanation for corrupting how
  # --superpassword's value got parsed. Not worth keeping an unverified diagnostic aid that may
  # be actively causing the exact bug it was added to help diagnose.
  $proc = Start-Process -FilePath $installerPath -ArgumentList @(
    "--mode", "unattended",
    "--unattendedmodeui", "none",
    "--superpassword", $superPassword,
    "--serverport", "$DbPort",
    "--disable-components", "pgAdmin,stackbuilder"
  ) -Wait -PassThru
  if ($proc.ExitCode -ne 0) {
    throw "PostgreSQL installer exited with code $($proc.ExitCode)."
  }
  Remove-Item $installerPath -ErrorAction SilentlyContinue

  # Exact name, not the "postgresql-x64-*" wildcard used elsewhere for display purposes only -
  # with a leftover PostgreSQL 17 also present, the wildcard matches BOTH services and returns
  # an array, which would have silently passed something like "postgresql-x64-16
  # postgresql-x64-17" as a single service name to Restart-Service later - the exact same class
  # of "assumed only one Postgres install would ever exist" bug as Find-PgBin/Find-PgDataDir.
  $expectedServiceName = Get-PgServiceName
  $service = Get-Service -Name $expectedServiceName -ErrorAction SilentlyContinue
  if (-not $service) {
    throw "PostgreSQL install reported success but no '$expectedServiceName' service was found."
  }
  # The installer starts the service itself, but give it a moment to finish accepting
  # connections before anything tries to use it.
  Start-Sleep -Seconds 5
  Write-Host "PostgreSQL v$PostgresVersion installed and running ($($service.Name))."

  # --superpassword has now proven unreliable across three separate real-machine failures
  # (special characters, unrecognized flags corrupting it, and now a genuinely fresh, isolated
  # install with no other explanation) - rather than continuing to chase why, the password is
  # now set explicitly and deterministically afterward, independent of whatever --superpassword
  # actually did or didn't do.
  Write-Host "Setting the superuser password directly (not trusting --superpassword alone)..."
  Reset-PostgresSuperuserPassword -NewPassword $superPassword -ServiceName $service.Name

  return $superPassword
}

# Deterministic, not "search Program Files\PostgreSQL and pick whichever version sorts
# highest" (the original implementation) - confirmed as a real bug on a real machine: with a
# leftover PostgreSQL 17 install still present (from an attempt before this script switched to
# installing 16), a descending sort always put "17" first, so every call silently operated on
# the wrong, unrelated instance instead of the one this script actually just installed and
# cares about. $PostgresVersion (e.g. "16.14-2") is always this script's own install target, so
# deriving the exact directory from it can never pick the wrong coexisting instance, regardless
# of how many others happen to be on the machine.
function Find-PgMajorVersionDir {
  $majorVersion = $PostgresVersion.Split('.')[0]
  $dir = "C:\Program Files\PostgreSQL\$majorVersion"
  if (-not (Test-Path $dir)) {
    throw "Postgres installation directory not found at $dir (expected major version $majorVersion, from PostgresVersion '$PostgresVersion')."
  }
  return $dir
}

function Find-PgBin {
  $bin = Join-Path (Find-PgMajorVersionDir) "bin"
  if (-not (Test-Path (Join-Path $bin "psql.exe"))) {
    throw "psql.exe not found under $bin."
  }
  return $bin
}

function Find-PgDataDir {
  $dataDir = Join-Path (Find-PgMajorVersionDir) "data"
  if (-not (Test-Path (Join-Path $dataDir "pg_hba.conf"))) {
    throw "pg_hba.conf not found under $dataDir."
  }
  return $dataDir
}

# Standard, well-established Postgres password-recovery technique: temporarily allow
# passwordless ("trust") local connections for the postgres user only, use that to set a
# password we know for certain via a normal ALTER USER, then put pg_hba.conf back exactly as
# it was. Doesn't depend on already knowing (or on the installer having correctly set) any
# existing password - it works unconditionally, which is the whole point after --superpassword
# proved unreliable in practice.
function Reset-PostgresSuperuserPassword {
  param(
    [Parameter(Mandatory = $true)][string]$NewPassword,
    [Parameter(Mandatory = $true)][string]$ServiceName
  )

  $hbaPath = Join-Path (Find-PgDataDir) "pg_hba.conf"
  $originalContent = Get-Content -Path $hbaPath -Raw

  try {
    # Inserted at the very top - pg_hba.conf uses first-match-wins, so these rules take
    # precedence over whatever the installer configured below, regardless of its exact content.
    $trustRules = "host all postgres 127.0.0.1/32 trust`r`nhost all postgres ::1/128 trust`r`n"
    Set-Content -Path $hbaPath -Value ($trustRules + $originalContent) -Encoding ascii -NoNewline
    Restart-Service -Name $ServiceName -Force
    Start-Sleep -Seconds 3

    $psql = Join-Path (Find-PgBin) "psql.exe"
    $escapedPassword = $NewPassword.Replace("'", "''")
    # See Invoke-NativeAllowingStderr's own comment (below in this file) for why this matters -
    # without it, this line throws immediately on psql's own stderr output, with the raw
    # message, before $LASTEXITCODE below is ever checked.
    Invoke-NativeAllowingStderr {
      & $psql -h localhost -p $DbPort -U postgres -d postgres -c "ALTER USER postgres WITH PASSWORD '$escapedPassword';" 2>&1 | Out-Null
    }
    if ($LASTEXITCODE -ne 0) {
      throw "Could not set the postgres superuser password even via trust-mode auth (psql exit $LASTEXITCODE)."
    }
  } finally {
    # Always restore, even if the ALTER USER above failed - a permanently passwordless
    # postgres superuser is not an acceptable state to leave the machine in either way.
    Set-Content -Path $hbaPath -Value $originalContent -Encoding ascii -NoNewline
    Restart-Service -Name $ServiceName -Force
    Start-Sleep -Seconds 3
  }

  # Verify immediately, with retries, rather than trusting the ALTER USER above "succeeded"
  # and finding out three real-machine failures later that the password still doesn't work.
  if (-not (Wait-ForPostgresAuth -Password $NewPassword)) {
    throw "Reset the postgres superuser password, but verifying it afterward still failed after several attempts. Last error: $script:LastPgAuthError"
  }
}

# Invoke-NativeAllowingStderr now lives in lib\install-app.ps1 (dot-sourced at the top of this
# file) - moved there once apply-update.ps1's own `prisma migrate deploy` call and
# Install-AppDependencies's npm/prisma calls needed the identical fix, to avoid the exact kind
# of duplication-drift lib\install-app.ps1's own header comment already warns about.

# Shared by Reset-PostgresSuperuserPassword's own immediate verification above and
# Ensure-AppDatabase's first connection below - confirmed on a real machine that even after
# Reset-PostgresSuperuserPassword's OWN verification succeeded, Ensure-AppDatabase's very next
# connection attempt moments later still failed once, a genuine transient/timing gap right at
# that boundary, not a logic bug (a *different*, more specific error would show if it were).
# Retrying here too, rather than assuming one successful check elsewhere means every subsequent
# connection is safe.
# $script:LastPgAuthError carries the real psql output from the last failed attempt back to
# whichever caller decides to throw - now that Invoke-NativeAllowingStderr (above) actually lets
# $LASTEXITCODE-based retry logic run instead of being skipped by a premature terminating
# exception, a genuine failure here needs to say WHAT psql actually reported (connection
# refused, role/password mismatch, etc.) instead of a generic "something is wrong" guess -
# exactly the kind of guessing that cost several real-device round trips earlier in this
# feature's history before this file could even see real error text.
function Wait-ForPostgresAuth {
  param(
    [Parameter(Mandatory = $true)][string]$Password,
    [int]$MaxAttempts = 8,
    [int]$DelaySeconds = 2
  )
  $psql = Join-Path (Find-PgBin) "psql.exe"
  for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
    $env:PGPASSWORD = $Password
    try {
      $output = Invoke-NativeAllowingStderr {
        & $psql -h localhost -p $DbPort -U postgres -d postgres -c "SELECT 1;" 2>&1
      }
      if ($LASTEXITCODE -eq 0) { return $true }
      $script:LastPgAuthError = "psql exit ${LASTEXITCODE}: $($output -join ' ')"
    } finally {
      Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue
    }
    if ($attempt -lt $MaxAttempts) { Start-Sleep -Seconds $DelaySeconds }
  }
  return $false
}

function Invoke-Psql {
  param([string[]]$PsqlArgs)
  $psql = Join-Path (Find-PgBin) "psql.exe"
  $output = Invoke-NativeAllowingStderr { & $psql @PsqlArgs 2>&1 }
  if ($LASTEXITCODE -ne 0) {
    throw "psql failed (exit $LASTEXITCODE): $($output -join "`n")"
  }
  return $output
}

function Ensure-AppDatabase {
  param([string]$SuperPassword)

  # Every progress message below uses Write-Host, never Write-Output - confirmed as a real,
  # active bug on a real device: this function's real returned connection string
  # ("postgresql://...") got silently corrupted into a garbled string containing every one of
  # these progress messages concatenated with the real URL, because the caller captures this
  # function's result (`$databaseUrl = Ensure-AppDatabase ...`), which in PowerShell captures
  # EVERY object written to the success/output stream during the call, not just the final
  # `return` value. That corrupted value got written straight into .env's DATABASE_URL, which is
  # exactly what made the app's login fail with a Prisma "Can't reach database server at `base`"
  # error - `base` came from deep inside the word "database" in one of these very messages, once
  # Prisma tried to parse the whole garbled string as a connection URL. See the identical, larger
  # comment on this same fix in Ensure-PostgresInstalled above for the full mechanism.
  if (-not $SuperPassword) {
    throw "PostgreSQL was already installed before this script ran, so its superuser " +
      "password is unknown here - can't create the app's role/database unattended. " +
      "Create them by hand (see .env.example's default DATABASE_URL for the expected " +
      "shape: role '$DbUser', database '$DbName'), or run this against a machine where " +
      "PostgreSQL doesn't exist yet so this script can install and configure it fully."
  }

  # Confirmed on a real machine, with real psql error text now that Invoke-NativeAllowingStderr
  # (above) lets this actually surface: this isn't a timing gap. The error is a genuine "FATAL:
  # password authentication failed" - which only happens once the server is up, pg_hba.conf is
  # already asking for a password (not still stuck in trust mode), and the exact password
  # Reset-PostgresSuperuserPassword's own check just verified moments earlier is now being
  # rejected. Something external changes the stored password in that window - EDB's Windows
  # installer is the leading suspect, since it's a BitRock-style bootstrapper where -Wait on the
  # launcher process doesn't guarantee an async post-install child has finished touching the
  # instance. Rather than chase exactly which process does it, re-run the same unconditional,
  # password-independent trust-mode reset used right after install - it doesn't matter what the
  # current password actually is - immediately before this function actually needs it, which is
  # about as late as this script can reasonably re-assert it.
  if (-not (Wait-ForPostgresAuth -Password $SuperPassword)) {
    Write-Host "Postgres superuser password stopped verifying since it was set ($script:LastPgAuthError) - re-asserting it via trust-mode auth before giving up..."
    Reset-PostgresSuperuserPassword -NewPassword $SuperPassword -ServiceName (Get-PgServiceName)
  }

  $appPassword = New-RandomAlphanumericSecret -Length 24

  $env:PGPASSWORD = $SuperPassword
  try {
    # Confirmed by direct testing in this environment: "(Func @(args) -join "").Trim()" does
    # NOT apply -join to Func's return value the way it looks like it should. Once the parser
    # commits to command-invocation syntax (a bare function name as the first token inside the
    # parens), everything after - including "-join" and "" - gets parsed as MORE ARGUMENTS to
    # that function call, not as an operator applied afterward. Invoke-Psql doesn't read $args,
    # so those extra tokens are silently swallowed and -join never actually runs; the parens'
    # value is just Invoke-Psql's own raw return value. This stayed invisible for as long as
    # Invoke-Psql happened to return a single non-null string (any actual query match), and only
    # crashes on .Trim() when it returns nothing at all - exactly what a `-tAc` query returns for
    # zero matching rows, i.e. the ordinary "role/database doesn't exist yet" case on a fresh
    # install. The fix: wrap the function call in its OWN parens first, forcing it to resolve to
    # a value before -join (now unambiguously an operator, not more arguments) is applied to it.
    # Confirmed on a real device: if this role survives from an earlier "Set up this machine"
    # run on the same machine (e.g. re-testing after a launcher update), skipping the password
    # here - as this used to do - leaves Postgres holding the OLD run's password while $appPassword
    # (freshly randomized every run, see above) still gets written into .env's DATABASE_URL below.
    # That mismatch is exactly a Prisma P1000 "credentials ... are not valid" error at first login,
    # not a timing or corruption bug. ALTER unconditionally so the role's real password always
    # matches this run's $appPassword, whether the role is new or pre-existing.
    $roleExists = ((Invoke-Psql @("-h", "localhost", "-p", "$DbPort", "-U", "postgres", "-d", "postgres", "-tAc", "SELECT 1 FROM pg_roles WHERE rolname = '$DbUser'")) -join "").Trim()
    if ($roleExists -eq "1") {
      Invoke-Psql @("-h", "localhost", "-p", "$DbPort", "-U", "postgres", "-d", "postgres", "-c", "ALTER ROLE $DbUser WITH PASSWORD '$appPassword';") | Out-Null
      Write-Host "Role '$DbUser' already exists - reset its password to match this run's .env."
    } else {
      Invoke-Psql @("-h", "localhost", "-p", "$DbPort", "-U", "postgres", "-d", "postgres", "-c", "CREATE ROLE $DbUser WITH LOGIN CREATEDB PASSWORD '$appPassword';") | Out-Null
      Write-Host "Created role '$DbUser'."
    }

    $dbExists = ((Invoke-Psql @("-h", "localhost", "-p", "$DbPort", "-U", "postgres", "-d", "postgres", "-tAc", "SELECT 1 FROM pg_database WHERE datname = '$DbName'")) -join "").Trim()
    if ($dbExists -eq "1") {
      Write-Host "Database '$DbName' already exists."
    } else {
      Invoke-Psql @("-h", "localhost", "-p", "$DbPort", "-U", "postgres", "-d", "postgres", "-c", "CREATE DATABASE $DbName OWNER $DbUser;") | Out-Null
      Write-Host "Created database '$DbName'."
    }
  } finally {
    Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue
  }

  return "postgresql://${DbUser}:${appPassword}@localhost:${DbPort}/${DbName}?schema=public"
}

function New-FreshEnvFile {
  param([string]$DatabaseUrl)

  # Real values for what this script can generate/knows on its own. AGENT_TOKEN is left blank
  # here - it can't be generated yet at all, since it lives on the Restaurant row, which doesn't
  # exist until someone completes the existing /onboarding flow after this script finishes -
  # but that flow now writes it into this exact file itself (src/lib/localEnv.ts, called from
  # src/app/onboarding/actions.ts) the moment it's generated, so this blank is only ever
  # momentary. Twilio/Resend/Anthropic keys are deliberately NOT here at all anymore - none of
  # them are local credentials any more: login email, phone-number provisioning, and SMS all
  # proxy through the cloud-hosted voice service (voice/mail.ts, voice/phoneNumbers.ts), which
  # holds those keys itself. See .env.example for the full explanation of what moved where.
  #
  # VOICE_PUBLIC_URL is the one non-obvious real value here - it's NOT restaurant-specific
  # (voice runs cloud-hosted on Railway for every restaurant using this product, not locally
  # per-machine), so the real URL is safe to bake in here, same as ManifestUrl's default above.
  # Previously defaulted to "http://localhost:3100" - silently broken on every fresh install,
  # since nothing runs a local voice service anymore: billing pages and login's
  # auto-restore-from-cloud (src/app/login/actions.ts) both depend on this being correct, not a
  # loopback address nothing is listening on. CLOUD_DATABASE_URL deliberately stays blank
  # instead - that one's a real credential (full read/write to every restaurant's cloud data),
  # not safe to bake into a distributed script the way a public HTTPS URL is.
  @"
DATABASE_URL="$DatabaseUrl"

LLM_MODEL="claude-sonnet-5"

PUBLIC_BASE_URL="http://localhost:3000"

SESSION_SECRET="$(New-RandomSecret -Bytes 32)"

AGENT_TOKEN=""

LOCAL_DATABASE_URL=""
CLOUD_DATABASE_URL=""

VOICE_PORT="3100"
VOICE_PUBLIC_URL="https://restaurant-reservation-app-production-d8b9.up.railway.app"
"@ | Set-Content -Path (Join-Path $InstallDir ".env") -Encoding utf8
}

function Get-LatestManifest {
  # Write-Host, not Write-Output - same class of bug as Ensure-PostgresInstalled/
  # Ensure-AppDatabase above: this function's result is captured (`$manifest = Get-
  # LatestManifest`), and Write-Output here would silently corrupt $manifest into an array
  # containing this message alongside the real parsed object, breaking `$manifest.version`/
  # `.downloadUrl`/`.sha256` access downstream. Not yet triggered on any real device only because
  # every real-device run so far reused an already-built app (BUILD_ID present) and skipped this
  # function entirely - it would hit the very next genuinely from-scratch fresh install otherwise.
  Write-Host "Fetching release manifest from $ManifestUrl ..."
  try {
    $json = Invoke-WebRequest -Uri $ManifestUrl -UseBasicParsing | Select-Object -ExpandProperty Content
  } catch {
    throw "Request to $ManifestUrl failed: $($_.Exception.Message)"
  }
  return $json | ConvertFrom-Json
}

# Any terminating error anywhere in the body below (a throw from one of the functions above,
# a native command failure, etc.) lands in the catch below, which writes a clean, single
# message here - deliberately separate from the full transcript log, which is noisy PowerShell
# formatting that isn't fit to show directly in the launcher's own UI. MainForm.cs reads this
# file to show the real reason in its status text instead of a generic "check the log" message
# (see MachineProvisioner.ReadLastError). Cleared at the start of every run so a stale error
# from an earlier failed attempt never gets shown again after a run that didn't reach this
# point (or succeeded).
$lastErrorPath = Join-Path $logDir "last-error.txt"
Remove-Item $lastErrorPath -ErrorAction SilentlyContinue

try {
  Write-Output "=== Provisioning a fresh install ==="
  Write-Output "Install dir: $InstallDir"

  Ensure-NodeInstalled
  $superPassword = Ensure-PostgresInstalled
  $databaseUrl = Ensure-AppDatabase -SuperPassword $superPassword

  # This script otherwise assumes a genuinely blank machine with no core services registered
  # yet, but a real device can reach here in a hybrid state: services already registered and
  # RUNNING from an earlier successful setup - either because BUILD_ID was deleted by hand to
  # force a clean rebuild (the documented recovery step after 1.0.24's fix), or because "Set up
  # this machine" simply got re-run on a device that was already set up. Ensure-PostgresInstalled
  # (above) unconditionally wipes and recreates this script's own dedicated Postgres instance on
  # EVERY run, regardless of which branch below gets taken - so $databaseUrl is always a
  # freshly-generated value that may no longer match what an already-running install's .env (and
  # the already-running services' own in-memory copy of it) currently has. Stop the core services
  # first, both to release file locks for a rebuild and so a DATABASE_URL correction below never
  # gets applied underneath an already-running process - Install-CoreService further down
  # (re)starts everything with the now-correct .env regardless of which branch ran.
  foreach ($existingServiceName in @($AppServiceName, $PrintAgentServiceName, $SyncServiceName)) {
    if (Get-Service -Name $existingServiceName -ErrorAction SilentlyContinue) {
      Write-Host "Stopping already-running service '$existingServiceName'..."
      Stop-Service -Name $existingServiceName -Force -ErrorAction SilentlyContinue
    }
  }
  Start-Sleep -Seconds 2

  $envPath = Join-Path $InstallDir ".env"
  if (Test-Path $envPath) {
    # A repeat run - this .env may already hold a real AGENT_TOKEN and other values the app or
    # its owner has since set for real, so patch just this one line rather than regenerating the
    # whole file the way New-FreshEnvFile (below, only for a genuinely fresh install) does.
    # Confirmed as a real, reproducible bug on a real device without this: the "skip fetch/build"
    # branch below never touched .env at all, so a DATABASE_URL from a since-wiped-and-recreated
    # Postgres instance was silently left in place, breaking every login with a Prisma P1000
    # "credentials ... are not valid" error - the exact same digest reappearing after re-running
    # "Set up this machine" is the signature of this exact gap.
    Set-EnvFileVar -EnvPath $envPath -Key "DATABASE_URL" -Value $databaseUrl
    Write-Host "Updated DATABASE_URL in the existing .env to match this run's Postgres role."
  }

  if (Test-Path (Join-Path $InstallDir ".next-prod\BUILD_ID")) {
    Write-Output "App already installed and built at $InstallDir - skipping fetch/build."
  } else {
    $manifest = Get-LatestManifest
    Write-Output "Latest release: $($manifest.version)"

    $zipPath = Join-Path $env:TEMP "restaurant-app-$($manifest.version).zip"
    Get-VerifiedRelease -Url $manifest.downloadUrl -ExpectedSha256 $manifest.sha256 -OutPath $zipPath

    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    Write-Output "Extracting..."
    Expand-Archive -Path $zipPath -DestinationPath $InstallDir -Force
    Remove-Item $zipPath -ErrorAction SilentlyContinue

    # Only for a genuinely fresh install - if .env already existed, it was already corrected
    # above and must not be reset back to blank AGENT_TOKEN/etc.
    if (-not (Test-Path $envPath)) {
      New-FreshEnvFile -DatabaseUrl $databaseUrl
    }
    Install-AppDependencies -InstallDir $InstallDir

    Push-Location $InstallDir
    try {
      Write-Output "Migrating the database (fresh, empty)..."
      Invoke-CheckedCommand -Description "prisma migrate deploy" -Command { & npx prisma migrate deploy 2>&1 } | Out-Null
    } finally {
      Pop-Location
    }
  }

  # The launcher's own publish output ships tools\nssm.exe alongside this script (see
  # RestaurantLauncher.csproj) - no WinGet dependency needed for a install this script itself
  # is doing (Find-Nssm still falls back to the old discovery if this script is ever run
  # outside the launcher's publish layout, e.g. directly from the repo for testing).
  $bundledNssm = Join-Path (Split-Path -Parent $PSScriptRoot) "tools\nssm.exe"
  $nssm = Find-Nssm -BundledPath $bundledNssm
  $npmCmd = Find-Npm

  function Install-CoreService($Name, $Params, $LogFile) {
    if (Get-Service -Name $Name -ErrorAction SilentlyContinue) {
      Write-Output "Service '$Name' already registered."
      # Not just a no-op: this function may run right after the rebuild path above stopped this
      # exact service to release a file lock, so "already registered" no longer safely implies
      # "already running" the way it used to when this script only ever ran once per machine.
      & $nssm start $Name | Out-Null
      return
    }
    Write-Output "Registering service '$Name'..."
    & $nssm install $Name $npmCmd $Params | Out-Null
    & $nssm set $Name AppDirectory $InstallDir | Out-Null
    & $nssm set $Name AppStdout (Join-Path $InstallDir $LogFile) | Out-Null
    & $nssm set $Name AppStderr (Join-Path $InstallDir $LogFile) | Out-Null
    & $nssm set $Name AppRotateFiles 1 | Out-Null
    & $nssm set $Name AppRotateBytes 5242880 | Out-Null
    & $nssm set $Name Start SERVICE_AUTO_START | Out-Null
    & $nssm set $Name AppExit Default Restart | Out-Null
    & $nssm set $Name AppRestartDelay 3000 | Out-Null
    & $nssm start $Name | Out-Null
  }

  Install-CoreService $AppServiceName "run start" "app.log"
  Install-CoreService $PrintAgentServiceName "run agent" "agent.log"
  Install-CoreService $SyncServiceName "run sync" "sync.log"

  Write-Output "Waiting for the app to respond..."
  $deadline = (Get-Date).AddSeconds(30)
  $healthy = $false
  while ((Get-Date) -lt $deadline) {
    try {
      $resp = Invoke-WebRequest -Uri $HealthCheckUrl -UseBasicParsing -TimeoutSec 5
      if ($resp.StatusCode -eq 200) { $healthy = $true; break }
    } catch {
      # Not up yet - keep polling.
    }
    Start-Sleep -Seconds 1
  }

  if (-not $healthy) {
    throw "Services were registered and started, but the app didn't respond healthy within 30s. Check the services by hand (Get-Service Restaurant*)."
  }

  Write-Output ""
  Write-Output "Provisioning complete - the app is running and reachable."
  Write-Output "Next step (not done by this script): open the app, log in, and create the"
  Write-Output "restaurant via the existing onboarding flow."
  Stop-Transcript | Out-Null
  exit 0
} catch {
  $errorMessage = $_.Exception.Message
  # A bare exception message alone (e.g. "You cannot call a method on a null-valued expression")
  # doesn't say WHERE - confirmed as a real, costly gap on a real device: this script had never
  # gotten far enough to hit a failure past Ensure-AppDatabase before, so a whole, never-
  # exercised code path (app fetch/build/migrate) could be the source with zero way to tell which
  # line without this. InvocationInfo carries the exact source line and its line number even for
  # a plain runtime exception like a null reference - appending it here turns "something failed
  # somewhere in this 600-line script" into an exact, actionable line the very first time it
  # happens, instead of costing another real-device round trip just to find out where to look.
  if ($_.InvocationInfo -and $_.InvocationInfo.ScriptLineNumber) {
    $errorMessage = "$errorMessage (line $($_.InvocationInfo.ScriptLineNumber): $($_.InvocationInfo.Line.Trim()))"
  }
  Set-Content -Path $lastErrorPath -Value $errorMessage -Encoding utf8
  Write-Output ""
  Write-Output "ERROR: $errorMessage"
  Stop-Transcript | Out-Null
  exit 1
}
