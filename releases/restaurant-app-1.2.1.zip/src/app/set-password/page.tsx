import { setPassword } from "./actions";

export default async function SetPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;

  return (
    <div className="mx-auto mt-24 max-w-sm space-y-4 px-4">
      <div>
        <h1 className="text-xl font-semibold">Set a password</h1>
        <p className="text-sm text-neutral-500">
          You&rsquo;re verified — set a password now so you can log in directly next time,
          without needing an email link.
        </p>
      </div>

      <form action={setPassword} className="rounded-lg border border-neutral-200 bg-white p-6">
        {error === "too-short" && (
          <p className="mb-3 text-sm text-red-600">Password must be at least 8 characters.</p>
        )}
        {error === "mismatch" && <p className="mb-3 text-sm text-red-600">Passwords don&rsquo;t match.</p>}
        <label className="mb-1 block text-xs text-neutral-500">Password</label>
        <input
          type="password"
          name="password"
          required
          minLength={8}
          className="mb-3 w-full rounded border border-neutral-300 px-2 py-1.5 text-sm"
        />
        <label className="mb-1 block text-xs text-neutral-500">Confirm password</label>
        <input
          type="password"
          name="confirm"
          required
          minLength={8}
          className="mb-3 w-full rounded border border-neutral-300 px-2 py-1.5 text-sm"
        />
        <button
          type="submit"
          className="w-full rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700"
        >
          Set password
        </button>
      </form>
    </div>
  );
}
