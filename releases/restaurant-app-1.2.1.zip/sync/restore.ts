// One-shot restore: pulls a restaurant's data down from the cloud backup onto a fresh local
// machine - the missing inverse of sync/index.ts's continuous local-to-cloud backup (there's
// no way back down today). Run manually, once, via `npm run restore -- --email <owner's
// email>` - never part of the regular sync loop.
//
// Deliberately NOT exposed anywhere in the app itself (onboarding, settings, etc.). This
// product is one restaurant per login/subscription - a full multi-restaurant switcher was
// built and explicitly rejected earlier in this project. Restore is an admin-only, run-once
// setup step for a replacement/second machine, not a restaurant-management feature. See the
// project_auth_multitenancy memory for the full history.
import { localDb, cloudDb } from "./db";
import { pullSubscription } from "./pull";
import { Prisma } from "../src/generated/prisma/client";

function omit<T extends object, K extends keyof T>(obj: T, key: K): Omit<T, K> {
  const copy = { ...obj };
  delete (copy as Partial<T>)[key];
  return copy;
}

type CloudCallMessage = Awaited<ReturnType<typeof cloudDb.callMessage.findMany>>[number];

// Prisma's create input wants JsonNull rather than a plain null for nullable Json columns -
// same handling as sync/pull.ts's ensureCall.
function messageCreateData(messages: CloudCallMessage[]): Prisma.CallMessageCreateManyInput[] {
  return messages.map((m) => ({
    ...m,
    toolInput: m.toolInput === null ? Prisma.JsonNull : m.toolInput,
    toolResult: m.toolResult === null ? Prisma.JsonNull : m.toolResult,
  }));
}

function parseArgs(): { email: string; restaurantId?: string } {
  const args = process.argv.slice(2);
  const flag = (name: string) => {
    const i = args.indexOf(name);
    return i >= 0 ? args[i + 1] : undefined;
  };
  const email = flag("--email");
  if (!email) {
    console.error("Usage: npm run restore -- --email <owner's email> [--restaurantId <id>]");
    process.exit(1);
  }
  return { email, restaurantId: flag("--restaurantId") };
}

async function resolveTargetRestaurantId(email: string, explicitId?: string): Promise<string> {
  if (explicitId) return explicitId;

  const cloudUser = await cloudDb.user.findUnique({ where: { email } });
  if (!cloudUser) {
    console.error(`No user found in the cloud backup with email "${email}".`);
    process.exit(1);
  }

  const memberships = await cloudDb.membership.findMany({
    where: { userId: cloudUser.id },
    include: { restaurant: true },
  });
  if (memberships.length === 0) {
    console.error(`"${email}" has no restaurant memberships in the cloud backup.`);
    process.exit(1);
  }
  if (memberships.length > 1) {
    console.error(
      `"${email}" belongs to more than one restaurant in the cloud backup - re-run with ` +
        `--restaurantId to pick one:\n` +
        memberships.map((m) => `  ${m.restaurantId}  (${m.restaurant.name})`).join("\n"),
    );
    process.exit(1);
  }
  return memberships[0].restaurantId;
}

// Matches by email, not by blindly reusing the cloud id: a local User is created independently
// at login time (db.user.upsert keyed by email, src/app/api/auth/verify/route.ts), so if
// someone already logged into this machine before running restore, reusing the cloud id would
// collide on User.email's unique constraint. Matching by email either way ends with the real
// owner's next login correctly landing on the restored Membership.
async function restoreUsersAndMemberships(
  restaurantId: string,
): Promise<{ users: number; memberships: number }> {
  const cloudMemberships = await cloudDb.membership.findMany({
    where: { restaurantId },
    include: { user: true },
  });

  let users = 0;
  for (const { user } of cloudMemberships) {
    const existing = await localDb.user.findUnique({ where: { email: user.email } });
    if (existing) {
      await localDb.user.update({ where: { id: existing.id }, data: omit(user, "id") });
    } else {
      await localDb.user.create({ data: user });
    }
    users++;
  }

  let memberships = 0;
  for (const membership of cloudMemberships) {
    const localUser = await localDb.user.findUniqueOrThrow({ where: { email: membership.user.email } });
    await localDb.membership.upsert({
      where: { userId_restaurantId: { userId: localUser.id, restaurantId } },
      create: { id: membership.id, userId: localUser.id, restaurantId, role: membership.role },
      update: { role: membership.role },
    });
    memberships++;
  }

  return { users, memberships };
}

interface RestaurantScopedDelegate<T extends { id: string }> {
  findMany(args: { where: { restaurantId: string } }): Promise<T[]>;
  upsert(args: { where: { id: string }; create: T; update: T }): Promise<unknown>;
}

// The inverse of sync/categoryB.ts's mirrorTable - upsert-only (no stale-row deletion needed;
// this only ever runs once, onto an empty local database).
async function restoreTable<T extends { id: string }>(
  cloud: RestaurantScopedDelegate<T>,
  local: RestaurantScopedDelegate<T>,
  restaurantId: string,
): Promise<number> {
  const rows = await cloud.findMany({ where: { restaurantId } });
  for (const row of rows) {
    await local.upsert({ where: { id: row.id }, create: row, update: row });
  }
  return rows.length;
}

// CallMessage isn't restaurantId-scoped directly (only via callId), so it doesn't fit
// restoreTable - same shape as sync/pull.ts's ensureCall, just restoring every call for the
// restaurant instead of one on demand.
async function restoreCalls(restaurantId: string): Promise<{ calls: number; messages: number }> {
  const calls = await cloudDb.call.findMany({ where: { restaurantId }, include: { messages: true } });

  let messageCount = 0;
  for (const { messages, ...call } of calls) {
    await localDb.call.upsert({ where: { id: call.id }, create: call, update: call });
    if (messages.length > 0) {
      await localDb.callMessage.createMany({ data: messageCreateData(messages), skipDuplicates: true });
      messageCount += messages.length;
    }
  }
  return { calls: calls.length, messages: messageCount };
}

// Mirrors sync/categoryA.ts's nested Bill -> Order -> OrderItem -> OrderItemOptionChoice (+
// Payment) tree, reversed. The cloud only ever has CLOSED bills to begin with (categoryA.ts
// only pushes those), so no extra status filtering is needed here.
async function restoreBills(
  restaurantId: string,
): Promise<{ bills: number; orders: number; items: number; choices: number; payments: number }> {
  const bills = await cloudDb.bill.findMany({
    where: { restaurantId },
    include: { payment: true, orders: { include: { items: { include: { optionChoices: true } } } } },
  });

  let orders = 0;
  let items = 0;
  let choices = 0;
  let payments = 0;

  for (const bill of bills) {
    const { payment, orders: billOrders, ...billData } = bill;
    await localDb.bill.upsert({ where: { id: billData.id }, create: billData, update: billData });

    for (const order of billOrders) {
      const { items: orderItems, ...orderData } = order;
      await localDb.order.upsert({ where: { id: orderData.id }, create: orderData, update: orderData });
      orders++;

      for (const item of orderItems) {
        const { optionChoices, ...itemData } = item;
        await localDb.orderItem.upsert({ where: { id: itemData.id }, create: itemData, update: itemData });
        items++;

        for (const choice of optionChoices) {
          await localDb.orderItemOptionChoice.upsert({ where: { id: choice.id }, create: choice, update: choice });
          choices++;
        }
      }
    }

    if (payment) {
      await localDb.payment.upsert({ where: { id: payment.id }, create: payment, update: payment });
      payments++;
    }
  }

  return { bills: bills.length, orders, items, choices, payments };
}

async function main(): Promise<void> {
  const { email, restaurantId: explicitId } = parseArgs();
  const restaurantId = await resolveTargetRestaurantId(email, explicitId);

  const restaurant = await cloudDb.restaurant.findUnique({ where: { id: restaurantId } });
  if (!restaurant) {
    console.error(`No restaurant "${restaurantId}" found in the cloud backup.`);
    process.exit(1);
  }

  console.log(`Restoring "${restaurant.name}" (${restaurant.id}) from the cloud backup...\n`);

  await localDb.restaurant.upsert({ where: { id: restaurant.id }, create: restaurant, update: restaurant });

  // Order matters - matches sync/categoryB.ts's own parent-before-child dependency chain,
  // plus Call before anything that can reference one (Reservation/Bill.createdByCallId).
  const { users, memberships } = await restoreUsersAndMemberships(restaurant.id);
  const tableCount = await restoreTable(cloudDb.table, localDb.table, restaurant.id);
  const menuCategoryCount = await restoreTable(cloudDb.menuCategory, localDb.menuCategory, restaurant.id);
  const printerCount = await restoreTable(cloudDb.printer, localDb.printer, restaurant.id);
  const businessHoursCount = await restoreTable(cloudDb.businessHours, localDb.businessHours, restaurant.id);
  const hoursOverrideCount = await restoreTable(cloudDb.hoursOverride, localDb.hoursOverride, restaurant.id);
  const menuItemCount = await restoreTable(cloudDb.menuItem, localDb.menuItem, restaurant.id);
  const optionGroupCount = await restoreTable(
    cloudDb.menuItemOptionGroup,
    localDb.menuItemOptionGroup,
    restaurant.id,
  );
  const optionChoiceCount = await restoreTable(
    cloudDb.menuItemOptionChoice,
    localDb.menuItemOptionChoice,
    restaurant.id,
  );
  const { calls, messages } = await restoreCalls(restaurant.id);
  const customerCount = await restoreTable(cloudDb.customer, localDb.customer, restaurant.id);
  const reservationCount = await restoreTable(cloudDb.reservation, localDb.reservation, restaurant.id);
  const { bills, orders, items, choices, payments } = await restoreBills(restaurant.id);
  await pullSubscription(restaurant.id);

  console.log("Restored:");
  console.log(`  Restaurant: 1`);
  console.log(`  User: ${users}`);
  console.log(`  Membership: ${memberships}`);
  console.log(`  Table: ${tableCount}`);
  console.log(`  MenuCategory: ${menuCategoryCount}`);
  console.log(`  Printer: ${printerCount}`);
  console.log(`  BusinessHours: ${businessHoursCount}`);
  console.log(`  HoursOverride: ${hoursOverrideCount}`);
  console.log(`  MenuItem: ${menuItemCount}`);
  console.log(`  MenuItemOptionGroup: ${optionGroupCount}`);
  console.log(`  MenuItemOptionChoice: ${optionChoiceCount}`);
  console.log(`  Call: ${calls}`);
  console.log(`  CallMessage: ${messages}`);
  console.log(`  Customer: ${customerCount}`);
  console.log(`  Reservation: ${reservationCount}`);
  console.log(`  Bill: ${bills}`);
  console.log(`  Order: ${orders}`);
  console.log(`  OrderItem: ${items}`);
  console.log(`  OrderItemOptionChoice: ${choices}`);
  console.log(`  Payment: ${payments}`);
  console.log(`  Subscription: pulled if one exists in the cloud`);
}

main()
  .catch((err) => {
    console.error("Restore failed:", err instanceof Error ? err.message : err);
    process.exitCode = 1;
  })
  .finally(async () => {
    await localDb.$disconnect();
    await cloudDb.$disconnect();
  });
