"use client";

import { MENU_CATEGORY_COLORS } from "@/lib/menuCategoryColors";
import type { MenuCategoryColor } from "@/generated/prisma/client";

type ServerAction = (formData: FormData) => void | Promise<void>;

export function CategoryColorPicker({
  categoryId,
  currentColor,
  action,
}: {
  categoryId: string;
  currentColor: MenuCategoryColor;
  action: ServerAction;
}) {
  return (
    // This renders inside CollapsibleCard's native <summary> - any click there natively
    // toggles the parent <details> unless stopped. preventDefault() (used by this same
    // summary's drag handle) would also cancel these buttons' own default action (submitting
    // their form), so stopPropagation() here instead - stops the toggle without blocking the
    // submit.
    <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
      {Object.entries(MENU_CATEGORY_COLORS).map(([key, c]) => (
        <form key={key} action={action}>
          <input type="hidden" name="categoryId" value={categoryId} />
          <input type="hidden" name="color" value={key} />
          <button
            type="submit"
            title={c.label}
            aria-label={`Set ${c.label} colour`}
            aria-pressed={currentColor === key}
            className={`h-5 w-5 rounded-full border-2 ${c.swatchBg} ${
              currentColor === key
                ? "border-neutral-900"
                : "border-transparent hover:border-neutral-300"
            }`}
          />
        </form>
      ))}
    </div>
  );
}
