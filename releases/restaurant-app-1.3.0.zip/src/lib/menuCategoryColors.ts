import type { MenuCategoryColor } from "@/generated/prisma/client";

// Single source of truth for what each preset category colour actually looks like - both the
// waiter order grid and the owner's colour-picker swatches reference this, never hardcode
// their own Tailwind classes. Record<MenuCategoryColor, ...> means adding a new enum value
// without a mapping here fails to compile, not silently falls through at runtime.
export const MENU_CATEGORY_COLORS: Record<
  MenuCategoryColor,
  {
    label: string;
    boxBg: string;
    boxBorder: string;
    boxText: string;
    boxHoverBg: string;
    swatchBg: string;
  }
> = {
  NEUTRAL: {
    label: "Neutral",
    boxBg: "bg-neutral-50",
    boxBorder: "border-neutral-200",
    boxText: "text-neutral-900",
    boxHoverBg: "hover:bg-neutral-100",
    swatchBg: "bg-neutral-400",
  },
  RED: {
    label: "Red",
    boxBg: "bg-red-50",
    boxBorder: "border-red-200",
    boxText: "text-red-900",
    boxHoverBg: "hover:bg-red-100",
    swatchBg: "bg-red-500",
  },
  ORANGE: {
    label: "Orange",
    boxBg: "bg-orange-50",
    boxBorder: "border-orange-200",
    boxText: "text-orange-900",
    boxHoverBg: "hover:bg-orange-100",
    swatchBg: "bg-orange-500",
  },
  AMBER: {
    label: "Amber",
    boxBg: "bg-amber-50",
    boxBorder: "border-amber-200",
    boxText: "text-amber-900",
    boxHoverBg: "hover:bg-amber-100",
    swatchBg: "bg-amber-500",
  },
  GREEN: {
    label: "Green",
    boxBg: "bg-green-50",
    boxBorder: "border-green-200",
    boxText: "text-green-900",
    boxHoverBg: "hover:bg-green-100",
    swatchBg: "bg-green-500",
  },
  TEAL: {
    label: "Teal",
    boxBg: "bg-teal-50",
    boxBorder: "border-teal-200",
    boxText: "text-teal-900",
    boxHoverBg: "hover:bg-teal-100",
    swatchBg: "bg-teal-500",
  },
  BLUE: {
    label: "Blue",
    boxBg: "bg-blue-50",
    boxBorder: "border-blue-200",
    boxText: "text-blue-900",
    boxHoverBg: "hover:bg-blue-100",
    swatchBg: "bg-blue-500",
  },
  PURPLE: {
    label: "Purple",
    boxBg: "bg-purple-50",
    boxBorder: "border-purple-200",
    boxText: "text-purple-900",
    boxHoverBg: "hover:bg-purple-100",
    swatchBg: "bg-purple-500",
  },
  PINK: {
    label: "Pink",
    boxBg: "bg-pink-50",
    boxBorder: "border-pink-200",
    boxText: "text-pink-900",
    boxHoverBg: "hover:bg-pink-100",
    swatchBg: "bg-pink-500",
  },
};
