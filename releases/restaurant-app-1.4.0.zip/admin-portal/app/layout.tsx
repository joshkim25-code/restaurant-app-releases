import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Admin",
  description: "Restaurant subscriptions and billing overview.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full flex flex-col bg-neutral-50">
        <div className="mx-auto w-full max-w-4xl flex-1 px-4 py-8">{children}</div>
      </body>
    </html>
  );
}
