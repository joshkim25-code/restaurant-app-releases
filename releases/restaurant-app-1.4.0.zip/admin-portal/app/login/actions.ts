"use server";

import { redirect } from "next/navigation";
import { getSession } from "../../lib/session";
import { verifyAdminLogin } from "../../lib/adminAuth";

export async function loginAdmin(formData: FormData) {
  const password = String(formData.get("password") ?? "");
  if (!password) {
    redirect("/login?error=invalid");
  }

  const result = await verifyAdminLogin(password);
  if (!result.ok) {
    redirect(result.reason === "locked-out" ? "/login?error=locked-out" : "/login?error=invalid");
  }

  const session = await getSession();
  session.isAdmin = true;
  await session.save();

  redirect("/");
}
