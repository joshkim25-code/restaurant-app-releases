import { loginAdmin } from "./actions";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;

  return (
    <div className="mx-auto mt-24 max-w-sm space-y-4 px-4">
      <div>
        <h1 className="text-xl font-semibold">Admin</h1>
        <p className="text-sm text-neutral-500">Restaurant subscriptions and billing overview.</p>
      </div>

      <form action={loginAdmin} className="rounded-lg border border-neutral-200 bg-white p-6">
        {error === "invalid" && <p className="mb-3 text-sm text-red-600">Invalid password.</p>}
        {error === "locked-out" && (
          <p className="mb-3 text-sm text-red-600">
            Too many failed attempts. Try again in a few minutes.
          </p>
        )}
        <label className="mb-1 block text-xs text-neutral-500">Password</label>
        <input
          type="password"
          name="password"
          required
          className="mb-3 w-full rounded border border-neutral-300 px-2 py-1.5 text-sm"
        />
        <button
          type="submit"
          className="w-full rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700"
        >
          Log in
        </button>
      </form>
    </div>
  );
}
