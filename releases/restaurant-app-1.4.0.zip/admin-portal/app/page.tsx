import Link from "next/link";
import { db } from "@/lib/db";
import { LogoutButton } from "../components/LogoutButton";

// No dynamic API of its own (the auth check lives in proxy.ts, not this component), so
// Next.js would otherwise try to statically prerender this at build time - wrong for a page
// that's always auth-gated anyway and whose data (restaurant/subscription status) should
// always be fresh, never cached from whenever the last build happened.
export const dynamic = "force-dynamic";

const STATUS_LABEL: Record<string, string> = {
  TRIALING: "Trialing",
  ACTIVE: "Active",
  PAST_DUE: "Past due",
  CANCELED: "Not subscribed",
};

const STATUS_CLASS: Record<string, string> = {
  TRIALING: "text-neutral-500",
  ACTIVE: "text-green-700",
  PAST_DUE: "text-amber-700",
  CANCELED: "text-red-600",
};

export default async function RestaurantsPage() {
  const restaurants = await db.restaurant.findMany({
    orderBy: { name: "asc" },
    select: {
      id: true,
      name: true,
      subscription: {
        select: { status: true, currentPeriodEnd: true, graceEndsAt: true },
      },
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-semibold">Restaurants</h1>
          <p className="text-sm text-neutral-500">Every subscribed restaurant and its billing status.</p>
        </div>
        <LogoutButton />
      </div>

      <div className="rounded-lg border border-neutral-200 bg-white p-4">
        {restaurants.length === 0 ? (
          <p className="text-sm text-neutral-400">No restaurants yet.</p>
        ) : (
          <table className="w-full text-sm">
            <thead className="text-left text-neutral-500">
              <tr>
                <th className="pb-2 font-medium">Restaurant</th>
                <th className="pb-2 font-medium">Status</th>
                <th className="pb-2 font-medium">Current period ends</th>
                <th className="pb-2 font-medium">Grace ends</th>
              </tr>
            </thead>
            <tbody>
              {restaurants.map((restaurant) => {
                const status = restaurant.subscription?.status ?? "CANCELED";
                return (
                  <tr key={restaurant.id} className="border-t border-neutral-100">
                    <td className="py-1.5">
                      <Link
                        href={`/restaurants/${restaurant.id}`}
                        className="underline hover:text-neutral-900"
                      >
                        {restaurant.name}
                      </Link>
                    </td>
                    <td className={`py-1.5 ${STATUS_CLASS[status]}`}>{STATUS_LABEL[status]}</td>
                    <td className="py-1.5 text-neutral-500">
                      {restaurant.subscription?.currentPeriodEnd
                        ? new Date(restaurant.subscription.currentPeriodEnd).toLocaleDateString()
                        : "—"}
                    </td>
                    <td className="py-1.5 text-neutral-500">
                      {restaurant.subscription?.graceEndsAt
                        ? new Date(restaurant.subscription.graceEndsAt).toLocaleDateString()
                        : "—"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
