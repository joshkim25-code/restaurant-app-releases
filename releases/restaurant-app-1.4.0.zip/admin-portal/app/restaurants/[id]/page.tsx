import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { SettingsRow } from "../../../components/SettingsRow";

// Same reasoning as app/page.tsx's own comment - no dynamic API of its own, so force this
// off the static-prerender path.
export const dynamic = "force-dynamic";

const STATUS_LABEL: Record<string, string> = {
  TRIALING: "Trialing",
  ACTIVE: "Active",
  PAST_DUE: "Past due",
  CANCELED: "Not subscribed",
};

function formatAmount(cents: number, currency: string): string {
  return new Intl.NumberFormat("en-GB", { style: "currency", currency: currency.toUpperCase() }).format(
    cents / 100,
  );
}

function formatDiscount(grant: { percentOff: number | null; amountOffCents: number | null }): string {
  if (grant.percentOff) return `${grant.percentOff}% off`;
  if (grant.amountOffCents) return `${formatAmount(grant.amountOffCents, "usd")} off`;
  return "—";
}

export default async function RestaurantDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const restaurant = await db.restaurant.findUnique({
    where: { id },
    include: {
      subscription: true,
      paymentHistory: { orderBy: { occurredAt: "desc" }, take: 50 },
      discountGrants: { orderBy: { appliedAt: "desc" } },
    },
  });

  if (!restaurant) notFound();

  const status = restaurant.subscription?.status ?? "CANCELED";

  return (
    <div className="space-y-6">
      <div>
        <Link href="/" className="text-sm text-neutral-500 underline hover:text-neutral-900">
          ← Back to restaurants
        </Link>
        <h1 className="mt-2 text-xl font-semibold">{restaurant.name}</h1>
      </div>

      <div className="rounded-lg border border-neutral-200 bg-white p-6">
        <SettingsRow label="Subscription status">
          <span className="text-sm text-neutral-700">{STATUS_LABEL[status]}</span>
        </SettingsRow>
        <SettingsRow label="Current period ends">
          <span className="text-sm text-neutral-700">
            {restaurant.subscription?.currentPeriodEnd
              ? new Date(restaurant.subscription.currentPeriodEnd).toLocaleString()
              : "—"}
          </span>
        </SettingsRow>
        <SettingsRow label="Grace period ends">
          <span className="text-sm text-neutral-700">
            {restaurant.subscription?.graceEndsAt
              ? new Date(restaurant.subscription.graceEndsAt).toLocaleString()
              : "—"}
          </span>
        </SettingsRow>
        <SettingsRow label="Stripe customer">
          <span className="text-sm text-neutral-700">
            {restaurant.subscription?.stripeCustomerId ?? "—"}
          </span>
        </SettingsRow>
      </div>

      <div className="rounded-lg border border-neutral-200 bg-white p-4">
        <h2 className="text-sm font-medium">Discount codes granted</h2>
        {restaurant.discountGrants.length === 0 ? (
          <p className="mt-3 text-sm text-neutral-400">No discount codes recorded.</p>
        ) : (
          <table className="mt-3 w-full text-sm">
            <thead className="text-left text-neutral-500">
              <tr>
                <th className="pb-2 font-medium">Code</th>
                <th className="pb-2 font-medium">Discount</th>
                <th className="pb-2 font-medium">Applied</th>
              </tr>
            </thead>
            <tbody>
              {restaurant.discountGrants.map((grant) => (
                <tr key={grant.id} className="border-t border-neutral-100">
                  <td className="py-1.5">{grant.code ?? "—"}</td>
                  <td className="py-1.5">{formatDiscount(grant)}</td>
                  <td className="py-1.5 text-neutral-500">
                    {new Date(grant.appliedAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="rounded-lg border border-neutral-200 bg-white p-4">
        <h2 className="text-sm font-medium">Payment history</h2>
        <p className="text-xs text-neutral-400">
          Recorded from the date this tracking shipped onward - earlier payments aren&rsquo;t
          included here.
        </p>
        {restaurant.paymentHistory.length === 0 ? (
          <p className="mt-3 text-sm text-neutral-400">No payments recorded yet.</p>
        ) : (
          <table className="mt-3 w-full text-sm">
            <thead className="text-left text-neutral-500">
              <tr>
                <th className="pb-2 font-medium">Date</th>
                <th className="pb-2 font-medium">Status</th>
                <th className="pb-2 font-medium text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {restaurant.paymentHistory.map((payment) => (
                <tr key={payment.id} className="border-t border-neutral-100">
                  <td className="py-1.5">{new Date(payment.occurredAt).toLocaleDateString()}</td>
                  <td className="py-1.5">
                    <span className={payment.status === "succeeded" ? "text-green-700" : "text-red-600"}>
                      {payment.status === "succeeded" ? "Succeeded" : "Failed"}
                    </span>
                  </td>
                  <td className="py-1.5 text-right">
                    {formatAmount(payment.amountCents, payment.currency)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
