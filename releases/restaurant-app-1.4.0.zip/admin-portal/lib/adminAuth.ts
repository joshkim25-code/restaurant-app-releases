import { hashPassword, verifyPassword } from "@/lib/auth";

// Single-operator auth, not the restaurant-scoped User/Membership system - there's no
// isAdmin-style field on User today, and adding one would conflate "is the app owner" with
// "is a member of a restaurant", two unrelated concepts, for a feature that only ever needs
// to recognize exactly one person. A plain ADMIN_PASSWORD env var is enough at this scale;
// revisit only if a second admin operator is ever actually needed.
//
// ADMIN_PASSWORD is compared with verifyPassword (reused from src/lib/auth.ts) against a
// scrypt hash of itself, computed once per process rather than stored pre-hashed anywhere -
// marginally better than a plain string compare for a secret that might end up in a
// deploy platform's env-var UI/logs.
let cachedAdminPasswordHash: string | null = null;
async function getAdminPasswordHash(): Promise<string> {
  if (cachedAdminPasswordHash) return cachedAdminPasswordHash;
  const adminPassword = process.env.ADMIN_PASSWORD;
  if (!adminPassword) throw new Error("ADMIN_PASSWORD is not set.");
  cachedAdminPasswordHash = await hashPassword(adminPassword);
  return cachedAdminPasswordHash;
}

// In-memory, per-process lockout - same accepted trade-off as voice/restore.ts's own copy of
// this pattern (resets on redeploy, not a distributed rate limiter, still meaningfully raises
// the cost of brute-forcing this internet-reachable login). Keyed by a constant rather than
// per-email, since there's exactly one account here.
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000;
let failedCount = 0;
let lockedUntil = 0;

function isLockedOut(): boolean {
  return lockedUntil > Date.now();
}

function recordFailure(): void {
  failedCount += 1;
  if (failedCount >= MAX_ATTEMPTS) {
    lockedUntil = Date.now() + LOCKOUT_MS;
    failedCount = 0;
  }
}

function clearFailures(): void {
  failedCount = 0;
}

export type AdminLoginResult = { ok: true } | { ok: false; reason: "locked-out" | "invalid" };

export async function verifyAdminLogin(password: string): Promise<AdminLoginResult> {
  if (isLockedOut()) {
    return { ok: false, reason: "locked-out" };
  }

  const hash = await getAdminPasswordHash();
  if (!(await verifyPassword(password, hash))) {
    recordFailure();
    return { ok: false, reason: "invalid" };
  }

  clearFailures();
  return { ok: true };
}
