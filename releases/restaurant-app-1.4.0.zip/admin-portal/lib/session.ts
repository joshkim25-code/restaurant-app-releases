import { cookies } from "next/headers";
import { getIronSession, type SessionOptions } from "iron-session";

// Own session shape, not a reuse of src/lib/session.ts/session-options.ts: this site's
// session only ever needs a boolean (there's no real User row involved - see adminAuth.ts's
// own comment on why this isn't the restaurant-scoped User/Membership system), so a fork is
// simpler and more honest here than force-fitting the shared { userId } shape.
export type AdminSessionData = { isAdmin?: boolean };

const ADMIN_SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 7;

export const adminSessionOptions: SessionOptions = {
  cookieName: "admin_session",
  password: process.env.ADMIN_SESSION_SECRET!,
  cookieOptions: {
    secure: process.env.NODE_ENV === "production",
    maxAge: ADMIN_SESSION_MAX_AGE_SECONDS,
  },
};

export async function getSession() {
  return getIronSession<AdminSessionData>(await cookies(), adminSessionOptions);
}

export async function isAdminLoggedIn(): Promise<boolean> {
  const session = await getSession();
  return session.isAdmin === true;
}
