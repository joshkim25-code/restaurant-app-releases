import Stripe from "stripe";

// Own key, own Stripe client - this site is the app owner's own private tool, so holding its
// own STRIPE_SECRET_KEY here is fine (unlike a restaurant's local app, which never holds it -
// see .env.example) and avoids a second network hop through voice/ for every page load. Used
// only for live fallback reads (pre-history backfill, an on-demand refresh) - PaymentHistory/
// DiscountGrant rows written by voice/billing.ts's webhook handler are the primary source for
// everything going forward.
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY;

export const stripe = STRIPE_SECRET_KEY ? new Stripe(STRIPE_SECRET_KEY) : null;
