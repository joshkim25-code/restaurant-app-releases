import type { NextConfig } from "next";
import path from "node:path";

// Reuses a couple of src/lib/*.ts files from the main app one directory up (unmodified, via
// the "@/*" -> "../src/*" path alias in this app's own tsconfig.json) - see the plan this
// came from, and owner-portal/next.config.ts's identical comment for the full reasoning.
const nextConfig: NextConfig = {
  outputFileTracingRoot: path.join(__dirname, ".."),
};

export default nextConfig;
