using System.Diagnostics;

namespace RestaurantLauncher;

/// <summary>
/// Runs scripts/provision-machine.ps1 elevated, the same way UpdateApplier runs
/// apply-update.ps1 - only this step (and the update-apply step) ever needs admin rights;
/// normal day-to-day launching doesn't.
/// </summary>
public static class MachineProvisioner
{
    public static async Task<bool> ProvisionAsync(LauncherConfig config, string exeDirectory)
    {
        var scriptPath = Path.Combine(exeDirectory, "scripts", "provision-machine.ps1");
        if (!File.Exists(scriptPath))
        {
            throw new FileNotFoundException($"Provisioning script not found at {scriptPath} - reinstall the launcher.");
        }

        var arguments = string.Join(' ', new[]
        {
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", Quote(scriptPath),
            "-ManifestUrl", Quote(config.ManifestUrl),
            "-InstallDir", Quote(config.InstallDir),
        });

        var psi = new ProcessStartInfo
        {
            FileName = "powershell.exe",
            Arguments = arguments,
            UseShellExecute = true,
            Verb = "runas",
        };

        return await Task.Run(() =>
        {
            using var process = Process.Start(psi);
            if (process is null) return false;
            process.WaitForExit();
            return process.ExitCode == 0;
        });
    }

    // provision-machine.ps1 writes the real reason for a failure here (last-error.txt, in the
    // same provision-logs folder as its full transcript) - a single clean message, separate
    // from the noisy PowerShell transcript formatting, specifically so it's fit to show
    // directly in the launcher's own status text instead of just pointing at a log file.
    // Computed the same way the script computes $logDir - split the parent off InstallDir.
    public static string? ReadLastError(LauncherConfig config)
    {
        var parent = Path.GetDirectoryName(config.InstallDir.TrimEnd('\\', '/'));
        if (string.IsNullOrEmpty(parent)) return null;

        var path = Path.Combine(parent, "provision-logs", "last-error.txt");
        if (!File.Exists(path)) return null;

        try
        {
            var text = File.ReadAllText(path).Trim();
            return string.IsNullOrEmpty(text) ? null : text;
        }
        catch
        {
            // Best-effort - a locked/unreadable file shouldn't block showing the generic
            // fallback message instead.
            return null;
        }
    }

    private static string Quote(string value) => $"\"{value}\"";
}
