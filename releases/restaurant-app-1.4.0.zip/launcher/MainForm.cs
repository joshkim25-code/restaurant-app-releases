using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace RestaurantLauncher;

/// <summary>
/// The launcher's one window. Startup sequence: make sure the core services are running
/// (offering to provision the machine from scratch if none exist at all), check for and (if
/// found) apply an update, then open a WebView2 view pointed at the app - the existing
/// magic-link login (src/app/login, src/proxy.ts) is the login gate; this window doesn't
/// implement any auth of its own, it just hosts the already-gated app.
/// See launcher/README.md for the full design and current phase status.
/// </summary>
public sealed class MainForm : Form
{
    private readonly Label _statusLabel;
    private readonly Button _setUpButton;
    private readonly WebView2 _webView;
    private readonly LauncherConfig _config;
    private readonly string _exeDirectory;
    private readonly Panel _debugBar;
    private readonly TextBox _debugUrlBox;

    public MainForm()
    {
        Text = "Restaurant App";
        Width = 1280;
        Height = 800;
        StartPosition = FormStartPosition.CenterScreen;

        _exeDirectory = AppContext.BaseDirectory;
        _config = LauncherConfig.Load(_exeDirectory);

        _statusLabel = new Label
        {
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font(Font.FontFamily, 14),
            Text = "Starting...",
        };

        _setUpButton = new Button
        {
            Text = "Set up this machine",
            AutoSize = true,
            Anchor = AnchorStyles.None,
            Visible = false,
        };
        _setUpButton.Click += async (_, _) => await RunProvisioningAsync();
        Resize += (_, _) => CenterSetUpButton();

        _webView = new WebView2
        {
            Dock = DockStyle.Fill,
            Visible = false,
        };

        // Temporary testing aid, not permanent UI: the real product needs a proper way to
        // route a magic-link email (opened in the OS's default browser) back into this
        // window's own isolated WebView2 cookie profile - most likely a custom URL protocol
        // handler (restaurantapp://) registered at install time, which is later work.
        // Until that exists, this lets a pasted link be opened directly inside the window,
        // which is what actually lets a session persist here across launcher restarts.
        _debugUrlBox = new TextBox { Dock = DockStyle.Fill };
        var goButton = new Button { Text = "Open in launcher (debug)", AutoSize = true, Dock = DockStyle.Right };
        goButton.Click += (_, _) => NavigateToDebugUrl();
        _debugUrlBox.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                NavigateToDebugUrl();
            }
        };
        _debugBar = new Panel { Dock = DockStyle.Top, Height = 30, Visible = false };
        _debugBar.Controls.Add(_debugUrlBox);
        _debugBar.Controls.Add(goButton);

        Controls.Add(_webView);
        Controls.Add(_debugBar);
        Controls.Add(_statusLabel);
        // Added last (and positioned explicitly, not docked) so it renders on top of the
        // Fill-docked status label instead of being hidden behind it.
        Controls.Add(_setUpButton);
        CenterSetUpButton();

        // AutoSize isn't reliably resolved until the control has a handle - re-centering
        // once more here (in addition to the constructor's best-effort attempt and the
        // Resize handler) covers the common case of a fixed-size form that's never resized.
        Load += (_, _) => CenterSetUpButton();
        Load += async (_, _) => await StartupAsync();
    }

    private void CenterSetUpButton()
    {
        _setUpButton.Location = new Point(
            (ClientSize.Width - _setUpButton.Width) / 2,
            (ClientSize.Height - _setUpButton.Height) / 2 + 60 // below the status label's text
        );
    }

    private void NavigateToDebugUrl()
    {
        var url = _debugUrlBox.Text.Trim();
        if (string.IsNullOrEmpty(url) || _webView.CoreWebView2 is null) return;
        _webView.CoreWebView2.Navigate(url);
    }

    private async Task StartupAsync()
    {
        SetStatus("Starting services...");
        var missing = await Task.Run(ServiceSupervisor.EnsureRunning);
        if (missing.Count > 0)
        {
            SetStatus(
                "This machine isn't set up yet.\n\n" +
                $"Missing service(s): {string.Join(", ", missing)}"
            );
            ShowSetUpButton(true);
            return;
        }

        await ContinueStartupAfterServicesReadyAsync();
    }

    private async Task RunProvisioningAsync()
    {
        ShowSetUpButton(false);
        SetStatus(
            "Setting up this machine for the first time...\n\n" +
            "This installs Node.js and PostgreSQL if they're missing, so it can take a " +
            "few minutes. A Windows security prompt may appear - this is expected, " +
            "setup needs it to install software and register services."
        );

        bool succeeded;
        string? startupError = null;
        try
        {
            succeeded = await MachineProvisioner.ProvisionAsync(_config, _exeDirectory);
        }
        catch (Exception ex)
        {
            succeeded = false;
            startupError = ex.Message;
        }

        if (!succeeded)
        {
            // startupError is the launcher's own problem (e.g. the script file is missing -
            // ProvisionAsync never even got to run it). Otherwise the script ran and exited
            // non-zero for a real reason - MachineProvisioner.ReadLastError surfaces the actual
            // clean message provision-machine.ps1 wrote (last-error.txt), so the person doesn't
            // have to go find and read a log file themselves to see why. Only fall back to the
            // generic message if neither is available (a failure early enough that not even
            // last-error.txt exists yet).
            var reason = startupError ?? MachineProvisioner.ReadLastError(_config);
            SetStatus(
                reason is not null
                    ? $"Setup failed: {reason}"
                    : "Setup didn't complete. Check provision-logs next to the install " +
                      "directory for details, then try again."
            );
            ShowSetUpButton(true);
            return;
        }

        await ContinueStartupAfterServicesReadyAsync();
    }

    private void ShowSetUpButton(bool visible)
    {
        // AutoSize's Width/Height aren't guaranteed resolved by the earlier Load-time
        // centering pass - re-centering here, using the size as it actually is right when
        // the button is about to be shown, avoids depending on that timing at all.
        //
        // BringToFront matters too: _statusLabel (Dock.Fill) was added to Controls before
        // this button, and this button only becomes Visible well after the form's initial
        // layout/paint pass (from StartupAsync, at least one await later) - a non-docked
        // sibling shown that late, at the same screen location as a Dock.Fill control, can
        // end up not actually painted on top even with correct Location/Size and Visible
        // genuinely true. Confirmed on a real machine: resizing (which re-centers but never
        // touches z-order) did not reveal the button, but this did.
        void Apply()
        {
            if (visible)
            {
                CenterSetUpButton();
                _setUpButton.BringToFront();
            }
            _setUpButton.Visible = visible;
        }

        if (InvokeRequired)
        {
            Invoke(Apply);
        }
        else
        {
            Apply();
        }
    }

    private async Task ContinueStartupAfterServicesReadyAsync()
    {
        SetStatus("Checking for updates...");
        var checker = new UpdateChecker(_config.ManifestUrl);
        var installedVersion = UpdateChecker.GetInstalledVersion(_config.InstallDir);
        var manifest = await checker.FetchLatestAsync();

        if (manifest is not null && UpdateChecker.IsNewer(manifest, installedVersion))
        {
            SetStatus($"Updating to version {manifest.Version}...\n\nA Windows security prompt may appear - this is expected, the update needs it to restart services.");
            bool succeeded;
            try
            {
                succeeded = await UpdateApplier.ApplyAsync(_config, manifest, _exeDirectory);
            }
            catch (Exception ex)
            {
                succeeded = false;
                SetStatus($"Update failed to start: {ex.Message}\n\nContinuing with the current version.");
                await Task.Delay(3000);
            }

            if (!succeeded)
            {
                // apply-update.ps1 already restores/restarts the previous version on
                // failure - the launcher just needs to carry on and open whatever is
                // actually running now, not treat this as fatal to opening the app at all.
                SetStatus("Update didn't complete - continuing with the current version. See update-logs for details.");
                await Task.Delay(3000);
            }
        }

        SetStatus("Starting app...");
        var healthy = await ServiceSupervisor.WaitUntilHealthyAsync(_config.AppUrl, TimeSpan.FromSeconds(30));
        if (!healthy)
        {
            SetStatus(
                "The app didn't respond in time.\n\n" +
                "Check the services by hand (Get-Service Restaurant*) and try reopening this launcher."
            );
            return;
        }

        await OpenAppAsync();
    }

    private async Task OpenAppAsync()
    {
        var userDataFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "RestaurantApp", "WebView2"
        );
        Directory.CreateDirectory(userDataFolder);

        var environment = await CoreWebView2Environment.CreateAsync(userDataFolder: userDataFolder);
        await _webView.EnsureCoreWebView2Async(environment);

        _webView.CoreWebView2.Navigate(_config.AppUrl);
        _webView.Visible = true;
        _statusLabel.Visible = false;
        _debugBar.Visible = true;
    }

    private void SetStatus(string text)
    {
        if (InvokeRequired)
        {
            Invoke(() => _statusLabel.Text = text);
        }
        else
        {
            _statusLabel.Text = text;
        }
    }
}
