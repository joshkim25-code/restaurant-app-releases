"use server";

import { redirect } from "next/navigation";
import { getSession } from "@/lib/session";
import { verifyOwnerLogin } from "../../lib/authOwner";

export async function loginOwner(formData: FormData) {
  const email = String(formData.get("email") ?? "").trim();
  const password = String(formData.get("password") ?? "");

  if (!email || !password) {
    redirect("/login?error=invalid");
  }

  const result = await verifyOwnerLogin(email, password);
  if (!result.ok) {
    redirect(result.reason === "locked-out" ? "/login?error=locked-out" : "/login?error=invalid");
  }

  const session = await getSession();
  session.userId = result.userId;
  await session.save();

  redirect("/reports");
}
