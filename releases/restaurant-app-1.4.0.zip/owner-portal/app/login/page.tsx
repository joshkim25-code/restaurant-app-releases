import { loginOwner } from "./actions";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;

  return (
    <div className="mx-auto mt-24 max-w-sm space-y-4 px-4">
      <div>
        <h1 className="text-xl font-semibold">Restaurant reports</h1>
        <p className="text-sm text-neutral-500">
          Log in with the owner account for your restaurant to view your sales reports
          remotely.
        </p>
      </div>

      <form action={loginOwner} className="rounded-lg border border-neutral-200 bg-white p-6">
        {error === "invalid" && (
          <p className="mb-3 text-sm text-red-600">Invalid email or password.</p>
        )}
        {error === "locked-out" && (
          <p className="mb-3 text-sm text-red-600">
            Too many failed attempts. Try again in a few minutes.
          </p>
        )}
        {error === "not-owner" && (
          <p className="mb-3 text-sm text-red-600">
            This account isn&rsquo;t an owner on any restaurant - remote reports are only
            available to owner accounts.
          </p>
        )}
        <label className="mb-1 block text-xs text-neutral-500">Email</label>
        <input
          type="email"
          name="email"
          required
          placeholder="you@restaurant.com"
          className="mb-3 w-full rounded border border-neutral-300 px-2 py-1.5 text-sm"
        />
        <label className="mb-1 block text-xs text-neutral-500">Password</label>
        <input
          type="password"
          name="password"
          required
          className="mb-3 w-full rounded border border-neutral-300 px-2 py-1.5 text-sm"
        />
        <button
          type="submit"
          className="w-full rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700"
        >
          Log in
        </button>
      </form>
    </div>
  );
}
