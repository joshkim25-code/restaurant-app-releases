import Link from "next/link";
import { getOwnerRestaurant } from "../../lib/getOwnerRestaurant";
import { getSalesReport, isPresetRange, parseISODate, type ReportRange } from "@/lib/reports";
import { formatMoney } from "@/lib/money";
import { RangeFilter } from "../../components/RangeFilter";
import { LogoutButton } from "../../components/LogoutButton";

export default async function ReportsPage({
  searchParams,
}: {
  searchParams: Promise<{ range?: string; from?: string; to?: string }>;
}) {
  const params = await searchParams;
  const from = parseISODate(params.from);
  const to = parseISODate(params.to);
  const range: ReportRange =
    params.range === "custom" && from && to ? "custom" : isPresetRange(params.range) ? params.range : "7d";
  const custom = range === "custom" && from && to ? { from, to } : undefined;

  const restaurant = await getOwnerRestaurant();
  const report = await getSalesReport(restaurant.id, range, custom);

  const maxDayRevenue = Math.max(1, ...report.revenueByDay.map(([, cents]) => cents));

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-semibold">Reports</h1>
          <p className="text-sm text-neutral-500">
            Sales performance for {restaurant.name}, based on closed and paid bills.{" "}
            <Link href="/reports/bills" className="underline hover:text-neutral-900">
              View bill history →
            </Link>
          </p>
        </div>
        <LogoutButton />
      </div>

      <RangeFilter basePath="/reports" range={range} from={params.from} to={params.to} />

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Revenue</div>
          <div className="mt-1 text-2xl font-semibold">
            {formatMoney(report.revenueCents, restaurant.currency)}
          </div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Bills paid</div>
          <div className="mt-1 text-2xl font-semibold">{report.billCount}</div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Average bill</div>
          <div className="mt-1 text-2xl font-semibold">
            {formatMoney(report.averageBillCents, restaurant.currency)}
          </div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Tax</div>
          <div className="mt-1 text-2xl font-semibold">
            {formatMoney(report.taxCents, restaurant.currency)}
          </div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Service charge</div>
          <div className="mt-1 text-2xl font-semibold">
            {formatMoney(report.serviceChargeCents, restaurant.currency)}
          </div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Bills cancelled</div>
          <div className="mt-1 text-2xl font-semibold">{report.cancelledCount}</div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Tips</div>
          <div className="mt-1 text-2xl font-semibold">
            {formatMoney(report.tipsCents, restaurant.currency)}
          </div>
        </div>
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <div className="text-xs text-neutral-500">Lost revenue</div>
          <div className="mt-1 text-2xl font-semibold">
            {formatMoney(report.cancelledValueCents, restaurant.currency)}
          </div>
        </div>
      </div>

      <div className="rounded-lg border border-neutral-200 bg-white p-4">
        <h2 className="text-sm font-medium">Revenue by day</h2>
        {report.revenueByDay.length === 0 ? (
          <p className="mt-3 text-sm text-neutral-400">No paid bills in this range.</p>
        ) : (
          <div className="mt-4 space-y-2">
            {report.revenueByDay.map(([day, cents]) => (
              <div key={day} className="flex items-center gap-3 text-sm">
                <span className="w-24 shrink-0 text-neutral-500">{day}</span>
                <div className="h-4 flex-1 rounded bg-neutral-100">
                  <div
                    className="h-4 rounded bg-neutral-900"
                    style={{ width: `${(cents / maxDayRevenue) * 100}%` }}
                  />
                </div>
                <span className="w-20 shrink-0 text-right">
                  {formatMoney(cents, restaurant.currency)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h2 className="text-sm font-medium">Top menu items</h2>
          {report.topItems.length === 0 ? (
            <p className="mt-3 text-sm text-neutral-400">No items sold in this range.</p>
          ) : (
            <table className="mt-3 w-full text-sm">
              <thead className="text-left text-neutral-500">
                <tr>
                  <th className="pb-2 font-medium">Item</th>
                  <th className="pb-2 font-medium text-right">Qty</th>
                  <th className="pb-2 font-medium text-right">Revenue</th>
                </tr>
              </thead>
              <tbody>
                {report.topItems.map((item) => (
                  <tr key={item.menuItemId} className="border-t border-neutral-100">
                    <td className="py-1.5">{item.name}</td>
                    <td className="py-1.5 text-right">{item.quantity}</td>
                    <td className="py-1.5 text-right">
                      {formatMoney(item.revenueCents, restaurant.currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h2 className="text-sm font-medium">Revenue by payment method</h2>
          {report.revenueByMethod.length === 0 ? (
            <p className="mt-3 text-sm text-neutral-400">No paid bills in this range.</p>
          ) : (
            <table className="mt-3 w-full text-sm">
              <thead className="text-left text-neutral-500">
                <tr>
                  <th className="pb-2 font-medium">Method</th>
                  <th className="pb-2 font-medium text-right">Count</th>
                  <th className="pb-2 font-medium text-right">Revenue</th>
                </tr>
              </thead>
              <tbody>
                {report.revenueByMethod.map(([method, stats]) => (
                  <tr key={method} className="border-t border-neutral-100">
                    <td className="py-1.5 capitalize">{method.toLowerCase()}</td>
                    <td className="py-1.5 text-right">{stats.count}</td>
                    <td className="py-1.5 text-right">
                      {formatMoney(stats.revenueCents, restaurant.currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h2 className="text-sm font-medium">Tips by payment method</h2>
          {report.tipsByMethod.length === 0 ? (
            <p className="mt-3 text-sm text-neutral-400">No tips in this range.</p>
          ) : (
            <table className="mt-3 w-full text-sm">
              <thead className="text-left text-neutral-500">
                <tr>
                  <th className="pb-2 font-medium">Method</th>
                  <th className="pb-2 font-medium text-right">Tips</th>
                </tr>
              </thead>
              <tbody>
                {report.tipsByMethod.map(([method, cents]) => (
                  <tr key={method} className="border-t border-neutral-100">
                    <td className="py-1.5 capitalize">{method.toLowerCase()}</td>
                    <td className="py-1.5 text-right">{formatMoney(cents, restaurant.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h2 className="text-sm font-medium">Revenue by category</h2>
          {report.revenueByCategory.length === 0 ? (
            <p className="mt-3 text-sm text-neutral-400">No items sold in this range.</p>
          ) : (
            <table className="mt-3 w-full text-sm">
              <thead className="text-left text-neutral-500">
                <tr>
                  <th className="pb-2 font-medium">Category</th>
                  <th className="pb-2 font-medium text-right">Revenue</th>
                </tr>
              </thead>
              <tbody>
                {report.revenueByCategory.map((cat) => (
                  <tr key={cat.categoryId} className="border-t border-neutral-100">
                    <td className="py-1.5">{cat.name}</td>
                    <td className="py-1.5 text-right">
                      {formatMoney(cat.revenueCents, restaurant.currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h2 className="text-sm font-medium">Dine-in vs takeaway</h2>
          <div className="mt-3 flex justify-between text-sm">
            <span>Dine-in</span>
            <span>{formatMoney(report.revenueByFulfillment.dineInCents, restaurant.currency)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>Takeaway</span>
            <span>{formatMoney(report.revenueByFulfillment.takeawayCents, restaurant.currency)}</span>
          </div>
        </div>

        <div className="rounded-lg border border-neutral-200 bg-white p-4">
          <h2 className="text-sm font-medium">Revenue by order source</h2>
          {report.revenueByBillSource.length === 0 ? (
            <p className="mt-3 text-sm text-neutral-400">No paid bills in this range.</p>
          ) : (
            <table className="mt-3 w-full text-sm">
              <thead className="text-left text-neutral-500">
                <tr>
                  <th className="pb-2 font-medium">Source</th>
                  <th className="pb-2 font-medium text-right">Revenue</th>
                </tr>
              </thead>
              <tbody>
                {report.revenueByBillSource.map(([source, cents]) => (
                  <tr key={source} className="border-t border-neutral-100">
                    <td className="py-1.5 capitalize">{source.toLowerCase()}</td>
                    <td className="py-1.5 text-right">{formatMoney(cents, restaurant.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
