import { db } from "@/lib/db";
import { verifyPassword } from "@/lib/auth";

// In-memory, per-process lockout - same accepted trade-off as voice/restore.ts's own copy of
// this pattern (resets on redeploy, not a distributed rate limiter, still meaningfully raises
// the cost of brute-forcing a specific email against this internet-reachable login).
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000;
const failedAttempts = new Map<string, { count: number; lockedUntil: number }>();

function isLockedOut(email: string): boolean {
  const entry = failedAttempts.get(email);
  return !!entry && entry.lockedUntil > Date.now();
}

function recordFailure(email: string): void {
  const entry = failedAttempts.get(email) ?? { count: 0, lockedUntil: 0 };
  entry.count += 1;
  if (entry.count >= MAX_ATTEMPTS) {
    entry.lockedUntil = Date.now() + LOCKOUT_MS;
    entry.count = 0;
  }
  failedAttempts.set(email, entry);
}

function clearFailures(email: string): void {
  failedAttempts.delete(email);
}

export type OwnerLoginResult =
  | { ok: true; userId: string }
  | { ok: false; reason: "locked-out" | "invalid" };

// Verifies email+password directly against the cloud User table (this app's own db import
// is already pointed at CLOUD_DATABASE_URL via its DATABASE_URL env var - see lib/db.ts and
// the plan this came from) - deliberately not delegating this to voice/, since this app
// already needs its own direct cloud DB connection for the reports themselves, so adding a
// second live dependency just for login would buy nothing.
export async function verifyOwnerLogin(email: string, password: string): Promise<OwnerLoginResult> {
  const normalizedEmail = email.trim().toLowerCase();

  if (isLockedOut(normalizedEmail)) {
    return { ok: false, reason: "locked-out" };
  }

  const user = await db.user.findUnique({ where: { email: normalizedEmail } });
  if (!user || !user.passwordHash || !(await verifyPassword(password, user.passwordHash))) {
    recordFailure(normalizedEmail);
    return { ok: false, reason: "invalid" };
  }

  clearFailures(normalizedEmail);
  return { ok: true, userId: user.id };
}
