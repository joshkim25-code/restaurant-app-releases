import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getCurrentUserId } from "@/lib/session";

// Same shape as src/lib/restaurant.ts's getCurrentRestaurant(), deliberately not imported
// from there and reused as-is: this site is internet-reachable, so remote financial access
// is restricted to the OWNER role - a STAFF login should never reach it. The local app
// intentionally allows any membership role to reach Settings/Reports there, so that file's
// existing behavior is left alone rather than changed to satisfy this stricter need.
export async function getOwnerRestaurant() {
  const userId = await getCurrentUserId();
  if (!userId) {
    redirect("/login");
  }

  const membership = await db.membership.findFirst({
    where: { userId, role: "OWNER" },
    orderBy: { createdAt: "asc" },
    include: { restaurant: true },
  });

  if (!membership) {
    redirect("/login?error=not-owner");
  }

  return membership.restaurant;
}
