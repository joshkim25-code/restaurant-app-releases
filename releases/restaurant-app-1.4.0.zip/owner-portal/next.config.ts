import type { NextConfig } from "next";
import path from "node:path";

// Reuses several src/lib/*.ts files from the main app one directory up (unmodified, via the
// "@/*" -> "../src/*" path alias in this app's own tsconfig.json) rather than duplicating
// them - see the plan this came from. Vercel's serverless output-file tracing only includes
// files under this app's own directory by default; outputFileTracingRoot widens that to the
// whole repo so the cross-directory imports actually get bundled into the deployed function.
const nextConfig: NextConfig = {
  outputFileTracingRoot: path.join(__dirname, ".."),
};

export default nextConfig;
