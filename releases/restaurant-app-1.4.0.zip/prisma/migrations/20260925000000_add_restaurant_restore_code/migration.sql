-- AlterTable
ALTER TABLE "Restaurant" ADD COLUMN "restoreCode" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "Restaurant_restoreCode_key" ON "Restaurant"("restoreCode");
