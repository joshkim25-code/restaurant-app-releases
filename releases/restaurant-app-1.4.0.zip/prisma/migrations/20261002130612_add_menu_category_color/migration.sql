-- CreateEnum
CREATE TYPE "MenuCategoryColor" AS ENUM ('NEUTRAL', 'RED', 'ORANGE', 'AMBER', 'GREEN', 'TEAL', 'BLUE', 'PURPLE', 'PINK');

-- AlterTable
ALTER TABLE "MenuCategory" ADD COLUMN     "color" "MenuCategoryColor" NOT NULL DEFAULT 'NEUTRAL';
