-- AlterTable
ALTER TABLE "MenuItemOptionChoice" ADD COLUMN     "color" "MenuCategoryColor" NOT NULL DEFAULT 'NEUTRAL';
