-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "MenuCategoryColor" ADD VALUE 'YELLOW';
ALTER TYPE "MenuCategoryColor" ADD VALUE 'LIME';
ALTER TYPE "MenuCategoryColor" ADD VALUE 'CYAN';
ALTER TYPE "MenuCategoryColor" ADD VALUE 'INDIGO';
ALTER TYPE "MenuCategoryColor" ADD VALUE 'ROSE';
ALTER TYPE "MenuCategoryColor" ADD VALUE 'BROWN';
