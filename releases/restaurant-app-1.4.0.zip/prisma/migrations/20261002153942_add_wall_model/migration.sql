-- CreateTable
CREATE TABLE "Wall" (
    "id" TEXT NOT NULL,
    "restaurantId" TEXT NOT NULL,
    "x1" INTEGER NOT NULL,
    "y1" INTEGER NOT NULL,
    "x2" INTEGER NOT NULL,
    "y2" INTEGER NOT NULL,

    CONSTRAINT "Wall_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Wall_restaurantId_idx" ON "Wall"("restaurantId");

-- AddForeignKey
ALTER TABLE "Wall" ADD CONSTRAINT "Wall_restaurantId_fkey" FOREIGN KEY ("restaurantId") REFERENCES "Restaurant"("id") ON DELETE CASCADE ON UPDATE CASCADE;
