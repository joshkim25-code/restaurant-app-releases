# Pushes the current committed code (git HEAD) to the disposable, fully isolated test
# install (its own directory, its own "restaurant_test" Postgres database, its own port
# 3100, its own Windows Services) via the REAL, unmodified apply-update.ps1 - the same
# script a restaurant's launcher runs for a real update. Never touches the real
# RestaurantApp/RestaurantPrintAgent/RestaurantSync services, the real app directory, or
# the real "restaurant" database.
#
# This only runs the happy-path deploy (no deliberate-failure test) - for that, use
# launcher\scripts\test-update-flow.ps1 instead. Shares its setup logic (Ensure-TestDatabase/
# Ensure-TestInstall/Ensure-TestServices are copied here, not imported, to avoid depending on
# or risking disturbing that file, which the launcher's own test suite also relies on).
#
# Safe to re-run any time there's new committed code to try out on the test instance.
# Requires an elevated (Administrator) PowerShell (NSSM service control needs it).
#
# Usage:  powershell -ExecutionPolicy Bypass -File scripts\deploy-to-test.ps1

$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
$applyUpdateScript = Join-Path $repoRoot "launcher\scripts\apply-update.ps1"

. (Join-Path $repoRoot "launcher\scripts\lib\install-app.ps1")

$TestInstallDir = "C:\ProgramData\RestaurantApp-test\app"
$TestDbName = "restaurant_test"
$TestPort = 3100
$TestHealthCheckUrl = "http://localhost:$TestPort/login"
$TestAppService = "RestaurantAppTest"
$TestPrintAgentService = "RestaurantPrintAgentTest"
$TestSyncService = "RestaurantSyncTest"
$FileServerPort = 8123

function Find-Node {
  $default = "C:\Program Files\nodejs\node.exe"
  if (Test-Path $default) { return $default }
  $onPath = Get-Command node.exe -ErrorAction SilentlyContinue
  if ($onPath) { return $onPath.Source }
  throw "node.exe not found - install Node.js first."
}

function Find-PgBin {
  $bin = Get-ChildItem "C:\Program Files\PostgreSQL" -Directory -ErrorAction SilentlyContinue |
    Sort-Object Name -Descending |
    ForEach-Object { Join-Path $_.FullName "bin" } |
    Where-Object { Test-Path (Join-Path $_ "psql.exe") } |
    Select-Object -First 1
  if (-not $bin) { throw "Postgres bin directory (with psql.exe) not found under C:\Program Files\PostgreSQL." }
  return $bin
}

function Get-RealDatabaseUrlParts {
  $envPath = Join-Path $repoRoot ".env"
  $line = Get-Content $envPath | Where-Object { $_ -match '^DATABASE_URL=' } | Select-Object -First 1
  if (-not $line) { throw "DATABASE_URL not found in $envPath" }
  $value = $line -replace '^DATABASE_URL=', '' -replace '^"|"$', ''
  if ($value -notmatch '^postgresql://([^:]+):([^@]+)@([^:/]+):(\d+)/([^?]+)(\?.*)?$') {
    throw "Could not parse DATABASE_URL - expected postgresql://user:pass@host:port/dbname[?params]"
  }
  return [ordered]@{
    User = $Matches[1]; Password = $Matches[2]; Host = $Matches[3]; Port = $Matches[4]
    Database = $Matches[5]; Params = $Matches[6]
  }
}

function Invoke-Psql {
  param([string[]]$PsqlArgs)
  $output = & $script:psql @PsqlArgs 2>&1
  if ($LASTEXITCODE -ne 0) {
    throw "psql failed (exit $LASTEXITCODE): $($output -join "`n")"
  }
  return $output
}

function Ensure-TestDatabase {
  param($DbParts)
  $pgBin = Find-PgBin
  $script:psql = Join-Path $pgBin "psql.exe"
  $env:PGPASSWORD = $DbParts.Password
  try {
    $exists = Invoke-Psql @("-h", $DbParts.Host, "-p", $DbParts.Port, "-U", $DbParts.User, "-d", "postgres", "-tAc", "SELECT 1 FROM pg_database WHERE datname = '$TestDbName'")
    if (($exists -join "").Trim() -eq "1") {
      Write-Output "Test database '$TestDbName' already exists."
    } else {
      Write-Output "Creating test database '$TestDbName'..."
      Invoke-Psql @("-h", $DbParts.Host, "-p", $DbParts.Port, "-U", $DbParts.User, "-d", "postgres", "-c", "CREATE DATABASE $TestDbName OWNER $($DbParts.User);") | Out-Null
    }
  } finally {
    Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue
  }
}

function Ensure-TestInstall {
  param($DbParts)
  $buildMarker = Join-Path $TestInstallDir ".next-prod\BUILD_ID"
  if (Test-Path $buildMarker) {
    Write-Output "Test install already present and built at $TestInstallDir."
    return
  }
  if (Test-Path $TestInstallDir) {
    Write-Output "Found an incomplete previous test install at $TestInstallDir - removing and redoing it."
    Remove-Item -Recurse -Force $TestInstallDir
  }

  Write-Output "Setting up test install at $TestInstallDir..."
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $TestInstallDir) | Out-Null

  $seedZip = Join-Path $env:TEMP "restaurant-app-test-seed.zip"
  Push-Location $repoRoot
  git archive --format=zip --output $seedZip HEAD
  Pop-Location
  Expand-Archive -Path $seedZip -DestinationPath $TestInstallDir -Force
  Remove-Item $seedZip -ErrorAction SilentlyContinue

  $pkgPath = Join-Path $TestInstallDir "package.json"
  $pkg = Get-Content -Raw $pkgPath | ConvertFrom-Json
  $pkg.version = "0.9.0"
  $pkg | ConvertTo-Json -Depth 20 | Set-Content -Path $pkgPath

  $realEnv = Get-Content (Join-Path $repoRoot ".env")
  $testDatabaseUrl = "postgresql://$($DbParts.User):$($DbParts.Password)@$($DbParts.Host):$($DbParts.Port)/$TestDbName$($DbParts.Params)"
  $testEnv = $realEnv | ForEach-Object {
    if ($_ -match '^DATABASE_URL=') { "DATABASE_URL=`"$testDatabaseUrl`"" }
    elseif ($_ -match '^PUBLIC_BASE_URL=') { "PUBLIC_BASE_URL=`"http://localhost:$TestPort`"" }
    else { $_ }
  }
  Set-Content -Path (Join-Path $TestInstallDir ".env") -Value $testEnv

  Install-AppDependencies -InstallDir $TestInstallDir

  Push-Location $TestInstallDir
  try {
    Write-Output "Migrating test database to current schema (baseline, matches a real pre-existing install)..."
    & npx prisma migrate deploy
    if ($LASTEXITCODE -ne 0) { throw "Baseline prisma migrate deploy failed against $TestDbName." }
  } finally {
    Pop-Location
  }
}

function Ensure-TestServices {
  $nssm = Find-Nssm
  $npmCmd = Find-Npm

  function Install-TestService($Name, $Params, $LogFile, $ExtraEnv) {
    if (Get-Service -Name $Name -ErrorAction SilentlyContinue) {
      Write-Output "Test service '$Name' already registered - reapplying its config."
    } else {
      Write-Output "Registering test service '$Name'..."
      & $nssm install $Name $npmCmd $Params | Out-Null
    }
    & $nssm set $Name AppParameters $Params | Out-Null
    & $nssm set $Name AppDirectory $TestInstallDir | Out-Null
    & $nssm set $Name AppStdout (Join-Path $TestInstallDir $LogFile) | Out-Null
    & $nssm set $Name AppStderr (Join-Path $TestInstallDir $LogFile) | Out-Null
    & $nssm set $Name AppRotateFiles 1 | Out-Null
    & $nssm set $Name AppRotateBytes 5242880 | Out-Null
    & $nssm set $Name Start SERVICE_AUTO_START | Out-Null
    & $nssm set $Name AppExit Default Restart | Out-Null
    & $nssm set $Name AppRestartDelay 3000 | Out-Null
    if ($ExtraEnv) { & $nssm set $Name AppEnvironmentExtra $ExtraEnv | Out-Null }
    & $nssm restart $Name | Out-Null
  }

  Install-TestService $TestAppService "run start" "app.log" "PORT=$TestPort"
  Install-TestService $TestPrintAgentService "run agent" "agent.log"
  Install-TestService $TestSyncService "run sync" "sync.log"

  Start-Sleep -Seconds 2
  Get-Service $TestAppService, $TestPrintAgentService, $TestSyncService | Format-Table Name, Status -AutoSize
}

function Start-LocalFileServer {
  param([string]$FilePath, [int]$Port)
  $serverScript = Join-Path $env:TEMP "release-file-server.cjs"
  @"
const http = require('http');
const fs = require('fs');
const filePath = process.argv[2];
const port = Number(process.argv[3]);
const server = http.createServer((req, res) => {
  if (req.url === '/release.zip') {
    res.writeHead(200, { 'Content-Type': 'application/zip' });
    fs.createReadStream(filePath).pipe(res);
  } else {
    res.writeHead(404);
    res.end();
  }
});
server.listen(port, '127.0.0.1', () => console.log('serving on ' + port));
"@ | Set-Content -Path $serverScript -Encoding utf8

  $proc = Start-Process -FilePath (Find-Node) -ArgumentList @($serverScript, $FilePath, $Port) -PassThru -WindowStyle Hidden
  Start-Sleep -Seconds 1
  return $proc
}

function Get-InstalledTestVersion {
  $pkgPath = Join-Path $TestInstallDir "package.json"
  return (Get-Content -Raw $pkgPath | ConvertFrom-Json).version
}

# ============================== Setup (idempotent) ==============================

Write-Output "=== Ensuring the disposable test install exists (skips anything already present) ==="
$dbParts = Get-RealDatabaseUrlParts
Ensure-TestDatabase -DbParts $dbParts
Ensure-TestInstall -DbParts $dbParts
Ensure-TestServices

# ============================== Deploy current HEAD ==============================

Write-Output ""
Write-Output "=== Deploying current committed code (git HEAD) to the test install ==="
$versionBefore = Get-InstalledTestVersion
Write-Output "Test install version before: $versionBefore"

$zip = Join-Path $env:TEMP "restaurant-app-test-deploy.zip"
Push-Location $repoRoot
git archive --format=zip --output $zip HEAD
Pop-Location

$targetVersion = (Get-Content -Raw (Join-Path $repoRoot "package.json") | ConvertFrom-Json).version
$sha256 = (Get-FileHash -Path $zip -Algorithm SHA256).Hash
$server = Start-LocalFileServer -FilePath $zip -Port $FileServerPort
try {
  & powershell -NoProfile -ExecutionPolicy Bypass -File $applyUpdateScript `
    -InstallDir $TestInstallDir `
    -DownloadUrl "http://localhost:$FileServerPort/release.zip" `
    -ExpectedSha256 $sha256 `
    -Version $targetVersion `
    -AppServiceName $TestAppService `
    -PrintAgentServiceName $TestPrintAgentService `
    -SyncServiceName $TestSyncService `
    -HealthCheckUrl $TestHealthCheckUrl
  $exitCode = $LASTEXITCODE
} finally {
  Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue
  Remove-Item $zip -ErrorAction SilentlyContinue
}

$versionAfter = Get-InstalledTestVersion
Write-Output ""
if ($exitCode -eq 0 -and $versionAfter -eq $targetVersion) {
  Write-Output "DEPLOY OK - test install is now running version $versionAfter at http://localhost:$TestPort"
} else {
  Write-Output "DEPLOY FAILED (exit $exitCode) - test install is still at version $versionAfter"
  exit 1
}
