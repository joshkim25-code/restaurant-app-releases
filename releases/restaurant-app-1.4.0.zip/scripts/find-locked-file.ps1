# Tries to open every file under the test install directory with exclusive access, to find
# exactly which one is locked (and by extension, narrow down what's holding it) - run this
# right after a failed deploy-to-test attempt, before anything restarts.

$InstallDir = "C:\ProgramData\RestaurantApp-test\app"
$locked = @()

Get-ChildItem -Path $InstallDir -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
  $path = $_.FullName
  try {
    $stream = [System.IO.File]::Open($path, 'Open', 'ReadWrite', 'None')
    $stream.Close()
  } catch {
    $locked += "$path -- $($_.Exception.Message)"
  }
}

$outPath = Join-Path $env:TEMP "locked-files-result.txt"
if ($locked.Count -eq 0) {
  "No individual locked files found - the lock may be on the directory handle itself (not a file), or on a subfolder that couldn't be enumerated." | Set-Content -Path $outPath -Encoding utf8
} else {
  "Locked files ($($locked.Count)):" | Set-Content -Path $outPath -Encoding utf8
  $locked | Add-Content -Path $outPath -Encoding utf8
}

Write-Output "Wrote results to $outPath"
Write-Output ""
Write-Output "Press Enter to close this window..."
Read-Host | Out-Null
