# One-off diagnostic/recovery helper: identifies the exact process tree holding port 3100
# (the test app), force-kills it directly by PID (not just via nssm stop, which may leave an
# orphaned grandchild if nssm doesn't kill its full process tree), confirms the directory can
# actually be renamed, then restarts the 3 test services clean. Safe to re-run. Requires an
# elevated PowerShell (same as deploy-to-test.ps1).

$ErrorActionPreference = "Stop"
$repoRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $repoRoot "launcher\scripts\lib\install-app.ps1")

$InstallDir = "C:\ProgramData\RestaurantApp-test\app"
$services = @("RestaurantAppTest", "RestaurantPrintAgentTest", "RestaurantSyncTest")
$nssm = Find-Nssm

Write-Output "Stopping test services via nssm..."
foreach ($svc in $services) {
  & $nssm stop $svc | Out-Null
}
Start-Sleep -Seconds 2

Write-Output "Finding whatever is still listening on port 3100..."
$conns = Get-NetTCPConnection -LocalPort 3100 -State Listen -ErrorAction SilentlyContinue
if ($conns) {
  $pids = $conns.OwningProcess | Sort-Object -Unique
  foreach ($procId in $pids) {
    Write-Output "Port 3100 still held by PID $procId - force-killing its full process tree..."
    taskkill /PID $procId /T /F 2>&1 | Write-Output
  }
  Start-Sleep -Seconds 2
} else {
  Write-Output "Nothing listening on port 3100."
}

Write-Output "Sweeping any remaining node/cmd/npm process still using files under the install dir..."
Stop-ProcessesUsingPath -Path $InstallDir

# The specific files that were actually found locked (via a separate probe): the 3 nssm
# stdout/stderr log files, plus two native .node addon binaries (Next's SWC compiler, the
# canvas library) - memory-mapped native binaries are known to stay locked for a while after
# the process that loaded them exits (deferred OS-level unmapping), and antivirus real-time
# scanning a freshly-touched .node binary can hold its own lock on top of that. A short fixed
# wait wasn't enough - poll with retries instead of guessing a longer fixed sleep.
$probeName = "$InstallDir.probe"
$maxAttempts = 12
$cleared = $false
for ($i = 1; $i -le $maxAttempts; $i++) {
  if (Test-Path $probeName) { Remove-Item -Recurse -Force $probeName -ErrorAction SilentlyContinue }
  try {
    Rename-Item -Path $InstallDir -NewName (Split-Path -Leaf $probeName) -ErrorAction Stop
    Rename-Item -Path $probeName -NewName (Split-Path -Leaf $InstallDir) -ErrorAction Stop
    $cleared = $true
    break
  } catch {
    Write-Output "Still locked (attempt $i of $maxAttempts) - waiting 5s..."
    Start-Sleep -Seconds 5
  }
}

if ($cleared) {
  Write-Output ""
  Write-Output "CLEAR - the directory can be renamed now. Safe to run deploy-to-test.bat."
} else {
  Write-Output ""
  Write-Output "STILL LOCKED after $($maxAttempts * 5)s of retries."
  Write-Output "Something other than the app process itself still has a handle open (a File"
  Write-Output "Explorer window, an editor, antivirus, or a backup tool). Close anything pointed"
  Write-Output "at $InstallDir and re-run this script."
}

Write-Output ""
Write-Output "Restarting test services..."
foreach ($svc in $services) {
  & $nssm start $svc | Out-Null
}
Start-Sleep -Seconds 2
Get-Service $services | Format-Table Name, Status -AutoSize

Write-Output "Press Enter to close this window..."
Read-Host | Out-Null
