import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { updateBusinessHours } from "./actions";

const DAY_LABELS = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

export default async function HoursPage() {
  const restaurant = await getCurrentRestaurant();
  const hours = await db.businessHours.findMany({
    where: { restaurantId: restaurant.id },
  });

  const byDay = new Map(hours.map((h) => [h.dayOfWeek, h]));

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-xl font-semibold">Business hours</h1>
        <p className="text-sm text-neutral-500 dark:text-neutral-400">
          Used to validate reservation requests taken over the phone.
        </p>
      </div>

      <form
        action={updateBusinessHours}
        className="overflow-hidden rounded-lg border border-neutral-200 bg-white dark:border-neutral-700 dark:bg-neutral-900"
      >
        <table className="w-full border-collapse text-sm">
          <thead className="bg-neutral-100 text-left text-neutral-600 dark:bg-neutral-800 dark:text-neutral-400">
            <tr>
              <th className="px-4 py-2 font-medium">Day</th>
              <th className="px-4 py-2 font-medium">Closed</th>
              <th className="px-4 py-2 font-medium">Open</th>
              <th className="px-4 py-2 font-medium">Close</th>
            </tr>
          </thead>
          <tbody>
            {DAY_LABELS.map((label, dayOfWeek) => {
              const existing = byDay.get(dayOfWeek);
              return (
                <tr key={dayOfWeek} className="border-t border-neutral-200 dark:border-neutral-700">
                  <td className="px-4 py-2">{label}</td>
                  <td className="px-4 py-2">
                    <input
                      type="checkbox"
                      name={`closed-${dayOfWeek}`}
                      defaultChecked={existing?.isClosed ?? false}
                    />
                  </td>
                  <td className="px-4 py-2">
                    <input
                      type="time"
                      name={`open-${dayOfWeek}`}
                      defaultValue={existing?.openTime ?? "17:00"}
                      className="rounded border border-neutral-300 px-2 py-1 dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
                    />
                  </td>
                  <td className="px-4 py-2">
                    <input
                      type="time"
                      name={`close-${dayOfWeek}`}
                      defaultValue={existing?.closeTime ?? "22:00"}
                      className="rounded border border-neutral-300 px-2 py-1 dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
                    />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <div className="border-t border-neutral-200 p-4 dark:border-neutral-700">
          <button
            type="submit"
            className="rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700 dark:bg-neutral-100 dark:text-neutral-900 dark:hover:bg-neutral-300"
          >
            Save hours
          </button>
        </div>
      </form>
    </div>
  );
}
