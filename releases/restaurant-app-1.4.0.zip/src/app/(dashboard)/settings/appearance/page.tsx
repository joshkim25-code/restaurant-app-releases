import { getThemePreference } from "@/lib/theme";
import { SettingsRow } from "@/components/settings/SettingsRow";
import { updateThemePreference } from "../actions";

const OPTIONS = ["light", "dark", "system"] as const;

export default async function AppearancePage() {
  const current = await getThemePreference();

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold dark:text-neutral-100">Appearance</h1>
        <p className="text-sm text-neutral-500 dark:text-neutral-400">
          Applies to this device only.
        </p>
      </div>

      <div className="rounded-lg border border-neutral-200 bg-white p-6 dark:border-neutral-700 dark:bg-neutral-900">
        <SettingsRow
          label="Theme"
          description="Light, dark, or match this device's system setting"
        >
          <div className="flex gap-2">
            {OPTIONS.map((opt) => (
              <form key={opt} action={updateThemePreference}>
                <input type="hidden" name="theme" value={opt} />
                <button
                  type="submit"
                  aria-pressed={current === opt}
                  className={`rounded border px-3 py-1.5 text-sm capitalize ${
                    current === opt
                      ? "border-neutral-900 bg-neutral-900 text-white dark:border-neutral-100 dark:bg-neutral-100 dark:text-neutral-900"
                      : "border-neutral-300 text-neutral-600 hover:bg-neutral-100 dark:border-neutral-600 dark:text-neutral-300 dark:hover:bg-neutral-800"
                  }`}
                >
                  {opt}
                </button>
              </form>
            ))}
          </div>
        </SettingsRow>
      </div>
    </div>
  );
}
