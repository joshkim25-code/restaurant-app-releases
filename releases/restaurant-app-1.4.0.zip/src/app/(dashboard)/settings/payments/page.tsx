import { getCurrentRestaurant } from "@/lib/restaurant";
import { SettingsRow } from "@/components/settings/SettingsRow";
import { updatePayments, startSubscriptionCheckout } from "../actions";

type SubscriptionStatusResponse = {
  active: boolean;
  status: "TRIALING" | "ACTIVE" | "PAST_DUE" | "CANCELED";
  graceEndsAt: string | null;
};

const STATUS_LABEL: Record<SubscriptionStatusResponse["status"], string> = {
  TRIALING: "Trialing",
  ACTIVE: "Active",
  PAST_DUE: "Past due",
  CANCELED: "Not subscribed",
};

// Billing lives entirely in the cloud-hosted voice service (voice/billing.ts) - the local
// app has no direct database access to it (see Subscription's own schema comment for why),
// so this is a live network call, not a DB read. Never lets a billing-service hiccup break
// the whole Settings page - a null return just means "couldn't check right now".
async function getSubscriptionStatus(restaurantId: string): Promise<SubscriptionStatusResponse | null> {
  const voiceBaseUrl = (process.env.VOICE_PUBLIC_URL ?? "").replace(/\/$/, "");
  if (!voiceBaseUrl) return null;

  try {
    const response = await fetch(
      `${voiceBaseUrl}/billing/status?restaurantId=${encodeURIComponent(restaurantId)}`,
      { cache: "no-store" },
    );
    if (!response.ok) return null;
    return (await response.json()) as SubscriptionStatusResponse;
  } catch {
    return null;
  }
}

export default async function PaymentsSettingsPage() {
  const restaurant = await getCurrentRestaurant();
  const subscription = await getSubscriptionStatus(restaurant.id);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Payments &amp; subscription</h1>
        <p className="text-sm text-neutral-500 dark:text-neutral-400">
          Tax and tipping defaults, plus billing status for {restaurant.name}.
        </p>
      </div>

      <form action={updatePayments} className="rounded-lg border border-neutral-200 bg-white p-6 dark:border-neutral-700 dark:bg-neutral-900">
        <SettingsRow label="Default tip options" description="Comma-separated percentages">
          <input
            name="defaultTipPercentages"
            key={restaurant.defaultTipPercentages}
            defaultValue={restaurant.defaultTipPercentages}
            placeholder="15,18,20"
            className="w-40 rounded border border-neutral-300 px-2 py-1.5 text-sm dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
          />
        </SettingsRow>
        <SettingsRow label="Payment processor">
          <span className="text-sm text-neutral-500 dark:text-neutral-400">Not connected — coming soon</span>
        </SettingsRow>

        <div className="mt-6">
          <button
            type="submit"
            className="rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700 dark:bg-neutral-100 dark:text-neutral-900 dark:hover:bg-neutral-300"
          >
            Save payments
          </button>
        </div>
      </form>

      <div className="rounded-lg border border-neutral-200 bg-white p-6 dark:border-neutral-700 dark:bg-neutral-900">
        <SettingsRow label="Subscription">
          {subscription === null ? (
            <span className="text-sm text-neutral-500 dark:text-neutral-400">
              Couldn&rsquo;t check subscription status right now.
            </span>
          ) : (
            <span className="text-sm text-neutral-700 dark:text-neutral-300">{STATUS_LABEL[subscription.status]}</span>
          )}
        </SettingsRow>

        {(subscription === null || !subscription.active) && (
          <form action={startSubscriptionCheckout} className="mt-2">
            <button
              type="submit"
              className="rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700 dark:bg-neutral-100 dark:text-neutral-900 dark:hover:bg-neutral-300"
            >
              Subscribe
            </button>
            <p className="mt-1 text-xs text-neutral-400 dark:text-neutral-500">
              Redirects to Stripe&rsquo;s secure checkout — you can enter a discount code
              there if you have one.
            </p>
          </form>
        )}
      </div>
    </div>
  );
}
