import Link from "next/link";
import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import { formatDateTime } from "@/lib/time";
import { createTable, deleteTable, toggleTableActive, updateTable } from "./actions";

type SortKey = "label" | "seats" | "section" | "status";
type SortDir = "asc" | "desc";

const SORT_COLUMNS: { key: SortKey; label: string }[] = [
  { key: "label", label: "Label" },
  { key: "seats", label: "Seats" },
  { key: "section", label: "Section" },
  { key: "status", label: "Status" },
];

function SortableHeader({
  column,
  activeSort,
  activeDir,
}: {
  column: { key: SortKey; label: string };
  activeSort: SortKey;
  activeDir: SortDir;
}) {
  const isActive = column.key === activeSort;
  const isActiveAsc = isActive && activeDir === "asc";
  const isActiveDesc = isActive && activeDir === "desc";
  const nextDir: SortDir = isActive && activeDir === "asc" ? "desc" : "asc";

  return (
    <th className="px-4 py-2 font-medium">
      <div className="flex items-center gap-1">
        {column.label}
        <Link
          href={`/tables?sort=${column.key}&dir=${nextDir}`}
          aria-label={`Sort by ${column.label} ${nextDir === "asc" ? "ascending" : "descending"}`}
          className="flex flex-col leading-none rounded border border-transparent px-1 py-0.5 text-neutral-400 hover:border-neutral-300 hover:bg-neutral-100 hover:text-neutral-600 dark:text-neutral-500 dark:hover:border-neutral-600 dark:hover:bg-neutral-800 dark:hover:text-neutral-400"
        >
          <span className={isActiveAsc ? "font-bold text-neutral-900 dark:text-neutral-100" : undefined}>
            ▲
          </span>
          <span className={isActiveDesc ? "font-bold text-neutral-900 dark:text-neutral-100" : undefined}>
            ▼
          </span>
        </Link>
      </div>
    </th>
  );
}

export default async function TablesPage({
  searchParams,
}: {
  searchParams: Promise<{ sort?: string; dir?: string; edit?: string; error?: string; seats?: string }>;
}) {
  const params = await searchParams;
  const sort: SortKey = SORT_COLUMNS.some((c) => c.key === params.sort)
    ? (params.sort as SortKey)
    : "seats";
  const dir: SortDir = params.dir === "desc" ? "desc" : "asc";

  const restaurant = await getCurrentRestaurant();
  const primaryOrderBy =
    sort === "label"
      ? { label: dir }
      : sort === "seats"
        ? { seats: dir }
        : sort === "section"
          ? { section: dir }
          : { isActive: dir };
  const tables = await db.table.findMany({
    where: { restaurantId: restaurant.id },
    orderBy: [primaryOrderBy, { label: "asc" }],
  });

  const requestedSeats = Number(params.seats);
  const blockingReservations =
    params.error === "reserved" && params.edit && Number.isInteger(requestedSeats)
      ? await db.reservation.findMany({
          where: {
            restaurantId: restaurant.id,
            tableId: params.edit,
            status: { in: ["PENDING", "CONFIRMED"] },
            startTime: { gte: new Date() },
            partySize: { gt: requestedSeats },
          },
          orderBy: { startTime: "asc" },
          include: { customer: true },
        })
      : [];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-xl font-semibold">Tables</h1>
        <p className="text-sm text-neutral-500 dark:text-neutral-400">
          Manage {restaurant.name}&rsquo;s floor plan. The assignment
          algorithm matches reservations to the smallest active table that
          fits the party.
        </p>
      </div>

      {params.error === "invalid" && (
        <p className="rounded border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-700 dark:bg-red-950 dark:text-red-400">
          Couldn&rsquo;t save: a table needs a label and a whole number of seats above zero.
        </p>
      )}
      {params.error === "reserved" && blockingReservations.length > 0 && (
        <div className="rounded border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-700 dark:bg-red-950 dark:text-red-400">
          <p>
            Couldn&rsquo;t reduce this table to {requestedSeats} seat{requestedSeats === 1 ? "" : "s"}:
            these upcoming reservations are booked on it for larger parties. Move or cancel them
            first.
          </p>
          <ul className="mt-1 list-disc pl-5">
            {blockingReservations.map((r) => (
              <li key={r.id}>
                {r.customer.name}, party of {r.partySize},{" "}
                {formatDateTime(r.startTime, restaurant.timezone)}
              </li>
            ))}
          </ul>
        </div>
      )}

      <table className="w-full border-collapse overflow-hidden rounded-lg border border-neutral-200 bg-white text-sm dark:border-neutral-700 dark:bg-neutral-900">
        <thead className="bg-neutral-100 text-left text-neutral-600 dark:bg-neutral-800 dark:text-neutral-400">
          <tr>
            {SORT_COLUMNS.map((column) => (
              <SortableHeader
                key={column.key}
                column={column}
                activeSort={sort}
                activeDir={dir}
              />
            ))}
            <th className="px-4 py-2" />
          </tr>
        </thead>
        <tbody>
          {tables.map((table) =>
            table.id === params.edit ? (
              <tr key={table.id} className="border-t border-neutral-200 bg-neutral-50 dark:border-neutral-700 dark:bg-neutral-950">
                <td className="px-4 py-2">
                  <input
                    form="edit-table-form"
                    name="label"
                    required
                    defaultValue={table.label}
                    aria-label="Label"
                    className="w-full rounded border border-neutral-300 px-2 py-1 dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
                  />
                </td>
                <td className="px-4 py-2">
                  <input
                    form="edit-table-form"
                    name="seats"
                    type="number"
                    min={1}
                    required
                    defaultValue={table.seats}
                    aria-label="Seats"
                    className="w-20 rounded border border-neutral-300 px-2 py-1 dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
                  />
                </td>
                <td className="px-4 py-2">
                  <input
                    form="edit-table-form"
                    name="section"
                    defaultValue={table.section ?? ""}
                    placeholder="Patio"
                    aria-label="Section"
                    className="w-full rounded border border-neutral-300 px-2 py-1 dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
                  />
                </td>
                <td className="px-4 py-2">
                  {table.isActive ? (
                    <span className="text-green-700 dark:text-green-400">Active</span>
                  ) : (
                    <span className="text-neutral-400 dark:text-neutral-500">Inactive</span>
                  )}
                </td>
                <td className="px-4 py-2 text-right">
                  <form
                    id="edit-table-form"
                    action={updateTable}
                    className="flex items-center justify-end gap-3"
                  >
                    <input type="hidden" name="id" value={table.id} />
                    <input type="hidden" name="sort" value={sort} />
                    <input type="hidden" name="dir" value={dir} />
                    <button
                      type="submit"
                      className="rounded bg-neutral-900 px-3 py-1 text-white hover:bg-neutral-700 dark:bg-neutral-100 dark:text-neutral-900 dark:hover:bg-neutral-300"
                    >
                      Save
                    </button>
                    <Link
                      href={`/tables?sort=${sort}&dir=${dir}`}
                      className="text-neutral-600 underline hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100"
                    >
                      Cancel
                    </Link>
                  </form>
                </td>
              </tr>
            ) : (
            <tr key={table.id} className="border-t border-neutral-200 dark:border-neutral-700">
              <td className="px-4 py-2">{table.label}</td>
              <td className="px-4 py-2">{table.seats}</td>
              <td className="px-4 py-2">{table.section ?? "—"}</td>
              <td className="px-4 py-2">
                {table.isActive ? (
                  <span className="text-green-700 dark:text-green-400">Active</span>
                ) : (
                  <span className="text-neutral-400 dark:text-neutral-500">Inactive</span>
                )}
              </td>
              <td className="px-4 py-2 text-right">
                <div className="flex justify-end gap-3">
                  <Link
                    href={`/tables?sort=${sort}&dir=${dir}&edit=${table.id}`}
                    className="text-neutral-600 underline hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100"
                  >
                    Edit
                  </Link>
                  <form action={toggleTableActive}>
                    <input type="hidden" name="id" value={table.id} />
                    <input
                      type="hidden"
                      name="isActive"
                      value={String(table.isActive)}
                    />
                    <button
                      type="submit"
                      className="text-neutral-600 underline hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100"
                    >
                      {table.isActive ? "Deactivate" : "Activate"}
                    </button>
                  </form>
                  <form action={deleteTable}>
                    <input type="hidden" name="id" value={table.id} />
                    <button
                      type="submit"
                      className="text-red-600 underline hover:text-red-800 dark:text-red-400 dark:hover:text-red-300"
                    >
                      Delete
                    </button>
                  </form>
                </div>
              </td>
            </tr>
            ),
          )}
          {tables.length === 0 && (
            <tr>
              <td
                colSpan={5}
                className="px-4 py-6 text-center text-neutral-400 dark:text-neutral-500"
              >
                No tables yet — add one below.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <form
        action={createTable}
        className="flex flex-wrap items-end gap-4 rounded-lg border border-neutral-200 bg-white p-4 dark:border-neutral-700 dark:bg-neutral-900"
      >
        <div className="flex flex-col gap-1">
          <label className="text-xs text-neutral-500 dark:text-neutral-400" htmlFor="label">
            Label
          </label>
          <input
            id="label"
            name="label"
            required
            placeholder="T7"
            className="rounded border border-neutral-300 px-2 py-1 dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs text-neutral-500 dark:text-neutral-400" htmlFor="seats">
            Seats
          </label>
          <input
            id="seats"
            name="seats"
            type="number"
            min={1}
            required
            className="w-20 rounded border border-neutral-300 px-2 py-1 dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs text-neutral-500 dark:text-neutral-400" htmlFor="section">
            Section (optional)
          </label>
          <input
            id="section"
            name="section"
            placeholder="Patio"
            className="rounded border border-neutral-300 px-2 py-1 dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
          />
        </div>
        <button
          type="submit"
          className="rounded bg-neutral-900 px-4 py-1.5 text-white hover:bg-neutral-700 dark:bg-neutral-100 dark:text-neutral-900 dark:hover:bg-neutral-300"
        >
          Add table
        </button>
      </form>
    </div>
  );
}
