import { NextRequest, NextResponse } from "next/server";
import { consumeLoginToken, findOrCreateUser } from "@/lib/auth";
import { getSession } from "@/lib/session";

export async function GET(request: NextRequest) {
  const token = request.nextUrl.searchParams.get("token");
  const email = token ? await consumeLoginToken(token) : null;

  if (!email) {
    return NextResponse.redirect(new URL("/login?error=invalid", request.url));
  }

  const user = await findOrCreateUser(email);

  const session = await getSession();
  session.userId = user.id;
  await session.save();

  // Always lands on /set-password now, whether this is a brand-new account or someone
  // resetting an existing one - that page itself redirects on to /dashboard or /onboarding
  // once a password is set (src/app/set-password/actions.ts).
  return NextResponse.redirect(new URL("/set-password", request.url));
}
