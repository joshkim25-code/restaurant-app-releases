"use server";

import { redirect } from "next/navigation";
import { createLoginToken } from "@/lib/auth";
import { sendLoginEmail } from "@/lib/mail";
import { db } from "@/lib/db";
import { getSession } from "@/lib/session";
import { setLocalEnvVar } from "@/lib/localEnv";
import crypto from "node:crypto";

const SCRYPT_KEY_LENGTH = 64;

// Duplicated from src/lib/auth.ts's verifyPassword rather than imported, so this file only
// ever touches the local db singleton the normal way - see the same duplication note in
// voice/restore.ts, which needs its own copy for a different reason (a separate process).
// Kept here too because this file already imports crypto for nothing else; simplest to just
// inline it rather than add a second import path for one function.
async function verifyPasswordLocally(password: string, stored: string): Promise<boolean> {
  const [saltHex, hashHex] = stored.split(":");
  if (!saltHex || !hashHex) return false;
  const salt = Buffer.from(saltHex, "hex");
  const expected = Buffer.from(hashHex, "hex");
  const derived = await new Promise<Buffer>((resolve, reject) => {
    crypto.scrypt(password, salt, SCRYPT_KEY_LENGTH, (err, key) => (err ? reject(err) : resolve(key)));
  });
  return expected.length === derived.length && crypto.timingSafeEqual(expected, derived);
}

export async function requestLoginLink(formData: FormData) {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  if (!email || !email.includes("@")) {
    throw new Error("A valid email is required.");
  }

  const token = await createLoginToken(email);

  try {
    await sendLoginEmail(email, token);
  } catch {
    redirect(`/login?error=send-failed&email=${encodeURIComponent(email)}`);
  }

  redirect("/login?sent=1");
}

function omit<T extends Record<string, unknown>>(obj: T, key: string): Record<string, unknown> {
  const copy = { ...obj };
  delete copy[key];
  return copy;
}

// Shape of voice/restore.ts's { found: true, ... } response - Prisma's own model types declare
// DateTime fields as `Date`, but this payload has already crossed a JSON.parse boundary, so
// those arrive as ISO strings instead. Prisma's create/update inputs accept both.
interface RestorePayload {
  found: true;
  restaurant: Record<string, unknown> & { id: string; name: string };
  memberships: Array<{ id: string; role: string; user: Record<string, unknown> & { id: string; email: string } }>;
  tables: Array<Record<string, unknown> & { id: string }>;
  walls: Array<Record<string, unknown> & { id: string }>;
  menuCategories: Array<Record<string, unknown> & { id: string }>;
  printers: Array<Record<string, unknown> & { id: string }>;
  businessHours: Array<Record<string, unknown> & { id: string }>;
  hoursOverrides: Array<Record<string, unknown> & { id: string }>;
  menuItems: Array<Record<string, unknown> & { id: string }>;
  menuItemOptionGroups: Array<Record<string, unknown> & { id: string }>;
  menuItemOptionChoices: Array<Record<string, unknown> & { id: string }>;
  calls: Array<
    Record<string, unknown> & { id: string; messages: Array<Record<string, unknown> & { id: string }> }
  >;
  customers: Array<Record<string, unknown> & { id: string }>;
  reservations: Array<Record<string, unknown> & { id: string }>;
  bills: Array<
    Record<string, unknown> & {
      id: string;
      payment: (Record<string, unknown> & { id: string }) | null;
      orders: Array<
        Record<string, unknown> & {
          id: string;
          items: Array<
            Record<string, unknown> & {
              id: string;
              optionChoices: Array<Record<string, unknown> & { id: string }>;
            }
          >;
        }
      >;
    }
  >;
  subscription: (Record<string, unknown> & { restaurantId: string }) | null;
}

// Matches by email, not by blindly reusing the cloud id - a local User can already exist
// under a different id as an empty shell (no password, no membership) created by using a
// magic login link on this device before ever restoring - loginWithPassword now falls
// through to this function in that case rather than bailing out, so backfill the password
// hash onto that existing row too, or the next plain password login on this device would
// still have nothing to check against.
async function restoreUsersAndMemberships(
  restaurantId: string,
  memberships: RestorePayload["memberships"],
): Promise<void> {
  for (const membership of memberships) {
    const { user } = membership;
    const existing = await db.user.findUnique({ where: { email: user.email as string } });
    if (existing && !existing.passwordHash && user.passwordHash) {
      await db.user.update({ where: { id: existing.id }, data: { passwordHash: user.passwordHash as string } });
    }
    const localUserId = existing
      ? existing.id
      : (await db.user.create({ data: omit(user, "id") as { email: string } })).id;

    await db.membership.upsert({
      where: { userId_restaurantId: { userId: localUserId, restaurantId } },
      create: { id: membership.id, userId: localUserId, restaurantId, role: membership.role as never },
      update: { role: membership.role as never },
    });
  }
}

async function applyRestorePayload(payload: RestorePayload): Promise<void> {
  await db.restaurant.upsert({
    where: { id: payload.restaurant.id },
    create: payload.restaurant as never,
    update: payload.restaurant as never,
  });

  // Confirmed as a real, reproduced bug on a real device: restoring onto a brand-new machine
  // writes agentToken into the LOCAL DATABASE (as part of the restaurant row above) but never
  // into .env, which is the only thing the print agent process actually reads
  // (-r dotenv/config). Every other path that sets this (onboarding/actions.ts's
  // createRestaurant, settings/actions.ts's generateAgentToken) already calls setLocalEnvVar -
  // this was the one path that didn't, leaving the print agent crash-looping on a freshly
  // restored device until someone thought to manually regenerate it from Settings.
  const agentToken = payload.restaurant.agentToken;
  if (typeof agentToken === "string" && agentToken) {
    setLocalEnvVar("AGENT_TOKEN", agentToken);
  }

  await restoreUsersAndMemberships(payload.restaurant.id, payload.memberships);

  for (const row of payload.tables) {
    await db.table.upsert({ where: { id: row.id }, create: row as never, update: row as never });
  }
  for (const row of payload.walls) {
    await db.wall.upsert({ where: { id: row.id }, create: row as never, update: row as never });
  }
  for (const row of payload.menuCategories) {
    await db.menuCategory.upsert({ where: { id: row.id }, create: row as never, update: row as never });
  }
  for (const row of payload.printers) {
    await db.printer.upsert({ where: { id: row.id }, create: row as never, update: row as never });
  }
  for (const row of payload.businessHours) {
    await db.businessHours.upsert({ where: { id: row.id }, create: row as never, update: row as never });
  }
  for (const row of payload.hoursOverrides) {
    await db.hoursOverride.upsert({ where: { id: row.id }, create: row as never, update: row as never });
  }
  for (const row of payload.menuItems) {
    await db.menuItem.upsert({ where: { id: row.id }, create: row as never, update: row as never });
  }
  for (const row of payload.menuItemOptionGroups) {
    await db.menuItemOptionGroup.upsert({ where: { id: row.id }, create: row as never, update: row as never });
  }
  for (const row of payload.menuItemOptionChoices) {
    await db.menuItemOptionChoice.upsert({ where: { id: row.id }, create: row as never, update: row as never });
  }

  for (const { messages, ...call } of payload.calls) {
    await db.call.upsert({ where: { id: call.id }, create: call as never, update: call as never });
    if (messages.length > 0) {
      await db.callMessage.createMany({ data: messages as never, skipDuplicates: true });
    }
  }

  for (const row of payload.customers) {
    await db.customer.upsert({ where: { id: row.id }, create: row as never, update: row as never });
  }
  for (const row of payload.reservations) {
    await db.reservation.upsert({ where: { id: row.id }, create: row as never, update: row as never });
  }

  for (const bill of payload.bills) {
    const { payment, orders, ...billData } = bill;
    await db.bill.upsert({ where: { id: billData.id }, create: billData as never, update: billData as never });

    for (const order of orders) {
      const { items, ...orderData } = order;
      await db.order.upsert({ where: { id: orderData.id }, create: orderData as never, update: orderData as never });

      for (const item of items) {
        const { optionChoices, ...itemData } = item;
        await db.orderItem.upsert({ where: { id: itemData.id }, create: itemData as never, update: itemData as never });

        for (const choice of optionChoices) {
          await db.orderItemOptionChoice.upsert({ where: { id: choice.id }, create: choice as never, update: choice as never });
        }
      }
    }

    if (payment) {
      await db.payment.upsert({ where: { id: payment.id }, create: payment as never, update: payment as never });
    }
  }

  if (payload.subscription) {
    const subscription = payload.subscription;
    await db.subscription.upsert({
      where: { restaurantId: subscription.restaurantId },
      create: subscription as never,
      update: omit(subscription, "id") as never,
    });
  }
}

async function finishLogin(userId: string): Promise<never> {
  const session = await getSession();
  session.userId = userId;
  await session.save();

  const membership = await db.membership.findFirst({ where: { userId } });
  redirect(membership ? "/dashboard" : "/onboarding");
}

export async function loginWithPassword(formData: FormData) {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  if (!email || !password) {
    redirect("/login?error=invalid");
  }

  const localUser = await db.user.findUnique({ where: { email } });

  // A local user row with no password and no membership is an empty shell - most commonly
  // created by using a magic login link on a brand-new device (findOrCreateUser in
  // api/auth/verify/route.ts makes exactly this kind of row). Treat it the same as "not on
  // this machine at all" and fall through to the cloud-restore check below, rather than
  // bailing out to "no-password" and permanently blocking that restore from ever running.
  const isEmptyShell =
    localUser && !localUser.passwordHash && !(await db.membership.findFirst({ where: { userId: localUser.id } }));

  if (localUser && !isEmptyShell) {
    if (!localUser.passwordHash) {
      redirect("/login?error=no-password");
    }
    const valid = await verifyPasswordLocally(password, localUser.passwordHash);
    if (!valid) {
      redirect("/login?error=invalid");
    }
    return finishLogin(localUser.id);
  }

  // Not on this machine at all (or only an empty shell account) - check whether the cloud
  // backup has this restaurant, gated by the same password (voice/restore.ts verifies it
  // server-side; this machine never holds cloud DB credentials itself).
  const voiceBaseUrl = (process.env.VOICE_PUBLIC_URL ?? "").replace(/\/$/, "");
  if (!voiceBaseUrl) {
    redirect("/login?error=invalid");
  }

  let response: Response;
  try {
    response = await fetch(`${voiceBaseUrl}/restore`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
  } catch {
    redirect("/login?error=invalid");
  }

  if (!response.ok) {
    redirect(response.status === 429 ? "/login?error=too-many-attempts" : "/login?error=invalid");
  }

  const result = (await response.json()) as RestorePayload | { found: false; user: Record<string, unknown> & { id: string; email: string } };

  if (!result.found) {
    // Valid credentials, but no restaurant in the cloud backup yet - create the matching local
    // account (reusing the cloud's own passwordHash, not a second separate one) and send them
    // through the normal "no membership yet" path, same as any brand-new account.
    const user = await db.user.upsert({
      where: { email },
      create: omit(result.user, "id") as never,
      update: omit(result.user, "id") as never,
    });
    return finishLogin(user.id);
  }

  await applyRestorePayload(result);
  const restoredUser = await db.user.findUniqueOrThrow({ where: { email } });
  return finishLogin(restoredUser.id);
}
