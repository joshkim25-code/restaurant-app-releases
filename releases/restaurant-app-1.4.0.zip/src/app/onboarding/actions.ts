"use server";

import { redirect } from "next/navigation";
import crypto from "node:crypto";
import { db } from "@/lib/db";
import { requireUserId } from "@/lib/session";
import { setLocalEnvVar } from "@/lib/localEnv";

export async function createRestaurant(formData: FormData) {
  const userId = await requireUserId();

  const existing = await db.membership.findFirst({ where: { userId } });
  if (existing) {
    redirect("/dashboard");
  }

  const name = String(formData.get("name") ?? "").trim();
  const timezone = String(formData.get("timezone") ?? "").trim();
  const currency = String(formData.get("currency") ?? "GBP").trim();

  if (!name || !timezone) {
    throw new Error("A restaurant name and timezone are required.");
  }

  // Generated up front (same crypto.randomBytes(24).toString("hex") shape as the Settings
  // page's own "regenerate" button - src/app/(dashboard)/settings/actions.ts) so a fresh
  // install has a working print agent from the start, instead of the owner needing to find
  // Settings -> Receipts and click "Generate" before anything can print. This closes the loop
  // from a Phase 2 fresh-machine provision (launcher/scripts/provision-machine.ps1, which
  // deliberately leaves AGENT_TOKEN blank in .env, since it lives on a Restaurant row that
  // doesn't exist until this action runs) to an install where the local print agent can
  // actually authenticate - see agent/index.ts and src/app/api/agent/*. setLocalEnvVar below
  // is what actually finishes that loop: the print-agent Windows service has been crash-
  // looping (NSSM's AppExit=Restart) since install waiting for exactly this value.
  const agentToken = crypto.randomBytes(24).toString("hex");

  await db.$transaction(async (tx) => {
    const restaurant = await tx.restaurant.create({ data: { name, timezone, currency, agentToken } });
    await tx.membership.create({ data: { userId, restaurantId: restaurant.id, role: "OWNER" } });
  });

  setLocalEnvVar("AGENT_TOKEN", agentToken);

  redirect("/dashboard?welcome=1");
}
