import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { requireUserId } from "@/lib/session";
import { LogoutButton } from "@/components/LogoutButton";
import { createRestaurant } from "./actions";

export default async function OnboardingPage() {
  const userId = await requireUserId();

  const existing = await db.membership.findFirst({ where: { userId } });
  if (existing) {
    redirect("/dashboard");
  }

  return (
    <div className="mx-auto mt-24 max-w-sm space-y-4 px-4">
      <div>
        <h1 className="text-xl font-semibold">Create your restaurant</h1>
        <p className="text-sm text-neutral-500 dark:text-neutral-400">
          Set up your restaurant to get started. You can configure tables, menu, and printers
          afterward.
        </p>
      </div>

      <form action={createRestaurant} className="rounded-lg border border-neutral-200 bg-white p-6 dark:border-neutral-700 dark:bg-neutral-900">
        <label className="mb-1 block text-xs text-neutral-500 dark:text-neutral-400">Restaurant name</label>
        <input
          name="name"
          required
          placeholder="The Test Kitchen"
          className="mb-3 w-full rounded border border-neutral-300 px-2 py-1.5 text-sm dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
        />
        <label className="mb-1 block text-xs text-neutral-500 dark:text-neutral-400">Timezone</label>
        <input
          name="timezone"
          required
          placeholder="Europe/London"
          className="mb-3 w-full rounded border border-neutral-300 px-2 py-1.5 text-sm dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
        />
        <label className="mb-1 block text-xs text-neutral-500 dark:text-neutral-400">Currency</label>
        <input
          name="currency"
          defaultValue="GBP"
          className="mb-4 w-full rounded border border-neutral-300 px-2 py-1.5 text-sm dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
        />
        <button
          type="submit"
          className="w-full rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700 dark:bg-neutral-100 dark:text-neutral-900 dark:hover:bg-neutral-300"
        >
          Create restaurant
        </button>
      </form>

      <div className="flex items-center gap-2 text-sm text-neutral-500 dark:text-neutral-400">
        <span>Not the right account?</span>
        <LogoutButton />
      </div>
    </div>
  );
}
