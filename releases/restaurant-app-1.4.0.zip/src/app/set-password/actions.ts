"use server";

import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { requireUserId } from "@/lib/session";
import { hashPassword } from "@/lib/auth";

const MIN_LENGTH = 8;

export async function setPassword(formData: FormData) {
  const userId = await requireUserId();

  const password = String(formData.get("password") ?? "");
  const confirm = String(formData.get("confirm") ?? "");

  if (password.length < MIN_LENGTH) {
    redirect("/set-password?error=too-short");
  }
  if (password !== confirm) {
    redirect("/set-password?error=mismatch");
  }

  const passwordHash = await hashPassword(password);
  await db.user.update({ where: { id: userId }, data: { passwordHash } });

  const membership = await db.membership.findFirst({ where: { userId } });
  redirect(membership ? "/dashboard" : "/onboarding");
}
