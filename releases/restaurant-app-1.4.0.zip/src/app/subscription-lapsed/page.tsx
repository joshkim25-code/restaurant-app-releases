import { startSubscriptionCheckout } from "@/app/(dashboard)/settings/actions";

export default function SubscriptionLapsedPage() {
  return (
    <div className="mx-auto mt-24 max-w-sm space-y-4 px-4">
      <div>
        <h1 className="text-xl font-semibold">Subscription paused</h1>
        <p className="text-sm text-neutral-500 dark:text-neutral-400">
          This restaurant&rsquo;s subscription has lapsed, so access is paused. Nothing has
          been deleted — resubscribe to pick up right where you left off.
        </p>
      </div>

      <form action={startSubscriptionCheckout} className="rounded-lg border border-neutral-200 bg-white p-6 dark:border-neutral-700 dark:bg-neutral-900">
        <button
          type="submit"
          className="w-full rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700 dark:bg-neutral-100 dark:text-neutral-900 dark:hover:bg-neutral-300"
        >
          Resubscribe
        </button>
      </form>
    </div>
  );
}
