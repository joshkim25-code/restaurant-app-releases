import { togglePhoneCalls } from "@/app/(dashboard)/settings/actions";

export function PhoneCallsToggle({ accepting }: { accepting: boolean }) {
  return (
    <form action={togglePhoneCalls}>
      <button
        type="submit"
        title={accepting ? "Click to stop the AI answering calls" : "Click to let the AI answer calls again"}
        className={`rounded-full border px-3 py-1 text-sm font-medium ${
          accepting
            ? "border-green-300 bg-green-50 text-green-800 hover:bg-green-100 dark:border-green-700 dark:bg-green-950 dark:text-green-300 dark:hover:bg-green-900"
            : "border-red-300 bg-red-50 text-red-800 hover:bg-red-100 dark:border-red-700 dark:bg-red-950 dark:text-red-300 dark:hover:bg-red-900"
        }`}
      >
        AI calls: {accepting ? "ON" : "OFF"}
      </button>
    </form>
  );
}
