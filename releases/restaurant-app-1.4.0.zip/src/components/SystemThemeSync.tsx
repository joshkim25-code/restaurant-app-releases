"use client";

import { useEffect } from "react";
import type { ThemePreference } from "@/lib/theme";

// The root <html> element resists soft-navigation class updates in the App Router - a
// server action that changes the theme cookie and calls revalidatePath("/", "layout")
// does cause this component to re-render with a new `pref`, but React does not reliably
// re-apply the server-computed <html class> after the initial hydration, so relying on
// the server-rendered className alone leaves a stale "dark" class stuck on screen until a
// hard reload (confirmed by testing: switching System -> Light while the page was showing
// dark did not visually update without a reload). Applying the class imperatively here on
// every `pref` change - not just for "system" - is what next-themes itself does under the
// hood, and is the one reliable way to guarantee the DOM actually reflects the current
// preference regardless of how Next.js reconciles the root layout on a soft transition.
export function SystemThemeSync({ pref }: { pref: ThemePreference }) {
  useEffect(() => {
    if (pref === "light") {
      document.documentElement.classList.remove("dark");
      return;
    }
    if (pref === "dark") {
      document.documentElement.classList.add("dark");
      return;
    }

    const mql = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () => document.documentElement.classList.toggle("dark", mql.matches);
    apply();
    mql.addEventListener("change", apply);
    return () => mql.removeEventListener("change", apply);
  }, [pref]);

  return null;
}
