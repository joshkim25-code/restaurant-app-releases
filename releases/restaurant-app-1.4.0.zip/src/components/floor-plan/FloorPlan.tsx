"use client";

import { useState, type CSSProperties, type PointerEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import type { TableShape, Wall } from "@/generated/prisma/client";
import type { TableWithStatus, TableDisplayStatus } from "@/lib/tables";
import type { TableLayoutUpdate } from "@/lib/floorPlanActions";
import type { WallLayoutUpdate } from "@/lib/wallActions";
import {
  FLOOR_PLAN_WIDTH,
  FLOOR_PLAN_HEIGHT,
  MIN_TABLE_SIZE,
  MAX_TABLE_SIZE,
  WALL_STROKE_WIDTH,
} from "@/lib/floorPlanConstants";
import { formatClockTime } from "@/lib/time";

interface Props {
  role: "owner" | "waiter";
  tables: TableWithStatus[];
  walls: Wall[];
  timezone: string;
  updateTableLayout: (id: string, updates: TableLayoutUpdate) => Promise<void>;
  createTable?: (formData: FormData) => Promise<void>;
  deleteTable?: (formData: FormData) => Promise<void>;
  updateWallLayout: (id: string, updates: WallLayoutUpdate) => Promise<void>;
  createWall?: (formData: FormData) => Promise<void>;
  deleteWall?: (formData: FormData) => Promise<void>;
}

type DragState =
  | {
      target: "table";
      kind: "move" | "resize";
      id: string;
      shape: TableShape;
      startClientX: number;
      startClientY: number;
      startPosX: number;
      startPosY: number;
      startWidth: number;
      startHeight: number;
      posX: number;
      posY: number;
      width: number;
      height: number;
    }
  | {
      target: "wall";
      endpoint: "start" | "end";
      id: string;
      startClientX: number;
      startClientY: number;
      startX: number;
      startY: number;
      x: number;
      y: number;
    };

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}


function statusClasses(status: TableDisplayStatus) {
  switch (status) {
    case "ACTIVE":
      return "bg-green-100 border-green-600 text-green-800 dark:bg-green-900 dark:text-green-300";
    case "RESERVED":
      return "bg-amber-100 border-amber-500 text-amber-800 dark:bg-amber-900 dark:text-amber-300";
    case "INACTIVE":
      return "bg-neutral-200 border-neutral-300 text-neutral-500 dark:bg-neutral-700 dark:border-neutral-600 dark:text-neutral-400";
    default:
      return "bg-white border-neutral-300 text-neutral-700 dark:bg-neutral-900 dark:border-neutral-600 dark:text-neutral-300";
  }
}

export function FloorPlan({
  role,
  tables,
  walls,
  timezone,
  updateTableLayout,
  createTable,
  deleteTable,
  updateWallLayout,
  createWall,
  deleteWall,
}: Props) {
  const router = useRouter();
  const [editMode, setEditMode] = useState(false);
  const [drag, setDrag] = useState<DragState | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  function startTableDrag(kind: "move" | "resize", table: TableWithStatus, e: PointerEvent) {
    setDrag({
      target: "table",
      id: table.id,
      kind,
      shape: table.shape,
      startClientX: e.clientX,
      startClientY: e.clientY,
      startPosX: table.posX,
      startPosY: table.posY,
      startWidth: table.width,
      startHeight: table.height,
      posX: table.posX,
      posY: table.posY,
      width: table.width,
      height: table.height,
    });
  }

  function startWallDrag(endpoint: "start" | "end", wall: Wall, e: PointerEvent) {
    const x = endpoint === "start" ? wall.x1 : wall.x2;
    const y = endpoint === "start" ? wall.y1 : wall.y2;
    setDrag({
      target: "wall",
      endpoint,
      id: wall.id,
      startClientX: e.clientX,
      startClientY: e.clientY,
      startX: x,
      startY: y,
      x,
      y,
    });
  }

  function handleBodyPointerDown(e: PointerEvent<HTMLDivElement>, table: TableWithStatus) {
    if (!editMode) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    startTableDrag("move", table, e);
  }

  function handleHandlePointerDown(e: PointerEvent<HTMLDivElement>, table: TableWithStatus) {
    if (!editMode) return;
    e.stopPropagation();
    e.currentTarget.setPointerCapture(e.pointerId);
    startTableDrag("resize", table, e);
  }

  function handleWallHandlePointerDown(
    e: PointerEvent<HTMLDivElement>,
    endpoint: "start" | "end",
    wall: Wall,
  ) {
    if (!editMode) return;
    e.stopPropagation();
    e.currentTarget.setPointerCapture(e.pointerId);
    startWallDrag(endpoint, wall, e);
  }

  function handlePointerMove(e: PointerEvent) {
    setDrag((prev) => {
      if (!prev) return prev;
      const dx = e.clientX - prev.startClientX;
      const dy = e.clientY - prev.startClientY;

      if (prev.target === "wall") {
        return {
          ...prev,
          x: clamp(prev.startX + dx, 0, FLOOR_PLAN_WIDTH),
          y: clamp(prev.startY + dy, 0, FLOOR_PLAN_HEIGHT),
        };
      }

      if (prev.kind === "move") {
        return {
          ...prev,
          posX: clamp(prev.startPosX + dx, 0, FLOOR_PLAN_WIDTH - prev.width),
          posY: clamp(prev.startPosY + dy, 0, FLOOR_PLAN_HEIGHT - prev.height),
        };
      }

      if (prev.shape === "CIRCLE") {
        const maxSize = Math.min(
          MAX_TABLE_SIZE,
          FLOOR_PLAN_WIDTH - prev.posX,
          FLOOR_PLAN_HEIGHT - prev.posY,
        );
        const size = clamp(prev.startWidth + Math.max(dx, dy), MIN_TABLE_SIZE, maxSize);
        return { ...prev, width: size, height: size };
      }

      const maxWidth = Math.min(MAX_TABLE_SIZE, FLOOR_PLAN_WIDTH - prev.posX);
      const maxHeight = Math.min(MAX_TABLE_SIZE, FLOOR_PLAN_HEIGHT - prev.posY);
      return {
        ...prev,
        width: clamp(prev.startWidth + dx, MIN_TABLE_SIZE, maxWidth),
        height: clamp(prev.startHeight + dy, MIN_TABLE_SIZE, maxHeight),
      };
    });
  }

  async function handlePointerUp() {
    if (!drag) return;
    try {
      if (drag.target === "wall") {
        const { id, endpoint, x, y } = drag;
        await updateWallLayout(id, endpoint === "start" ? { x1: x, y1: y } : { x2: x, y2: y });
      } else {
        const { id, posX, posY, width, height } = drag;
        await updateTableLayout(id, { posX, posY, width, height });
      }
      router.refresh();
    } finally {
      setDrag(null);
    }
  }

  function handlePointerCancel() {
    setDrag(null);
  }

  async function handleToggleShape(table: TableWithStatus) {
    const nextShape: TableShape = table.shape === "CIRCLE" ? "RECTANGLE" : "CIRCLE";
    await updateTableLayout(table.id, { shape: nextShape });
    router.refresh();
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={() => setEditMode((prev) => !prev)}
          className={`rounded px-3 py-1.5 text-sm font-medium ${
            editMode
              ? "bg-neutral-900 text-white hover:bg-neutral-700 dark:bg-neutral-100 dark:text-neutral-900 dark:hover:bg-neutral-300"
              : "border border-neutral-300 text-neutral-700 hover:bg-neutral-100 dark:border-neutral-600 dark:text-neutral-300 dark:hover:bg-neutral-800"
          }`}
        >
          {editMode ? "Done editing" : "Edit layout"}
        </button>
        {role === "owner" && editMode && createTable && (
          <button
            type="button"
            onClick={() => setShowAddForm((prev) => !prev)}
            className="rounded border border-neutral-300 px-3 py-1.5 text-sm text-neutral-700 hover:bg-neutral-100 dark:border-neutral-600 dark:text-neutral-300 dark:hover:bg-neutral-800"
          >
            {showAddForm ? "Cancel" : "Add table"}
          </button>
        )}
        {role === "owner" && editMode && createWall && (
          <form action={createWall}>
            <button
              type="submit"
              className="rounded border border-neutral-300 px-3 py-1.5 text-sm text-neutral-700 hover:bg-neutral-100 dark:border-neutral-600 dark:text-neutral-300 dark:hover:bg-neutral-800"
            >
              Add wall
            </button>
          </form>
        )}
      </div>

      {role === "owner" && editMode && showAddForm && createTable && (
        <form
          action={async (formData) => {
            await createTable(formData);
            setShowAddForm(false);
          }}
          className="flex flex-wrap items-end gap-3 rounded-lg border border-neutral-200 bg-white p-3 dark:border-neutral-700 dark:bg-neutral-900"
        >
          <div className="flex flex-col gap-1">
            <label className="text-xs text-neutral-500 dark:text-neutral-400">Label</label>
            <input
              name="label"
              required
              placeholder="T8"
              className="w-24 rounded border border-neutral-300 px-2 py-1 dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs text-neutral-500 dark:text-neutral-400">Seats</label>
            <input
              name="seats"
              type="number"
              min={1}
              required
              className="w-20 rounded border border-neutral-300 px-2 py-1 dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs text-neutral-500 dark:text-neutral-400">Shape</label>
            <select
              name="shape"
              defaultValue="RECTANGLE"
              className="rounded border border-neutral-300 px-2 py-1 dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-100"
            >
              <option value="RECTANGLE">Rectangle</option>
              <option value="CIRCLE">Circle</option>
            </select>
          </div>
          <button
            type="submit"
            className="rounded bg-neutral-900 px-4 py-1.5 text-sm text-white hover:bg-neutral-700 dark:bg-neutral-100 dark:text-neutral-900 dark:hover:bg-neutral-300"
          >
            Add
          </button>
        </form>
      )}

      <div className="overflow-auto rounded-lg border border-neutral-200 bg-neutral-50 dark:border-neutral-700 dark:bg-neutral-950">
        <div
          className="relative"
          style={{ width: FLOOR_PLAN_WIDTH, height: FLOOR_PLAN_HEIGHT }}
        >
          <svg
            width={FLOOR_PLAN_WIDTH}
            height={FLOOR_PLAN_HEIGHT}
            viewBox={`0 0 ${FLOOR_PLAN_WIDTH} ${FLOOR_PLAN_HEIGHT}`}
            className="pointer-events-none absolute left-0 top-0"
          >
            {walls.map((wall) => {
              const w =
                drag && drag.target === "wall" && drag.id === wall.id
                  ? {
                      ...wall,
                      ...(drag.endpoint === "start"
                        ? { x1: drag.x, y1: drag.y }
                        : { x2: drag.x, y2: drag.y }),
                    }
                  : wall;
              return (
                <line
                  key={wall.id}
                  x1={w.x1}
                  y1={w.y1}
                  x2={w.x2}
                  y2={w.y2}
                  strokeWidth={WALL_STROKE_WIDTH}
                  strokeLinecap="round"
                  className="stroke-neutral-700 dark:stroke-neutral-400"
                />
              );
            })}
          </svg>

          {tables.map((table) => {
            const t = drag && drag.target === "table" && drag.id === table.id ? drag : table;
            const shapeClasses = statusClasses(table.status);
            const borderRadius = t.shape === "CIRCLE" ? "9999px" : "0.5rem";
            const isDragging = drag?.target === "table" && drag.id === table.id;

            const content = (
              <div className="flex h-full w-full flex-col items-center justify-center text-center text-xs font-medium leading-tight">
                <span>{table.label}</span>
                <span className="text-[10px] font-normal opacity-75">{table.seats} seats</span>
                {table.status === "RESERVED" && table.nextReservation && (
                  <span className="text-[10px] font-normal">
                    {formatClockTime(table.nextReservation.startTime, timezone)} ·{" "}
                    {table.nextReservation.partySize}p
                  </span>
                )}
              </div>
            );

            const baseStyle: CSSProperties = {
              position: "absolute",
              left: t.posX,
              top: t.posY,
              width: t.width,
              height: t.height,
              borderRadius,
            };

            if (!editMode) {
              const canNavigate = role === "waiter" && table.status !== "INACTIVE";
              if (canNavigate) {
                return (
                  <Link
                    key={table.id}
                    href={`/waiter/${table.id}`}
                    style={baseStyle}
                    className={`border-2 ${shapeClasses} hover:opacity-80`}
                  >
                    {content}
                  </Link>
                );
              }
              return (
                <div key={table.id} style={baseStyle} className={`border-2 ${shapeClasses}`}>
                  {content}
                </div>
              );
            }

            return (
              <div
                key={table.id}
                onPointerDown={(e) => handleBodyPointerDown(e, table)}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerCancel={handlePointerCancel}
                style={{ ...baseStyle, zIndex: isDragging ? 10 : 1, cursor: "grab" }}
                className={`touch-none border-2 ${shapeClasses}`}
              >
                {content}

                <div className="absolute -right-2 -top-2 flex gap-1">
                  <button
                    type="button"
                    onPointerDown={(e) => e.stopPropagation()}
                    onClick={() => handleToggleShape(table)}
                    title="Toggle shape"
                    className="flex h-5 w-5 items-center justify-center rounded-full border border-neutral-300 bg-white text-[10px] text-neutral-600 hover:bg-neutral-100 dark:border-neutral-600 dark:bg-neutral-900 dark:text-neutral-400 dark:hover:bg-neutral-800"
                  >
                    {table.shape === "CIRCLE" ? "▭" : "●"}
                  </button>
                  {role === "owner" && deleteTable && (
                    <form action={deleteTable}>
                      <input type="hidden" name="id" value={table.id} />
                      <button
                        type="submit"
                        onPointerDown={(e) => e.stopPropagation()}
                        title="Delete table"
                        className="flex h-5 w-5 items-center justify-center rounded-full border border-red-300 bg-white text-[10px] text-red-600 hover:bg-red-50 dark:border-red-700 dark:bg-neutral-900 dark:text-red-400 dark:hover:bg-red-950"
                      >
                        ×
                      </button>
                    </form>
                  )}
                </div>

                <div
                  onPointerDown={(e) => handleHandlePointerDown(e, table)}
                  className="absolute -bottom-2 -right-2 h-6 w-6 touch-none rounded-full border border-neutral-400 bg-white dark:bg-neutral-900"
                  style={{ cursor: "nwse-resize" }}
                />
              </div>
            );
          })}

          {role === "owner" &&
            editMode &&
            walls.map((wall) => {
              const w =
                drag && drag.target === "wall" && drag.id === wall.id
                  ? {
                      ...wall,
                      ...(drag.endpoint === "start"
                        ? { x1: drag.x, y1: drag.y }
                        : { x2: drag.x, y2: drag.y }),
                    }
                  : wall;
              const midX = (w.x1 + w.x2) / 2;
              const midY = (w.y1 + w.y2) / 2;

              return (
                <div key={wall.id}>
                  <div
                    onPointerDown={(e) => handleWallHandlePointerDown(e, "start", wall)}
                    onPointerMove={handlePointerMove}
                    onPointerUp={handlePointerUp}
                    onPointerCancel={handlePointerCancel}
                    className="absolute h-4 w-4 -translate-x-1/2 -translate-y-1/2 touch-none rounded-full border border-neutral-400 bg-white dark:bg-neutral-900"
                    style={{ left: w.x1, top: w.y1, zIndex: 5, cursor: "move" }}
                  />
                  <div
                    onPointerDown={(e) => handleWallHandlePointerDown(e, "end", wall)}
                    onPointerMove={handlePointerMove}
                    onPointerUp={handlePointerUp}
                    onPointerCancel={handlePointerCancel}
                    className="absolute h-4 w-4 -translate-x-1/2 -translate-y-1/2 touch-none rounded-full border border-neutral-400 bg-white dark:bg-neutral-900"
                    style={{ left: w.x2, top: w.y2, zIndex: 5, cursor: "move" }}
                  />
                  {deleteWall && (
                    <form
                      action={deleteWall}
                      style={{ position: "absolute", left: midX, top: midY, zIndex: 5 }}
                      className="-translate-x-1/2 -translate-y-1/2"
                    >
                      <input type="hidden" name="id" value={wall.id} />
                      <button
                        type="submit"
                        title="Delete wall"
                        className="flex h-5 w-5 items-center justify-center rounded-full border border-red-300 bg-white text-[10px] text-red-600 hover:bg-red-50 dark:border-red-700 dark:bg-neutral-900 dark:text-red-400 dark:hover:bg-red-950"
                      >
                        ×
                      </button>
                    </form>
                  )}
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
}
