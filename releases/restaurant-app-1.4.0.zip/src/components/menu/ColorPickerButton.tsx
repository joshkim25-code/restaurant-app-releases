"use client";

import { useState } from "react";
import { MENU_CATEGORY_COLORS } from "@/lib/menuCategoryColors";
import type { MenuCategoryColor } from "@/generated/prisma/client";

type ServerAction = (formData: FormData) => void | Promise<void>;

export function ColorPickerButton({
  currentColor,
  action,
  hiddenFields,
  title = "Colour",
}: {
  currentColor: MenuCategoryColor;
  action: ServerAction;
  // Extra fields each swatch's own form must submit alongside `color` - e.g. the row's id, or
  // (for option choices, whose update action also re-saves name/price from the same form) a
  // snapshot of the row's other current values, so a colour-only click doesn't wipe them.
  hiddenFields: Record<string, string>;
  title?: string;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const current = MENU_CATEGORY_COLORS[currentColor];

  return (
    // Stops a click from reaching a native <summary> ancestor (the category call site renders
    // inside CollapsibleCard's summary, where any click would otherwise toggle it open/closed).
    <div onClick={(e) => e.stopPropagation()}>
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        title={title}
        aria-label={title}
        className={`h-5 w-5 rounded-none border-2 border-neutral-300 dark:border-neutral-600 ${current.swatchBg}`}
      />
      {isOpen && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 p-4"
          onClick={() => setIsOpen(false)}
        >
          <div
            className="w-full max-w-xs rounded-lg bg-white p-4 shadow-lg dark:bg-neutral-900"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-sm font-medium">{title}</h3>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="text-sm text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-neutral-100"
              >
                Close
              </button>
            </div>
            <div className="grid grid-cols-5 gap-2">
              {Object.entries(MENU_CATEGORY_COLORS).map(([key, c]) => (
                <form key={key} action={action} onSubmit={() => setIsOpen(false)}>
                  {Object.entries(hiddenFields).map(([name, value]) => (
                    <input key={name} type="hidden" name={name} value={value} />
                  ))}
                  <input type="hidden" name="color" value={key} />
                  <button
                    type="submit"
                    title={c.label}
                    aria-label={`Set ${c.label} colour`}
                    aria-pressed={currentColor === key}
                    className={`h-8 w-8 rounded-none border-2 ${c.swatchBg} ${
                      currentColor === key
                        ? "border-neutral-900 dark:border-neutral-100"
                        : "border-transparent hover:border-neutral-300 dark:hover:border-neutral-600"
                    }`}
                  />
                </form>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
