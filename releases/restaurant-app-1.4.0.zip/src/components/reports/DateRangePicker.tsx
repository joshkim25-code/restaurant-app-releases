"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { DayPicker, type DateRange } from "react-day-picker";

function toISODate(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function parseISODate(value: string): Date {
  const [y, m, d] = value.split("-").map(Number);
  return new Date(y, m - 1, d);
}

function formatRangeLabel(from: string, to: string): string {
  const fmt = new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric" });
  if (from === to) return fmt.format(parseISODate(from));
  return `${fmt.format(parseISODate(from))} – ${fmt.format(parseISODate(to))}`;
}

export function DateRangePicker({
  basePath,
  from,
  to,
  active,
  extraParams = {},
}: {
  basePath: string;
  from?: string;
  to?: string;
  active: boolean;
  extraParams?: Record<string, string | undefined>;
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const selected: DateRange | undefined =
    from && to ? { from: parseISODate(from), to: parseISODate(to) } : undefined;

  const [pendingRange, setPendingRange] = useState<DateRange | undefined>(selected);

  useEffect(() => {
    if (!open) return;
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [open]);

  function handleTriggerClick() {
    setPendingRange(selected);
    setOpen((v) => !v);
  }

  function handleConfirm() {
    if (!pendingRange?.from || !pendingRange?.to) return;
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(extraParams)) {
      if (value) params.set(key, value);
    }
    params.set("range", "custom");
    params.set("from", toISODate(pendingRange.from));
    params.set("to", toISODate(pendingRange.to));
    router.push(`${basePath}?${params.toString()}`);
    setOpen(false);
  }

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={handleTriggerClick}
        className={`rounded-full px-3 py-1 text-sm ${
          active
            ? "bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900"
            : "border border-neutral-300 text-neutral-600 hover:bg-neutral-100 dark:border-neutral-600 dark:text-neutral-400 dark:hover:bg-neutral-800"
        }`}
      >
        {active && from && to ? formatRangeLabel(from, to) : "Custom range"}
      </button>
      {open && (
        <div className="absolute z-10 mt-2 w-[320px] rounded-lg border border-neutral-200 bg-white p-4 shadow-lg dark:border-neutral-700 dark:bg-neutral-900">
          <DayPicker
            mode="range"
            navLayout="around"
            selected={pendingRange}
            onSelect={setPendingRange}
            defaultMonth={pendingRange?.from ?? selected?.from}
            classNames={{
              months: "flex flex-col",
              month: "flex flex-wrap items-center gap-y-2",
              button_previous:
                "order-1 flex h-8 w-8 items-center justify-center rounded hover:bg-neutral-100 dark:hover:bg-neutral-800",
              month_caption: "order-2 flex-1 text-center text-sm font-medium",
              button_next:
                "order-3 flex h-8 w-8 items-center justify-center rounded hover:bg-neutral-100 dark:hover:bg-neutral-800",
              month_grid: "order-4 w-full table-fixed border-collapse mt-2",
              weekday: "pb-2 text-xs font-medium text-neutral-400 dark:text-neutral-500",
              day: "p-0 text-center align-middle",
              day_button:
                "mx-auto flex h-9 w-9 appearance-none items-center justify-center rounded-full bg-transparent text-sm text-inherit hover:bg-neutral-900/10 dark:hover:bg-neutral-100/10 transition-colors",
              range_start: "rounded-l-full bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900",
              range_end: "rounded-r-full bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900",
              range_middle: "bg-neutral-100 dark:bg-neutral-800",
              selected: "rounded-full bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900",
              today: "font-semibold",
              outside: "text-neutral-300 dark:text-neutral-600",
            }}
          />
          <div className="mt-3 flex items-center justify-between gap-2 border-t border-neutral-200 pt-3 text-xs dark:border-neutral-700">
            <span className="text-neutral-500 dark:text-neutral-400">
              {pendingRange?.from && pendingRange?.to
                ? formatRangeLabel(toISODate(pendingRange.from), toISODate(pendingRange.to))
                : pendingRange?.from
                  ? "Pick an end date"
                  : "Pick a start date"}
            </span>
            <button
              type="button"
              onClick={handleConfirm}
              disabled={!pendingRange?.from || !pendingRange?.to}
              className="rounded-full bg-neutral-900 px-3 py-1 text-white disabled:cursor-not-allowed disabled:bg-neutral-300 dark:bg-neutral-100 dark:text-neutral-900"
            >
              Confirm
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
