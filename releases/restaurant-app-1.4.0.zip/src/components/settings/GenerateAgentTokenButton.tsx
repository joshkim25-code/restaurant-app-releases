"use client";

import { useState } from "react";

export function GenerateAgentTokenButton({
  generateAgentToken,
}: {
  generateAgentToken: () => Promise<string>;
}) {
  const [token, setToken] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);

  async function generate() {
    setGenerating(true);
    try {
      setToken(await generateAgentToken());
    } finally {
      setGenerating(false);
    }
  }

  return (
    <div className="flex flex-col gap-2">
      <button
        type="button"
        onClick={generate}
        disabled={generating}
        className="w-fit rounded border border-neutral-300 px-4 py-1.5 text-sm text-neutral-700 hover:bg-neutral-100 disabled:opacity-50 dark:border-neutral-600 dark:text-neutral-300 dark:hover:bg-neutral-800"
      >
        {generating ? "Generating…" : token ? "Regenerate token" : "Generate agent token"}
      </button>
      {token && (
        <div className="rounded border border-amber-300 bg-amber-50 p-3 text-sm dark:border-amber-700 dark:bg-amber-950">
          <p className="mb-1 text-xs text-amber-800 dark:text-amber-300">
            The print agent has been reconnected with this token automatically — no setup
            needed. Shown here only for reference; it won&rsquo;t be shown again.
          </p>
          <code className="block break-all rounded bg-white px-2 py-1 text-xs dark:bg-neutral-900">{token}</code>
        </div>
      )}
    </div>
  );
}
