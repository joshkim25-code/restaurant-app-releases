import crypto from "node:crypto";
import { db } from "@/lib/db";

const TOKEN_TTL_MS = 15 * 60 * 1000;
const SCRYPT_KEY_LENGTH = 64;

// Node's built-in scrypt, not a new dependency - stored as "<saltHex>:<hashHex>". Used both
// locally (src/app/login/actions.ts) and on the cloud-hosted voice service (voice/restore.ts,
// which can't import this file directly since it's a separate process - see the same logic
// duplicated there with a comment pointing back here).
export async function hashPassword(password: string): Promise<string> {
  const salt = crypto.randomBytes(16);
  const derived = await new Promise<Buffer>((resolve, reject) => {
    crypto.scrypt(password, salt, SCRYPT_KEY_LENGTH, (err, key) => (err ? reject(err) : resolve(key)));
  });
  return `${salt.toString("hex")}:${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [saltHex, hashHex] = stored.split(":");
  if (!saltHex || !hashHex) return false;

  const salt = Buffer.from(saltHex, "hex");
  const expected = Buffer.from(hashHex, "hex");
  const derived = await new Promise<Buffer>((resolve, reject) => {
    crypto.scrypt(password, salt, SCRYPT_KEY_LENGTH, (err, key) => (err ? reject(err) : resolve(key)));
  });

  return expected.length === derived.length && crypto.timingSafeEqual(expected, derived);
}

function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export async function createLoginToken(email: string): Promise<string> {
  const token = crypto.randomBytes(32).toString("hex");
  await db.loginToken.create({
    data: {
      email: email.toLowerCase().trim(),
      tokenHash: hashToken(token),
      expiresAt: new Date(Date.now() + TOKEN_TTL_MS),
    },
  });
  return token;
}

export async function consumeLoginToken(rawToken: string): Promise<string | null> {
  const record = await db.loginToken.findUnique({ where: { tokenHash: hashToken(rawToken) } });
  if (!record || record.usedAt || record.expiresAt < new Date()) {
    return null;
  }
  await db.loginToken.update({ where: { id: record.id }, data: { usedAt: new Date() } });
  return record.email;
}

export async function findOrCreateUser(email: string) {
  return db.user.upsert({ where: { email }, update: {}, create: { email } });
}
