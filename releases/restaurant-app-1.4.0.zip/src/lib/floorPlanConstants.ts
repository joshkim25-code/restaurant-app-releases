export const FLOOR_PLAN_WIDTH = 1000;
export const FLOOR_PLAN_HEIGHT = 700;
export const MIN_TABLE_SIZE = 40;
export const MAX_TABLE_SIZE = 400;
export const WALL_STROKE_WIDTH = 6;
export const DEFAULT_WALL_LENGTH = 150;
export const DEFAULT_WALL_MARGIN = 40;
