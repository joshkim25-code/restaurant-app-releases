import fs from "node:fs";
import path from "node:path";

// Only meaningful for a real, launcher-provisioned local install (see
// launcher/scripts/provision-machine.ps1's New-FreshEnvFile) - the app always runs with its
// install directory as CWD (NSSM sets AppDirectory to it, `next dev`/`next start` in the repo
// during development also run from the repo root where .env already lives), so this is the same
// place Next.js itself already loads .env from.
const ENV_PATH = path.join(process.cwd(), ".env");

// Patches a single KEY=value line into the local .env file in place, preserving every other
// line - used to close the loop on values that don't exist yet when provision-machine.ps1
// generates the initial .env (e.g. AGENT_TOKEN, which lives on a Restaurant row that isn't
// created until onboarding runs, long after the installer has already written .env once).
// No-ops if the value is already set to exactly this, so repeat calls (e.g. Settings ->
// Receipts' "regenerate" button firing this again later) don't rewrite the file needlessly.
export function setLocalEnvVar(key: string, value: string): void {
  if (!fs.existsSync(ENV_PATH)) return;

  const content = fs.readFileSync(ENV_PATH, "utf8");
  const line = `${key}="${value}"`;
  const pattern = new RegExp(`^${key}=.*$`, "m");

  if (pattern.test(content)) {
    if (content.match(pattern)?.[0] === line) return;
    fs.writeFileSync(ENV_PATH, content.replace(pattern, line), "utf8");
  } else {
    const withNewline = content.endsWith("\n") ? content : `${content}\n`;
    fs.writeFileSync(ENV_PATH, `${withNewline}${line}\n`, "utf8");
  }

  // Takes effect on this process's own next restart (dotenv only loads once, at startup) -
  // callers that need another service to pick this up (the print agent, via its own
  // AppExit=Restart crash-loop) rely on that service's next restart attempt re-reading .env
  // fresh, not on this process somehow live-reloading it.
  process.env[key] = value;
}
