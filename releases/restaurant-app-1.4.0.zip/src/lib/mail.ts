// Proxied through the cloud-hosted voice service (voice/mail.ts) - the local app never holds
// RESEND_API_KEY itself, same reasoning as Stripe billing and cloud restore already use
// (settings/actions.ts's startSubscriptionCheckout, login/actions.ts's cloud restore call).
// This is also what makes a fresh install on a new restaurant's machine able to send real login
// emails immediately, with no Resend account of their own to set up.
export async function sendLoginEmail(email: string, token: string): Promise<void> {
  const url = `${process.env.PUBLIC_BASE_URL}/api/auth/verify?token=${encodeURIComponent(token)}`;
  const voiceBaseUrl = (process.env.VOICE_PUBLIC_URL ?? "").replace(/\/$/, "");

  if (!voiceBaseUrl) {
    throw new Error("VOICE_PUBLIC_URL isn't configured - can't reach the email service.");
  }

  const response = await fetch(`${voiceBaseUrl}/send-login-email`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, url }),
  });

  if (!response.ok) {
    const body = await response.text().catch(() => "");
    throw new Error(`Could not send login email (${response.status}): ${body}`);
  }
}
