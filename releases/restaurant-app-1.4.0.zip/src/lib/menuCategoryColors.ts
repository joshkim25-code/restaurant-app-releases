import type { MenuCategoryColor } from "@/generated/prisma/client";

// Single source of truth for what each preset category colour actually looks like - both the
// waiter order grid and the owner's colour-picker swatches reference this, never hardcode
// their own Tailwind classes. Record<MenuCategoryColor, ...> means adding a new enum value
// without a mapping here fails to compile, not silently falls through at runtime.
export const MENU_CATEGORY_COLORS: Record<
  MenuCategoryColor,
  {
    label: string;
    boxBg: string;
    boxBorder: string;
    boxText: string;
    boxHoverBg: string;
    swatchBg: string;
  }
> = {
  // Solid, saturated fills (not pale washes) so categories/choices stay distinguishable
  // at a glance during busy service. AMBER/YELLOW/LIME stay at -400 with dark text -
  // white text fails contrast on those hues even at -500, and darkening further makes
  // them read as muddy orange/olive rather than bright yellow/lime/amber.
  NEUTRAL: {
    label: "Neutral",
    boxBg: "bg-neutral-500",
    boxBorder: "border-neutral-600",
    boxText: "text-white",
    boxHoverBg: "hover:bg-neutral-600",
    swatchBg: "bg-neutral-500",
  },
  RED: {
    label: "Red",
    boxBg: "bg-red-500",
    boxBorder: "border-red-600",
    boxText: "text-white",
    boxHoverBg: "hover:bg-red-600",
    swatchBg: "bg-red-500",
  },
  ORANGE: {
    label: "Orange",
    boxBg: "bg-orange-500",
    boxBorder: "border-orange-600",
    boxText: "text-white",
    boxHoverBg: "hover:bg-orange-600",
    swatchBg: "bg-orange-500",
  },
  AMBER: {
    label: "Amber",
    boxBg: "bg-amber-400",
    boxBorder: "border-amber-500",
    boxText: "text-amber-950",
    boxHoverBg: "hover:bg-amber-500",
    swatchBg: "bg-amber-400",
  },
  YELLOW: {
    label: "Yellow",
    boxBg: "bg-yellow-400",
    boxBorder: "border-yellow-500",
    boxText: "text-yellow-950",
    boxHoverBg: "hover:bg-yellow-500",
    swatchBg: "bg-yellow-400",
  },
  LIME: {
    label: "Lime",
    boxBg: "bg-lime-400",
    boxBorder: "border-lime-500",
    boxText: "text-lime-950",
    boxHoverBg: "hover:bg-lime-500",
    swatchBg: "bg-lime-400",
  },
  GREEN: {
    label: "Green",
    boxBg: "bg-green-500",
    boxBorder: "border-green-600",
    boxText: "text-white",
    boxHoverBg: "hover:bg-green-600",
    swatchBg: "bg-green-500",
  },
  TEAL: {
    label: "Teal",
    boxBg: "bg-teal-500",
    boxBorder: "border-teal-600",
    boxText: "text-white",
    boxHoverBg: "hover:bg-teal-600",
    swatchBg: "bg-teal-500",
  },
  CYAN: {
    label: "Cyan",
    boxBg: "bg-cyan-500",
    boxBorder: "border-cyan-600",
    boxText: "text-white",
    boxHoverBg: "hover:bg-cyan-600",
    swatchBg: "bg-cyan-500",
  },
  BLUE: {
    label: "Blue",
    boxBg: "bg-blue-500",
    boxBorder: "border-blue-600",
    boxText: "text-white",
    boxHoverBg: "hover:bg-blue-600",
    swatchBg: "bg-blue-500",
  },
  INDIGO: {
    label: "Indigo",
    boxBg: "bg-indigo-500",
    boxBorder: "border-indigo-600",
    boxText: "text-white",
    boxHoverBg: "hover:bg-indigo-600",
    swatchBg: "bg-indigo-500",
  },
  PURPLE: {
    label: "Purple",
    boxBg: "bg-purple-500",
    boxBorder: "border-purple-600",
    boxText: "text-white",
    boxHoverBg: "hover:bg-purple-600",
    swatchBg: "bg-purple-500",
  },
  PINK: {
    label: "Pink",
    boxBg: "bg-pink-500",
    boxBorder: "border-pink-600",
    boxText: "text-white",
    boxHoverBg: "hover:bg-pink-600",
    swatchBg: "bg-pink-500",
  },
  ROSE: {
    label: "Rose",
    boxBg: "bg-rose-500",
    boxBorder: "border-rose-600",
    boxText: "text-white",
    boxHoverBg: "hover:bg-rose-600",
    swatchBg: "bg-rose-500",
  },
  BROWN: {
    label: "Brown",
    boxBg: "bg-stone-500",
    boxBorder: "border-stone-600",
    boxText: "text-white",
    boxHoverBg: "hover:bg-stone-600",
    swatchBg: "bg-stone-500",
  },
};
