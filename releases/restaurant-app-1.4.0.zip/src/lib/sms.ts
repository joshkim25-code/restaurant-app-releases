import { formatDateTime } from "@/lib/time";

// Proxied through the cloud-hosted voice service (voice/phoneNumbers.ts) - the local app never
// holds TWILIO_ACCOUNT_SID/TWILIO_AUTH_TOKEN itself. This isn't optional the way Resend's
// proxying is a nice-to-have: `params.from` is a number purchased under the platform's own
// master Twilio account (see voice/phoneNumbers.ts's provisioning endpoint), so only that
// account's credentials can ever send from it - a restaurant owner's own Twilio credentials,
// even if they had any, couldn't.
export async function sendReservationConfirmationSms(params: {
  to: string;
  from: string;
  customerName: string;
  partySize: number;
  startTime: Date;
  timezone: string;
  restaurantName: string;
}): Promise<void> {
  const body = `Hi ${params.customerName}, your table for ${params.partySize} at ${params.restaurantName} on ${formatDateTime(params.startTime, params.timezone)} is confirmed. See you then!`;
  const voiceBaseUrl = (process.env.VOICE_PUBLIC_URL ?? "").replace(/\/$/, "");

  if (!voiceBaseUrl) {
    throw new Error("VOICE_PUBLIC_URL isn't configured - can't reach the SMS service.");
  }

  const response = await fetch(`${voiceBaseUrl}/send-sms`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ to: params.to, from: params.from, body }),
  });

  if (!response.ok) {
    const responseBody = await response.text().catch(() => "");
    throw new Error(`Could not send confirmation SMS (${response.status}): ${responseBody}`);
  }
}
