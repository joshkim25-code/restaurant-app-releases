import { cookies } from "next/headers";

export type ThemePreference = "light" | "dark" | "system";

const COOKIE_NAME = "theme";

export async function getThemePreference(): Promise<ThemePreference> {
  const value = (await cookies()).get(COOKIE_NAME)?.value;
  return value === "light" || value === "dark" ? value : "system";
}

export async function setThemePreference(pref: ThemePreference) {
  (await cookies()).set(COOKIE_NAME, pref, {
    path: "/",
    maxAge: 60 * 60 * 24 * 365,
    sameSite: "lax",
  });
}
