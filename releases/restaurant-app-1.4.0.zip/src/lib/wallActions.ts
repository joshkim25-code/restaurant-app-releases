"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { getCurrentRestaurant } from "@/lib/restaurant";
import {
  FLOOR_PLAN_WIDTH,
  FLOOR_PLAN_HEIGHT,
  DEFAULT_WALL_LENGTH,
  DEFAULT_WALL_MARGIN,
} from "@/lib/floorPlanConstants";

export interface WallLayoutUpdate {
  x1?: number;
  y1?: number;
  x2?: number;
  y2?: number;
}

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function revalidateWallViews() {
  revalidatePath("/dashboard");
  revalidatePath("/waiter");
}

export async function updateWallLayout(id: string, updates: WallLayoutUpdate) {
  const restaurant = await getCurrentRestaurant();
  const wall = await db.wall.findUnique({ where: { id, restaurantId: restaurant.id } });
  if (!wall) {
    throw new Error("Wall not found.");
  }

  const x1 = clamp(Math.round(updates.x1 ?? wall.x1), 0, FLOOR_PLAN_WIDTH);
  const y1 = clamp(Math.round(updates.y1 ?? wall.y1), 0, FLOOR_PLAN_HEIGHT);
  const x2 = clamp(Math.round(updates.x2 ?? wall.x2), 0, FLOOR_PLAN_WIDTH);
  const y2 = clamp(Math.round(updates.y2 ?? wall.y2), 0, FLOOR_PLAN_HEIGHT);

  await db.wall.update({ where: { id }, data: { x1, y1, x2, y2 } });
  revalidateWallViews();
}

export async function createWall() {
  const restaurant = await getCurrentRestaurant();

  await db.wall.create({
    data: {
      restaurantId: restaurant.id,
      x1: DEFAULT_WALL_MARGIN,
      y1: DEFAULT_WALL_MARGIN,
      x2: DEFAULT_WALL_MARGIN + DEFAULT_WALL_LENGTH,
      y2: DEFAULT_WALL_MARGIN,
    },
  });

  revalidateWallViews();
}

export async function deleteWall(formData: FormData) {
  const id = String(formData.get("id"));
  const restaurant = await getCurrentRestaurant();
  await db.wall.delete({ where: { id, restaurantId: restaurant.id } });
  revalidateWallViews();
}
