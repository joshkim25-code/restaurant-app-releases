import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { getIronSession, nextProxyCookies } from "iron-session";
import { sessionOptions, type SessionData } from "@/lib/session-options";
import { db } from "@/lib/db";

// /api/agent/ isn't a browser route — the local print agent authenticates with its own
// per-restaurant bearer token (checked in each agent route handler), not the session cookie.
// /settings/payments and /subscription-lapsed stay reachable even for a lapsed restaurant, so
// it can see why and resubscribe.
const PUBLIC_PREFIXES = ["/login", "/api/auth/", "/api/agent/"];
const BILLING_EXEMPT_PREFIXES = ["/settings/payments", "/subscription-lapsed"];

// Runs on the Node.js runtime by default in this Next.js version (confirmed against
// node_modules/next/dist/docs/01-app/03-api-reference/03-file-conventions/proxy.md), so a
// direct Prisma call here is safe.
//
// Reads the LOCAL Subscription row only - kept fresh by sync/pull.ts's pullSubscription every
// 30s - never a live call to the cloud voice service, so a cloud/network hiccup never locks a
// restaurant out of its own local app.
async function isSubscriptionLapsed(userId: string): Promise<boolean> {
  const membership = await db.membership.findFirst({
    where: { userId },
    orderBy: { createdAt: "asc" },
    select: { restaurant: { select: { subscription: true } } },
  });

  const subscription = membership?.restaurant.subscription;
  // No row at all = never started checkout yet - don't block a brand new restaurant.
  if (!subscription) return false;

  if (subscription.status === "CANCELED") return true;
  if (subscription.status === "PAST_DUE" && subscription.graceEndsAt) {
    return subscription.graceEndsAt < new Date();
  }
  return false;
}

export async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (PUBLIC_PREFIXES.some((p) => pathname === p || pathname.startsWith(p))) {
    return NextResponse.next();
  }

  const response = NextResponse.next();
  const session = await getIronSession<SessionData>(nextProxyCookies(request, response), sessionOptions);

  if (!session.userId) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  if (
    !BILLING_EXEMPT_PREFIXES.some((p) => pathname === p || pathname.startsWith(p)) &&
    (await isSubscriptionLapsed(session.userId))
  ) {
    return NextResponse.redirect(new URL("/subscription-lapsed", request.url));
  }

  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
