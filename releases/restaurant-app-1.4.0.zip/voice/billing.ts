// Per-restaurant subscription billing, backed by Stripe. Kept in its own file - dispatched
// from voice/index.ts's existing raw http.createServer routing - so the phone-call handling
// and billing code stay visibly separate even though they currently share one deployment
// (reusing the already-running, cloud-hosted voice service rather than standing up a new
// one - see the plan this came from).
//
// Cloud-only by design: the local app never holds STRIPE_SECRET_KEY. It only ever calls
// POST /billing/checkout (to start a subscription) and, later, GET /billing/status (not yet
// wired up anywhere - enforcement is a deliberate follow-up, not part of this slice).
//
// Subscription rows live in Subscription (prisma/schema.prisma), never Restaurant - see that
// model's own comment for why (sync/categoryB.ts's full-row overwrite of Restaurant would
// silently wipe billing fields if they lived there instead).
import http from "node:http";
import Stripe from "stripe";
import { db } from "./db";
import type { SubscriptionStatus } from "../src/generated/prisma/client";

const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY;
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET;
const STRIPE_PRICE_ID = process.env.STRIPE_PRICE_ID;

const stripe = STRIPE_SECRET_KEY ? new Stripe(STRIPE_SECRET_KEY) : null;

function requireStripe(): Stripe {
  if (!stripe) throw new Error("STRIPE_SECRET_KEY is not set.");
  return stripe;
}

async function readRawBody(req: http.IncomingMessage): Promise<Buffer> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) chunks.push(chunk as Buffer);
  return Buffer.concat(chunks);
}

function mapStripeStatus(status: Stripe.Subscription.Status): SubscriptionStatus {
  switch (status) {
    case "trialing":
      return "TRIALING";
    case "active":
      return "ACTIVE";
    case "canceled":
    case "incomplete_expired":
      return "CANCELED";
    // incomplete (checkout started but never finished paying), past_due, unpaid, paused -
    // none of these mean "this restaurant currently has working access", so all land on
    // PAST_DUE rather than silently defaulting to ACTIVE.
    default:
      return "PAST_DUE";
  }
}

// POST /billing/checkout - { restaurantId, successUrl, cancelUrl } -> { url }
// The caller (the local app's own Settings -> Billing page) supplies successUrl/cancelUrl
// since it's the one that knows where the browser should land back - almost always its own
// localhost:3000, but this endpoint has no reason to assume that itself.
async function handleCreateCheckout(req: http.IncomingMessage, res: http.ServerResponse) {
  const body = JSON.parse((await readRawBody(req)).toString("utf8"));
  const restaurantId = String(body.restaurantId ?? "");
  const successUrl = String(body.successUrl ?? "");
  const cancelUrl = String(body.cancelUrl ?? "");

  if (!restaurantId || !successUrl || !cancelUrl) {
    res.writeHead(400, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "restaurantId, successUrl, and cancelUrl are required." }));
    return;
  }
  if (!STRIPE_PRICE_ID) {
    res.writeHead(500, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "STRIPE_PRICE_ID is not configured." }));
    return;
  }

  const restaurant = await db.restaurant.findUnique({ where: { id: restaurantId } });
  if (!restaurant) {
    res.writeHead(404, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "Restaurant not found." }));
    return;
  }

  const existing = await db.subscription.findUnique({ where: { restaurantId } });

  // Reuse the same Stripe Customer across repeated checkout attempts (e.g. someone who
  // abandons checkout once and comes back) instead of creating a new one every time.
  let stripeCustomerId = existing?.stripeCustomerId ?? null;
  if (!stripeCustomerId) {
    const customer = await requireStripe().customers.create({
      name: restaurant.name,
      metadata: { restaurantId },
    });
    stripeCustomerId = customer.id;
  }

  const session = await requireStripe().checkout.sessions.create({
    mode: "subscription",
    customer: stripeCustomerId,
    line_items: [{ price: STRIPE_PRICE_ID, quantity: 1 }],
    // The one flag that puts Stripe's own promotion-code entry field on the hosted checkout
    // page - no custom discount-code UI needed for this to work.
    allow_promotion_codes: true,
    success_url: successUrl,
    cancel_url: cancelUrl,
    metadata: { restaurantId },
    subscription_data: { metadata: { restaurantId } },
  });

  if (!session.url) {
    res.writeHead(500, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "Stripe did not return a checkout URL." }));
    return;
  }

  res.writeHead(200, { "Content-Type": "application/json" }).end(JSON.stringify({ url: session.url }));
}

// Written once, at checkout.session.completed only (never on later customer.subscription.updated
// replays, which would otherwise create a duplicate row every time the subscription object is
// touched for an unrelated reason) - see PaymentHistory/DiscountGrant's own schema comment for
// why these live in their own cloud-only tables rather than on Subscription/Restaurant.
async function recordDiscountGrant(subscription: Stripe.Subscription) {
  const restaurantId = subscription.metadata?.restaurantId;
  if (!restaurantId) return;

  for (const discount of subscription.discounts) {
    // Only ever a string if the checkout.session.completed handler's own expand (below)
    // didn't include it - skip rather than guess at a coupon/code this call didn't fetch.
    if (typeof discount === "string") continue;

    const promotionCode = typeof discount.promotion_code === "object" ? discount.promotion_code : null;
    const coupon = typeof discount.source.coupon === "object" ? discount.source.coupon : null;

    await db.discountGrant.create({
      data: {
        restaurantId,
        stripePromotionCodeId: promotionCode?.id ?? null,
        code: promotionCode?.code ?? null,
        percentOff: coupon?.percent_off ?? null,
        amountOffCents: coupon?.amount_off ?? null,
      },
    });
  }
}

// Upserted (not just created) since Stripe can redeliver the same webhook event more than
// once - stripeInvoiceId's unique constraint plus this upsert keeps redelivery idempotent
// instead of creating duplicate history rows.
async function recordPaymentHistory(invoice: Stripe.Invoice, restaurantId: string, status: "succeeded" | "failed") {
  const amountCents = status === "succeeded" ? invoice.amount_paid : invoice.amount_due;
  await db.paymentHistory.upsert({
    where: { stripeInvoiceId: invoice.id },
    create: {
      restaurantId,
      stripeInvoiceId: invoice.id,
      amountCents,
      currency: invoice.currency,
      status,
      occurredAt: new Date(invoice.created * 1000),
    },
    update: { status, amountCents },
  });
}

const PAST_DUE_GRACE_MS = 7 * 24 * 60 * 60 * 1000;

// Creates or updates the Subscription row for whichever restaurant a Stripe subscription
// object's metadata (set at creation - see subscription_data.metadata above) points at.
async function upsertFromStripeSubscription(subscription: Stripe.Subscription) {
  const restaurantId = subscription.metadata?.restaurantId;
  if (!restaurantId) {
    console.error(`Stripe subscription ${subscription.id} has no restaurantId in metadata - can't reconcile it.`);
    return;
  }

  const currentPeriodEnd = subscription.items.data[0]?.current_period_end;
  const status = mapStripeStatus(subscription.status);

  const existing = await db.subscription.findUnique({ where: { restaurantId } });

  // Grace period only applies to a failed payment (PAST_DUE), not an explicit CANCELED.
  // Set it once on the transition into PAST_DUE - repeat webhook redelivery of the same
  // event must not keep pushing the deadline out - and clear it on any other status.
  let graceEndsAt: Date | null;
  if (status === "PAST_DUE") {
    graceEndsAt =
      existing?.status === "PAST_DUE" && existing.graceEndsAt
        ? existing.graceEndsAt
        : new Date(Date.now() + PAST_DUE_GRACE_MS);
  } else {
    graceEndsAt = null;
  }

  await db.subscription.upsert({
    where: { restaurantId },
    create: {
      restaurantId,
      stripeCustomerId: typeof subscription.customer === "string" ? subscription.customer : subscription.customer.id,
      stripeSubscriptionId: subscription.id,
      status,
      currentPeriodEnd: currentPeriodEnd ? new Date(currentPeriodEnd * 1000) : null,
      graceEndsAt,
    },
    update: {
      stripeSubscriptionId: subscription.id,
      status,
      currentPeriodEnd: currentPeriodEnd ? new Date(currentPeriodEnd * 1000) : null,
      graceEndsAt,
    },
  });
}

// POST /billing/webhook - Stripe's own signed event delivery. Needs the exact raw request
// body (not JSON-parsed first) for signature verification, which is why this reads the body
// itself rather than sharing readRawBody's JSON.parse'd cousin used above.
async function handleWebhook(req: http.IncomingMessage, res: http.ServerResponse) {
  if (!STRIPE_WEBHOOK_SECRET) {
    res.writeHead(500).end("STRIPE_WEBHOOK_SECRET is not configured.");
    return;
  }

  const rawBody = await readRawBody(req);
  const signature = req.headers["stripe-signature"];
  if (typeof signature !== "string") {
    res.writeHead(400).end("Missing Stripe-Signature header.");
    return;
  }

  let event: Stripe.Event;
  try {
    event = requireStripe().webhooks.constructEvent(rawBody, signature, STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.warn("Rejected webhook with invalid signature:", err instanceof Error ? err.message : err);
    res.writeHead(400).end("Invalid signature.");
    return;
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        if (typeof session.subscription === "string") {
          const subscription = await requireStripe().subscriptions.retrieve(session.subscription, {
            expand: ["discounts", "discounts.promotion_code", "discounts.source.coupon"],
          });
          await upsertFromStripeSubscription(subscription);
          await recordDiscountGrant(subscription);
        }
        break;
      }
      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        await upsertFromStripeSubscription(event.data.object as Stripe.Subscription);
        break;
      }
      case "invoice.payment_succeeded":
      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        const subscriptionId = invoice.parent?.subscription_details?.subscription;
        if (typeof subscriptionId === "string") {
          const subscription = await requireStripe().subscriptions.retrieve(subscriptionId);
          await upsertFromStripeSubscription(subscription);
          const restaurantId = subscription.metadata?.restaurantId;
          if (restaurantId) {
            await recordPaymentHistory(invoice, restaurantId, event.type === "invoice.payment_succeeded" ? "succeeded" : "failed");
          }
        }
        break;
      }
      default:
        break;
    }
  } catch (err) {
    // Full detail stays server-side (Railway logs) - confirmed working end-to-end with a
    // real test checkout, so no reason for this internet-reachable endpoint to keep echoing
    // internal error details back in the response body (briefly did, on purpose, only to
    // debug initial setup).
    console.error(`Error handling webhook event ${event.type}:`, err);
    res.writeHead(500).end("Internal error.");
    return;
  }

  res.writeHead(200).end("ok");
}

// GET /billing/status?restaurantId=... -> { active, status, graceEndsAt }
// Not called by anything yet - enforcement (the launcher or the app checking this before
// letting a lapsed restaurant keep working) is a deliberate follow-up, not part of this
// slice. Exists now so that follow-up doesn't also need a server-side change.
async function handleStatus(req: http.IncomingMessage, res: http.ServerResponse, url: URL) {
  const restaurantId = url.searchParams.get("restaurantId");
  if (!restaurantId) {
    res.writeHead(400, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "restaurantId is required." }));
    return;
  }

  const subscription = await db.subscription.findUnique({ where: { restaurantId } });
  const active = subscription?.status === "ACTIVE" || subscription?.status === "TRIALING";

  res.writeHead(200, { "Content-Type": "application/json" }).end(
    JSON.stringify({
      active,
      status: subscription?.status ?? "CANCELED",
      graceEndsAt: subscription?.graceEndsAt ?? null,
    }),
  );
}

// Dispatched from voice/index.ts's existing routing - returns true if this function handled
// the request, so the caller knows not to fall through to its own 404.
export async function tryHandleBillingRequest(req: http.IncomingMessage, res: http.ServerResponse): Promise<boolean> {
  const url = new URL(req.url ?? "/", "http://localhost");

  if (req.method === "POST" && url.pathname === "/billing/checkout") {
    await handleCreateCheckout(req, res);
    return true;
  }
  if (req.method === "POST" && url.pathname === "/billing/webhook") {
    await handleWebhook(req, res);
    return true;
  }
  if (req.method === "GET" && url.pathname === "/billing/status") {
    await handleStatus(req, res, url);
    return true;
  }
  return false;
}
