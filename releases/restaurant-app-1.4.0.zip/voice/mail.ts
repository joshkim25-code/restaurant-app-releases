// Sends login-link emails on behalf of every local install - the local app never holds
// RESEND_API_KEY itself (same reasoning as billing.ts's Stripe key and restore.ts's cloud DB
// access: the local machine calls this already-cloud-hosted service instead of holding a raw
// shared credential capable of sending mail/spending money on the platform owner's account).
//
// The login link itself (email + full verify URL) is built entirely by the caller
// (src/lib/mail.ts) - this endpoint only ever embeds a URL it's handed into an email body, it
// never needs to know anything about a specific local install's own PUBLIC_BASE_URL.
import http from "node:http";
import { Resend } from "resend";

const RESEND_API_KEY = process.env.RESEND_API_KEY;
const resend = RESEND_API_KEY ? new Resend(RESEND_API_KEY) : null;

// Same in-memory, per-process rate limiting as restore.ts - resets on redeploy, an accepted
// trade-off at this scale. This endpoint has no password to check (unlike /restore), so it's
// rate-limited purely by target email: without this, anyone could hit it repeatedly to spam an
// arbitrary inbox through the platform's Resend account/quota.
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000;
const sendAttempts = new Map<string, { count: number; lockedUntil: number }>();

function isLockedOut(email: string): boolean {
  const entry = sendAttempts.get(email);
  return !!entry && entry.lockedUntil > Date.now();
}

function recordSend(email: string): void {
  const entry = sendAttempts.get(email) ?? { count: 0, lockedUntil: 0 };
  entry.count += 1;
  if (entry.count >= MAX_ATTEMPTS) {
    entry.lockedUntil = Date.now() + LOCKOUT_MS;
    entry.count = 0;
  }
  sendAttempts.set(email, entry);
}

async function readBody(req: http.IncomingMessage): Promise<string> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) chunks.push(chunk as Buffer);
  return Buffer.concat(chunks).toString("utf8");
}

async function handleSendLoginEmail(req: http.IncomingMessage, res: http.ServerResponse) {
  const body = JSON.parse((await readBody(req)) || "{}");
  const email = String(body.email ?? "").trim().toLowerCase();
  const url = String(body.url ?? "");

  if (!email || !url) {
    res.writeHead(400, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "email and url are required." }));
    return;
  }

  if (isLockedOut(email)) {
    res.writeHead(429, { "Content-Type": "application/json" }).end(
      JSON.stringify({ error: "Too many login emails sent to this address recently. Try again later." }),
    );
    return;
  }
  recordSend(email);

  // Mirrors src/lib/mail.ts's original local dev-fallback: no key configured (e.g. running
  // this service locally for development) just logs instead of failing every login attempt.
  if (!resend) {
    console.log(`[dev] Login link for ${email}: ${url}`);
    res.writeHead(200, { "Content-Type": "application/json" }).end(JSON.stringify({ ok: true }));
    return;
  }

  const { error } = await resend.emails.send({
    from: "onboarding@resend.dev",
    to: email,
    subject: "Your login link",
    html: `<p><a href="${url}">Click to log in</a>. Expires in 15 minutes.</p>`,
  });

  // resend.emails.send() never throws for API errors — it returns { error } instead —
  // so this check is required, not optional, or a failed send looks identical to success.
  if (error) {
    res.writeHead(502, { "Content-Type": "application/json" }).end(JSON.stringify({ error: `Could not send login email: ${error.message}` }));
    return;
  }

  res.writeHead(200, { "Content-Type": "application/json" }).end(JSON.stringify({ ok: true }));
}

export async function tryHandleMailRequest(req: http.IncomingMessage, res: http.ServerResponse): Promise<boolean> {
  const url = new URL(req.url ?? "/", "http://localhost");

  if (req.method === "POST" && url.pathname === "/send-login-email") {
    await handleSendLoginEmail(req, res);
    return true;
  }
  return false;
}
