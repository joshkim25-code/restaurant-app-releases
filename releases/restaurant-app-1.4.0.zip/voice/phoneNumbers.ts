// Twilio phone number provisioning + SMS sending, both cloud-only for the same reason as
// billing.ts's Stripe key and mail.ts's Resend key: there is exactly one master Twilio account
// (TWILIO_ACCOUNT_SID/TWILIO_AUTH_TOKEN, already a single global env var - see .env.example),
// shared across every restaurant's calls, numbers, and SMS. A restaurant owner's own Twilio
// credentials (even if they had any) couldn't send from a number purchased under this account,
// so both operations have to happen here, never locally.
import http from "node:http";
import twilio from "twilio";
import { db } from "./db";

const TWILIO_ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID;
const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN;
const VOICE_PUBLIC_URL = (process.env.VOICE_PUBLIC_URL ?? "").replace(/\/$/, "");

const client = TWILIO_ACCOUNT_SID && TWILIO_AUTH_TOKEN ? twilio(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN) : null;

function requireClient(): twilio.Twilio {
  if (!client) throw new Error("TWILIO_ACCOUNT_SID/TWILIO_AUTH_TOKEN are not set.");
  return client;
}

async function readBody(req: http.IncomingMessage): Promise<string> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) chunks.push(chunk as Buffer);
  return Buffer.concat(chunks).toString("utf8");
}

// POST /provision-phone-number - { restaurantId } -> { phoneNumber }
// Idempotent: a restaurant that already has a number gets the same one back rather than ever
// buying a second one. Purchases under the platform's own master Twilio account (there's no
// self-service "bring your own Twilio account" flow anywhere in this codebase - see the plan
// this came from), so the local app never needs its own Twilio credentials to make this work.
//
// The only Twilio-side configuration a number needs for calls to reach this service correctly
// is its Voice webhook - confirmed by reading voice/index.ts's entire inbound-call handling
// flow: no TwiML App/Bin, no Messaging Service, nothing else is involved anywhere.
//
// Deliberately does NOT write the purchased number to this service's own (cloud) database - the
// local app owns that write, straight to its own local database (the primary source of truth in
// this app's local-primary/cloud-sync architecture), and the existing scheduled sync process
// carries it up to the cloud copy on its own next run. Writing it here too would just create a
// second, momentarily-inconsistent copy to reconcile for no benefit.
async function handleProvisionPhoneNumber(req: http.IncomingMessage, res: http.ServerResponse) {
  const body = JSON.parse((await readBody(req)) || "{}");
  const restaurantId = String(body.restaurantId ?? "");

  if (!restaurantId) {
    res.writeHead(400, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "restaurantId is required." }));
    return;
  }
  if (!VOICE_PUBLIC_URL) {
    res.writeHead(500, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "VOICE_PUBLIC_URL is not configured." }));
    return;
  }

  const restaurant = await db.restaurant.findUnique({ where: { id: restaurantId } });
  if (!restaurant) {
    res.writeHead(404, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "Restaurant not found." }));
    return;
  }
  if (restaurant.twilioPhoneNumber) {
    res.writeHead(200, { "Content-Type": "application/json" }).end(JSON.stringify({ phoneNumber: restaurant.twilioPhoneNumber }));
    return;
  }

  const available = await requireClient().availablePhoneNumbers("US").local.list({ limit: 1 });
  const candidate = available[0];
  if (!candidate) {
    res.writeHead(502, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "No phone numbers currently available to purchase." }));
    return;
  }

  const purchased = await requireClient().incomingPhoneNumbers.create({
    phoneNumber: candidate.phoneNumber,
    voiceUrl: `${VOICE_PUBLIC_URL}/voice/incoming`,
    voiceMethod: "POST",
  });

  res.writeHead(200, { "Content-Type": "application/json" }).end(JSON.stringify({ phoneNumber: purchased.phoneNumber }));
}

// POST /send-sms - { to, from, body } -> { ok: true }
// A thin relay, not a template - the caller (src/lib/sms.ts) builds the actual message text
// itself, since that's reservation-specific business logic that belongs in the main app, not
// duplicated here.
async function handleSendSms(req: http.IncomingMessage, res: http.ServerResponse) {
  const parsed = JSON.parse((await readBody(req)) || "{}");
  const to = String(parsed.to ?? "");
  const from = String(parsed.from ?? "");
  const smsBody = String(parsed.body ?? "");

  if (!to || !from || !smsBody) {
    res.writeHead(400, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "to, from, and body are required." }));
    return;
  }

  await requireClient().messages.create({ to, from, body: smsBody });
  res.writeHead(200, { "Content-Type": "application/json" }).end(JSON.stringify({ ok: true }));
}

export async function tryHandlePhoneNumberRequest(req: http.IncomingMessage, res: http.ServerResponse): Promise<boolean> {
  const url = new URL(req.url ?? "/", "http://localhost");

  if (req.method === "POST" && url.pathname === "/provision-phone-number") {
    await handleProvisionPhoneNumber(req, res);
    return true;
  }
  if (req.method === "POST" && url.pathname === "/send-sms") {
    await handleSendSms(req, res);
    return true;
  }
  return false;
}
