// Serves the data behind "log in on a new device and get restored automatically"
// (src/app/login/actions.ts) - the new machine never holds cloud DB credentials itself, it
// just calls this already-cloud-hosted service (same reasoning as billing.ts) with the owner's
// email+password and gets back a JSON snapshot to write into its own local database.
//
// Gated by a real password check, not a bare email - a bare email would let anyone who
// knows/guesses a restaurant's owner email pull down that restaurant's private customer/
// reservation data with no verification at all.
import http from "node:http";
import crypto from "node:crypto";
import { db } from "./db";

const SCRYPT_KEY_LENGTH = 64;

// Duplicated from src/lib/auth.ts rather than imported - this process runs standalone via
// `tsx voice/index.ts`, not through Next's bundler, so the `@/` path alias src/lib/auth.ts
// relies on isn't reliably available here (every other voice/ file that reaches into src/ uses
// a relative path instead, and this one additionally needs its own db.ts, not src/lib/db.ts's
// singleton). Keep both in sync if the hashing scheme ever changes.
async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [saltHex, hashHex] = stored.split(":");
  if (!saltHex || !hashHex) return false;

  const salt = Buffer.from(saltHex, "hex");
  const expected = Buffer.from(hashHex, "hex");
  const derived = await new Promise<Buffer>((resolve, reject) => {
    crypto.scrypt(password, salt, SCRYPT_KEY_LENGTH, (err, key) => (err ? reject(err) : resolve(key)));
  });

  return expected.length === derived.length && crypto.timingSafeEqual(expected, derived);
}

// In-memory, per-process - resets on redeploy, which is an accepted trade-off at this scale
// (a handful of restaurants), not a distributed rate limiter. Still meaningfully raises the
// cost of brute-forcing a specific email's password against this internet-reachable endpoint.
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000;
const failedAttempts = new Map<string, { count: number; lockedUntil: number }>();

function isLockedOut(email: string): boolean {
  const entry = failedAttempts.get(email);
  return !!entry && entry.lockedUntil > Date.now();
}

function recordFailure(email: string): void {
  const entry = failedAttempts.get(email) ?? { count: 0, lockedUntil: 0 };
  entry.count += 1;
  if (entry.count >= MAX_ATTEMPTS) {
    entry.lockedUntil = Date.now() + LOCKOUT_MS;
    entry.count = 0;
  }
  failedAttempts.set(email, entry);
}

function clearFailures(email: string): void {
  failedAttempts.delete(email);
}

async function readBody(req: http.IncomingMessage): Promise<string> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) chunks.push(chunk as Buffer);
  return Buffer.concat(chunks).toString("utf8");
}

function unauthorized(res: http.ServerResponse): void {
  // Deliberately generic - never distinguish "wrong password" from "no such account", that
  // would leak whether an email has an account here at all.
  res.writeHead(401, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "Invalid email or password." }));
}

async function handleRestore(req: http.IncomingMessage, res: http.ServerResponse) {
  const body = JSON.parse((await readBody(req)) || "{}");
  const email = String(body.email ?? "").trim().toLowerCase();
  const password = String(body.password ?? "");
  if (!email || !password) {
    res.writeHead(400, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "email and password are required." }));
    return;
  }

  if (isLockedOut(email)) {
    res.writeHead(429, { "Content-Type": "application/json" }).end(
      JSON.stringify({ error: "Too many failed attempts. Try again later." }),
    );
    return;
  }

  const user = await db.user.findUnique({ where: { email } });
  if (!user || !user.passwordHash || !(await verifyPassword(password, user.passwordHash))) {
    recordFailure(email);
    unauthorized(res);
    return;
  }
  clearFailures(email);

  const membership = await db.membership.findFirst({
    where: { userId: user.id },
    orderBy: { createdAt: "asc" },
  });
  if (!membership) {
    // Real account, real password, just no restaurant in the cloud backup yet - not a bad
    // credential, so not the generic 401. The local app treats this as "nothing to restore,
    // proceed as a normal (if very first) login" - passwordHash included so the local User it
    // creates matches this one instead of needing a second, separate password.
    res.writeHead(200, { "Content-Type": "application/json" }).end(
      JSON.stringify({ found: false, user: { id: user.id, email: user.email, name: user.name, passwordHash: user.passwordHash } }),
    );
    return;
  }

  const restaurant = await db.restaurant.findUniqueOrThrow({ where: { id: membership.restaurantId } });
  const memberships = await db.membership.findMany({
    where: { restaurantId: restaurant.id },
    include: { user: true },
  });
  const tables = await db.table.findMany({ where: { restaurantId: restaurant.id } });
  const walls = await db.wall.findMany({ where: { restaurantId: restaurant.id } });
  const menuCategories = await db.menuCategory.findMany({ where: { restaurantId: restaurant.id } });
  const printers = await db.printer.findMany({ where: { restaurantId: restaurant.id } });
  const businessHours = await db.businessHours.findMany({ where: { restaurantId: restaurant.id } });
  const hoursOverrides = await db.hoursOverride.findMany({ where: { restaurantId: restaurant.id } });
  const menuItems = await db.menuItem.findMany({ where: { restaurantId: restaurant.id } });
  const menuItemOptionGroups = await db.menuItemOptionGroup.findMany({ where: { restaurantId: restaurant.id } });
  const menuItemOptionChoices = await db.menuItemOptionChoice.findMany({ where: { restaurantId: restaurant.id } });
  const calls = await db.call.findMany({ where: { restaurantId: restaurant.id }, include: { messages: true } });
  const customers = await db.customer.findMany({ where: { restaurantId: restaurant.id } });
  const reservations = await db.reservation.findMany({ where: { restaurantId: restaurant.id } });
  const bills = await db.bill.findMany({
    where: { restaurantId: restaurant.id },
    include: { payment: true, orders: { include: { items: { include: { optionChoices: true } } } } },
  });
  const subscription = await db.subscription.findUnique({ where: { restaurantId: restaurant.id } });

  res.writeHead(200, { "Content-Type": "application/json" }).end(
    JSON.stringify({
      found: true,
      restaurant,
      memberships,
      tables,
      walls,
      menuCategories,
      printers,
      businessHours,
      hoursOverrides,
      menuItems,
      menuItemOptionGroups,
      menuItemOptionChoices,
      calls,
      customers,
      reservations,
      bills,
      subscription,
    }),
  );
}

export async function tryHandleRestoreRequest(req: http.IncomingMessage, res: http.ServerResponse): Promise<boolean> {
  const url = new URL(req.url ?? "/", "http://localhost");

  if (req.method === "POST" && url.pathname === "/restore") {
    await handleRestore(req, res);
    return true;
  }
  return false;
}
